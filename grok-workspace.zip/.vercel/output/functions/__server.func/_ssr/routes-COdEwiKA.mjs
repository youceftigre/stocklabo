import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { S as ArrowLeftRight, _ as Download, a as Trash2, b as ClipboardPen, c as Plus, d as LogOut, f as LoaderCircle, g as FileSpreadsheet, h as History, i as TriangleAlert, l as Pencil, m as ImagePlus, n as Warehouse, o as Settings2, p as LayoutDashboard, r as Upload, s as Search, t as X, u as Package, v as Cloud, x as Camera, y as CloudOff } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as getApps, i as getApp, o as initializeApp } from "../_libs/@firebase/app+[...].mjs";
import "../_libs/firebase.mjs";
import { a as getFirestore, i as getDocs, n as doc, o as onSnapshot, r as getDoc, s as writeBatch, t as collection } from "../_libs/@firebase/firestore+[...].mjs";
import { i as uploadString, n as getStorage, r as ref, t as getDownloadURL } from "../_libs/firebase__storage+undici.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-COdEwiKA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
async function sha256Hex(text) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
	return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function checkAuth() {
	return sessionStorage.getItem("warehouse_admin") === "true";
}
async function loginWithPassword(value) {
	if (await sha256Hex(value) === "d93e1653433b2a3a23c4ebcdded3a4fb566c6625cacdc4be468988df54b4f35a") {
		sessionStorage.setItem("warehouse_admin", "true");
		return true;
	}
	return false;
}
function logoutSession() {
	sessionStorage.removeItem("warehouse_admin");
}
function item(qty, ar, fr, en, unit = "قطعة") {
	return {
		qty,
		unit,
		borrowed: 0,
		section: "office",
		ar,
		fr,
		en,
		img: "",
		imgUrl: "",
		minQty: 10
	};
}
var defaultOffice = {
	"marqueur black": item(43, "marqueur black", "Marqueur noir", "Black marker"),
	"baguette a relier": item(7, "baguette a relier", "Baguette à relier", "Binding rod"),
	"قلم التظهير": item(4, "قلم التظهير", "Surligneur", "Highlighter"),
	graveuse: item(1, "graveuse", "Agrafeuse", "Stapler"),
	مقص: item(2, "مقص", "Ciseaux", "Scissors"),
	"agrafes 24/6": item(28, "agrafes 24/6", "Agrafes 24/6", "Staples 24/6"),
	"CD-R": item(50, "CD-R", "CD-R", "CD-R"),
	"أقلام حمراء": item(115, "أقلام حمراء", "Stylos rouges", "Red pens"),
	"pochet CD 2 side": item(400, "pochet CD 2 side", "Pochette CD double face", "CD sleeve double side"),
	"marquer blue": item(42, "marquer blue", "Marqueur bleu", "Blue marker"),
	"papier thermique": item(4, "papier thermique", "Papier thermique", "Thermal paper"),
	"faceur corection tap 12mx5mm": item(8, "faceur corection tap 12mx5mm", "Ruban correcteur 12mx5mm", "Correction tape 12mx5mm"),
	"trobone 31mm": item(28, "trobone 31mm", "Trombone 31mm", "Paper clip 31mm"),
	ممحاة: item(4, "ممحاة", "Gomme", "Eraser"),
	غراء: item(3, "غراء", "Colle", "Glue"),
	thermomètre: item(11, "thermomètre", "Thermomètre", "Thermometer"),
	gratoire: item(1, "gratoire", "Gratoire", "Gratoire"),
	مسطرة: item(6, "مسطرة", "Règle", "Ruler"),
	calculator: item(3, "calculator", "Calculatrice", "Calculator"),
	papier: item(0, "papier", "papier", "papier", "قدعة"),
	"sticky notes": item(22, "sticky notes", "Sticky notes", "Sticky notes"),
	"toneure hp": item(0, "toneure hp", "Toner HP", "HP toner"),
	"مشابك أوراق": item(1, "مشابك أوراق", "Pince à double clip", "Paper clips"),
	"أقلام زرقاء": item(214, "أقلام زرقاء", "Stylos bleus", "Blue pens"),
	"شريط لاصق شفاف": item(7, "شريط لاصق شفاف", "Ruban adhésif transparent", "Transparent tape"),
	"toneur canon": item(4, "toneur canon", "Toner Canon", "Canon toner"),
	"أقلام سوداء": item(37, "أقلام سوداء", "Stylos noirs", "Black pens"),
	"tronone 28mm": item(16, "tronone 28mm", "Trombone 28mm", "Paper clip 28mm"),
	kiteur: item(1, "kiteur", "Kiteur", "Kiteur"),
	"DVD-R": item(50, "DVD-R", "DVD-R", "DVD-R"),
	"grave 31/19": item(2, "grave 31/19", "Agrafe 31/19", "Staple 31/19"),
	"قلم الرصاص": item(44, "قلم الرصاص", "Crayon à papier", "Pencil")
};
var firebaseConfig = {
	apiKey: "AIzaSyAZn1okMYzlwpfkI_8pyJQyd_NNk6vhJmk",
	authDomain: "magasine-6f1ef.firebaseapp.com",
	projectId: "magasine-6f1ef",
	storageBucket: "magasine-6f1ef.firebasestorage.app",
	messagingSenderId: "522494730439",
	appId: "1:522494730439:web:8cfd445b6ee209f5d4dee2"
};
var translations = {
	ar: {
		appTitle: "إدارة المخزون والمكتب",
		appSubtitle: "نظام إدارة مخزون سريع وذكي",
		companyName: "MAPA İNŞAAT ve TİCARET A.Ş.",
		totalQty: "إجمالي الكمية",
		lowStock: "مخزون منخفض",
		totalItems: "عدد المواد",
		totalOps: "عدد العمليات",
		borrowedCount: "مستعار حالياً",
		tabDashboard: "لوحة التحكم",
		tabRegister: "تسجيل عملية",
		tabInventory: "المخزون",
		tabBorrow: "الاستعارات",
		tabHistory: "التاريخ",
		tabManage: "إدارة المواد",
		dashOffice: "حالة المخزون — المكتب",
		quickReg: "تسجيل عملية",
		material: "المادة *",
		quantity: "الكمية *",
		type: "النوع",
		btnOut: "صرف",
		btnIn: "إضافة",
		employee: "الموظف *",
		date: "التاريخ",
		btnSubmit: "تسجيل الآن",
		invOffice: "تفاصيل المخزون — المكتب",
		thMaterial: "المادة",
		thQty: "الكمية",
		thStatus: "الحالة",
		thBorrowed: "المستعار",
		historyTitle: "سجل العمليات",
		empStatsTitle: "إحصائيات الموظفين",
		thEmployee: "الموظف",
		thOutCount: "عدد الإخراج",
		thInCount: "عدد الإدخال",
		thTotalOps: "الإجمالي",
		noEmpStats: "لا توجد بيانات كافية بعد",
		footerText: "نظام مخزون ذكي · التحديث تلقائي",
		alertTitle: "تنبيه: مخزون منخفض",
		noHistory: "لا توجد عمليات مسجلة حتى الآن",
		statusMissing: "ناقص",
		statusLow: "منخفض",
		statusMed: "متوسط",
		statusOK: "كافٍ",
		borrowedLabel: "مستعار",
		manageTitle: "إدارة المواد",
		addOffice: "إضافة مادة مكتبية",
		nameAr: "الاسم بالعربية",
		nameFr: "الاسم بالفرنسية",
		nameEn: "الاسم بالإنجليزية",
		unit: "الوحدة",
		image: "الصورة",
		chooseImg: "اختر صورة",
		captureImg: "التقاط صورة",
		changeImg: "تغيير الصورة",
		btnAdd: "إضافة",
		btnSave: "حفظ التعديلات",
		listOffice: "قائمة مواد المكتب",
		editTitle: "تعديل المادة",
		btnEdit: "تعديل",
		btnDelete: "حذف",
		confirmDelete: "هل أنت متأكد من حذف هذه المادة؟",
		syncOnline: "متصل بالسحابة — مزامنة فورية",
		syncOffline: "وضع غير متصل — حفظ محلي فقط",
		syncError: "خطأ في الاتصال — استخدم التصدير/الاستيراد",
		syncSyncing: "جاري المزامنة…",
		borrowTitle: "نظام الاستعارة والإرجاع",
		borrowType: "نوع العملية",
		btnBorrow: "استعارة",
		btnReturn: "إرجاع",
		borrowNote: "ملاحظة (اختياري)",
		btnBorrowSubmit: "تسجيل استعارة",
		btnReturnSubmit: "تسجيل إرجاع",
		borrowHistory: "سجل الاستعارات",
		borrowSuccess: "تم تسجيل الاستعارة بنجاح",
		returnSuccess: "تم تسجيل الإرجاع بنجاح",
		noBorrowHistory: "لا توجد استعارات مسجلة",
		noResults: "لا توجد نتائج",
		searchPlaceholder: "بحث في المواد…",
		loadMore: "عرض المزيد",
		minQty: "حد التنبيه",
		confirmImport: "سيتم استبدال/تحديث بيانات المخزون. هل تريد المتابعة؟",
		confirmExcel: "سيتم تحديث الكميات من ملف Excel. هل تريد المتابعة؟",
		qtyInvalid: "أدخل كمية صحيحة (رقم صحيح أكبر من صفر).",
		quotaError: "مساحة الحفظ المحلي ممتلئة. تم حفظ البيانات الأساسية بدون صور.",
		typeIn: "إضافة",
		typeOut: "صرف",
		typeBorrow: "استعارة",
		typeReturn: "إرجاع",
		showingOf: "عرض",
		exportJson: "تصدير",
		importJson: "استيراد",
		exportExcel: "تصدير Excel",
		importExcel: "استيراد Excel",
		logout: "خروج",
		loginTitle: "الدخول إلى نظام المخزون",
		loginSub: "أدخل كلمة المرور للمتابعة إلى لوحة التحكم",
		loginBtn: "دخول",
		loginError: "كلمة المرور غير صحيحة",
		passwordPlaceholder: "كلمة المرور",
		loginOk: "تم تسجيل الدخول بنجاح",
		logoutOk: "تم تسجيل الخروج",
		adminOnly: "فقط المشرفون يمكنهم تنفيذ هذه العملية.",
		fillFields: "املأ جميع الحقول المطلوبة.",
		notEnough: "الكمية غير كافية. المتوفر:",
		notEnoughBorrowed: "الكمية المستعارة غير كافية. المستعار:",
		addedOk: "تمت الإضافة",
		savedOk: "تم حفظ التعديلات بنجاح",
		deletedOk: "تم الحذف",
		exportOk: "تم تصدير البيانات",
		importOk: "تم استيراد البيانات",
		excelExportOk: "تم تصدير ملف Excel",
		jsonError: "خطأ في ملف JSON",
		excelError: "خطأ في قراءة ملف Excel",
		emptyFile: "الملف فارغ",
		duplicateName: "هذه المادة موجودة مسبقاً",
		enterName: "أدخل الاسم",
		materialMissing: "المادة غير موجودة",
		busy: "عملية أخرى قيد التنفيذ…",
		guestHint: "مرحباً! سجل الدخول للتحكم الكامل.",
		lowEmpty: "لا توجد تنبيهات مخزون حالياً",
		imagesHint: "الصور تُحفظ على هذا الجهاز وتُرفع للسحابة عند الإمكان.",
		signature: "By Youcef.B",
		of: "من"
	},
	fr: {
		appTitle: "Entrepôt stylos & papier",
		appSubtitle: "Système de gestion d'entrepôt intelligent et rapide",
		companyName: "MAPA İNŞAAT ve TİCARET A.Ş.",
		totalQty: "Quantité totale",
		lowStock: "Stock faible",
		totalItems: "Types de matériaux",
		totalOps: "Opérations enregistrées",
		borrowedCount: "Emprunté actuellement",
		tabDashboard: "Tableau de bord",
		tabRegister: "Enregistrement",
		tabInventory: "Inventaire",
		tabBorrow: "Emprunts",
		tabHistory: "Historique",
		tabManage: "Matériaux",
		dashOffice: "État du stock — Bureau",
		quickReg: "Enregistrement rapide",
		material: "Matériel *",
		quantity: "Quantité *",
		type: "Type",
		btnOut: "Sortie",
		btnIn: "Entrée",
		employee: "Employé *",
		date: "Date",
		btnSubmit: "Enregistrer",
		invOffice: "Détails inventaire — Bureau",
		thMaterial: "Matériel",
		thQty: "Quantité",
		thStatus: "État",
		thBorrowed: "Emprunté",
		historyTitle: "Historique des opérations",
		empStatsTitle: "Statistiques des employés",
		thEmployee: "Employé",
		thOutCount: "Nb. sorties",
		thInCount: "Nb. entrées",
		thTotalOps: "Total",
		noEmpStats: "Pas assez de données pour le moment",
		footerText: "Système entrepôt intelligent · mise à jour auto",
		alertTitle: "Alerte : stock faible",
		noHistory: "Aucune opération enregistrée pour le moment",
		statusMissing: "Manquant",
		statusLow: "Faible",
		statusMed: "Moyen",
		statusOK: "Suffisant",
		borrowedLabel: "Emprunté",
		manageTitle: "Gérer les matériaux",
		addOffice: "Ajouter un matériel bureau",
		nameAr: "Nom en arabe",
		nameFr: "Nom en français",
		nameEn: "Nom en anglais",
		unit: "Unité",
		image: "Image",
		chooseImg: "Choisir une image",
		captureImg: "Prendre une photo",
		changeImg: "Changer l'image",
		btnAdd: "Ajouter",
		btnSave: "Enregistrer",
		listOffice: "Liste matériaux bureau",
		editTitle: "Modifier le matériel",
		btnEdit: "Modifier",
		btnDelete: "Supprimer",
		confirmDelete: "Êtes-vous sûr de vouloir supprimer ce matériel ?",
		syncOnline: "Connecté au cloud — synchro instantanée",
		syncOffline: "Mode hors-ligne — sauvegarde locale uniquement",
		syncError: "Erreur de connexion — utilisez Export/Import",
		syncSyncing: "Synchronisation…",
		borrowTitle: "Système d'emprunt et de retour",
		borrowType: "Type d'opération",
		btnBorrow: "Emprunter",
		btnReturn: "Retourner",
		borrowNote: "Note (optionnel)",
		btnBorrowSubmit: "Enregistrer l'emprunt",
		btnReturnSubmit: "Enregistrer le retour",
		borrowHistory: "Historique des emprunts",
		borrowSuccess: "Emprunt enregistré avec succès",
		returnSuccess: "Retour enregistré avec succès",
		noBorrowHistory: "Aucun emprunt enregistré",
		noResults: "Aucun résultat",
		searchPlaceholder: "Rechercher un matériel…",
		loadMore: "Voir plus",
		minQty: "Seuil d'alerte",
		confirmImport: "Les données du stock seront remplacées/mises à jour. Continuer ?",
		confirmExcel: "Les quantités seront mises à jour depuis Excel. Continuer ?",
		qtyInvalid: "Saisissez une quantité entière supérieure à zéro.",
		quotaError: "Stockage local plein. Données essentielles enregistrées sans images.",
		typeIn: "Entrée",
		typeOut: "Sortie",
		typeBorrow: "Emprunt",
		typeReturn: "Retour",
		showingOf: "Affichage",
		exportJson: "Exporter",
		importJson: "Importer",
		exportExcel: "Exporter Excel",
		importExcel: "Importer Excel",
		logout: "Sortir",
		loginTitle: "Accès au système de stock",
		loginSub: "Entrez le mot de passe pour ouvrir le tableau de bord",
		loginBtn: "Entrée",
		loginError: "Mot de passe incorrect",
		passwordPlaceholder: "Mot de passe",
		loginOk: "Connexion réussie",
		logoutOk: "Déconnexion effectuée",
		adminOnly: "Seuls les administrateurs peuvent faire cette action.",
		fillFields: "Remplissez tous les champs requis.",
		notEnough: "Quantité insuffisante. Disponible :",
		notEnoughBorrowed: "Quantité empruntée insuffisante. Emprunté :",
		addedOk: "Ajouté",
		savedOk: "Modifications enregistrées",
		deletedOk: "Supprimé",
		exportOk: "Données exportées",
		importOk: "Données importées",
		excelExportOk: "Fichier Excel exporté",
		jsonError: "Erreur dans le fichier JSON",
		excelError: "Erreur de lecture Excel",
		emptyFile: "Fichier vide",
		duplicateName: "Ce matériel existe déjà",
		enterName: "Saisissez un nom",
		materialMissing: "Matériel introuvable",
		busy: "Une autre opération est en cours…",
		guestHint: "Bienvenue ! Connectez-vous pour le contrôle complet.",
		lowEmpty: "Aucune alerte de stock pour le moment",
		imagesHint: "Les images restent sur cet appareil et sont envoyées au cloud si possible.",
		signature: "By Youcef.B",
		of: "sur"
	},
	en: {
		appTitle: "Office warehouse",
		appSubtitle: "Smart & fast warehouse management",
		companyName: "MAPA İNŞAAT ve TİCARET A.Ş.",
		totalQty: "Total quantity",
		lowStock: "Low stock",
		totalItems: "Material types",
		totalOps: "Recorded operations",
		borrowedCount: "Currently borrowed",
		tabDashboard: "Dashboard",
		tabRegister: "Register",
		tabInventory: "Inventory",
		tabBorrow: "Borrowings",
		tabHistory: "History",
		tabManage: "Materials",
		dashOffice: "Stock status — Office",
		quickReg: "Quick register",
		material: "Material *",
		quantity: "Quantity *",
		type: "Type",
		btnOut: "Out",
		btnIn: "In",
		employee: "Employee *",
		date: "Date",
		btnSubmit: "Register now",
		invOffice: "Inventory details — Office",
		thMaterial: "Material",
		thQty: "Quantity",
		thStatus: "Status",
		thBorrowed: "Borrowed",
		historyTitle: "Operations history",
		empStatsTitle: "Employee statistics",
		thEmployee: "Employee",
		thOutCount: "Out count",
		thInCount: "In count",
		thTotalOps: "Total",
		noEmpStats: "Not enough data yet",
		footerText: "Smart warehouse · auto update",
		alertTitle: "Warning: low stock",
		noHistory: "No operations recorded yet",
		statusMissing: "Missing",
		statusLow: "Low",
		statusMed: "Medium",
		statusOK: "Sufficient",
		borrowedLabel: "Borrowed",
		manageTitle: "Manage materials",
		addOffice: "Add office material",
		nameAr: "Name in Arabic",
		nameFr: "Name in French",
		nameEn: "Name in English",
		unit: "Unit",
		image: "Image",
		chooseImg: "Choose image",
		captureImg: "Take photo",
		changeImg: "Change image",
		btnAdd: "Add",
		btnSave: "Save changes",
		listOffice: "Office materials list",
		editTitle: "Edit material",
		btnEdit: "Edit",
		btnDelete: "Delete",
		confirmDelete: "Are you sure you want to delete this material?",
		syncOnline: "Cloud connected — live sync",
		syncOffline: "Offline mode — local storage only",
		syncError: "Connection error — use Export/Import",
		syncSyncing: "Syncing…",
		borrowTitle: "Borrow & return",
		borrowType: "Operation type",
		btnBorrow: "Borrow",
		btnReturn: "Return",
		borrowNote: "Note (optional)",
		btnBorrowSubmit: "Register borrow",
		btnReturnSubmit: "Register return",
		borrowHistory: "Borrow history",
		borrowSuccess: "Borrow registered successfully",
		returnSuccess: "Return registered successfully",
		noBorrowHistory: "No borrowings recorded",
		noResults: "No results",
		searchPlaceholder: "Search materials…",
		loadMore: "Load more",
		minQty: "Alert threshold",
		confirmImport: "Inventory data will be replaced/updated. Continue?",
		confirmExcel: "Quantities will be updated from Excel. Continue?",
		qtyInvalid: "Enter a whole quantity greater than zero.",
		quotaError: "Local storage is full. Core data saved without images.",
		typeIn: "In",
		typeOut: "Out",
		typeBorrow: "Borrow",
		typeReturn: "Return",
		showingOf: "Showing",
		exportJson: "Export",
		importJson: "Import",
		exportExcel: "Export Excel",
		importExcel: "Import Excel",
		logout: "Log out",
		loginTitle: "Warehouse system login",
		loginSub: "Enter the password to open the dashboard",
		loginBtn: "Enter",
		loginError: "Incorrect password",
		passwordPlaceholder: "Password",
		loginOk: "Signed in successfully",
		logoutOk: "Signed out",
		adminOnly: "Only administrators can do this.",
		fillFields: "Fill in all required fields.",
		notEnough: "Not enough quantity. Available:",
		notEnoughBorrowed: "Not enough borrowed quantity. Borrowed:",
		addedOk: "Added",
		savedOk: "Changes saved",
		deletedOk: "Deleted",
		exportOk: "Data exported",
		importOk: "Data imported",
		excelExportOk: "Excel file exported",
		jsonError: "JSON file error",
		excelError: "Excel read error",
		emptyFile: "File is empty",
		duplicateName: "This material already exists",
		enterName: "Enter a name",
		materialMissing: "Material not found",
		busy: "Another operation is in progress…",
		guestHint: "Welcome! Sign in for full control.",
		lowEmpty: "No stock alerts right now",
		imagesHint: "Photos stay on this device and upload to the cloud when possible.",
		signature: "By Youcef.B",
		of: "of"
	}
};
function t(lang, key) {
	return translations[lang][key] || translations.ar[key];
}
var DB_NAME = "mapa-warehouse";
var STORE = "images";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function idbSet(key, dataUrl) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(dataUrl, key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
async function idbGetAll() {
	const db = await openDb();
	const out = {};
	await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).openCursor();
		req.onsuccess = () => {
			const cursor = req.result;
			if (cursor) {
				out[String(cursor.key)] = cursor.value;
				cursor.continue();
			} else resolve();
		};
		req.onerror = () => reject(req.error);
	});
	db.close();
	return out;
}
async function idbDelete(key) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
function newId() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function parseQty(raw) {
	const trimmed = String(raw).trim();
	if (!trimmed || !/^[0-9]+$/.test(trimmed)) return null;
	const n = Number(trimmed);
	if (!Number.isInteger(n) || n < 1 || n > 1e6) return null;
	return n;
}
function sanitizeDocId(str) {
	return String(str).trim().replace(/[/.#$[\]]/g, "_").slice(0, 300) || `m_${Date.now()}`;
}
function matchesSearch(key, item, query) {
	const q = query.trim().toLowerCase();
	if (!q) return true;
	return `${item.ar || ""} ${item.fr || ""} ${item.en || ""} ${key}`.toLowerCase().includes(q);
}
function getName(item, key, lang) {
	if (lang === "ar" && item.ar) return item.ar;
	if (lang === "en" && item.en) return item.en;
	if (lang === "fr" && item.fr) return item.fr;
	return item.ar || item.fr || item.en || key;
}
function stockLevel(qty, minQty) {
	const min = minQty > 0 ? minQty : 10;
	if (qty <= 0) return "missing";
	if (qty < min) return "low";
	if (qty < min * 5) return "med";
	return "ok";
}
function stockColor(qty, minQty) {
	const level = stockLevel(qty, minQty);
	if (level === "missing") return "var(--color-bad)";
	if (level === "low") return "var(--color-warn)";
	if (level === "med") return "var(--color-mid)";
	return "var(--color-ok)";
}
function stockLabel(qty, minQty, lang) {
	const level = stockLevel(qty, minQty);
	if (level === "missing") return t(lang, "statusMissing");
	if (level === "low") return t(lang, "statusLow");
	if (level === "med") return t(lang, "statusMed");
	return t(lang, "statusOK");
}
function typeLabel(type, lang) {
	if (type === "in") return t(lang, "typeIn");
	if (type === "borrow") return t(lang, "typeBorrow");
	if (type === "return") return t(lang, "typeReturn");
	return t(lang, "typeOut");
}
function entryTs(entry) {
	if (typeof entry.ts === "number" && Number.isFinite(entry.ts)) return entry.ts;
	const n = Number(entry.id);
	return Number.isFinite(n) ? n : 0;
}
function todayISO() {
	return (/* @__PURE__ */ new Date()).toISOString().split("T")[0] ?? "";
}
function normalizeMaterial(data, key) {
	const d = data;
	const minRaw = Number(d.minQty);
	return {
		qty: Number(d.qty) || 0,
		unit: String(d.unit || "قطعة"),
		borrowed: Number(d.borrowed) || 0,
		section: "office",
		ar: String(d.ar || key),
		fr: String(d.fr || key),
		en: String(d.en || key),
		img: "",
		imgUrl: typeof d.imgUrl === "string" ? d.imgUrl : "",
		minQty: minRaw > 0 ? minRaw : 10
	};
}
function cloudPayload(key, item) {
	return {
		key,
		qty: item.qty,
		unit: item.unit,
		borrowed: item.borrowed || 0,
		section: "office",
		ar: item.ar,
		fr: item.fr,
		en: item.en,
		minQty: item.minQty > 0 ? item.minQty : 10,
		imgUrl: item.imgUrl || ""
	};
}
function idle(cb, timeout = 400) {
	const ric = window.requestIdleCallback;
	if (typeof ric === "function") return ric(cb, { timeout });
	return window.setTimeout(cb, 200);
}
function cancelIdle(handle) {
	const cic = window.cancelIdleCallback;
	if (typeof cic === "function") cic(handle);
	else window.clearTimeout(handle);
}
var useWarehouse = create(() => ({
	ready: false,
	lang: "ar",
	isAdmin: false,
	inventory: {},
	history: [],
	borrowHistory: [],
	syncStatus: "syncing",
	search: "",
	tab: "dashboard",
	historyLimit: 50,
	borrowLimit: 50,
	toasts: [],
	submitting: false,
	currentType: "out",
	currentBorrowType: "borrow",
	editingKey: null
}));
var loading = null;
function loadSheetJS() {
	const w = window;
	if (w.XLSX) return Promise.resolve(w.XLSX);
	if (loading) return loading;
	loading = new Promise((resolve, reject) => {
		const script = document.createElement("script");
		script.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
		script.async = true;
		script.onload = () => {
			const lib = window.XLSX;
			if (!lib) reject(/* @__PURE__ */ new Error("xlsx"));
			else resolve(lib);
		};
		script.onerror = () => reject(/* @__PURE__ */ new Error("xlsx"));
		document.head.appendChild(script);
	});
	return loading;
}
var inventory = {};
var history = [];
var borrowHistory = [];
var syncedMaterialSnapshots = {};
var syncedHistoryIds = /* @__PURE__ */ new Set();
var syncedBorrowIds = /* @__PURE__ */ new Set();
var isSyncing = false;
var cloudEnabled = false;
var db = null;
var storage = null;
var unsubs = [];
var pending = {
	materials: null,
	history: null,
	borrow: null
};
var idleHandle = null;
var seeded = false;
function lang() {
	return useWarehouse.getState().lang;
}
function admin() {
	return useWarehouse.getState().isAdmin;
}
function showToast(message, type = "info", duration = 4e3) {
	const id = newId();
	const toasts = [...useWarehouse.getState().toasts, {
		id,
		message,
		type
	}];
	useWarehouse.setState({ toasts });
	window.setTimeout(() => {
		useWarehouse.setState({ toasts: useWarehouse.getState().toasts.filter((x) => x.id !== id) });
	}, duration);
}
function dismissToast(id) {
	useWarehouse.setState({ toasts: useWarehouse.getState().toasts.filter((x) => x.id !== id) });
}
function updateSyncStatus(status) {
	useWarehouse.setState({ syncStatus: status });
}
function pushData() {
	useWarehouse.setState({
		inventory: { ...inventory },
		history: history.slice(),
		borrowHistory: borrowHistory.slice()
	});
}
function saveToStorage() {
	const slim = {};
	for (const [key, item] of Object.entries(inventory)) {
		const { img: _ignored, ...rest } = item;
		slim[key] = rest;
	}
	try {
		localStorage.setItem("inventory", JSON.stringify(slim));
		localStorage.setItem("history", JSON.stringify(history));
		localStorage.setItem("borrowHistory", JSON.stringify(borrowHistory));
	} catch {
		showToast(t(lang(), "quotaError"), "warning");
	}
}
function readJson(key, fallback) {
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
function loadFromStorage() {
	const saved = readJson("inventory", null);
	if (saved && typeof saved === "object") {
		const next = {};
		for (const [key, value] of Object.entries(saved)) next[key] = normalizeMaterial(value, key);
		inventory = next;
	} else inventory = structuredClone(defaultOffice);
	history = normalizeEntries(readJson("history", []));
	borrowHistory = normalizeEntries(readJson("borrowHistory", []));
}
function normalizeEntries(list) {
	if (!Array.isArray(list)) return [];
	return list.map((raw) => {
		const e = raw;
		const id = String(e.id ?? newId());
		const ts = typeof e.ts === "number" ? e.ts : Number(e.id) || Date.now();
		const type = e.type || "out";
		return {
			id,
			ts,
			material: String(e.material || ""),
			qty: Number(e.qty) || 0,
			employee: String(e.employee || ""),
			date: String(e.date || ""),
			type,
			section: "office",
			note: e.note ? String(e.note) : void 0
		};
	});
}
async function hydrateImages() {
	try {
		const images = await idbGetAll();
		for (const key of Object.keys(inventory)) if (images[key]) inventory[key].img = images[key];
		else if (inventory[key].imgUrl) inventory[key].img = inventory[key].imgUrl;
	} catch (err) {
		console.warn("idb hydrate", err);
	}
}
async function persistImage(key, dataUrl) {
	inventory[key].img = dataUrl;
	try {
		await idbSet(key, dataUrl);
	} catch (err) {
		console.warn("idb set", err);
	}
	const url = await uploadImage(key, dataUrl);
	if (url) inventory[key].imgUrl = url;
}
async function uploadImage(key, dataUrl) {
	if (!storage) return "";
	try {
		const r = ref(storage, `wh_images/${sanitizeDocId(key)}.jpg`);
		await uploadString(r, dataUrl, "data_url");
		return await getDownloadURL(r);
	} catch (err) {
		console.warn("storage upload skipped", err);
		return "";
	}
}
async function syncToCloud() {
	if (!cloudEnabled || !db) return;
	updateSyncStatus("syncing");
	const ops = [];
	const currentKeys = new Set(Object.keys(inventory));
	for (const key of Object.keys(syncedMaterialSnapshots)) if (!currentKeys.has(key)) ops.push({
		type: "delete",
		ref: doc(db, "wh_materials", sanitizeDocId(key))
	});
	for (const key of currentKeys) {
		const json = JSON.stringify(cloudPayload(key, inventory[key]));
		if (syncedMaterialSnapshots[key] !== json) ops.push({
			type: "set",
			ref: doc(db, "wh_materials", sanitizeDocId(key)),
			data: cloudPayload(key, inventory[key])
		});
	}
	const currentHistoryIds = new Set(history.map((h) => String(h.id)));
	for (const id of syncedHistoryIds) if (!currentHistoryIds.has(id)) ops.push({
		type: "delete",
		ref: doc(db, "wh_history", id)
	});
	for (const entry of history) {
		const idStr = String(entry.id);
		if (!syncedHistoryIds.has(idStr)) ops.push({
			type: "set",
			ref: doc(db, "wh_history", idStr),
			data: { ...entry }
		});
	}
	const currentBorrowIds = new Set(borrowHistory.map((h) => String(h.id)));
	for (const id of syncedBorrowIds) if (!currentBorrowIds.has(id)) ops.push({
		type: "delete",
		ref: doc(db, "wh_borrowHistory", id)
	});
	for (const entry of borrowHistory) {
		const idStr = String(entry.id);
		if (!syncedBorrowIds.has(idStr)) ops.push({
			type: "set",
			ref: doc(db, "wh_borrowHistory", idStr),
			data: { ...entry }
		});
	}
	try {
		for (let i = 0; i < ops.length; i += 450) {
			const chunk = ops.slice(i, i + 450);
			const batch = writeBatch(db);
			for (const op of chunk) if (op.type === "set") batch.set(op.ref, op.data);
			else batch.delete(op.ref);
			await batch.commit();
		}
		syncedMaterialSnapshots = {};
		for (const key of currentKeys) syncedMaterialSnapshots[key] = JSON.stringify(cloudPayload(key, inventory[key]));
		syncedHistoryIds = currentHistoryIds;
		syncedBorrowIds = currentBorrowIds;
		updateSyncStatus("online");
	} catch (err) {
		console.error("Sync error:", err);
		updateSyncStatus("error");
		throw err;
	}
}
function mergeMaterialsSnapshot(snap) {
	const next = {};
	snap.forEach((d) => {
		const data = d.data();
		const key = String(data.key || d.id);
		const mat = normalizeMaterial(data, key);
		const prev = inventory[key];
		if (typeof data.img === "string" && data.img.startsWith("data:")) {
			mat.img = data.img;
			idbSet(key, data.img);
		} else if (prev?.img) mat.img = prev.img;
		else if (mat.imgUrl) mat.img = mat.imgUrl;
		next[key] = mat;
	});
	inventory = next;
	syncedMaterialSnapshots = {};
	for (const key of Object.keys(inventory)) syncedMaterialSnapshots[key] = JSON.stringify(cloudPayload(key, inventory[key]));
}
function mergeHistorySnapshot(snap) {
	const list = [];
	snap.forEach((d) => list.push(normalizeEntries([d.data()])[0]));
	list.sort((a, b) => a.ts - b.ts);
	history = list;
	syncedHistoryIds = new Set(list.map((h) => String(h.id)));
}
function mergeBorrowSnapshot(snap) {
	const list = [];
	snap.forEach((d) => list.push(normalizeEntries([d.data()])[0]));
	list.sort((a, b) => a.ts - b.ts);
	borrowHistory = list;
	syncedBorrowIds = new Set(list.map((h) => String(h.id)));
}
function scheduleCloudApply() {
	if (idleHandle != null) return;
	idleHandle = idle(() => {
		idleHandle = null;
		if (isSyncing) {
			scheduleCloudApply();
			return;
		}
		let changed = false;
		if (pending.materials) {
			mergeMaterialsSnapshot(pending.materials);
			pending.materials = null;
			changed = true;
		}
		if (pending.history) {
			mergeHistorySnapshot(pending.history);
			pending.history = null;
			changed = true;
		}
		if (pending.borrow) {
			mergeBorrowSnapshot(pending.borrow);
			pending.borrow = null;
			changed = true;
		}
		if (!changed) return;
		saveToStorage();
		pushData();
		updateSyncStatus("online");
	});
}
async function migrateOldDataIfNeeded() {
	if (!db) return false;
	try {
		if (!(await getDocs(collection(db, "wh_materials"))).empty) return false;
		const oldSnap = await getDoc(doc(db, "warehouse", "data"));
		if (!oldSnap.exists()) return false;
		const oldData = oldSnap.data();
		const oldInventory = oldData.inventory || {};
		const oldHistory = normalizeEntries(oldData.history || []);
		const oldBorrow = normalizeEntries(oldData.borrowHistory || []);
		if (Object.keys(oldInventory).length === 0 && oldHistory.length === 0 && oldBorrow.length === 0) return false;
		const ops = [];
		for (const key of Object.keys(oldInventory)) {
			const mat = normalizeMaterial(oldInventory[key], key);
			const rawImg = oldInventory[key]?.img;
			if (typeof rawImg === "string" && rawImg.startsWith("data:")) await persistImage(key, rawImg);
			ops.push({
				ref: doc(db, "wh_materials", sanitizeDocId(key)),
				data: cloudPayload(key, mat)
			});
		}
		for (const entry of oldHistory) ops.push({
			ref: doc(db, "wh_history", String(entry.id)),
			data: { ...entry }
		});
		for (const entry of oldBorrow) ops.push({
			ref: doc(db, "wh_borrowHistory", String(entry.id)),
			data: { ...entry }
		});
		for (let i = 0; i < ops.length; i += 450) {
			const chunk = ops.slice(i, i + 450);
			const batch = writeBatch(db);
			for (const op of chunk) batch.set(op.ref, op.data);
			await batch.commit();
		}
		return true;
	} catch (err) {
		console.error("Migration error:", err);
		return false;
	}
}
function attachListeners() {
	if (!db) return;
	unsubs.forEach((u) => u());
	unsubs = [];
	unsubs.push(onSnapshot(collection(db, "wh_materials"), (snap) => {
		if (isSyncing) return;
		if (snap.metadata.hasPendingWrites) return;
		if (!seeded && snap.empty) {
			seedIfEmpty();
			return;
		}
		pending.materials = snap;
		scheduleCloudApply();
	}, (err) => {
		console.error("Materials snapshot error:", err);
		updateSyncStatus("offline");
	}));
	unsubs.push(onSnapshot(collection(db, "wh_history"), (snap) => {
		if (isSyncing) return;
		if (snap.metadata.hasPendingWrites) return;
		pending.history = snap;
		scheduleCloudApply();
	}, (err) => console.error("History snapshot error:", err)));
	unsubs.push(onSnapshot(collection(db, "wh_borrowHistory"), (snap) => {
		if (isSyncing) return;
		if (snap.metadata.hasPendingWrites) return;
		pending.borrow = snap;
		scheduleCloudApply();
	}, (err) => console.error("BorrowHistory snapshot error:", err)));
}
async function seedIfEmpty() {
	if (seeded) return;
	seeded = true;
	if (Object.keys(inventory).length === 0) inventory = structuredClone(defaultOffice);
	saveToStorage();
	pushData();
	try {
		await syncToCloud();
	} catch {}
}
async function initWarehouse() {
	if (typeof window === "undefined") return;
	const isAdmin = checkAuth();
	useWarehouse.setState({
		isAdmin,
		ready: false,
		syncStatus: "syncing"
	});
	loadFromStorage();
	await hydrateImages();
	pushData();
	try {
		if (firebaseConfig.apiKey && firebaseConfig.apiKey.length > 10) {
			const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
			db = getFirestore(app);
			try {
				storage = getStorage(app);
			} catch {
				storage = null;
			}
			cloudEnabled = true;
		}
	} catch (err) {
		console.warn("Firebase init failed:", err);
		cloudEnabled = false;
	}
	if (cloudEnabled && db) try {
		await migrateOldDataIfNeeded();
		attachListeners();
	} catch (err) {
		console.error("Load from Firebase error:", err);
		updateSyncStatus("offline");
	}
	else updateSyncStatus("offline");
	useWarehouse.setState({ ready: true });
	if (!isAdmin) showToast(t(lang(), "guestHint"), "info", 5e3);
}
async function login(password) {
	if (await loginWithPassword(password)) {
		useWarehouse.setState({ isAdmin: true });
		showToast(t(lang(), "loginOk"), "success");
		return true;
	}
	showToast(t(lang(), "loginError"), "error");
	return false;
}
function logout() {
	logoutSession();
	useWarehouse.setState({
		isAdmin: false,
		tab: "dashboard",
		editingKey: null
	});
	showToast(t(lang(), "logoutOk"), "info");
}
function setLang(next) {
	useWarehouse.setState({ lang: next });
	document.documentElement.lang = next === "ar" ? "ar" : next;
	document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
}
function setTab(tab) {
	useWarehouse.setState({ tab });
}
function setSearch(search) {
	useWarehouse.setState({ search });
}
function setType(type) {
	if (!admin()) return;
	useWarehouse.setState({ currentType: type });
}
function setBorrowType(type) {
	if (!admin()) return;
	useWarehouse.setState({ currentBorrowType: type });
}
function loadMoreHistory() {
	useWarehouse.setState({ historyLimit: useWarehouse.getState().historyLimit + 50 });
}
function loadMoreBorrow() {
	useWarehouse.setState({ borrowLimit: useWarehouse.getState().borrowLimit + 50 });
}
function openEdit(key) {
	if (!admin()) return;
	useWarehouse.setState({ editingKey: key });
}
function closeEdit() {
	useWarehouse.setState({ editingKey: null });
}
async function withSync(fn) {
	if (isSyncing || useWarehouse.getState().submitting) {
		showToast(t(lang(), "busy"), "warning");
		return;
	}
	isSyncing = true;
	useWarehouse.setState({ submitting: true });
	updateSyncStatus("syncing");
	try {
		const result = await fn();
		saveToStorage();
		pushData();
		try {
			await syncToCloud();
		} catch {}
		return result;
	} finally {
		isSyncing = false;
		useWarehouse.setState({ submitting: false });
		if (cloudEnabled) updateSyncStatus("online");
	}
}
async function submitRegister(input) {
	if (!admin()) {
		showToast(t(lang(), "adminOnly"), "error");
		return false;
	}
	const quantity = parseQty(input.quantity);
	const employee = input.employee.trim();
	if (!quantity || !employee || !input.material) {
		showToast(!quantity ? t(lang(), "qtyInvalid") : t(lang(), "fillFields"), "error");
		return false;
	}
	const item = inventory[input.material];
	if (!item) {
		showToast(t(lang(), "materialMissing"), "error");
		return false;
	}
	const type = useWarehouse.getState().currentType;
	if (type === "out" && item.qty < quantity) {
		showToast(`${t(lang(), "notEnough")} ${item.qty}`, "error");
		return false;
	}
	await withSync(() => {
		if (type === "out") item.qty -= quantity;
		else item.qty += quantity;
		history.push({
			id: newId(),
			ts: Date.now(),
			material: input.material,
			qty: type === "out" ? -quantity : quantity,
			employee,
			date: input.date || "",
			type,
			section: "office"
		});
	});
	showToast(`${t(lang(), type === "out" ? "typeOut" : "typeIn")} — OK`, "success");
	return true;
}
async function submitBorrow(input) {
	if (!admin()) {
		showToast(t(lang(), "adminOnly"), "error");
		return false;
	}
	const quantity = parseQty(input.quantity);
	const employee = input.employee.trim();
	if (!quantity || !employee || !input.material) {
		showToast(!quantity ? t(lang(), "qtyInvalid") : t(lang(), "fillFields"), "error");
		return false;
	}
	const item = inventory[input.material];
	if (!item) {
		showToast(t(lang(), "materialMissing"), "error");
		return false;
	}
	const type = useWarehouse.getState().currentBorrowType;
	if (type === "borrow" && item.qty < quantity) {
		showToast(`${t(lang(), "notEnough")} ${item.qty}`, "error");
		return false;
	}
	if (type === "return" && (item.borrowed || 0) < quantity) {
		showToast(`${t(lang(), "notEnoughBorrowed")} ${item.borrowed || 0}`, "error");
		return false;
	}
	await withSync(() => {
		if (type === "borrow") {
			item.qty -= quantity;
			item.borrowed = (item.borrowed || 0) + quantity;
		} else {
			item.qty += quantity;
			item.borrowed = Math.max(0, (item.borrowed || 0) - quantity);
		}
		const entry = {
			id: newId(),
			ts: Date.now(),
			material: input.material,
			qty: quantity,
			employee,
			date: input.date || "",
			type,
			section: "office",
			note: input.note.trim() || (type === "borrow" ? t(lang(), "typeBorrow") : t(lang(), "typeReturn"))
		};
		borrowHistory.push(entry);
		history.push(entry);
	});
	showToast(t(lang(), type === "borrow" ? "borrowSuccess" : "returnSuccess"), "success");
	return true;
}
function isDuplicateName(name, excludeKey = null) {
	const lower = name.toLowerCase();
	return Object.keys(inventory).some((k) => k !== excludeKey && k.toLowerCase() === lower);
}
async function addMaterial(input) {
	if (!admin()) {
		showToast(t(lang(), "adminOnly"), "error");
		return false;
	}
	const ar = input.ar.trim();
	const fr = input.fr.trim();
	const en = input.en.trim();
	if (!ar && !fr && !en) {
		showToast(t(lang(), "enterName"), "error");
		return false;
	}
	const key = ar || fr || en;
	if (isDuplicateName(key)) {
		showToast(`${t(lang(), "duplicateName")}: ${key}`, "error");
		return false;
	}
	const minQty = Number.parseInt(input.minQty, 10);
	await withSync(async () => {
		inventory[key] = {
			qty: 0,
			unit: input.unit.trim() || "قطعة",
			borrowed: 0,
			section: "office",
			ar: ar || key,
			fr: fr || key,
			en: en || key,
			img: "",
			imgUrl: "",
			minQty: minQty > 0 ? minQty : 10
		};
		if (input.img) await persistImage(key, input.img);
	});
	showToast(`${t(lang(), "addedOk")}: ${key}`, "success");
	return true;
}
async function saveEdit(input) {
	if (!admin()) return false;
	const item = inventory[input.key];
	if (!item) {
		showToast(t(lang(), "materialMissing"), "error");
		return false;
	}
	const minQty = Number.parseInt(input.minQty, 10);
	await withSync(async () => {
		item.ar = input.ar.trim() || input.key;
		item.fr = input.fr.trim() || input.key;
		item.en = input.en.trim() || input.key;
		item.unit = input.unit.trim() || item.unit;
		if (minQty > 0) item.minQty = minQty;
		if (input.img) await persistImage(input.key, input.img);
	});
	useWarehouse.setState({ editingKey: null });
	showToast(t(lang(), "savedOk"), "success");
	return true;
}
async function deleteMaterial(key) {
	if (!admin()) {
		showToast(t(lang(), "adminOnly"), "error");
		return false;
	}
	if (!inventory[key]) {
		showToast(t(lang(), "materialMissing"), "error");
		return false;
	}
	if (!window.confirm(`${t(lang(), "confirmDelete")}\n${key}`)) return false;
	await withSync(async () => {
		delete inventory[key];
		history = history.filter((h) => h.material !== key);
		borrowHistory = borrowHistory.filter((h) => h.material !== key);
		try {
			await idbDelete(key);
		} catch {}
	});
	showToast(`${t(lang(), "deletedOk")}: ${key}`, "success");
	return true;
}
function exportJson() {
	const data = {
		inventory: Object.fromEntries(Object.entries(inventory).map(([k, v]) => {
			const { img: _ignored, ...rest } = v;
			return [k, rest];
		})),
		history,
		borrowHistory,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		version: "2.0"
	};
	const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = `warehouse-backup-${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
	showToast(t(lang(), "exportOk"), "success");
}
async function importJsonFile(file) {
	if (!admin()) {
		showToast(t(lang(), "adminOnly"), "error");
		return;
	}
	if (!window.confirm(t(lang(), "confirmImport"))) return;
	try {
		const text = await file.text();
		const data = JSON.parse(text);
		await withSync(() => {
			if (data.inventory) {
				const next = {};
				for (const [key, value] of Object.entries(data.inventory)) {
					const mat = normalizeMaterial(value, key);
					const prev = inventory[key];
					if (prev?.img) mat.img = prev.img;
					next[key] = mat;
				}
				inventory = next;
			}
			if (data.history) history = normalizeEntries(data.history);
			if (data.borrowHistory) borrowHistory = normalizeEntries(data.borrowHistory);
		});
		showToast(t(lang(), "importOk"), "success");
	} catch (err) {
		showToast(`${t(lang(), "jsonError")}: ${err.message}`, "error");
	}
}
async function exportExcel() {
	try {
		showToast(t(lang(), "syncSyncing"), "info", 1600);
		const XLSX = await loadSheetJS();
		const rows = Object.keys(inventory).map((key) => {
			const it = inventory[key];
			return {
				"المفتاح/Key": key,
				بالعربية: it.ar || "",
				بالفرنسية: it.fr || "",
				بالإنجليزية: it.en || "",
				الوحدة: it.unit || "",
				الكمية: it.qty || 0,
				المستعار: it.borrowed || 0,
				"الحد الأدنى": it.minQty || 10
			};
		});
		const ws = XLSX.utils.json_to_sheet(rows);
		const wb = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, "المواد");
		XLSX.writeFile(wb, `warehouse-materials-${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.xlsx`);
		showToast(t(lang(), "excelExportOk"), "success");
	} catch (err) {
		showToast(`${t(lang(), "excelError")}: ${err.message}`, "error");
	}
}
async function importExcelFile(file) {
	if (!admin()) {
		showToast(t(lang(), "adminOnly"), "error");
		return;
	}
	if (!window.confirm(t(lang(), "confirmExcel"))) return;
	try {
		const XLSX = await loadSheetJS();
		const buf = await file.arrayBuffer();
		const wb = XLSX.read(buf, { type: "array" });
		const sheet = wb.Sheets[wb.SheetNames[0] ?? ""];
		if (!sheet) {
			showToast(t(lang(), "emptyFile"), "error");
			return;
		}
		const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
		if (!rows.length) {
			showToast(t(lang(), "emptyFile"), "error");
			return;
		}
		let added = 0;
		let updated = 0;
		await withSync(() => {
			for (const row of rows) {
				const ar = String(row["بالعربية"] ?? row.ar ?? "").trim();
				const fr = String(row["بالفرنسية"] ?? row.fr ?? "").trim();
				const en = String(row["بالإنجليزية"] ?? row.en ?? "").trim();
				const unit = String(row["الوحدة"] ?? row.unit ?? "قطعة").trim() || "قطعة";
				const qtyRaw = Number(row["الكمية"] ?? row.qty ?? 0);
				const qty = Number.isFinite(qtyRaw) ? qtyRaw : 0;
				const borrowedRaw = Number(row["المستعار"] ?? row.borrowed ?? 0);
				const borrowed = Number.isFinite(borrowedRaw) ? borrowedRaw : 0;
				const minRaw = Number(row["الحد الأدنى"] ?? row.minQty ?? 10);
				const minQty = minRaw > 0 ? minRaw : 10;
				const key = String(row["المفتاح/Key"] ?? row.key ?? "").trim() || ar || fr || en;
				if (!key) continue;
				if (inventory[key]) {
					inventory[key].qty = qty;
					inventory[key].borrowed = borrowed;
					inventory[key].unit = unit;
					inventory[key].minQty = minQty;
					if (ar) inventory[key].ar = ar;
					if (fr) inventory[key].fr = fr;
					if (en) inventory[key].en = en;
					updated += 1;
				} else {
					inventory[key] = {
						qty,
						unit,
						borrowed,
						section: "office",
						ar: ar || key,
						fr: fr || key,
						en: en || key,
						img: "",
						imgUrl: "",
						minQty
					};
					added += 1;
				}
			}
		});
		showToast(`${t(lang(), "importOk")}: +${added} / ~${updated}`, "success");
	} catch (err) {
		showToast(`${t(lang(), "excelError")}: ${err.message}`, "error");
	}
}
function destroyWarehouse() {
	unsubs.forEach((u) => u());
	unsubs = [];
	if (idleHandle != null) cancelIdle(idleHandle);
	idleHandle = null;
}
function DashboardPanel() {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	const search = useWarehouse((s) => s.search);
	const entries = Object.entries(inventory).filter(([key, item]) => matchesSearch(key, item, search));
	const low = Object.entries(inventory).filter(([, i]) => i.qty < (i.minQty || 10)).map(([name, i]) => ({
		...i,
		name
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [low.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card border-2 border-warn/40 bg-amber-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mb-2 font-bold text-warn",
			children: t(lang, "alertTitle")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-1 sm:grid-cols-2",
			children: low.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "truncate rounded-md bg-white/80 px-2 py-1 text-sm font-semibold",
				style: { color: item.qty <= 0 ? "var(--color-bad)" : "var(--color-warn)" },
				children: [
					getName(item, item.name, lang),
					" · ",
					item.qty,
					" ",
					item.unit
				]
			}, item.name))
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "card text-sm text-muted",
		children: t(lang, "lowEmpty")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-lg font-bold text-navy",
			children: t(lang, "dashOffice")
		}), entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-8 text-center text-muted",
			children: t(lang, "noResults")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2 sm:grid-cols-5 md:grid-cols-6",
			children: entries.map(([name, item]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-md border-2 bg-card p-2 text-center shadow-sm",
				style: { borderColor: stockColor(item.qty, item.minQty) },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { src: item.img }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 line-clamp-2 text-[11px] font-bold leading-tight",
						children: getName(item, name, lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-bold tabular-nums",
						style: { color: stockColor(item.qty, item.minQty) },
						children: item.qty
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] text-muted",
						children: stockLabel(item.qty, item.minQty, lang)
					}),
					item.borrowed > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[10px] font-semibold text-warn",
						children: [
							t(lang, "borrowedLabel"),
							": ",
							item.borrowed
						]
					}) : null
				]
			}, name))
		})]
	})] });
}
function InventoryPanel() {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	const search = useWarehouse((s) => s.search);
	const entries = Object.entries(inventory).filter(([key, item]) => matchesSearch(key, item, search));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-lg font-bold text-navy",
			children: t(lang, "invOffice")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b-2 border-navy bg-paper/80 text-navy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-start",
							children: t(lang, "thMaterial")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: t(lang, "thQty")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: t(lang, "thStatus")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-3 text-center",
							children: t(lang, "thBorrowed")
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 4,
					className: "p-6 text-center text-muted",
					children: t(lang, "noResults")
				}) }) : entries.map(([name, item], idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: idx % 2 === 0 ? "bg-paper/40" : "bg-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 font-medium",
							children: getName(item, name, lang)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-center font-bold tabular-nums",
							style: { color: stockColor(item.qty, item.minQty) },
							children: item.qty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-center text-xs",
							children: stockLabel(item.qty, item.minQty, lang)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3 text-center tabular-nums text-warn",
							children: item.borrowed > 0 ? item.borrowed : "—"
						})
					]
				}, name)) })]
			})
		})]
	});
}
function Thumb({ src }) {
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className: "mx-auto size-8 rounded-md border border-line object-cover"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto flex size-8 items-center justify-center rounded-md border border-dashed border-line bg-paper text-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" })
	});
}
function compressImage(file, maxDim = 160, quality = .62) {
	return new Promise((resolve, reject) => {
		if (!file.type || !file.type.startsWith("image/")) {
			reject(/* @__PURE__ */ new Error("not-image"));
			return;
		}
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("read"));
		reader.onload = () => {
			const img = new Image();
			img.onload = () => {
				let { width, height } = img;
				if (width > height && width > maxDim) {
					height = Math.round(height * (maxDim / width));
					width = maxDim;
				} else if (height >= width && height > maxDim) {
					width = Math.round(width * (maxDim / height));
					height = maxDim;
				}
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, width);
				canvas.height = Math.max(1, height);
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					reject(/* @__PURE__ */ new Error("ctx"));
					return;
				}
				ctx.fillStyle = "#ffffff";
				ctx.fillRect(0, 0, canvas.width, canvas.height);
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				try {
					resolve(canvas.toDataURL("image/jpeg", quality));
				} catch (err) {
					reject(err);
				}
			};
			img.onerror = () => reject(/* @__PURE__ */ new Error("img"));
			img.src = String(reader.result);
		};
		reader.readAsDataURL(file);
	});
}
function RegisterPanel() {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	const currentType = useWarehouse((s) => s.currentType);
	const submitting = useWarehouse((s) => s.submitting);
	const keys = Object.keys(inventory);
	const [material, setMaterial] = (0, import_react.useState)(keys[0] || "");
	const [quantity, setQuantity] = (0, import_react.useState)("");
	const [employee, setEmployee] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	(0, import_react.useEffect)(() => {
		if (!material && keys[0]) setMaterial(keys[0]);
		if (material && !inventory[material] && keys[0]) setMaterial(keys[0]);
	}, [
		inventory,
		keys,
		material
	]);
	async function onSubmit(e) {
		e.preventDefault();
		if (await submitRegister({
			material,
			quantity,
			employee,
			date
		})) {
			setQuantity("");
			setEmployee("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card mx-auto max-w-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-4 text-center text-lg font-bold text-navy",
			children: t(lang, "quickReg")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MaterialSelect, {
					value: material,
					onChange: setMaterial
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "quantity") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						step: 1,
						inputMode: "numeric",
						required: true,
						value: quantity,
						onChange: (e) => setQuantity(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "type") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeBtn, {
							active: currentType === "out",
							tone: "out",
							onClick: () => setType("out"),
							children: t(lang, "btnOut")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeBtn, {
							active: currentType === "in",
							tone: "in",
							onClick: () => setType("in"),
							children: t(lang, "btnIn")
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "employee") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: employee,
						onChange: (e) => setEmployee(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "date") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "primary-btn",
					disabled: submitting,
					children: t(lang, "btnSubmit")
				})
			]
		})]
	});
}
function BorrowPanel() {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	const currentBorrowType = useWarehouse((s) => s.currentBorrowType);
	const submitting = useWarehouse((s) => s.submitting);
	const borrowHistory = useWarehouse((s) => s.borrowHistory);
	const borrowLimit = useWarehouse((s) => s.borrowLimit);
	const keys = Object.keys(inventory);
	const [material, setMaterial] = (0, import_react.useState)(keys[0] || "");
	const [quantity, setQuantity] = (0, import_react.useState)("");
	const [employee, setEmployee] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	(0, import_react.useEffect)(() => {
		if (!material && keys[0]) setMaterial(keys[0]);
		if (material && !inventory[material] && keys[0]) setMaterial(keys[0]);
	}, [
		inventory,
		keys,
		material
	]);
	const shown = (0, import_react.useMemo)(() => [...borrowHistory].sort((a, b) => entryTs(b) - entryTs(a)).slice(0, borrowLimit), [borrowHistory, borrowLimit]);
	async function onSubmit(e) {
		e.preventDefault();
		if (await submitBorrow({
			material,
			quantity,
			employee,
			date,
			note
		})) {
			setQuantity("");
			setEmployee("");
			setNote("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card mx-auto max-w-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-4 text-center text-lg font-bold text-navy",
			children: t(lang, "borrowTitle")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MaterialSelect, {
					value: material,
					onChange: setMaterial
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "borrowType") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeBtn, {
							active: currentBorrowType === "borrow",
							tone: "borrow",
							onClick: () => setBorrowType("borrow"),
							children: t(lang, "btnBorrow")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeBtn, {
							active: currentBorrowType === "return",
							tone: "return",
							onClick: () => setBorrowType("return"),
							children: t(lang, "btnReturn")
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "quantity") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						step: 1,
						inputMode: "numeric",
						required: true,
						value: quantity,
						onChange: (e) => setQuantity(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "employee") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: employee,
						onChange: (e) => setEmployee(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "borrowNote") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: note,
						onChange: (e) => setNote(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "date") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "primary-btn",
					disabled: submitting,
					children: t(lang, currentBorrowType === "borrow" ? "btnBorrowSubmit" : "btnReturnSubmit")
				})
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-bold text-navy",
				children: t(lang, "borrowHistory")
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-center text-muted",
				children: t(lang, "noBorrowHistory")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryList, { items: shown }),
			borrowHistory.length > shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "primary-btn",
				onClick: loadMoreBorrow,
				children: [
					t(lang, "loadMore"),
					" (",
					shown.length,
					" ",
					t(lang, "of"),
					" ",
					borrowHistory.length,
					")"
				]
			}) : null
		]
	})] });
}
function HistoryPanel() {
	const lang = useWarehouse((s) => s.lang);
	const history = useWarehouse((s) => s.history);
	const historyLimit = useWarehouse((s) => s.historyLimit);
	const stats = (0, import_react.useMemo)(() => {
		const map = {};
		for (const entry of history) {
			const name = entry.employee || "-";
			if (!map[name]) map[name] = {
				out: 0,
				in: 0
			};
			if (entry.type === "out") map[name].out += 1;
			else if (entry.type === "in") map[name].in += 1;
		}
		return Object.entries(map).sort((a, b) => b[1].out + b[1].in - (a[1].out + a[1].in));
	}, [history]);
	const shown = (0, import_react.useMemo)(() => [...history].sort((a, b) => entryTs(b) - entryTs(a)).slice(0, historyLimit), [history, historyLimit]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-lg font-bold text-navy",
			children: t(lang, "empStatsTitle")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b-2 border-line text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-2 text-start",
							children: t(lang, "thEmployee")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-2",
							children: t(lang, "thOutCount")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-2",
							children: t(lang, "thInCount")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-2",
							children: t(lang, "thTotalOps")
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: stats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 4,
					className: "p-4 text-center text-muted",
					children: t(lang, "noEmpStats")
				}) }) : stats.map(([name, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-2 text-start font-semibold",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-2 text-center tabular-nums text-bad",
							children: s.out
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-2 text-center tabular-nums text-ok",
							children: s.in
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-2 text-center font-bold tabular-nums",
							children: s.out + s.in
						})
					]
				}, name)) })]
			})
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-bold text-navy",
				children: t(lang, "historyTitle")
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-center text-muted",
				children: t(lang, "noHistory")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryList, { items: shown }),
			history.length > shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "primary-btn",
				onClick: loadMoreHistory,
				children: [
					t(lang, "loadMore"),
					" (",
					shown.length,
					" ",
					t(lang, "of"),
					" ",
					history.length,
					")"
				]
			}) : null
		]
	})] });
}
function ManagePanel() {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	const search = useWarehouse((s) => s.search);
	const submitting = useWarehouse((s) => s.submitting);
	const fileRef = (0, import_react.useRef)(null);
	const [ar, setAr] = (0, import_react.useState)("");
	const [fr, setFr] = (0, import_react.useState)("");
	const [en, setEn] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("");
	const [minQty, setMinQty] = (0, import_react.useState)("10");
	const [img, setImg] = (0, import_react.useState)("");
	const entries = Object.entries(inventory).filter(([key, item]) => matchesSearch(key, item, search));
	async function onPick(file) {
		if (!file) return;
		try {
			setImg(await compressImage(file));
		} catch (err) {
			showToast(String(err.message), "error");
		}
	}
	async function onAdd() {
		if (await addMaterial({
			ar,
			fr,
			en,
			unit,
			minQty,
			img
		})) {
			setAr("");
			setFr("");
			setEn("");
			setUnit("");
			setMinQty("10");
			setImg("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-bold text-navy",
				children: t(lang, "manageTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 rounded-lg border-2 border-dashed border-navy/30 bg-paper/50 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "mb-3 flex items-center gap-2 font-bold text-navy",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
							" ",
							t(lang, "addOffice")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "nameAr") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ar,
									onChange: (e) => setAr(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "nameFr") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: fr,
									onChange: (e) => setFr(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "nameEn") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: en,
									onChange: (e) => setEn(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "unit") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: unit,
									onChange: (e) => setUnit(e.target.value),
									placeholder: "قطعة"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "minQty") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 1,
									value: minQty,
									onChange: (e) => setMinQty(e.target.value)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "chip !bg-navy !text-paper",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-3.5" }),
									" ",
									t(lang, "chooseImg"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "hidden",
										onChange: (e) => void onPick(e.target.files?.[0])
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "chip !bg-navy-deep !text-paper",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5" }),
									" ",
									t(lang, "captureImg"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										capture: "environment",
										className: "hidden",
										onChange: (e) => void onPick(e.target.files?.[0])
									})
								]
							}),
							img ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img,
								alt: "",
								className: "size-16 rounded-md border border-line object-cover"
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: t(lang, "imagesHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "primary-btn max-w-xs",
						disabled: submitting,
						onClick: () => void onAdd(),
						children: t(lang, "btnAdd")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold text-navy",
					children: t(lang, "listOffice")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-1 rounded-md bg-navy px-3 py-1.5 text-xs text-paper",
							onClick: () => void exportExcel(),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-3.5" }),
								" ",
								t(lang, "exportExcel")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-1 rounded-md bg-navy px-3 py-1.5 text-xs text-paper",
							onClick: () => fileRef.current?.click(),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-3.5" }),
								" ",
								t(lang, "importExcel")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: ".xlsx,.xls,.csv",
							className: "hidden",
							onChange: (e) => {
								const file = e.target.files?.[0];
								if (file) importExcelFile(file);
								e.target.value = "";
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: entries.map(([key, item]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[40px_1fr_auto] items-center gap-2 rounded-md border border-line bg-paper/40 p-2 sm:grid-cols-[48px_1fr_1fr_80px_auto]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { src: item.img }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-bold",
								children: item.ar || key
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "truncate text-xs text-muted",
								children: [
									item.fr,
									" · ",
									item.en
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden text-xs text-muted sm:block",
							children: item.unit
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden text-xs tabular-nums sm:block",
							children: [
								item.qty,
								" / ",
								t(lang, "minQty"),
								" ",
								item.minQty
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-md bg-navy px-2 py-1 text-xs text-paper",
								onClick: () => openEdit(key),
								"aria-label": t(lang, "btnEdit"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-md bg-bad px-2 py-1 text-xs text-white",
								onClick: () => void deleteMaterial(key),
								"aria-label": t(lang, "btnDelete"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
							})]
						})
					]
				}, key))
			})
		]
	});
}
function MaterialSelect({ value, onChange }) {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "material") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value,
			onChange: (e) => onChange(e.target.value),
			required: true,
			children: Object.entries(inventory).map(([key, item]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: key,
				children: getName(item, key, lang)
			}, key))
		})]
	});
}
function TypeBtn({ active, tone, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `rounded-md border-2 px-3 py-2 text-sm ${active ? `${tone === "out" ? "border-bad bg-paper text-bad" : tone === "in" ? "border-ok bg-paper text-ok" : tone === "borrow" ? "border-warn bg-paper text-warn" : "border-cyan bg-paper text-cyan-dark"} font-bold` : "border-line bg-white text-ink"}`,
		children
	});
}
function HistoryList({ items }) {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid max-h-[420px] gap-2 overflow-y-auto",
		children: items.map((entry) => {
			const tone = entry.type === "in" ? "border-s-ok bg-paper" : entry.type === "borrow" ? "border-s-warn bg-paper" : entry.type === "return" ? "border-s-cyan bg-paper" : "border-s-bad bg-paper";
			const item = inventory[entry.material];
			const name = item ? getName(item, entry.material, lang) : entry.material;
			const color = entry.type === "in" ? "var(--color-ok)" : entry.type === "borrow" ? "var(--color-warn)" : entry.type === "return" ? "var(--color-cyan)" : "var(--color-bad)";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `grid grid-cols-2 gap-2 rounded-md border-s-4 p-3 text-sm ${tone}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] font-bold text-cyan-dark",
						children: "Office"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold",
						children: name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted",
						children: [entry.employee, entry.note ? ` · ${entry.note}` : ""]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-bold",
						style: { color },
						children: [
							entry.qty > 0 && (entry.type === "in" || entry.type === "out") ? "+" : "",
							entry.qty,
							" ",
							typeLabel(entry.type, lang)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted",
						children: entry.date
					})]
				})]
			}, entry.id);
		})
	});
}
function EditModal() {
	const lang = useWarehouse((s) => s.lang);
	const editingKey = useWarehouse((s) => s.editingKey);
	const inventory = useWarehouse((s) => s.inventory);
	const submitting = useWarehouse((s) => s.submitting);
	const item = editingKey ? inventory[editingKey] : null;
	const [ar, setAr] = (0, import_react.useState)("");
	const [fr, setFr] = (0, import_react.useState)("");
	const [en, setEn] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("");
	const [minQty, setMinQty] = (0, import_react.useState)("10");
	const [img, setImg] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!item || !editingKey) return;
		setAr(item.ar || editingKey);
		setFr(item.fr || editingKey);
		setEn(item.en || editingKey);
		setUnit(item.unit || "");
		setMinQty(String(item.minQty || 10));
		setImg(item.img || "");
	}, [editingKey, item]);
	async function onPick(file) {
		if (!file) return;
		try {
			setImg(await compressImage(file));
		} catch (err) {
			showToast(String(err.message), "error");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: Boolean(editingKey && item),
		onOpenChange: (open) => !open && closeEdit(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-black/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed top-1/2 left-1/2 z-50 max-h-[80vh] w-[min(500px,92vw)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-lg bg-card p-5 shadow-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-lg font-bold text-navy",
						children: t(lang, "editTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "sr-only",
						children: t(lang, "editTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "text-muted hover:text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})
				]
			}), editingKey && item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "nameAr") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: ar,
							onChange: (e) => setAr(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "nameFr") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: fr,
							onChange: (e) => setFr(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "nameEn") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: en,
							onChange: (e) => setEn(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "unit") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: unit,
								onChange: (e) => setUnit(e.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t(lang, "minQty") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								value: minQty,
								onChange: (e) => setMinQty(e.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [
							img ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img,
								alt: "",
								className: "size-16 rounded-md border border-line object-cover"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "chip !bg-navy !text-paper",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-3.5" }),
									" ",
									t(lang, "changeImg"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "hidden",
										onChange: (e) => void onPick(e.target.files?.[0])
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "chip !bg-navy-deep !text-paper",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5" }),
									" ",
									t(lang, "captureImg"),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										capture: "environment",
										className: "hidden",
										onChange: (e) => void onPick(e.target.files?.[0])
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "primary-btn",
						disabled: submitting,
						onClick: () => void saveEdit({
							key: editingKey,
							ar,
							fr,
							en,
							unit,
							minQty,
							img: img && img !== item.img ? img : void 0
						}),
						children: t(lang, "btnSave")
					})
				]
			}) : null]
		})] })
	});
}
var TABS = [
	{
		id: "dashboard",
		key: "tabDashboard",
		icon: LayoutDashboard
	},
	{
		id: "register",
		key: "tabRegister",
		icon: ClipboardPen,
		admin: true
	},
	{
		id: "inventory",
		key: "tabInventory",
		icon: Package
	},
	{
		id: "borrow",
		key: "tabBorrow",
		icon: ArrowLeftRight,
		admin: true
	},
	{
		id: "history",
		key: "tabHistory",
		icon: History
	},
	{
		id: "manage",
		key: "tabManage",
		icon: Settings2,
		admin: true
	}
];
function WarehouseApp() {
	const ready = useWarehouse((s) => s.ready);
	const isAdmin = useWarehouse((s) => s.isAdmin);
	const lang = useWarehouse((s) => s.lang);
	const tab = useWarehouse((s) => s.tab);
	const search = useWarehouse((s) => s.search);
	const toasts = useWarehouse((s) => s.toasts);
	(0, import_react.useEffect)(() => {
		initWarehouse();
		document.documentElement.lang = "ar";
		document.documentElement.dir = "rtl";
		return () => destroyWarehouse();
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang === "ar" ? "ar" : lang;
		document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
	}, [lang]);
	const visibleTabs = (0, import_react.useMemo)(() => TABS.filter((item) => item.admin ? isAdmin : true), [isAdmin]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-navy-deep text-ink",
		children: [
			!isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginOverlay, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SyncBar, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsRow, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3 pb-2 sm:px-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 rounded-md border border-white/10 bg-navy px-3 py-2 text-paper",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0 opacity-70" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: search,
									onChange: (e) => setSearch(e.target.value),
									placeholder: t(lang, "searchPlaceholder"),
									className: "w-full bg-transparent text-sm text-paper outline-none placeholder:text-paper/50"
								}),
								search ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSearch(""),
									className: "text-paper/70 hover:text-paper",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
								}) : null
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex gap-1 overflow-x-auto border-b border-white/10 bg-navy-deep/80 px-2",
						children: visibleTabs.map((item) => {
							const Icon = item.icon;
							const active = tab === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setTab(item.id),
								className: cn("flex shrink-0 items-center gap-2 border-b-2 px-3 py-3 text-sm transition", active ? "border-paper bg-white/10 font-semibold text-paper" : "border-transparent text-paper/70 hover:bg-white/5 hover:text-paper"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), t(lang, item.key)]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "px-3 py-4 sm:px-4",
						children: !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-center gap-2 py-16 text-paper/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }), t(lang, "syncSyncing")]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							tab === "dashboard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardPanel, {}) : null,
							tab === "register" && isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegisterPanel, {}) : null,
							tab === "inventory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InventoryPanel, {}) : null,
							tab === "borrow" && isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BorrowPanel, {}) : null,
							tab === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, {}) : null,
							tab === "manage" && isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManagePanel, {}) : null
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "px-4 pb-8 pt-2 text-center text-xs text-paper/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"MAPA İNŞAAT ve TİCARET A.Ş. · ",
							t(lang, "footerText"),
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { lang })
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-semibold tracking-wide text-gold",
							children: t(lang, "signature")
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditModal, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed top-4 z-50 flex w-full max-w-sm flex-col gap-2 px-3 start-0",
				children: toasts.map((toast) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("pointer-events-auto flex items-start gap-2 rounded-md px-3 py-3 text-sm text-white shadow-lg", toast.type === "success" && "bg-ok", toast.type === "error" && "bg-bad", toast.type === "warning" && "bg-warn", toast.type === "info" && "bg-cyan"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex-1 text-pretty",
						children: toast.message
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => dismissToast(toast.id),
						className: "opacity-80 hover:opacity-100",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}, toast.id))
			})
		]
	});
}
function TopBar() {
	const lang = useWarehouse((s) => s.lang);
	const isAdmin = useWarehouse((s) => s.isAdmin);
	const jsonRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-2 bg-navy-deep/90 px-3 py-2 sm:px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-full border border-gold/40 bg-white/10 px-3 py-1 text-xs font-semibold tracking-wide text-gold",
			children: t(lang, "signature")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "chip",
					onClick: exportJson,
					title: t(lang, "exportJson"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), t(lang, "exportJson")]
				}),
				isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "chip",
					onClick: () => jsonRef.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }), t(lang, "importJson")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: jsonRef,
					type: "file",
					accept: ".json",
					className: "hidden",
					onChange: (e) => {
						const file = e.target.files?.[0];
						if (file) importJsonFile(file);
						e.target.value = "";
					}
				})] }) : null,
				isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "chip",
					onClick: logout,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3.5" }), t(lang, "logout")]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					children: [
						"ar",
						"fr",
						"en"
					].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setLang(code),
						className: cn("chip", lang === code && "bg-paper text-ink"),
						children: code === "ar" ? "العربية" : code === "fr" ? "Français" : "English"
					}, code))
				})
			]
		})]
	});
}
function SyncBar() {
	const lang = useWarehouse((s) => s.lang);
	const status = useWarehouse((s) => s.syncStatus);
	const label = status === "online" ? t(lang, "syncOnline") : status === "offline" ? t(lang, "syncOffline") : status === "error" ? t(lang, "syncError") : t(lang, "syncSyncing");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 bg-navy px-4 py-2 text-xs text-paper/90",
		children: [status === "online" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-3.5 text-ok" }) : status === "syncing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin text-cyan" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudOff, { className: "size-3.5 text-warn" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function Header() {
	const lang = useWarehouse((s) => s.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "bg-navy px-4 pb-6 pt-5 text-center text-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mb-3 flex max-w-md flex-col items-center rounded-lg bg-cyan px-5 py-3 shadow-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/logo.svg",
					alt: "MAPA",
					className: "h-14 w-auto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-sm font-bold tracking-wide",
					children: t(lang, "companyName")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-balance text-2xl font-bold sm:text-3xl",
				children: t(lang, "appTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-paper/80",
				children: t(lang, "appSubtitle")
			})
		]
	});
}
function StatsRow() {
	const lang = useWarehouse((s) => s.lang);
	const inventory = useWarehouse((s) => s.inventory);
	const history = useWarehouse((s) => s.history);
	const items = Object.values(inventory);
	const totalQty = items.reduce((s, i) => s + (i.qty || 0), 0);
	const lowStock = items.filter((i) => i.qty < (i.minQty || 10) && i.qty >= 0).length;
	const borrowed = items.reduce((s, i) => s + (i.borrowed || 0), 0);
	const cards = [
		{
			n: totalQty,
			k: "totalQty"
		},
		{
			n: lowStock,
			k: "lowStock"
		},
		{
			n: items.length,
			k: "totalItems"
		},
		{
			n: history.length,
			k: "totalOps"
		},
		{
			n: borrowed,
			k: "borrowedCount"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "grid grid-cols-2 gap-2 px-3 py-4 sm:grid-cols-5 sm:px-4",
		children: cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border border-white/15 bg-white/10 px-3 py-3 text-center text-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-2xl font-bold tabular-nums",
				children: c.n
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-[11px] text-paper/75",
				children: t(lang, c.k)
			})]
		}, c.k))
	});
}
function Clock({ lang }) {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	if (!now) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums",
		children: "—"
	});
	const locale = lang === "ar" ? "ar-EG" : lang === "fr" ? "fr-FR" : "en-US";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums",
		children: now.toLocaleString(locale, {
			year: "numeric",
			month: "short",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			numberingSystem: "latn"
		})
	});
}
function LoginOverlay() {
	const lang = useWarehouse((s) => s.lang);
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit() {
		setBusy(true);
		const ok = await login(password);
		setBusy(false);
		if (!ok) {
			setError(true);
			setPassword("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-center justify-center bg-navy-deep/90 px-4 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm rounded-lg bg-card p-6 text-center shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warehouse, { className: "mx-auto mb-2 size-10 text-cyan" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold text-navy",
					children: t(lang, "loginTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 mb-4 text-sm text-muted",
					children: t(lang, "loginSub")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					value: password,
					dir: "ltr",
					autoComplete: "current-password",
					placeholder: t(lang, "passwordPlaceholder"),
					onChange: (e) => {
						setPassword(e.target.value);
						setError(false);
					},
					onKeyDown: (e) => {
						if (e.key === "Enter") onSubmit();
					},
					className: "mb-3 w-full rounded-md border-2 border-line px-3 py-2 text-left text-base outline-none focus:border-navy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void onSubmit(),
					className: "w-full rounded-md bg-navy py-2.5 text-base font-bold text-paper disabled:opacity-60",
					children: t(lang, "loginBtn")
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-center justify-center gap-1 text-sm text-bad",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }), t(lang, "loginError")]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 border-t border-line pt-3 text-xs text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold tracking-wide text-gold",
						children: t(lang, "signature")
					})
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WarehouseApp, {});
}
//#endregion
export { Home as component };
