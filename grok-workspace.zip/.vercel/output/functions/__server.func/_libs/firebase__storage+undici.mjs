import { i as __require, t as __commonJSMin } from "../_runtime.mjs";
import { d as FirebaseError, f as createMockUserToken, i as getApp, m as getModularInstance, n as _getProvider, p as getDefaultEmulatorHostnameAndPort, r as _registerComponent, s as registerVersion, t as SDK_VERSION, u as Component } from "./@firebase/app+[...].mjs";
import { t as require_main } from "./fastify__busboy.mjs";
//#region node_modules/undici/lib/core/symbols.js
var require_symbols$4 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		kClose: Symbol("close"),
		kDestroy: Symbol("destroy"),
		kDispatch: Symbol("dispatch"),
		kUrl: Symbol("url"),
		kWriting: Symbol("writing"),
		kResuming: Symbol("resuming"),
		kQueue: Symbol("queue"),
		kConnect: Symbol("connect"),
		kConnecting: Symbol("connecting"),
		kHeadersList: Symbol("headers list"),
		kKeepAliveDefaultTimeout: Symbol("default keep alive timeout"),
		kKeepAliveMaxTimeout: Symbol("max keep alive timeout"),
		kKeepAliveTimeoutThreshold: Symbol("keep alive timeout threshold"),
		kKeepAliveTimeoutValue: Symbol("keep alive timeout"),
		kKeepAlive: Symbol("keep alive"),
		kHeadersTimeout: Symbol("headers timeout"),
		kBodyTimeout: Symbol("body timeout"),
		kServerName: Symbol("server name"),
		kLocalAddress: Symbol("local address"),
		kHost: Symbol("host"),
		kNoRef: Symbol("no ref"),
		kBodyUsed: Symbol("used"),
		kRunning: Symbol("running"),
		kBlocking: Symbol("blocking"),
		kPending: Symbol("pending"),
		kSize: Symbol("size"),
		kBusy: Symbol("busy"),
		kQueued: Symbol("queued"),
		kFree: Symbol("free"),
		kConnected: Symbol("connected"),
		kClosed: Symbol("closed"),
		kNeedDrain: Symbol("need drain"),
		kReset: Symbol("reset"),
		kDestroyed: Symbol.for("nodejs.stream.destroyed"),
		kMaxHeadersSize: Symbol("max headers size"),
		kRunningIdx: Symbol("running index"),
		kPendingIdx: Symbol("pending index"),
		kError: Symbol("error"),
		kClients: Symbol("clients"),
		kClient: Symbol("client"),
		kParser: Symbol("parser"),
		kOnDestroyed: Symbol("destroy callbacks"),
		kPipelining: Symbol("pipelining"),
		kSocket: Symbol("socket"),
		kHostHeader: Symbol("host header"),
		kConnector: Symbol("connector"),
		kStrictContentLength: Symbol("strict content length"),
		kMaxRedirections: Symbol("maxRedirections"),
		kMaxRequests: Symbol("maxRequestsPerClient"),
		kProxy: Symbol("proxy agent options"),
		kCounter: Symbol("socket request counter"),
		kInterceptors: Symbol("dispatch interceptors"),
		kMaxResponseSize: Symbol("max response size"),
		kHTTP2Session: Symbol("http2Session"),
		kHTTP2SessionState: Symbol("http2Session state"),
		kHTTP2BuildRequest: Symbol("http2 build request"),
		kHTTP1BuildRequest: Symbol("http1 build request"),
		kHTTP2CopyHeaders: Symbol("http2 copy headers"),
		kHTTPConnVersion: Symbol("http connection version"),
		kRetryHandlerDefaultRetry: Symbol("retry agent default retry"),
		kConstruct: Symbol("constructable")
	};
}));
//#endregion
//#region node_modules/undici/lib/core/errors.js
var require_errors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var UndiciError = class extends Error {
		constructor(message) {
			super(message);
			this.name = "UndiciError";
			this.code = "UND_ERR";
		}
	};
	var ConnectTimeoutError = class ConnectTimeoutError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, ConnectTimeoutError);
			this.name = "ConnectTimeoutError";
			this.message = message || "Connect Timeout Error";
			this.code = "UND_ERR_CONNECT_TIMEOUT";
		}
	};
	var HeadersTimeoutError = class HeadersTimeoutError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, HeadersTimeoutError);
			this.name = "HeadersTimeoutError";
			this.message = message || "Headers Timeout Error";
			this.code = "UND_ERR_HEADERS_TIMEOUT";
		}
	};
	var HeadersOverflowError = class HeadersOverflowError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, HeadersOverflowError);
			this.name = "HeadersOverflowError";
			this.message = message || "Headers Overflow Error";
			this.code = "UND_ERR_HEADERS_OVERFLOW";
		}
	};
	var BodyTimeoutError = class BodyTimeoutError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, BodyTimeoutError);
			this.name = "BodyTimeoutError";
			this.message = message || "Body Timeout Error";
			this.code = "UND_ERR_BODY_TIMEOUT";
		}
	};
	var ResponseStatusCodeError = class ResponseStatusCodeError extends UndiciError {
		constructor(message, statusCode, headers, body) {
			super(message);
			Error.captureStackTrace(this, ResponseStatusCodeError);
			this.name = "ResponseStatusCodeError";
			this.message = message || "Response Status Code Error";
			this.code = "UND_ERR_RESPONSE_STATUS_CODE";
			this.body = body;
			this.status = statusCode;
			this.statusCode = statusCode;
			this.headers = headers;
		}
	};
	var InvalidArgumentError = class InvalidArgumentError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, InvalidArgumentError);
			this.name = "InvalidArgumentError";
			this.message = message || "Invalid Argument Error";
			this.code = "UND_ERR_INVALID_ARG";
		}
	};
	var InvalidReturnValueError = class InvalidReturnValueError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, InvalidReturnValueError);
			this.name = "InvalidReturnValueError";
			this.message = message || "Invalid Return Value Error";
			this.code = "UND_ERR_INVALID_RETURN_VALUE";
		}
	};
	var RequestAbortedError = class RequestAbortedError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, RequestAbortedError);
			this.name = "AbortError";
			this.message = message || "Request aborted";
			this.code = "UND_ERR_ABORTED";
		}
	};
	var InformationalError = class InformationalError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, InformationalError);
			this.name = "InformationalError";
			this.message = message || "Request information";
			this.code = "UND_ERR_INFO";
		}
	};
	var RequestContentLengthMismatchError = class RequestContentLengthMismatchError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, RequestContentLengthMismatchError);
			this.name = "RequestContentLengthMismatchError";
			this.message = message || "Request body length does not match content-length header";
			this.code = "UND_ERR_REQ_CONTENT_LENGTH_MISMATCH";
		}
	};
	var ResponseContentLengthMismatchError = class ResponseContentLengthMismatchError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, ResponseContentLengthMismatchError);
			this.name = "ResponseContentLengthMismatchError";
			this.message = message || "Response body length does not match content-length header";
			this.code = "UND_ERR_RES_CONTENT_LENGTH_MISMATCH";
		}
	};
	var ClientDestroyedError = class ClientDestroyedError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, ClientDestroyedError);
			this.name = "ClientDestroyedError";
			this.message = message || "The client is destroyed";
			this.code = "UND_ERR_DESTROYED";
		}
	};
	var ClientClosedError = class ClientClosedError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, ClientClosedError);
			this.name = "ClientClosedError";
			this.message = message || "The client is closed";
			this.code = "UND_ERR_CLOSED";
		}
	};
	var SocketError = class SocketError extends UndiciError {
		constructor(message, socket) {
			super(message);
			Error.captureStackTrace(this, SocketError);
			this.name = "SocketError";
			this.message = message || "Socket error";
			this.code = "UND_ERR_SOCKET";
			this.socket = socket;
		}
	};
	var NotSupportedError = class NotSupportedError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, NotSupportedError);
			this.name = "NotSupportedError";
			this.message = message || "Not supported error";
			this.code = "UND_ERR_NOT_SUPPORTED";
		}
	};
	var BalancedPoolMissingUpstreamError = class extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, NotSupportedError);
			this.name = "MissingUpstreamError";
			this.message = message || "No upstream has been added to the BalancedPool";
			this.code = "UND_ERR_BPL_MISSING_UPSTREAM";
		}
	};
	module.exports = {
		HTTPParserError: class HTTPParserError extends Error {
			constructor(message, code, data) {
				super(message);
				Error.captureStackTrace(this, HTTPParserError);
				this.name = "HTTPParserError";
				this.code = code ? `HPE_${code}` : void 0;
				this.data = data ? data.toString() : void 0;
			}
		},
		UndiciError,
		HeadersTimeoutError,
		HeadersOverflowError,
		BodyTimeoutError,
		RequestContentLengthMismatchError,
		ConnectTimeoutError,
		ResponseStatusCodeError,
		InvalidArgumentError,
		InvalidReturnValueError,
		RequestAbortedError,
		ClientDestroyedError,
		ClientClosedError,
		InformationalError,
		SocketError,
		NotSupportedError,
		ResponseContentLengthMismatchError,
		BalancedPoolMissingUpstreamError,
		ResponseExceededMaxSizeError: class ResponseExceededMaxSizeError extends UndiciError {
			constructor(message) {
				super(message);
				Error.captureStackTrace(this, ResponseExceededMaxSizeError);
				this.name = "ResponseExceededMaxSizeError";
				this.message = message || "Response content exceeded max size";
				this.code = "UND_ERR_RES_EXCEEDED_MAX_SIZE";
			}
		},
		RequestRetryError: class RequestRetryError extends UndiciError {
			constructor(message, code, { headers, data }) {
				super(message);
				Error.captureStackTrace(this, RequestRetryError);
				this.name = "RequestRetryError";
				this.message = message || "Request retry error";
				this.code = "UND_ERR_REQ_RETRY";
				this.statusCode = code;
				this.data = data;
				this.headers = headers;
			}
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/core/constants.js
var require_constants$4 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/** @type {Record<string, string | undefined>} */
	var headerNameLowerCasedRecord = {};
	var wellknownHeaderNames = [
		"Accept",
		"Accept-Encoding",
		"Accept-Language",
		"Accept-Ranges",
		"Access-Control-Allow-Credentials",
		"Access-Control-Allow-Headers",
		"Access-Control-Allow-Methods",
		"Access-Control-Allow-Origin",
		"Access-Control-Expose-Headers",
		"Access-Control-Max-Age",
		"Access-Control-Request-Headers",
		"Access-Control-Request-Method",
		"Age",
		"Allow",
		"Alt-Svc",
		"Alt-Used",
		"Authorization",
		"Cache-Control",
		"Clear-Site-Data",
		"Connection",
		"Content-Disposition",
		"Content-Encoding",
		"Content-Language",
		"Content-Length",
		"Content-Location",
		"Content-Range",
		"Content-Security-Policy",
		"Content-Security-Policy-Report-Only",
		"Content-Type",
		"Cookie",
		"Cross-Origin-Embedder-Policy",
		"Cross-Origin-Opener-Policy",
		"Cross-Origin-Resource-Policy",
		"Date",
		"Device-Memory",
		"Downlink",
		"ECT",
		"ETag",
		"Expect",
		"Expect-CT",
		"Expires",
		"Forwarded",
		"From",
		"Host",
		"If-Match",
		"If-Modified-Since",
		"If-None-Match",
		"If-Range",
		"If-Unmodified-Since",
		"Keep-Alive",
		"Last-Modified",
		"Link",
		"Location",
		"Max-Forwards",
		"Origin",
		"Permissions-Policy",
		"Pragma",
		"Proxy-Authenticate",
		"Proxy-Authorization",
		"RTT",
		"Range",
		"Referer",
		"Referrer-Policy",
		"Refresh",
		"Retry-After",
		"Sec-WebSocket-Accept",
		"Sec-WebSocket-Extensions",
		"Sec-WebSocket-Key",
		"Sec-WebSocket-Protocol",
		"Sec-WebSocket-Version",
		"Server",
		"Server-Timing",
		"Service-Worker-Allowed",
		"Service-Worker-Navigation-Preload",
		"Set-Cookie",
		"SourceMap",
		"Strict-Transport-Security",
		"Supports-Loading-Mode",
		"TE",
		"Timing-Allow-Origin",
		"Trailer",
		"Transfer-Encoding",
		"Upgrade",
		"Upgrade-Insecure-Requests",
		"User-Agent",
		"Vary",
		"Via",
		"WWW-Authenticate",
		"X-Content-Type-Options",
		"X-DNS-Prefetch-Control",
		"X-Frame-Options",
		"X-Permitted-Cross-Domain-Policies",
		"X-Powered-By",
		"X-Requested-With",
		"X-XSS-Protection"
	];
	for (let i = 0; i < wellknownHeaderNames.length; ++i) {
		const key = wellknownHeaderNames[i];
		const lowerCasedKey = key.toLowerCase();
		headerNameLowerCasedRecord[key] = headerNameLowerCasedRecord[lowerCasedKey] = lowerCasedKey;
	}
	Object.setPrototypeOf(headerNameLowerCasedRecord, null);
	module.exports = {
		wellknownHeaderNames,
		headerNameLowerCasedRecord
	};
}));
//#endregion
//#region node_modules/undici/lib/core/util.js
var require_util$6 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$20 = __require("assert");
	var { kDestroyed, kBodyUsed } = require_symbols$4();
	var { IncomingMessage } = __require("http");
	var stream = __require("stream");
	var net$2 = __require("net");
	var { InvalidArgumentError } = require_errors();
	var { Blob: Blob$4 } = __require("buffer");
	var nodeUtil = __require("util");
	var { stringify } = __require("querystring");
	var { headerNameLowerCasedRecord } = require_constants$4();
	var [nodeMajor, nodeMinor] = process.versions.node.split(".").map((v) => Number(v));
	function nop() {}
	function isStream(obj) {
		return obj && typeof obj === "object" && typeof obj.pipe === "function" && typeof obj.on === "function";
	}
	function isBlobLike(object) {
		return Blob$4 && object instanceof Blob$4 || object && typeof object === "object" && (typeof object.stream === "function" || typeof object.arrayBuffer === "function") && /^(Blob|File)$/.test(object[Symbol.toStringTag]);
	}
	function buildURL(url, queryParams) {
		if (url.includes("?") || url.includes("#")) throw new Error("Query params cannot be passed when url already contains \"?\" or \"#\".");
		const stringified = stringify(queryParams);
		if (stringified) url += "?" + stringified;
		return url;
	}
	function parseURL(url) {
		if (typeof url === "string") {
			url = new URL(url);
			if (!/^https?:/.test(url.origin || url.protocol)) throw new InvalidArgumentError("Invalid URL protocol: the URL must start with `http:` or `https:`.");
			return url;
		}
		if (!url || typeof url !== "object") throw new InvalidArgumentError("Invalid URL: The URL argument must be a non-null object.");
		if (!/^https?:/.test(url.origin || url.protocol)) throw new InvalidArgumentError("Invalid URL protocol: the URL must start with `http:` or `https:`.");
		if (!(url instanceof URL)) {
			if (url.port != null && url.port !== "" && !Number.isFinite(parseInt(url.port))) throw new InvalidArgumentError("Invalid URL: port must be a valid integer or a string representation of an integer.");
			if (url.path != null && typeof url.path !== "string") throw new InvalidArgumentError("Invalid URL path: the path must be a string or null/undefined.");
			if (url.pathname != null && typeof url.pathname !== "string") throw new InvalidArgumentError("Invalid URL pathname: the pathname must be a string or null/undefined.");
			if (url.hostname != null && typeof url.hostname !== "string") throw new InvalidArgumentError("Invalid URL hostname: the hostname must be a string or null/undefined.");
			if (url.origin != null && typeof url.origin !== "string") throw new InvalidArgumentError("Invalid URL origin: the origin must be a string or null/undefined.");
			const port = url.port != null ? url.port : url.protocol === "https:" ? 443 : 80;
			let origin = url.origin != null ? url.origin : `${url.protocol}//${url.hostname}:${port}`;
			let path = url.path != null ? url.path : `${url.pathname || ""}${url.search || ""}`;
			if (origin.endsWith("/")) origin = origin.substring(0, origin.length - 1);
			if (path && !path.startsWith("/")) path = `/${path}`;
			url = new URL(origin + path);
		}
		return url;
	}
	function parseOrigin(url) {
		url = parseURL(url);
		if (url.pathname !== "/" || url.search || url.hash) throw new InvalidArgumentError("invalid url");
		return url;
	}
	function getHostname(host) {
		if (host[0] === "[") {
			const idx = host.indexOf("]");
			assert$20(idx !== -1);
			return host.substring(1, idx);
		}
		const idx = host.indexOf(":");
		if (idx === -1) return host;
		return host.substring(0, idx);
	}
	function getServerName(host) {
		if (!host) return null;
		assert$20.strictEqual(typeof host, "string");
		const servername = getHostname(host);
		if (net$2.isIP(servername)) return "";
		return servername;
	}
	function deepClone(obj) {
		return JSON.parse(JSON.stringify(obj));
	}
	function isAsyncIterable(obj) {
		return !!(obj != null && typeof obj[Symbol.asyncIterator] === "function");
	}
	function isIterable(obj) {
		return !!(obj != null && (typeof obj[Symbol.iterator] === "function" || typeof obj[Symbol.asyncIterator] === "function"));
	}
	function bodyLength(body) {
		if (body == null) return 0;
		else if (isStream(body)) {
			const state = body._readableState;
			return state && state.objectMode === false && state.ended === true && Number.isFinite(state.length) ? state.length : null;
		} else if (isBlobLike(body)) return body.size != null ? body.size : null;
		else if (isBuffer(body)) return body.byteLength;
		return null;
	}
	function isDestroyed(stream) {
		return !stream || !!(stream.destroyed || stream[kDestroyed]);
	}
	function isReadableAborted(stream) {
		const state = stream && stream._readableState;
		return isDestroyed(stream) && state && !state.endEmitted;
	}
	function destroy(stream, err) {
		if (stream == null || !isStream(stream) || isDestroyed(stream)) return;
		if (typeof stream.destroy === "function") {
			if (Object.getPrototypeOf(stream).constructor === IncomingMessage) stream.socket = null;
			stream.destroy(err);
		} else if (err) process.nextTick((stream, err) => {
			stream.emit("error", err);
		}, stream, err);
		if (stream.destroyed !== true) stream[kDestroyed] = true;
	}
	var KEEPALIVE_TIMEOUT_EXPR = /timeout=(\d+)/;
	function parseKeepAliveTimeout(val) {
		const m = val.toString().match(KEEPALIVE_TIMEOUT_EXPR);
		return m ? parseInt(m[1], 10) * 1e3 : null;
	}
	/**
	* Retrieves a header name and returns its lowercase value.
	* @param {string | Buffer} value Header name
	* @returns {string}
	*/
	function headerNameToString(value) {
		return headerNameLowerCasedRecord[value] || value.toLowerCase();
	}
	function parseHeaders(headers, obj = {}) {
		if (!Array.isArray(headers)) return headers;
		for (let i = 0; i < headers.length; i += 2) {
			const key = headers[i].toString().toLowerCase();
			let val = obj[key];
			if (!val) {
				if (Array.isArray(headers[i + 1])) obj[key] = headers[i + 1].map((x) => x.toString("utf8"));
				else obj[key] = headers[i + 1].toString("utf8");
			} else {
				if (!Array.isArray(val)) {
					val = [val];
					obj[key] = val;
				}
				val.push(headers[i + 1].toString("utf8"));
			}
		}
		if ("content-length" in obj && "content-disposition" in obj) obj["content-disposition"] = Buffer.from(obj["content-disposition"]).toString("latin1");
		return obj;
	}
	function parseRawHeaders(headers) {
		const ret = [];
		let hasContentLength = false;
		let contentDispositionIdx = -1;
		for (let n = 0; n < headers.length; n += 2) {
			const key = headers[n + 0].toString();
			const val = headers[n + 1].toString("utf8");
			if (key.length === 14 && (key === "content-length" || key.toLowerCase() === "content-length")) {
				ret.push(key, val);
				hasContentLength = true;
			} else if (key.length === 19 && (key === "content-disposition" || key.toLowerCase() === "content-disposition")) contentDispositionIdx = ret.push(key, val) - 1;
			else ret.push(key, val);
		}
		if (hasContentLength && contentDispositionIdx !== -1) ret[contentDispositionIdx] = Buffer.from(ret[contentDispositionIdx]).toString("latin1");
		return ret;
	}
	function isBuffer(buffer) {
		return buffer instanceof Uint8Array || Buffer.isBuffer(buffer);
	}
	function validateHandler(handler, method, upgrade) {
		if (!handler || typeof handler !== "object") throw new InvalidArgumentError("handler must be an object");
		if (typeof handler.onConnect !== "function") throw new InvalidArgumentError("invalid onConnect method");
		if (typeof handler.onError !== "function") throw new InvalidArgumentError("invalid onError method");
		if (typeof handler.onBodySent !== "function" && handler.onBodySent !== void 0) throw new InvalidArgumentError("invalid onBodySent method");
		if (upgrade || method === "CONNECT") {
			if (typeof handler.onUpgrade !== "function") throw new InvalidArgumentError("invalid onUpgrade method");
		} else {
			if (typeof handler.onHeaders !== "function") throw new InvalidArgumentError("invalid onHeaders method");
			if (typeof handler.onData !== "function") throw new InvalidArgumentError("invalid onData method");
			if (typeof handler.onComplete !== "function") throw new InvalidArgumentError("invalid onComplete method");
		}
	}
	function isDisturbed(body) {
		return !!(body && (stream.isDisturbed ? stream.isDisturbed(body) || body[kBodyUsed] : body[kBodyUsed] || body.readableDidRead || body._readableState && body._readableState.dataEmitted || isReadableAborted(body)));
	}
	function isErrored(body) {
		return !!(body && (stream.isErrored ? stream.isErrored(body) : /state: 'errored'/.test(nodeUtil.inspect(body))));
	}
	function isReadable(body) {
		return !!(body && (stream.isReadable ? stream.isReadable(body) : /state: 'readable'/.test(nodeUtil.inspect(body))));
	}
	function getSocketInfo(socket) {
		return {
			localAddress: socket.localAddress,
			localPort: socket.localPort,
			remoteAddress: socket.remoteAddress,
			remotePort: socket.remotePort,
			remoteFamily: socket.remoteFamily,
			timeout: socket.timeout,
			bytesWritten: socket.bytesWritten,
			bytesRead: socket.bytesRead
		};
	}
	async function* convertIterableToBuffer(iterable) {
		for await (const chunk of iterable) yield Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
	}
	var ReadableStream;
	function ReadableStreamFrom(iterable) {
		if (!ReadableStream) ReadableStream = __require("stream/web").ReadableStream;
		if (ReadableStream.from) return ReadableStream.from(convertIterableToBuffer(iterable));
		let iterator;
		return new ReadableStream({
			async start() {
				iterator = iterable[Symbol.asyncIterator]();
			},
			async pull(controller) {
				const { done, value } = await iterator.next();
				if (done) queueMicrotask(() => {
					controller.close();
				});
				else {
					const buf = Buffer.isBuffer(value) ? value : Buffer.from(value);
					controller.enqueue(new Uint8Array(buf));
				}
				return controller.desiredSize > 0;
			},
			async cancel(reason) {
				await iterator.return();
			}
		}, 0);
	}
	function isFormDataLike(object) {
		return object && typeof object === "object" && typeof object.append === "function" && typeof object.delete === "function" && typeof object.get === "function" && typeof object.getAll === "function" && typeof object.has === "function" && typeof object.set === "function" && object[Symbol.toStringTag] === "FormData";
	}
	function throwIfAborted(signal) {
		if (!signal) return;
		if (typeof signal.throwIfAborted === "function") signal.throwIfAborted();
		else if (signal.aborted) {
			const err = /* @__PURE__ */ new Error("The operation was aborted");
			err.name = "AbortError";
			throw err;
		}
	}
	function addAbortListener(signal, listener) {
		if ("addEventListener" in signal) {
			signal.addEventListener("abort", listener, { once: true });
			return () => signal.removeEventListener("abort", listener);
		}
		signal.addListener("abort", listener);
		return () => signal.removeListener("abort", listener);
	}
	var hasToWellFormed = !!String.prototype.toWellFormed;
	/**
	* @param {string} val
	*/
	function toUSVString(val) {
		if (hasToWellFormed) return `${val}`.toWellFormed();
		else if (nodeUtil.toUSVString) return nodeUtil.toUSVString(val);
		return `${val}`;
	}
	function parseRangeHeader(range) {
		if (range == null || range === "") return {
			start: 0,
			end: null,
			size: null
		};
		const m = range ? range.match(/^bytes (\d+)-(\d+)\/(\d+)?$/) : null;
		return m ? {
			start: parseInt(m[1]),
			end: m[2] ? parseInt(m[2]) : null,
			size: m[3] ? parseInt(m[3]) : null
		} : null;
	}
	var kEnumerableProperty = Object.create(null);
	kEnumerableProperty.enumerable = true;
	module.exports = {
		kEnumerableProperty,
		nop,
		isDisturbed,
		isErrored,
		isReadable,
		toUSVString,
		isReadableAborted,
		isBlobLike,
		parseOrigin,
		parseURL,
		getServerName,
		isStream,
		isIterable,
		isAsyncIterable,
		isDestroyed,
		headerNameToString,
		parseRawHeaders,
		parseHeaders,
		parseKeepAliveTimeout,
		destroy,
		bodyLength,
		deepClone,
		ReadableStreamFrom,
		isBuffer,
		validateHandler,
		getSocketInfo,
		isFormDataLike,
		buildURL,
		throwIfAborted,
		addAbortListener,
		parseRangeHeader,
		nodeMajor,
		nodeMinor,
		nodeHasAutoSelectFamily: nodeMajor > 18 || nodeMajor === 18 && nodeMinor >= 13,
		safeHTTPMethods: [
			"GET",
			"HEAD",
			"OPTIONS",
			"TRACE"
		]
	};
}));
//#endregion
//#region node_modules/undici/lib/timers.js
var require_timers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var fastNow = Date.now();
	var fastNowTimeout;
	var fastTimers = [];
	function onTimeout() {
		fastNow = Date.now();
		let len = fastTimers.length;
		let idx = 0;
		while (idx < len) {
			const timer = fastTimers[idx];
			if (timer.state === 0) timer.state = fastNow + timer.delay;
			else if (timer.state > 0 && fastNow >= timer.state) {
				timer.state = -1;
				timer.callback(timer.opaque);
			}
			if (timer.state === -1) {
				timer.state = -2;
				if (idx !== len - 1) fastTimers[idx] = fastTimers.pop();
				else fastTimers.pop();
				len -= 1;
			} else idx += 1;
		}
		if (fastTimers.length > 0) refreshTimeout();
	}
	function refreshTimeout() {
		if (fastNowTimeout && fastNowTimeout.refresh) fastNowTimeout.refresh();
		else {
			clearTimeout(fastNowTimeout);
			fastNowTimeout = setTimeout(onTimeout, 1e3);
			if (fastNowTimeout.unref) fastNowTimeout.unref();
		}
	}
	var Timeout = class {
		constructor(callback, delay, opaque) {
			this.callback = callback;
			this.delay = delay;
			this.opaque = opaque;
			this.state = -2;
			this.refresh();
		}
		refresh() {
			if (this.state === -2) {
				fastTimers.push(this);
				if (!fastNowTimeout || fastTimers.length === 1) refreshTimeout();
			}
			this.state = 0;
		}
		clear() {
			this.state = -1;
		}
	};
	module.exports = {
		setTimeout(callback, delay, opaque) {
			return delay < 1e3 ? setTimeout(callback, delay, opaque) : new Timeout(callback, delay, opaque);
		},
		clearTimeout(timeout) {
			if (timeout instanceof Timeout) timeout.clear();
			else clearTimeout(timeout);
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/constants.js
var require_constants$3 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { MessageChannel, receiveMessageOnPort } = __require("worker_threads");
	var corsSafeListedMethods = [
		"GET",
		"HEAD",
		"POST"
	];
	var corsSafeListedMethodsSet = new Set(corsSafeListedMethods);
	var nullBodyStatus = [
		101,
		204,
		205,
		304
	];
	var redirectStatus = [
		301,
		302,
		303,
		307,
		308
	];
	var redirectStatusSet = new Set(redirectStatus);
	var badPorts = [
		"1",
		"7",
		"9",
		"11",
		"13",
		"15",
		"17",
		"19",
		"20",
		"21",
		"22",
		"23",
		"25",
		"37",
		"42",
		"43",
		"53",
		"69",
		"77",
		"79",
		"87",
		"95",
		"101",
		"102",
		"103",
		"104",
		"109",
		"110",
		"111",
		"113",
		"115",
		"117",
		"119",
		"123",
		"135",
		"137",
		"139",
		"143",
		"161",
		"179",
		"389",
		"427",
		"465",
		"512",
		"513",
		"514",
		"515",
		"526",
		"530",
		"531",
		"532",
		"540",
		"548",
		"554",
		"556",
		"563",
		"587",
		"601",
		"636",
		"989",
		"990",
		"993",
		"995",
		"1719",
		"1720",
		"1723",
		"2049",
		"3659",
		"4045",
		"5060",
		"5061",
		"6000",
		"6566",
		"6665",
		"6666",
		"6667",
		"6668",
		"6669",
		"6697",
		"10080"
	];
	var badPortsSet = new Set(badPorts);
	var referrerPolicy = [
		"",
		"no-referrer",
		"no-referrer-when-downgrade",
		"same-origin",
		"origin",
		"strict-origin",
		"origin-when-cross-origin",
		"strict-origin-when-cross-origin",
		"unsafe-url"
	];
	var referrerPolicySet = new Set(referrerPolicy);
	var requestRedirect = [
		"follow",
		"manual",
		"error"
	];
	var safeMethods = [
		"GET",
		"HEAD",
		"OPTIONS",
		"TRACE"
	];
	var safeMethodsSet = new Set(safeMethods);
	var requestMode = [
		"navigate",
		"same-origin",
		"no-cors",
		"cors"
	];
	var requestCredentials = [
		"omit",
		"same-origin",
		"include"
	];
	var requestCache = [
		"default",
		"no-store",
		"reload",
		"no-cache",
		"force-cache",
		"only-if-cached"
	];
	var requestBodyHeader = [
		"content-encoding",
		"content-language",
		"content-location",
		"content-type",
		"content-length"
	];
	var requestDuplex = ["half"];
	var forbiddenMethods = [
		"CONNECT",
		"TRACE",
		"TRACK"
	];
	var forbiddenMethodsSet = new Set(forbiddenMethods);
	var subresource = [
		"audio",
		"audioworklet",
		"font",
		"image",
		"manifest",
		"paintworklet",
		"script",
		"style",
		"track",
		"video",
		"xslt",
		""
	];
	var subresourceSet = new Set(subresource);
	/** @type {globalThis['DOMException']} */
	var DOMException = globalThis.DOMException ?? (() => {
		try {
			atob("~");
		} catch (err) {
			return Object.getPrototypeOf(err).constructor;
		}
	})();
	var channel;
	module.exports = {
		DOMException,
		structuredClone: globalThis.structuredClone ?? function structuredClone(value, options = void 0) {
			if (arguments.length === 0) throw new TypeError("missing argument");
			if (!channel) channel = new MessageChannel();
			channel.port1.unref();
			channel.port2.unref();
			channel.port1.postMessage(value, options?.transfer);
			return receiveMessageOnPort(channel.port2).message;
		},
		subresource,
		forbiddenMethods,
		requestBodyHeader,
		referrerPolicy,
		requestRedirect,
		requestMode,
		requestCredentials,
		requestCache,
		redirectStatus,
		corsSafeListedMethods,
		nullBodyStatus,
		safeMethods,
		badPorts,
		requestDuplex,
		subresourceSet,
		badPortsSet,
		redirectStatusSet,
		corsSafeListedMethodsSet,
		safeMethodsSet,
		forbiddenMethodsSet,
		referrerPolicySet
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/global.js
var require_global$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var globalOrigin = Symbol.for("undici.globalOrigin.1");
	function getGlobalOrigin() {
		return globalThis[globalOrigin];
	}
	function setGlobalOrigin(newOrigin) {
		if (newOrigin === void 0) {
			Object.defineProperty(globalThis, globalOrigin, {
				value: void 0,
				writable: true,
				enumerable: false,
				configurable: false
			});
			return;
		}
		const parsedURL = new URL(newOrigin);
		if (parsedURL.protocol !== "http:" && parsedURL.protocol !== "https:") throw new TypeError(`Only http & https urls are allowed, received ${parsedURL.protocol}`);
		Object.defineProperty(globalThis, globalOrigin, {
			value: parsedURL,
			writable: true,
			enumerable: false,
			configurable: false
		});
	}
	module.exports = {
		getGlobalOrigin,
		setGlobalOrigin
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/util.js
var require_util$5 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { redirectStatusSet, referrerPolicySet: referrerPolicyTokens, badPortsSet } = require_constants$3();
	var { getGlobalOrigin } = require_global$1();
	var { performance: performance$1 } = __require("perf_hooks");
	var { isBlobLike, toUSVString, ReadableStreamFrom } = require_util$6();
	var assert$19 = __require("assert");
	var { isUint8Array: isUint8Array$1 } = __require("util/types");
	var supportedHashes = [];
	/** @type {import('crypto')|undefined} */
	var crypto;
	try {
		crypto = __require("crypto");
		const possibleRelevantHashes = [
			"sha256",
			"sha384",
			"sha512"
		];
		supportedHashes = crypto.getHashes().filter((hash) => possibleRelevantHashes.includes(hash));
	} catch {}
	function responseURL(response) {
		const urlList = response.urlList;
		const length = urlList.length;
		return length === 0 ? null : urlList[length - 1].toString();
	}
	function responseLocationURL(response, requestFragment) {
		if (!redirectStatusSet.has(response.status)) return null;
		let location = response.headersList.get("location");
		if (location !== null && isValidHeaderValue(location)) location = new URL(location, responseURL(response));
		if (location && !location.hash) location.hash = requestFragment;
		return location;
	}
	/** @returns {URL} */
	function requestCurrentURL(request) {
		return request.urlList[request.urlList.length - 1];
	}
	function requestBadPort(request) {
		const url = requestCurrentURL(request);
		if (urlIsHttpHttpsScheme(url) && badPortsSet.has(url.port)) return "blocked";
		return "allowed";
	}
	function isErrorLike(object) {
		return object instanceof Error || object?.constructor?.name === "Error" || object?.constructor?.name === "DOMException";
	}
	function isValidReasonPhrase(statusText) {
		for (let i = 0; i < statusText.length; ++i) {
			const c = statusText.charCodeAt(i);
			if (!(c === 9 || c >= 32 && c <= 126 || c >= 128 && c <= 255)) return false;
		}
		return true;
	}
	/**
	* @see https://tools.ietf.org/html/rfc7230#section-3.2.6
	* @param {number} c
	*/
	function isTokenCharCode(c) {
		switch (c) {
			case 34:
			case 40:
			case 41:
			case 44:
			case 47:
			case 58:
			case 59:
			case 60:
			case 61:
			case 62:
			case 63:
			case 64:
			case 91:
			case 92:
			case 93:
			case 123:
			case 125: return false;
			default: return c >= 33 && c <= 126;
		}
	}
	/**
	* @param {string} characters
	*/
	function isValidHTTPToken(characters) {
		if (characters.length === 0) return false;
		for (let i = 0; i < characters.length; ++i) if (!isTokenCharCode(characters.charCodeAt(i))) return false;
		return true;
	}
	/**
	* @see https://fetch.spec.whatwg.org/#header-name
	* @param {string} potentialValue
	*/
	function isValidHeaderName(potentialValue) {
		return isValidHTTPToken(potentialValue);
	}
	/**
	* @see https://fetch.spec.whatwg.org/#header-value
	* @param {string} potentialValue
	*/
	function isValidHeaderValue(potentialValue) {
		if (potentialValue.startsWith("	") || potentialValue.startsWith(" ") || potentialValue.endsWith("	") || potentialValue.endsWith(" ")) return false;
		if (potentialValue.includes("\0") || potentialValue.includes("\r") || potentialValue.includes("\n")) return false;
		return true;
	}
	function setRequestReferrerPolicyOnRedirect(request, actualResponse) {
		const { headersList } = actualResponse;
		const policyHeader = (headersList.get("referrer-policy") ?? "").split(",");
		let policy = "";
		if (policyHeader.length > 0) for (let i = policyHeader.length; i !== 0; i--) {
			const token = policyHeader[i - 1].trim();
			if (referrerPolicyTokens.has(token)) {
				policy = token;
				break;
			}
		}
		if (policy !== "") request.referrerPolicy = policy;
	}
	function crossOriginResourcePolicyCheck() {
		return "allowed";
	}
	function corsCheck() {
		return "success";
	}
	function TAOCheck() {
		return "success";
	}
	function appendFetchMetadata(httpRequest) {
		let header = null;
		header = httpRequest.mode;
		httpRequest.headersList.set("sec-fetch-mode", header);
	}
	function appendRequestOriginHeader(request) {
		let serializedOrigin = request.origin;
		if (request.responseTainting === "cors" || request.mode === "websocket") {
			if (serializedOrigin) request.headersList.append("origin", serializedOrigin);
		} else if (request.method !== "GET" && request.method !== "HEAD") {
			switch (request.referrerPolicy) {
				case "no-referrer":
					serializedOrigin = null;
					break;
				case "no-referrer-when-downgrade":
				case "strict-origin":
				case "strict-origin-when-cross-origin":
					if (request.origin && urlHasHttpsScheme(request.origin) && !urlHasHttpsScheme(requestCurrentURL(request))) serializedOrigin = null;
					break;
				case "same-origin": if (!sameOrigin(request, requestCurrentURL(request))) serializedOrigin = null;
			}
			if (serializedOrigin) request.headersList.append("origin", serializedOrigin);
		}
	}
	function coarsenedSharedCurrentTime(crossOriginIsolatedCapability) {
		return performance$1.now();
	}
	function createOpaqueTimingInfo(timingInfo) {
		return {
			startTime: timingInfo.startTime ?? 0,
			redirectStartTime: 0,
			redirectEndTime: 0,
			postRedirectStartTime: timingInfo.startTime ?? 0,
			finalServiceWorkerStartTime: 0,
			finalNetworkResponseStartTime: 0,
			finalNetworkRequestStartTime: 0,
			endTime: 0,
			encodedBodySize: 0,
			decodedBodySize: 0,
			finalConnectionTimingInfo: null
		};
	}
	function makePolicyContainer() {
		return { referrerPolicy: "strict-origin-when-cross-origin" };
	}
	function clonePolicyContainer(policyContainer) {
		return { referrerPolicy: policyContainer.referrerPolicy };
	}
	function determineRequestsReferrer(request) {
		const policy = request.referrerPolicy;
		assert$19(policy);
		let referrerSource = null;
		if (request.referrer === "client") {
			const globalOrigin = getGlobalOrigin();
			if (!globalOrigin || globalOrigin.origin === "null") return "no-referrer";
			referrerSource = new URL(globalOrigin);
		} else if (request.referrer instanceof URL) referrerSource = request.referrer;
		let referrerURL = stripURLForReferrer(referrerSource);
		const referrerOrigin = stripURLForReferrer(referrerSource, true);
		if (referrerURL.toString().length > 4096) referrerURL = referrerOrigin;
		const areSameOrigin = sameOrigin(request, referrerURL);
		const isNonPotentiallyTrustWorthy = isURLPotentiallyTrustworthy(referrerURL) && !isURLPotentiallyTrustworthy(request.url);
		switch (policy) {
			case "origin": return referrerOrigin != null ? referrerOrigin : stripURLForReferrer(referrerSource, true);
			case "unsafe-url": return referrerURL;
			case "same-origin": return areSameOrigin ? referrerOrigin : "no-referrer";
			case "origin-when-cross-origin": return areSameOrigin ? referrerURL : referrerOrigin;
			case "strict-origin-when-cross-origin": {
				const currentURL = requestCurrentURL(request);
				if (sameOrigin(referrerURL, currentURL)) return referrerURL;
				if (isURLPotentiallyTrustworthy(referrerURL) && !isURLPotentiallyTrustworthy(currentURL)) return "no-referrer";
				return referrerOrigin;
			}
			/**
			* 1. If referrerURL is a potentially trustworthy URL and
			* request’s current URL is not a potentially trustworthy URL,
			* then return no referrer.
			* 2. Return referrerOrigin
			*/
			default: return isNonPotentiallyTrustWorthy ? "no-referrer" : referrerOrigin;
		}
	}
	/**
	* @see https://w3c.github.io/webappsec-referrer-policy/#strip-url
	* @param {URL} url
	* @param {boolean|undefined} originOnly
	*/
	function stripURLForReferrer(url, originOnly) {
		assert$19(url instanceof URL);
		if (url.protocol === "file:" || url.protocol === "about:" || url.protocol === "blank:") return "no-referrer";
		url.username = "";
		url.password = "";
		url.hash = "";
		if (originOnly) {
			url.pathname = "";
			url.search = "";
		}
		return url;
	}
	function isURLPotentiallyTrustworthy(url) {
		if (!(url instanceof URL)) return false;
		if (url.href === "about:blank" || url.href === "about:srcdoc") return true;
		if (url.protocol === "data:") return true;
		if (url.protocol === "file:") return true;
		return isOriginPotentiallyTrustworthy(url.origin);
		function isOriginPotentiallyTrustworthy(origin) {
			if (origin == null || origin === "null") return false;
			const originAsURL = new URL(origin);
			if (originAsURL.protocol === "https:" || originAsURL.protocol === "wss:") return true;
			if (/^127(?:\.[0-9]+){0,2}\.[0-9]+$|^\[(?:0*:)*?:?0*1\]$/.test(originAsURL.hostname) || originAsURL.hostname === "localhost" || originAsURL.hostname.includes("localhost.") || originAsURL.hostname.endsWith(".localhost")) return true;
			return false;
		}
	}
	/**
	* @see https://w3c.github.io/webappsec-subresource-integrity/#does-response-match-metadatalist
	* @param {Uint8Array} bytes
	* @param {string} metadataList
	*/
	function bytesMatch(bytes, metadataList) {
		/* istanbul ignore if: only if node is built with --without-ssl */
		if (crypto === void 0) return true;
		const parsedMetadata = parseMetadata(metadataList);
		if (parsedMetadata === "no metadata") return true;
		if (parsedMetadata.length === 0) return true;
		const metadata = filterMetadataListByAlgorithm(parsedMetadata, getStrongestMetadata(parsedMetadata));
		for (const item of metadata) {
			const algorithm = item.algo;
			const expectedValue = item.hash;
			let actualValue = crypto.createHash(algorithm).update(bytes).digest("base64");
			if (actualValue[actualValue.length - 1] === "=") {
				if (actualValue[actualValue.length - 2] === "=") actualValue = actualValue.slice(0, -2);
				else actualValue = actualValue.slice(0, -1);
			}
			if (compareBase64Mixed(actualValue, expectedValue)) return true;
		}
		return false;
	}
	var parseHashWithOptions = /(?<algo>sha256|sha384|sha512)-((?<hash>[A-Za-z0-9+/]+|[A-Za-z0-9_-]+)={0,2}(?:\s|$)( +[!-~]*)?)?/i;
	/**
	* @see https://w3c.github.io/webappsec-subresource-integrity/#parse-metadata
	* @param {string} metadata
	*/
	function parseMetadata(metadata) {
		/** @type {{ algo: string, hash: string }[]} */
		const result = [];
		let empty = true;
		for (const token of metadata.split(" ")) {
			empty = false;
			const parsedToken = parseHashWithOptions.exec(token);
			if (parsedToken === null || parsedToken.groups === void 0 || parsedToken.groups.algo === void 0) continue;
			const algorithm = parsedToken.groups.algo.toLowerCase();
			if (supportedHashes.includes(algorithm)) result.push(parsedToken.groups);
		}
		if (empty === true) return "no metadata";
		return result;
	}
	/**
	* @param {{ algo: 'sha256' | 'sha384' | 'sha512' }[]} metadataList
	*/
	function getStrongestMetadata(metadataList) {
		let algorithm = metadataList[0].algo;
		if (algorithm[3] === "5") return algorithm;
		for (let i = 1; i < metadataList.length; ++i) {
			const metadata = metadataList[i];
			if (metadata.algo[3] === "5") {
				algorithm = "sha512";
				break;
			} else if (algorithm[3] === "3") continue;
			else if (metadata.algo[3] === "3") algorithm = "sha384";
		}
		return algorithm;
	}
	function filterMetadataListByAlgorithm(metadataList, algorithm) {
		if (metadataList.length === 1) return metadataList;
		let pos = 0;
		for (let i = 0; i < metadataList.length; ++i) if (metadataList[i].algo === algorithm) metadataList[pos++] = metadataList[i];
		metadataList.length = pos;
		return metadataList;
	}
	/**
	* Compares two base64 strings, allowing for base64url
	* in the second string.
	*
	* @param {string} actualValue always base64
	* @param {string} expectedValue base64 or base64url
	* @returns {boolean}
	*/
	function compareBase64Mixed(actualValue, expectedValue) {
		if (actualValue.length !== expectedValue.length) return false;
		for (let i = 0; i < actualValue.length; ++i) if (actualValue[i] !== expectedValue[i]) {
			if (actualValue[i] === "+" && expectedValue[i] === "-" || actualValue[i] === "/" && expectedValue[i] === "_") continue;
			return false;
		}
		return true;
	}
	function tryUpgradeRequestToAPotentiallyTrustworthyURL(request) {}
	/**
	* @link {https://html.spec.whatwg.org/multipage/origin.html#same-origin}
	* @param {URL} A
	* @param {URL} B
	*/
	function sameOrigin(A, B) {
		if (A.origin === B.origin && A.origin === "null") return true;
		if (A.protocol === B.protocol && A.hostname === B.hostname && A.port === B.port) return true;
		return false;
	}
	function createDeferredPromise() {
		let res;
		let rej;
		return {
			promise: new Promise((resolve, reject) => {
				res = resolve;
				rej = reject;
			}),
			resolve: res,
			reject: rej
		};
	}
	function isAborted(fetchParams) {
		return fetchParams.controller.state === "aborted";
	}
	function isCancelled(fetchParams) {
		return fetchParams.controller.state === "aborted" || fetchParams.controller.state === "terminated";
	}
	var normalizeMethodRecord = {
		delete: "DELETE",
		DELETE: "DELETE",
		get: "GET",
		GET: "GET",
		head: "HEAD",
		HEAD: "HEAD",
		options: "OPTIONS",
		OPTIONS: "OPTIONS",
		post: "POST",
		POST: "POST",
		put: "PUT",
		PUT: "PUT"
	};
	Object.setPrototypeOf(normalizeMethodRecord, null);
	/**
	* @see https://fetch.spec.whatwg.org/#concept-method-normalize
	* @param {string} method
	*/
	function normalizeMethod(method) {
		return normalizeMethodRecord[method.toLowerCase()] ?? method;
	}
	function serializeJavascriptValueToJSONString(value) {
		const result = JSON.stringify(value);
		if (result === void 0) throw new TypeError("Value is not JSON serializable");
		assert$19(typeof result === "string");
		return result;
	}
	var esIteratorPrototype = Object.getPrototypeOf(Object.getPrototypeOf([][Symbol.iterator]()));
	/**
	* @see https://webidl.spec.whatwg.org/#dfn-iterator-prototype-object
	* @param {() => unknown[]} iterator
	* @param {string} name name of the instance
	* @param {'key'|'value'|'key+value'} kind
	*/
	function makeIterator(iterator, name, kind) {
		const object = {
			index: 0,
			kind,
			target: iterator
		};
		const i = {
			next() {
				if (Object.getPrototypeOf(this) !== i) throw new TypeError(`'next' called on an object that does not implement interface ${name} Iterator.`);
				const { index, kind, target } = object;
				const values = target();
				if (index >= values.length) return {
					value: void 0,
					done: true
				};
				const pair = values[index];
				object.index = index + 1;
				return iteratorResult(pair, kind);
			},
			[Symbol.toStringTag]: `${name} Iterator`
		};
		Object.setPrototypeOf(i, esIteratorPrototype);
		return Object.setPrototypeOf({}, i);
	}
	function iteratorResult(pair, kind) {
		let result;
		switch (kind) {
			case "key":
				result = pair[0];
				break;
			case "value":
				result = pair[1];
				break;
			case "key+value": result = pair;
		}
		return {
			value: result,
			done: false
		};
	}
	/**
	* @see https://fetch.spec.whatwg.org/#body-fully-read
	*/
	async function fullyReadBody(body, processBody, processBodyError) {
		const successSteps = processBody;
		const errorSteps = processBodyError;
		let reader;
		try {
			reader = body.stream.getReader();
		} catch (e) {
			errorSteps(e);
			return;
		}
		try {
			successSteps(await readAllBytes(reader));
		} catch (e) {
			errorSteps(e);
		}
	}
	/** @type {ReadableStream} */
	var ReadableStream = globalThis.ReadableStream;
	function isReadableStreamLike(stream) {
		if (!ReadableStream) ReadableStream = __require("stream/web").ReadableStream;
		return stream instanceof ReadableStream || stream[Symbol.toStringTag] === "ReadableStream" && typeof stream.tee === "function";
	}
	var MAXIMUM_ARGUMENT_LENGTH = 65535;
	/**
	* @see https://infra.spec.whatwg.org/#isomorphic-decode
	* @param {number[]|Uint8Array} input
	*/
	function isomorphicDecode(input) {
		if (input.length < MAXIMUM_ARGUMENT_LENGTH) return String.fromCharCode(...input);
		return input.reduce((previous, current) => previous + String.fromCharCode(current), "");
	}
	/**
	* @param {ReadableStreamController<Uint8Array>} controller
	*/
	function readableStreamClose(controller) {
		try {
			controller.close();
		} catch (err) {
			if (!err.message.includes("Controller is already closed")) throw err;
		}
	}
	/**
	* @see https://infra.spec.whatwg.org/#isomorphic-encode
	* @param {string} input
	*/
	function isomorphicEncode(input) {
		for (let i = 0; i < input.length; i++) assert$19(input.charCodeAt(i) <= 255);
		return input;
	}
	/**
	* @see https://streams.spec.whatwg.org/#readablestreamdefaultreader-read-all-bytes
	* @see https://streams.spec.whatwg.org/#read-loop
	* @param {ReadableStreamDefaultReader} reader
	*/
	async function readAllBytes(reader) {
		const bytes = [];
		let byteLength = 0;
		while (true) {
			const { done, value: chunk } = await reader.read();
			if (done) return Buffer.concat(bytes, byteLength);
			if (!isUint8Array$1(chunk)) throw new TypeError("Received non-Uint8Array chunk");
			bytes.push(chunk);
			byteLength += chunk.length;
		}
	}
	/**
	* @see https://fetch.spec.whatwg.org/#is-local
	* @param {URL} url
	*/
	function urlIsLocal(url) {
		assert$19("protocol" in url);
		const protocol = url.protocol;
		return protocol === "about:" || protocol === "blob:" || protocol === "data:";
	}
	/**
	* @param {string|URL} url
	*/
	function urlHasHttpsScheme(url) {
		if (typeof url === "string") return url.startsWith("https:");
		return url.protocol === "https:";
	}
	/**
	* @see https://fetch.spec.whatwg.org/#http-scheme
	* @param {URL} url
	*/
	function urlIsHttpHttpsScheme(url) {
		assert$19("protocol" in url);
		const protocol = url.protocol;
		return protocol === "http:" || protocol === "https:";
	}
	module.exports = {
		isAborted,
		isCancelled,
		createDeferredPromise,
		ReadableStreamFrom,
		toUSVString,
		tryUpgradeRequestToAPotentiallyTrustworthyURL,
		coarsenedSharedCurrentTime,
		determineRequestsReferrer,
		makePolicyContainer,
		clonePolicyContainer,
		appendFetchMetadata,
		appendRequestOriginHeader,
		TAOCheck,
		corsCheck,
		crossOriginResourcePolicyCheck,
		createOpaqueTimingInfo,
		setRequestReferrerPolicyOnRedirect,
		isValidHTTPToken,
		requestBadPort,
		requestCurrentURL,
		responseURL,
		responseLocationURL,
		isBlobLike,
		isURLPotentiallyTrustworthy,
		isValidReasonPhrase,
		sameOrigin,
		normalizeMethod,
		serializeJavascriptValueToJSONString,
		makeIterator,
		isValidHeaderName,
		isValidHeaderValue,
		hasOwn: Object.hasOwn || ((dict, key) => Object.prototype.hasOwnProperty.call(dict, key)),
		isErrorLike,
		fullyReadBody,
		bytesMatch,
		isReadableStreamLike,
		readableStreamClose,
		isomorphicEncode,
		isomorphicDecode,
		urlIsLocal,
		urlHasHttpsScheme,
		urlIsHttpHttpsScheme,
		readAllBytes,
		normalizeMethodRecord,
		parseMetadata
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/symbols.js
var require_symbols$3 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		kUrl: Symbol("url"),
		kHeaders: Symbol("headers"),
		kSignal: Symbol("signal"),
		kState: Symbol("state"),
		kGuard: Symbol("guard"),
		kRealm: Symbol("realm")
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/webidl.js
var require_webidl = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { types: types$4 } = __require("util");
	var { hasOwn, toUSVString } = require_util$5();
	/** @type {import('../../types/webidl').Webidl} */
	var webidl = {};
	webidl.converters = {};
	webidl.util = {};
	webidl.errors = {};
	webidl.errors.exception = function(message) {
		return /* @__PURE__ */ new TypeError(`${message.header}: ${message.message}`);
	};
	webidl.errors.conversionFailed = function(context) {
		const plural = context.types.length === 1 ? "" : " one of";
		const message = `${context.argument} could not be converted to${plural}: ${context.types.join(", ")}.`;
		return webidl.errors.exception({
			header: context.prefix,
			message
		});
	};
	webidl.errors.invalidArgument = function(context) {
		return webidl.errors.exception({
			header: context.prefix,
			message: `"${context.value}" is an invalid ${context.type}.`
		});
	};
	webidl.brandCheck = function(V, I, opts = void 0) {
		if (opts?.strict !== false && !(V instanceof I)) throw new TypeError("Illegal invocation");
		else return V?.[Symbol.toStringTag] === I.prototype[Symbol.toStringTag];
	};
	webidl.argumentLengthCheck = function({ length }, min, ctx) {
		if (length < min) throw webidl.errors.exception({
			message: `${min} argument${min !== 1 ? "s" : ""} required, but${length ? " only" : ""} ${length} found.`,
			...ctx
		});
	};
	webidl.illegalConstructor = function() {
		throw webidl.errors.exception({
			header: "TypeError",
			message: "Illegal constructor"
		});
	};
	webidl.util.Type = function(V) {
		switch (typeof V) {
			case "undefined": return "Undefined";
			case "boolean": return "Boolean";
			case "string": return "String";
			case "symbol": return "Symbol";
			case "number": return "Number";
			case "bigint": return "BigInt";
			case "function":
			case "object":
				if (V === null) return "Null";
				return "Object";
		}
	};
	webidl.util.ConvertToInt = function(V, bitLength, signedness, opts = {}) {
		let upperBound;
		let lowerBound;
		if (bitLength === 64) {
			upperBound = Math.pow(2, 53) - 1;
			if (signedness === "unsigned") lowerBound = 0;
			else lowerBound = Math.pow(-2, 53) + 1;
		} else if (signedness === "unsigned") {
			lowerBound = 0;
			upperBound = Math.pow(2, bitLength) - 1;
		} else {
			lowerBound = Math.pow(-2, bitLength) - 1;
			upperBound = Math.pow(2, bitLength - 1) - 1;
		}
		let x = Number(V);
		if (x === 0) x = 0;
		if (opts.enforceRange === true) {
			if (Number.isNaN(x) || x === Number.POSITIVE_INFINITY || x === Number.NEGATIVE_INFINITY) throw webidl.errors.exception({
				header: "Integer conversion",
				message: `Could not convert ${V} to an integer.`
			});
			x = webidl.util.IntegerPart(x);
			if (x < lowerBound || x > upperBound) throw webidl.errors.exception({
				header: "Integer conversion",
				message: `Value must be between ${lowerBound}-${upperBound}, got ${x}.`
			});
			return x;
		}
		if (!Number.isNaN(x) && opts.clamp === true) {
			x = Math.min(Math.max(x, lowerBound), upperBound);
			if (Math.floor(x) % 2 === 0) x = Math.floor(x);
			else x = Math.ceil(x);
			return x;
		}
		if (Number.isNaN(x) || x === 0 && Object.is(0, x) || x === Number.POSITIVE_INFINITY || x === Number.NEGATIVE_INFINITY) return 0;
		x = webidl.util.IntegerPart(x);
		x = x % Math.pow(2, bitLength);
		if (signedness === "signed" && x >= Math.pow(2, bitLength) - 1) return x - Math.pow(2, bitLength);
		return x;
	};
	webidl.util.IntegerPart = function(n) {
		const r = Math.floor(Math.abs(n));
		if (n < 0) return -1 * r;
		return r;
	};
	webidl.sequenceConverter = function(converter) {
		return (V) => {
			if (webidl.util.Type(V) !== "Object") throw webidl.errors.exception({
				header: "Sequence",
				message: `Value of type ${webidl.util.Type(V)} is not an Object.`
			});
			/** @type {Generator} */
			const method = V?.[Symbol.iterator]?.();
			const seq = [];
			if (method === void 0 || typeof method.next !== "function") throw webidl.errors.exception({
				header: "Sequence",
				message: "Object is not an iterator."
			});
			while (true) {
				const { done, value } = method.next();
				if (done) break;
				seq.push(converter(value));
			}
			return seq;
		};
	};
	webidl.recordConverter = function(keyConverter, valueConverter) {
		return (O) => {
			if (webidl.util.Type(O) !== "Object") throw webidl.errors.exception({
				header: "Record",
				message: `Value of type ${webidl.util.Type(O)} is not an Object.`
			});
			const result = {};
			if (!types$4.isProxy(O)) {
				const keys = Object.keys(O);
				for (const key of keys) {
					const typedKey = keyConverter(key);
					result[typedKey] = valueConverter(O[key]);
				}
				return result;
			}
			const keys = Reflect.ownKeys(O);
			for (const key of keys) if (Reflect.getOwnPropertyDescriptor(O, key)?.enumerable) {
				const typedKey = keyConverter(key);
				result[typedKey] = valueConverter(O[key]);
			}
			return result;
		};
	};
	webidl.interfaceConverter = function(i) {
		return (V, opts = {}) => {
			if (opts.strict !== false && !(V instanceof i)) throw webidl.errors.exception({
				header: i.name,
				message: `Expected ${V} to be an instance of ${i.name}.`
			});
			return V;
		};
	};
	webidl.dictionaryConverter = function(converters) {
		return (dictionary) => {
			const type = webidl.util.Type(dictionary);
			const dict = {};
			if (type === "Null" || type === "Undefined") return dict;
			else if (type !== "Object") throw webidl.errors.exception({
				header: "Dictionary",
				message: `Expected ${dictionary} to be one of: Null, Undefined, Object.`
			});
			for (const options of converters) {
				const { key, defaultValue, required, converter } = options;
				if (required === true) {
					if (!hasOwn(dictionary, key)) throw webidl.errors.exception({
						header: "Dictionary",
						message: `Missing required key "${key}".`
					});
				}
				let value = dictionary[key];
				const hasDefault = hasOwn(options, "defaultValue");
				if (hasDefault && value !== null) value = value ?? defaultValue;
				if (required || hasDefault || value !== void 0) {
					value = converter(value);
					if (options.allowedValues && !options.allowedValues.includes(value)) throw webidl.errors.exception({
						header: "Dictionary",
						message: `${value} is not an accepted type. Expected one of ${options.allowedValues.join(", ")}.`
					});
					dict[key] = value;
				}
			}
			return dict;
		};
	};
	webidl.nullableConverter = function(converter) {
		return (V) => {
			if (V === null) return V;
			return converter(V);
		};
	};
	webidl.converters.DOMString = function(V, opts = {}) {
		if (V === null && opts.legacyNullToEmptyString) return "";
		if (typeof V === "symbol") throw new TypeError("Could not convert argument of type symbol to string.");
		return String(V);
	};
	webidl.converters.ByteString = function(V) {
		const x = webidl.converters.DOMString(V);
		for (let index = 0; index < x.length; index++) if (x.charCodeAt(index) > 255) throw new TypeError(`Cannot convert argument to a ByteString because the character at index ${index} has a value of ${x.charCodeAt(index)} which is greater than 255.`);
		return x;
	};
	webidl.converters.USVString = toUSVString;
	webidl.converters.boolean = function(V) {
		return Boolean(V);
	};
	webidl.converters.any = function(V) {
		return V;
	};
	webidl.converters["long long"] = function(V) {
		return webidl.util.ConvertToInt(V, 64, "signed");
	};
	webidl.converters["unsigned long long"] = function(V) {
		return webidl.util.ConvertToInt(V, 64, "unsigned");
	};
	webidl.converters["unsigned long"] = function(V) {
		return webidl.util.ConvertToInt(V, 32, "unsigned");
	};
	webidl.converters["unsigned short"] = function(V, opts) {
		return webidl.util.ConvertToInt(V, 16, "unsigned", opts);
	};
	webidl.converters.ArrayBuffer = function(V, opts = {}) {
		if (webidl.util.Type(V) !== "Object" || !types$4.isAnyArrayBuffer(V)) throw webidl.errors.conversionFailed({
			prefix: `${V}`,
			argument: `${V}`,
			types: ["ArrayBuffer"]
		});
		if (opts.allowShared === false && types$4.isSharedArrayBuffer(V)) throw webidl.errors.exception({
			header: "ArrayBuffer",
			message: "SharedArrayBuffer is not allowed."
		});
		return V;
	};
	webidl.converters.TypedArray = function(V, T, opts = {}) {
		if (webidl.util.Type(V) !== "Object" || !types$4.isTypedArray(V) || V.constructor.name !== T.name) throw webidl.errors.conversionFailed({
			prefix: `${T.name}`,
			argument: `${V}`,
			types: [T.name]
		});
		if (opts.allowShared === false && types$4.isSharedArrayBuffer(V.buffer)) throw webidl.errors.exception({
			header: "ArrayBuffer",
			message: "SharedArrayBuffer is not allowed."
		});
		return V;
	};
	webidl.converters.DataView = function(V, opts = {}) {
		if (webidl.util.Type(V) !== "Object" || !types$4.isDataView(V)) throw webidl.errors.exception({
			header: "DataView",
			message: "Object is not a DataView."
		});
		if (opts.allowShared === false && types$4.isSharedArrayBuffer(V.buffer)) throw webidl.errors.exception({
			header: "ArrayBuffer",
			message: "SharedArrayBuffer is not allowed."
		});
		return V;
	};
	webidl.converters.BufferSource = function(V, opts = {}) {
		if (types$4.isAnyArrayBuffer(V)) return webidl.converters.ArrayBuffer(V, opts);
		if (types$4.isTypedArray(V)) return webidl.converters.TypedArray(V, V.constructor);
		if (types$4.isDataView(V)) return webidl.converters.DataView(V, opts);
		throw new TypeError(`Could not convert ${V} to a BufferSource.`);
	};
	webidl.converters["sequence<ByteString>"] = webidl.sequenceConverter(webidl.converters.ByteString);
	webidl.converters["sequence<sequence<ByteString>>"] = webidl.sequenceConverter(webidl.converters["sequence<ByteString>"]);
	webidl.converters["record<ByteString, ByteString>"] = webidl.recordConverter(webidl.converters.ByteString, webidl.converters.ByteString);
	module.exports = { webidl };
}));
//#endregion
//#region node_modules/undici/lib/fetch/dataURL.js
var require_dataURL = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$18 = __require("assert");
	var { atob: atob$1 } = __require("buffer");
	var { isomorphicDecode } = require_util$5();
	var encoder = new TextEncoder();
	/**
	* @see https://mimesniff.spec.whatwg.org/#http-token-code-point
	*/
	var HTTP_TOKEN_CODEPOINTS = /^[!#$%&'*+-.^_|~A-Za-z0-9]+$/;
	var HTTP_WHITESPACE_REGEX = /(\u000A|\u000D|\u0009|\u0020)/;
	/**
	* @see https://mimesniff.spec.whatwg.org/#http-quoted-string-token-code-point
	*/
	var HTTP_QUOTED_STRING_TOKENS = /[\u0009|\u0020-\u007E|\u0080-\u00FF]/;
	/** @param {URL} dataURL */
	function dataURLProcessor(dataURL) {
		assert$18(dataURL.protocol === "data:");
		let input = URLSerializer(dataURL, true);
		input = input.slice(5);
		const position = { position: 0 };
		let mimeType = collectASequenceOfCodePointsFast(",", input, position);
		const mimeTypeLength = mimeType.length;
		mimeType = removeASCIIWhitespace(mimeType, true, true);
		if (position.position >= input.length) return "failure";
		position.position++;
		let body = stringPercentDecode(input.slice(mimeTypeLength + 1));
		if (/;(\u0020){0,}base64$/i.test(mimeType)) {
			body = forgivingBase64(isomorphicDecode(body));
			if (body === "failure") return "failure";
			mimeType = mimeType.slice(0, -6);
			mimeType = mimeType.replace(/(\u0020)+$/, "");
			mimeType = mimeType.slice(0, -1);
		}
		if (mimeType.startsWith(";")) mimeType = "text/plain" + mimeType;
		let mimeTypeRecord = parseMIMEType(mimeType);
		if (mimeTypeRecord === "failure") mimeTypeRecord = parseMIMEType("text/plain;charset=US-ASCII");
		return {
			mimeType: mimeTypeRecord,
			body
		};
	}
	/**
	* @param {URL} url
	* @param {boolean} excludeFragment
	*/
	function URLSerializer(url, excludeFragment = false) {
		if (!excludeFragment) return url.href;
		const href = url.href;
		const hashLength = url.hash.length;
		return hashLength === 0 ? href : href.substring(0, href.length - hashLength);
	}
	/**
	* @param {(char: string) => boolean} condition
	* @param {string} input
	* @param {{ position: number }} position
	*/
	function collectASequenceOfCodePoints(condition, input, position) {
		let result = "";
		while (position.position < input.length && condition(input[position.position])) {
			result += input[position.position];
			position.position++;
		}
		return result;
	}
	/**
	* A faster collectASequenceOfCodePoints that only works when comparing a single character.
	* @param {string} char
	* @param {string} input
	* @param {{ position: number }} position
	*/
	function collectASequenceOfCodePointsFast(char, input, position) {
		const idx = input.indexOf(char, position.position);
		const start = position.position;
		if (idx === -1) {
			position.position = input.length;
			return input.slice(start);
		}
		position.position = idx;
		return input.slice(start, position.position);
	}
	/** @param {string} input */
	function stringPercentDecode(input) {
		return percentDecode(encoder.encode(input));
	}
	/** @param {Uint8Array} input */
	function percentDecode(input) {
		/** @type {number[]} */
		const output = [];
		for (let i = 0; i < input.length; i++) {
			const byte = input[i];
			if (byte !== 37) output.push(byte);
			else if (byte === 37 && !/^[0-9A-Fa-f]{2}$/i.test(String.fromCharCode(input[i + 1], input[i + 2]))) output.push(37);
			else {
				const nextTwoBytes = String.fromCharCode(input[i + 1], input[i + 2]);
				const bytePoint = Number.parseInt(nextTwoBytes, 16);
				output.push(bytePoint);
				i += 2;
			}
		}
		return Uint8Array.from(output);
	}
	/** @param {string} input */
	function parseMIMEType(input) {
		input = removeHTTPWhitespace(input, true, true);
		const position = { position: 0 };
		const type = collectASequenceOfCodePointsFast("/", input, position);
		if (type.length === 0 || !HTTP_TOKEN_CODEPOINTS.test(type)) return "failure";
		if (position.position > input.length) return "failure";
		position.position++;
		let subtype = collectASequenceOfCodePointsFast(";", input, position);
		subtype = removeHTTPWhitespace(subtype, false, true);
		if (subtype.length === 0 || !HTTP_TOKEN_CODEPOINTS.test(subtype)) return "failure";
		const typeLowercase = type.toLowerCase();
		const subtypeLowercase = subtype.toLowerCase();
		const mimeType = {
			type: typeLowercase,
			subtype: subtypeLowercase,
			/** @type {Map<string, string>} */
			parameters: /* @__PURE__ */ new Map(),
			essence: `${typeLowercase}/${subtypeLowercase}`
		};
		while (position.position < input.length) {
			position.position++;
			collectASequenceOfCodePoints((char) => HTTP_WHITESPACE_REGEX.test(char), input, position);
			let parameterName = collectASequenceOfCodePoints((char) => char !== ";" && char !== "=", input, position);
			parameterName = parameterName.toLowerCase();
			if (position.position < input.length) {
				if (input[position.position] === ";") continue;
				position.position++;
			}
			if (position.position > input.length) break;
			let parameterValue = null;
			if (input[position.position] === "\"") {
				parameterValue = collectAnHTTPQuotedString(input, position, true);
				collectASequenceOfCodePointsFast(";", input, position);
			} else {
				parameterValue = collectASequenceOfCodePointsFast(";", input, position);
				parameterValue = removeHTTPWhitespace(parameterValue, false, true);
				if (parameterValue.length === 0) continue;
			}
			if (parameterName.length !== 0 && HTTP_TOKEN_CODEPOINTS.test(parameterName) && (parameterValue.length === 0 || HTTP_QUOTED_STRING_TOKENS.test(parameterValue)) && !mimeType.parameters.has(parameterName)) mimeType.parameters.set(parameterName, parameterValue);
		}
		return mimeType;
	}
	/** @param {string} data */
	function forgivingBase64(data) {
		data = data.replace(/[\u0009\u000A\u000C\u000D\u0020]/g, "");
		if (data.length % 4 === 0) data = data.replace(/=?=$/, "");
		if (data.length % 4 === 1) return "failure";
		if (/[^+/0-9A-Za-z]/.test(data)) return "failure";
		const binary = atob$1(data);
		const bytes = new Uint8Array(binary.length);
		for (let byte = 0; byte < binary.length; byte++) bytes[byte] = binary.charCodeAt(byte);
		return bytes;
	}
	/**
	* @param {string} input
	* @param {{ position: number }} position
	* @param {boolean?} extractValue
	*/
	function collectAnHTTPQuotedString(input, position, extractValue) {
		const positionStart = position.position;
		let value = "";
		assert$18(input[position.position] === "\"");
		position.position++;
		while (true) {
			value += collectASequenceOfCodePoints((char) => char !== "\"" && char !== "\\", input, position);
			if (position.position >= input.length) break;
			const quoteOrBackslash = input[position.position];
			position.position++;
			if (quoteOrBackslash === "\\") {
				if (position.position >= input.length) {
					value += "\\";
					break;
				}
				value += input[position.position];
				position.position++;
			} else {
				assert$18(quoteOrBackslash === "\"");
				break;
			}
		}
		if (extractValue) return value;
		return input.slice(positionStart, position.position);
	}
	/**
	* @see https://mimesniff.spec.whatwg.org/#serialize-a-mime-type
	*/
	function serializeAMimeType(mimeType) {
		assert$18(mimeType !== "failure");
		const { parameters, essence } = mimeType;
		let serialization = essence;
		for (let [name, value] of parameters.entries()) {
			serialization += ";";
			serialization += name;
			serialization += "=";
			if (!HTTP_TOKEN_CODEPOINTS.test(value)) {
				value = value.replace(/(\\|")/g, "\\$1");
				value = "\"" + value;
				value += "\"";
			}
			serialization += value;
		}
		return serialization;
	}
	/**
	* @see https://fetch.spec.whatwg.org/#http-whitespace
	* @param {string} char
	*/
	function isHTTPWhiteSpace(char) {
		return char === "\r" || char === "\n" || char === "	" || char === " ";
	}
	/**
	* @see https://fetch.spec.whatwg.org/#http-whitespace
	* @param {string} str
	*/
	function removeHTTPWhitespace(str, leading = true, trailing = true) {
		let lead = 0;
		let trail = str.length - 1;
		if (leading) for (; lead < str.length && isHTTPWhiteSpace(str[lead]); lead++);
		if (trailing) for (; trail > 0 && isHTTPWhiteSpace(str[trail]); trail--);
		return str.slice(lead, trail + 1);
	}
	/**
	* @see https://infra.spec.whatwg.org/#ascii-whitespace
	* @param {string} char
	*/
	function isASCIIWhitespace(char) {
		return char === "\r" || char === "\n" || char === "	" || char === "\f" || char === " ";
	}
	/**
	* @see https://infra.spec.whatwg.org/#strip-leading-and-trailing-ascii-whitespace
	*/
	function removeASCIIWhitespace(str, leading = true, trailing = true) {
		let lead = 0;
		let trail = str.length - 1;
		if (leading) for (; lead < str.length && isASCIIWhitespace(str[lead]); lead++);
		if (trailing) for (; trail > 0 && isASCIIWhitespace(str[trail]); trail--);
		return str.slice(lead, trail + 1);
	}
	module.exports = {
		dataURLProcessor,
		URLSerializer,
		collectASequenceOfCodePoints,
		collectASequenceOfCodePointsFast,
		stringPercentDecode,
		parseMIMEType,
		collectAnHTTPQuotedString,
		serializeAMimeType
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/file.js
var require_file = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Blob: Blob$3, File: NativeFile$2 } = __require("buffer");
	var { types: types$3 } = __require("util");
	var { kState } = require_symbols$3();
	var { isBlobLike } = require_util$5();
	var { webidl } = require_webidl();
	var { parseMIMEType, serializeAMimeType } = require_dataURL();
	var { kEnumerableProperty } = require_util$6();
	var encoder = new TextEncoder();
	var File = class File extends Blob$3 {
		constructor(fileBits, fileName, options = {}) {
			webidl.argumentLengthCheck(arguments, 2, { header: "File constructor" });
			fileBits = webidl.converters["sequence<BlobPart>"](fileBits);
			fileName = webidl.converters.USVString(fileName);
			options = webidl.converters.FilePropertyBag(options);
			const n = fileName;
			let t = options.type;
			let d;
			substep: {
				if (t) {
					t = parseMIMEType(t);
					if (t === "failure") {
						t = "";
						break substep;
					}
					t = serializeAMimeType(t).toLowerCase();
				}
				d = options.lastModified;
			}
			super(processBlobParts(fileBits, options), { type: t });
			this[kState] = {
				name: n,
				lastModified: d,
				type: t
			};
		}
		get name() {
			webidl.brandCheck(this, File);
			return this[kState].name;
		}
		get lastModified() {
			webidl.brandCheck(this, File);
			return this[kState].lastModified;
		}
		get type() {
			webidl.brandCheck(this, File);
			return this[kState].type;
		}
	};
	var FileLike = class FileLike {
		constructor(blobLike, fileName, options = {}) {
			const n = fileName;
			const t = options.type;
			const d = options.lastModified ?? Date.now();
			this[kState] = {
				blobLike,
				name: n,
				type: t,
				lastModified: d
			};
		}
		stream(...args) {
			webidl.brandCheck(this, FileLike);
			return this[kState].blobLike.stream(...args);
		}
		arrayBuffer(...args) {
			webidl.brandCheck(this, FileLike);
			return this[kState].blobLike.arrayBuffer(...args);
		}
		slice(...args) {
			webidl.brandCheck(this, FileLike);
			return this[kState].blobLike.slice(...args);
		}
		text(...args) {
			webidl.brandCheck(this, FileLike);
			return this[kState].blobLike.text(...args);
		}
		get size() {
			webidl.brandCheck(this, FileLike);
			return this[kState].blobLike.size;
		}
		get type() {
			webidl.brandCheck(this, FileLike);
			return this[kState].blobLike.type;
		}
		get name() {
			webidl.brandCheck(this, FileLike);
			return this[kState].name;
		}
		get lastModified() {
			webidl.brandCheck(this, FileLike);
			return this[kState].lastModified;
		}
		get [Symbol.toStringTag]() {
			return "File";
		}
	};
	Object.defineProperties(File.prototype, {
		[Symbol.toStringTag]: {
			value: "File",
			configurable: true
		},
		name: kEnumerableProperty,
		lastModified: kEnumerableProperty
	});
	webidl.converters.Blob = webidl.interfaceConverter(Blob$3);
	webidl.converters.BlobPart = function(V, opts) {
		if (webidl.util.Type(V) === "Object") {
			if (isBlobLike(V)) return webidl.converters.Blob(V, { strict: false });
			if (ArrayBuffer.isView(V) || types$3.isAnyArrayBuffer(V)) return webidl.converters.BufferSource(V, opts);
		}
		return webidl.converters.USVString(V, opts);
	};
	webidl.converters["sequence<BlobPart>"] = webidl.sequenceConverter(webidl.converters.BlobPart);
	webidl.converters.FilePropertyBag = webidl.dictionaryConverter([
		{
			key: "lastModified",
			converter: webidl.converters["long long"],
			get defaultValue() {
				return Date.now();
			}
		},
		{
			key: "type",
			converter: webidl.converters.DOMString,
			defaultValue: ""
		},
		{
			key: "endings",
			converter: (value) => {
				value = webidl.converters.DOMString(value);
				value = value.toLowerCase();
				if (value !== "native") value = "transparent";
				return value;
			},
			defaultValue: "transparent"
		}
	]);
	/**
	* @see https://www.w3.org/TR/FileAPI/#process-blob-parts
	* @param {(NodeJS.TypedArray|Blob|string)[]} parts
	* @param {{ type: string, endings: string }} options
	*/
	function processBlobParts(parts, options) {
		/** @type {NodeJS.TypedArray[]} */
		const bytes = [];
		for (const element of parts) if (typeof element === "string") {
			let s = element;
			if (options.endings === "native") s = convertLineEndingsNative(s);
			bytes.push(encoder.encode(s));
		} else if (types$3.isAnyArrayBuffer(element) || types$3.isTypedArray(element)) {
			if (!element.buffer) bytes.push(new Uint8Array(element));
			else bytes.push(new Uint8Array(element.buffer, element.byteOffset, element.byteLength));
		} else if (isBlobLike(element)) bytes.push(element);
		return bytes;
	}
	/**
	* @see https://www.w3.org/TR/FileAPI/#convert-line-endings-to-native
	* @param {string} s
	*/
	function convertLineEndingsNative(s) {
		let nativeLineEnding = "\n";
		if (process.platform === "win32") nativeLineEnding = "\r\n";
		return s.replace(/\r?\n/g, nativeLineEnding);
	}
	function isFileLike(object) {
		return NativeFile$2 && object instanceof NativeFile$2 || object instanceof File || object && (typeof object.stream === "function" || typeof object.arrayBuffer === "function") && object[Symbol.toStringTag] === "File";
	}
	module.exports = {
		File,
		FileLike,
		isFileLike
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/formdata.js
var require_formdata = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { isBlobLike, toUSVString, makeIterator } = require_util$5();
	var { kState } = require_symbols$3();
	var { File: UndiciFile, FileLike, isFileLike } = require_file();
	var { webidl } = require_webidl();
	var { Blob: Blob$2, File: NativeFile$1 } = __require("buffer");
	/** @type {globalThis['File']} */
	var File = NativeFile$1 ?? UndiciFile;
	var FormData = class FormData {
		constructor(form) {
			if (form !== void 0) throw webidl.errors.conversionFailed({
				prefix: "FormData constructor",
				argument: "Argument 1",
				types: ["undefined"]
			});
			this[kState] = [];
		}
		append(name, value, filename = void 0) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 2, { header: "FormData.append" });
			if (arguments.length === 3 && !isBlobLike(value)) throw new TypeError("Failed to execute 'append' on 'FormData': parameter 2 is not of type 'Blob'");
			name = webidl.converters.USVString(name);
			value = isBlobLike(value) ? webidl.converters.Blob(value, { strict: false }) : webidl.converters.USVString(value);
			filename = arguments.length === 3 ? webidl.converters.USVString(filename) : void 0;
			const entry = makeEntry(name, value, filename);
			this[kState].push(entry);
		}
		delete(name) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 1, { header: "FormData.delete" });
			name = webidl.converters.USVString(name);
			this[kState] = this[kState].filter((entry) => entry.name !== name);
		}
		get(name) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 1, { header: "FormData.get" });
			name = webidl.converters.USVString(name);
			const idx = this[kState].findIndex((entry) => entry.name === name);
			if (idx === -1) return null;
			return this[kState][idx].value;
		}
		getAll(name) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 1, { header: "FormData.getAll" });
			name = webidl.converters.USVString(name);
			return this[kState].filter((entry) => entry.name === name).map((entry) => entry.value);
		}
		has(name) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 1, { header: "FormData.has" });
			name = webidl.converters.USVString(name);
			return this[kState].findIndex((entry) => entry.name === name) !== -1;
		}
		set(name, value, filename = void 0) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 2, { header: "FormData.set" });
			if (arguments.length === 3 && !isBlobLike(value)) throw new TypeError("Failed to execute 'set' on 'FormData': parameter 2 is not of type 'Blob'");
			name = webidl.converters.USVString(name);
			value = isBlobLike(value) ? webidl.converters.Blob(value, { strict: false }) : webidl.converters.USVString(value);
			filename = arguments.length === 3 ? toUSVString(filename) : void 0;
			const entry = makeEntry(name, value, filename);
			const idx = this[kState].findIndex((entry) => entry.name === name);
			if (idx !== -1) this[kState] = [
				...this[kState].slice(0, idx),
				entry,
				...this[kState].slice(idx + 1).filter((entry) => entry.name !== name)
			];
			else this[kState].push(entry);
		}
		entries() {
			webidl.brandCheck(this, FormData);
			return makeIterator(() => this[kState].map((pair) => [pair.name, pair.value]), "FormData", "key+value");
		}
		keys() {
			webidl.brandCheck(this, FormData);
			return makeIterator(() => this[kState].map((pair) => [pair.name, pair.value]), "FormData", "key");
		}
		values() {
			webidl.brandCheck(this, FormData);
			return makeIterator(() => this[kState].map((pair) => [pair.name, pair.value]), "FormData", "value");
		}
		/**
		* @param {(value: string, key: string, self: FormData) => void} callbackFn
		* @param {unknown} thisArg
		*/
		forEach(callbackFn, thisArg = globalThis) {
			webidl.brandCheck(this, FormData);
			webidl.argumentLengthCheck(arguments, 1, { header: "FormData.forEach" });
			if (typeof callbackFn !== "function") throw new TypeError("Failed to execute 'forEach' on 'FormData': parameter 1 is not of type 'Function'.");
			for (const [key, value] of this) callbackFn.apply(thisArg, [
				value,
				key,
				this
			]);
		}
	};
	FormData.prototype[Symbol.iterator] = FormData.prototype.entries;
	Object.defineProperties(FormData.prototype, { [Symbol.toStringTag]: {
		value: "FormData",
		configurable: true
	} });
	/**
	* @see https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#create-an-entry
	* @param {string} name
	* @param {string|Blob} value
	* @param {?string} filename
	* @returns
	*/
	function makeEntry(name, value, filename) {
		name = Buffer.from(name).toString("utf8");
		if (typeof value === "string") value = Buffer.from(value).toString("utf8");
		else {
			if (!isFileLike(value)) value = value instanceof Blob$2 ? new File([value], "blob", { type: value.type }) : new FileLike(value, "blob", { type: value.type });
			if (filename !== void 0) {
				/** @type {FilePropertyBag} */
				const options = {
					type: value.type,
					lastModified: value.lastModified
				};
				value = NativeFile$1 && value instanceof NativeFile$1 || value instanceof UndiciFile ? new File([value], filename, options) : new FileLike(value, filename, options);
			}
		}
		return {
			name,
			value
		};
	}
	module.exports = { FormData };
}));
//#endregion
//#region node_modules/undici/lib/fetch/body.js
var require_body = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Busboy = require_main();
	var util = require_util$6();
	var { ReadableStreamFrom, isBlobLike, isReadableStreamLike, readableStreamClose, createDeferredPromise, fullyReadBody } = require_util$5();
	var { FormData } = require_formdata();
	var { kState } = require_symbols$3();
	var { webidl } = require_webidl();
	var { DOMException, structuredClone } = require_constants$3();
	var { Blob: Blob$1, File: NativeFile } = __require("buffer");
	var { kBodyUsed } = require_symbols$4();
	var assert$17 = __require("assert");
	var { isErrored } = require_util$6();
	var { isUint8Array, isArrayBuffer } = __require("util/types");
	var { File: UndiciFile } = require_file();
	var { parseMIMEType, serializeAMimeType } = require_dataURL();
	var ReadableStream = globalThis.ReadableStream;
	/** @type {globalThis['File']} */
	var File = NativeFile ?? UndiciFile;
	var textEncoder = new TextEncoder();
	var textDecoder = new TextDecoder();
	function extractBody(object, keepalive = false) {
		if (!ReadableStream) ReadableStream = __require("stream/web").ReadableStream;
		let stream = null;
		if (object instanceof ReadableStream) stream = object;
		else if (isBlobLike(object)) stream = object.stream();
		else stream = new ReadableStream({
			async pull(controller) {
				controller.enqueue(typeof source === "string" ? textEncoder.encode(source) : source);
				queueMicrotask(() => readableStreamClose(controller));
			},
			start() {},
			type: void 0
		});
		assert$17(isReadableStreamLike(stream));
		let action = null;
		let source = null;
		let length = null;
		let type = null;
		if (typeof object === "string") {
			source = object;
			type = "text/plain;charset=UTF-8";
		} else if (object instanceof URLSearchParams) {
			source = object.toString();
			type = "application/x-www-form-urlencoded;charset=UTF-8";
		} else if (isArrayBuffer(object)) source = new Uint8Array(object.slice());
		else if (ArrayBuffer.isView(object)) source = new Uint8Array(object.buffer.slice(object.byteOffset, object.byteOffset + object.byteLength));
		else if (util.isFormDataLike(object)) {
			const boundary = `----formdata-undici-0${`${Math.floor(Math.random() * 1e11)}`.padStart(11, "0")}`;
			const prefix = `--${boundary}\r\nContent-Disposition: form-data`;
			/*! formdata-polyfill. MIT License. Jimmy Wärting <https://jimmy.warting.se/opensource> */
			const escape = (str) => str.replace(/\n/g, "%0A").replace(/\r/g, "%0D").replace(/"/g, "%22");
			const normalizeLinefeeds = (value) => value.replace(/\r?\n|\r/g, "\r\n");
			const blobParts = [];
			const rn = new Uint8Array([13, 10]);
			length = 0;
			let hasUnknownSizeValue = false;
			for (const [name, value] of object) if (typeof value === "string") {
				const chunk = textEncoder.encode(prefix + `; name="${escape(normalizeLinefeeds(name))}"\r\n\r\n${normalizeLinefeeds(value)}\r\n`);
				blobParts.push(chunk);
				length += chunk.byteLength;
			} else {
				const chunk = textEncoder.encode(`${prefix}; name="${escape(normalizeLinefeeds(name))}"` + (value.name ? `; filename="${escape(value.name)}"` : "") + `\r
Content-Type: ${value.type || "application/octet-stream"}\r\n\r\n`);
				blobParts.push(chunk, value, rn);
				if (typeof value.size === "number") length += chunk.byteLength + value.size + rn.byteLength;
				else hasUnknownSizeValue = true;
			}
			const chunk = textEncoder.encode(`--${boundary}--`);
			blobParts.push(chunk);
			length += chunk.byteLength;
			if (hasUnknownSizeValue) length = null;
			source = object;
			action = async function* () {
				for (const part of blobParts) if (part.stream) yield* part.stream();
				else yield part;
			};
			type = "multipart/form-data; boundary=" + boundary;
		} else if (isBlobLike(object)) {
			source = object;
			length = object.size;
			if (object.type) type = object.type;
		} else if (typeof object[Symbol.asyncIterator] === "function") {
			if (keepalive) throw new TypeError("keepalive");
			if (util.isDisturbed(object) || object.locked) throw new TypeError("Response body object should not be disturbed or locked");
			stream = object instanceof ReadableStream ? object : ReadableStreamFrom(object);
		}
		if (typeof source === "string" || util.isBuffer(source)) length = Buffer.byteLength(source);
		if (action != null) {
			let iterator;
			stream = new ReadableStream({
				async start() {
					iterator = action(object)[Symbol.asyncIterator]();
				},
				async pull(controller) {
					const { value, done } = await iterator.next();
					if (done) queueMicrotask(() => {
						controller.close();
					});
					else if (!isErrored(stream)) controller.enqueue(new Uint8Array(value));
					return controller.desiredSize > 0;
				},
				async cancel(reason) {
					await iterator.return();
				},
				type: void 0
			});
		}
		return [{
			stream,
			source,
			length
		}, type];
	}
	function safelyExtractBody(object, keepalive = false) {
		if (!ReadableStream)
 // istanbul ignore next
		ReadableStream = __require("stream/web").ReadableStream;
		if (object instanceof ReadableStream) {
			// istanbul ignore next
			assert$17(!util.isDisturbed(object), "The body has already been consumed.");
			// istanbul ignore next
			assert$17(!object.locked, "The stream is locked.");
		}
		return extractBody(object, keepalive);
	}
	function cloneBody(body) {
		const [out1, out2] = body.stream.tee();
		const [, finalClone] = structuredClone(out2, { transfer: [out2] }).tee();
		body.stream = out1;
		return {
			stream: finalClone,
			length: body.length,
			source: body.source
		};
	}
	async function* consumeBody(body) {
		if (body) {
			if (isUint8Array(body)) yield body;
			else {
				const stream = body.stream;
				if (util.isDisturbed(stream)) throw new TypeError("The body has already been consumed.");
				if (stream.locked) throw new TypeError("The stream is locked.");
				stream[kBodyUsed] = true;
				yield* stream;
			}
		}
	}
	function throwIfAborted(state) {
		if (state.aborted) throw new DOMException("The operation was aborted.", "AbortError");
	}
	function bodyMixinMethods(instance) {
		return {
			blob() {
				return specConsumeBody(this, (bytes) => {
					let mimeType = bodyMimeType(this);
					if (mimeType === "failure") mimeType = "";
					else if (mimeType) mimeType = serializeAMimeType(mimeType);
					return new Blob$1([bytes], { type: mimeType });
				}, instance);
			},
			arrayBuffer() {
				return specConsumeBody(this, (bytes) => {
					return new Uint8Array(bytes).buffer;
				}, instance);
			},
			text() {
				return specConsumeBody(this, utf8DecodeBytes, instance);
			},
			json() {
				return specConsumeBody(this, parseJSONFromBytes, instance);
			},
			async formData() {
				webidl.brandCheck(this, instance);
				throwIfAborted(this[kState]);
				const contentType = this.headers.get("Content-Type");
				if (/multipart\/form-data/.test(contentType)) {
					const headers = {};
					for (const [key, value] of this.headers) headers[key.toLowerCase()] = value;
					const responseFormData = new FormData();
					let busboy;
					try {
						busboy = new Busboy({
							headers,
							preservePath: true
						});
					} catch (err) {
						throw new DOMException(`${err}`, "AbortError");
					}
					busboy.on("field", (name, value) => {
						responseFormData.append(name, value);
					});
					busboy.on("file", (name, value, filename, encoding, mimeType) => {
						const chunks = [];
						if (encoding === "base64" || encoding.toLowerCase() === "base64") {
							let base64chunk = "";
							value.on("data", (chunk) => {
								base64chunk += chunk.toString().replace(/[\r\n]/gm, "");
								const end = base64chunk.length - base64chunk.length % 4;
								chunks.push(Buffer.from(base64chunk.slice(0, end), "base64"));
								base64chunk = base64chunk.slice(end);
							});
							value.on("end", () => {
								chunks.push(Buffer.from(base64chunk, "base64"));
								responseFormData.append(name, new File(chunks, filename, { type: mimeType }));
							});
						} else {
							value.on("data", (chunk) => {
								chunks.push(chunk);
							});
							value.on("end", () => {
								responseFormData.append(name, new File(chunks, filename, { type: mimeType }));
							});
						}
					});
					const busboyResolve = new Promise((resolve, reject) => {
						busboy.on("finish", resolve);
						busboy.on("error", (err) => reject(new TypeError(err)));
					});
					if (this.body !== null) for await (const chunk of consumeBody(this[kState].body)) busboy.write(chunk);
					busboy.end();
					await busboyResolve;
					return responseFormData;
				} else if (/application\/x-www-form-urlencoded/.test(contentType)) {
					let entries;
					try {
						let text = "";
						const streamingDecoder = new TextDecoder("utf-8", { ignoreBOM: true });
						for await (const chunk of consumeBody(this[kState].body)) {
							if (!isUint8Array(chunk)) throw new TypeError("Expected Uint8Array chunk");
							text += streamingDecoder.decode(chunk, { stream: true });
						}
						text += streamingDecoder.decode();
						entries = new URLSearchParams(text);
					} catch (err) {
						// istanbul ignore next: Unclear when new URLSearchParams can fail on a string.
						throw Object.assign(/* @__PURE__ */ new TypeError(), { cause: err });
					}
					const formData = new FormData();
					for (const [name, value] of entries) formData.append(name, value);
					return formData;
				} else {
					await Promise.resolve();
					throwIfAborted(this[kState]);
					throw webidl.errors.exception({
						header: `${instance.name}.formData`,
						message: "Could not parse content as FormData."
					});
				}
			}
		};
	}
	function mixinBody(prototype) {
		Object.assign(prototype.prototype, bodyMixinMethods(prototype));
	}
	/**
	* @see https://fetch.spec.whatwg.org/#concept-body-consume-body
	* @param {Response|Request} object
	* @param {(value: unknown) => unknown} convertBytesToJSValue
	* @param {Response|Request} instance
	*/
	async function specConsumeBody(object, convertBytesToJSValue, instance) {
		webidl.brandCheck(object, instance);
		throwIfAborted(object[kState]);
		if (bodyUnusable(object[kState].body)) throw new TypeError("Body is unusable");
		const promise = createDeferredPromise();
		const errorSteps = (error) => promise.reject(error);
		const successSteps = (data) => {
			try {
				promise.resolve(convertBytesToJSValue(data));
			} catch (e) {
				errorSteps(e);
			}
		};
		if (object[kState].body == null) {
			successSteps(/* @__PURE__ */ new Uint8Array());
			return promise.promise;
		}
		await fullyReadBody(object[kState].body, successSteps, errorSteps);
		return promise.promise;
	}
	function bodyUnusable(body) {
		return body != null && (body.stream.locked || util.isDisturbed(body.stream));
	}
	/**
	* @see https://encoding.spec.whatwg.org/#utf-8-decode
	* @param {Buffer} buffer
	*/
	function utf8DecodeBytes(buffer) {
		if (buffer.length === 0) return "";
		if (buffer[0] === 239 && buffer[1] === 187 && buffer[2] === 191) buffer = buffer.subarray(3);
		return textDecoder.decode(buffer);
	}
	/**
	* @see https://infra.spec.whatwg.org/#parse-json-bytes-to-a-javascript-value
	* @param {Uint8Array} bytes
	*/
	function parseJSONFromBytes(bytes) {
		return JSON.parse(utf8DecodeBytes(bytes));
	}
	/**
	* @see https://fetch.spec.whatwg.org/#concept-body-mime-type
	* @param {import('./response').Response|import('./request').Request} object
	*/
	function bodyMimeType(object) {
		const { headersList } = object[kState];
		const contentType = headersList.get("content-type");
		if (contentType === null) return "failure";
		return parseMIMEType(contentType);
	}
	module.exports = {
		extractBody,
		safelyExtractBody,
		cloneBody,
		mixinBody
	};
}));
//#endregion
//#region node_modules/undici/lib/core/request.js
var require_request$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { InvalidArgumentError, NotSupportedError } = require_errors();
	var assert$16 = __require("assert");
	var { kHTTP2BuildRequest, kHTTP2CopyHeaders, kHTTP1BuildRequest } = require_symbols$4();
	var util = require_util$6();
	/**
	* Verifies that the given val is a valid HTTP token
	* per the rules defined in RFC 7230
	* See https://tools.ietf.org/html/rfc7230#section-3.2.6
	*/
	var tokenRegExp = /^[\^_`a-zA-Z\-0-9!#$%&'*+.|~]+$/;
	/**
	* Matches if val contains an invalid field-vchar
	*  field-value    = *( field-content / obs-fold )
	*  field-content  = field-vchar [ 1*( SP / HTAB ) field-vchar ]
	*  field-vchar    = VCHAR / obs-text
	*/
	var headerCharRegex = /[^\t\x20-\x7e\x80-\xff]/;
	var invalidPathRegex = /[^\u0021-\u00ff]/;
	var kHandler = Symbol("handler");
	var channels = {};
	var extractBody;
	try {
		const diagnosticsChannel = __require("diagnostics_channel");
		channels.create = diagnosticsChannel.channel("undici:request:create");
		channels.bodySent = diagnosticsChannel.channel("undici:request:bodySent");
		channels.headers = diagnosticsChannel.channel("undici:request:headers");
		channels.trailers = diagnosticsChannel.channel("undici:request:trailers");
		channels.error = diagnosticsChannel.channel("undici:request:error");
	} catch {
		channels.create = { hasSubscribers: false };
		channels.bodySent = { hasSubscribers: false };
		channels.headers = { hasSubscribers: false };
		channels.trailers = { hasSubscribers: false };
		channels.error = { hasSubscribers: false };
	}
	var Request = class Request {
		constructor(origin, { path, method, body, headers, query, idempotent, blocking, upgrade, headersTimeout, bodyTimeout, reset, throwOnError, expectContinue }, handler) {
			if (typeof path !== "string") throw new InvalidArgumentError("path must be a string");
			else if (path[0] !== "/" && !(path.startsWith("http://") || path.startsWith("https://")) && method !== "CONNECT") throw new InvalidArgumentError("path must be an absolute URL or start with a slash");
			else if (invalidPathRegex.exec(path) !== null) throw new InvalidArgumentError("invalid request path");
			if (typeof method !== "string") throw new InvalidArgumentError("method must be a string");
			else if (tokenRegExp.exec(method) === null) throw new InvalidArgumentError("invalid request method");
			if (upgrade && typeof upgrade !== "string") throw new InvalidArgumentError("upgrade must be a string");
			if (headersTimeout != null && (!Number.isFinite(headersTimeout) || headersTimeout < 0)) throw new InvalidArgumentError("invalid headersTimeout");
			if (bodyTimeout != null && (!Number.isFinite(bodyTimeout) || bodyTimeout < 0)) throw new InvalidArgumentError("invalid bodyTimeout");
			if (reset != null && typeof reset !== "boolean") throw new InvalidArgumentError("invalid reset");
			if (expectContinue != null && typeof expectContinue !== "boolean") throw new InvalidArgumentError("invalid expectContinue");
			this.headersTimeout = headersTimeout;
			this.bodyTimeout = bodyTimeout;
			this.throwOnError = throwOnError === true;
			this.method = method;
			this.abort = null;
			if (body == null) this.body = null;
			else if (util.isStream(body)) {
				this.body = body;
				const rState = this.body._readableState;
				if (!rState || !rState.autoDestroy) {
					this.endHandler = function autoDestroy() {
						util.destroy(this);
					};
					this.body.on("end", this.endHandler);
				}
				this.errorHandler = (err) => {
					if (this.abort) this.abort(err);
					else this.error = err;
				};
				this.body.on("error", this.errorHandler);
			} else if (util.isBuffer(body)) this.body = body.byteLength ? body : null;
			else if (ArrayBuffer.isView(body)) this.body = body.buffer.byteLength ? Buffer.from(body.buffer, body.byteOffset, body.byteLength) : null;
			else if (body instanceof ArrayBuffer) this.body = body.byteLength ? Buffer.from(body) : null;
			else if (typeof body === "string") this.body = body.length ? Buffer.from(body) : null;
			else if (util.isFormDataLike(body) || util.isIterable(body) || util.isBlobLike(body)) this.body = body;
			else throw new InvalidArgumentError("body must be a string, a Buffer, a Readable stream, an iterable, or an async iterable");
			this.completed = false;
			this.aborted = false;
			this.upgrade = upgrade || null;
			this.path = query ? util.buildURL(path, query) : path;
			this.origin = origin;
			this.idempotent = idempotent == null ? method === "HEAD" || method === "GET" : idempotent;
			this.blocking = blocking == null ? false : blocking;
			this.reset = reset == null ? null : reset;
			this.host = null;
			this.contentLength = null;
			this.contentType = null;
			this.headers = "";
			this.expectContinue = expectContinue != null ? expectContinue : false;
			if (Array.isArray(headers)) {
				if (headers.length % 2 !== 0) throw new InvalidArgumentError("headers array must be even");
				for (let i = 0; i < headers.length; i += 2) processHeader(this, headers[i], headers[i + 1]);
			} else if (headers && typeof headers === "object") {
				const keys = Object.keys(headers);
				for (let i = 0; i < keys.length; i++) {
					const key = keys[i];
					processHeader(this, key, headers[key]);
				}
			} else if (headers != null) throw new InvalidArgumentError("headers must be an object or an array");
			if (util.isFormDataLike(this.body)) {
				if (util.nodeMajor < 16 || util.nodeMajor === 16 && util.nodeMinor < 8) throw new InvalidArgumentError("Form-Data bodies are only supported in node v16.8 and newer.");
				if (!extractBody) extractBody = require_body().extractBody;
				const [bodyStream, contentType] = extractBody(body);
				if (this.contentType == null) {
					this.contentType = contentType;
					this.headers += `content-type: ${contentType}\r\n`;
				}
				this.body = bodyStream.stream;
				this.contentLength = bodyStream.length;
			} else if (util.isBlobLike(body) && this.contentType == null && body.type) {
				this.contentType = body.type;
				this.headers += `content-type: ${body.type}\r\n`;
			}
			util.validateHandler(handler, method, upgrade);
			this.servername = util.getServerName(this.host);
			this[kHandler] = handler;
			if (channels.create.hasSubscribers) channels.create.publish({ request: this });
		}
		onBodySent(chunk) {
			if (this[kHandler].onBodySent) try {
				return this[kHandler].onBodySent(chunk);
			} catch (err) {
				this.abort(err);
			}
		}
		onRequestSent() {
			if (channels.bodySent.hasSubscribers) channels.bodySent.publish({ request: this });
			if (this[kHandler].onRequestSent) try {
				return this[kHandler].onRequestSent();
			} catch (err) {
				this.abort(err);
			}
		}
		onConnect(abort) {
			assert$16(!this.aborted);
			assert$16(!this.completed);
			if (this.error) abort(this.error);
			else {
				this.abort = abort;
				return this[kHandler].onConnect(abort);
			}
		}
		onHeaders(statusCode, headers, resume, statusText) {
			assert$16(!this.aborted);
			assert$16(!this.completed);
			if (channels.headers.hasSubscribers) channels.headers.publish({
				request: this,
				response: {
					statusCode,
					headers,
					statusText
				}
			});
			try {
				return this[kHandler].onHeaders(statusCode, headers, resume, statusText);
			} catch (err) {
				this.abort(err);
			}
		}
		onData(chunk) {
			assert$16(!this.aborted);
			assert$16(!this.completed);
			try {
				return this[kHandler].onData(chunk);
			} catch (err) {
				this.abort(err);
				return false;
			}
		}
		onUpgrade(statusCode, headers, socket) {
			assert$16(!this.aborted);
			assert$16(!this.completed);
			return this[kHandler].onUpgrade(statusCode, headers, socket);
		}
		onComplete(trailers) {
			this.onFinally();
			assert$16(!this.aborted);
			this.completed = true;
			if (channels.trailers.hasSubscribers) channels.trailers.publish({
				request: this,
				trailers
			});
			try {
				return this[kHandler].onComplete(trailers);
			} catch (err) {
				this.onError(err);
			}
		}
		onError(error) {
			this.onFinally();
			if (channels.error.hasSubscribers) channels.error.publish({
				request: this,
				error
			});
			if (this.aborted) return;
			this.aborted = true;
			return this[kHandler].onError(error);
		}
		onFinally() {
			if (this.errorHandler) {
				this.body.off("error", this.errorHandler);
				this.errorHandler = null;
			}
			if (this.endHandler) {
				this.body.off("end", this.endHandler);
				this.endHandler = null;
			}
		}
		addHeader(key, value) {
			processHeader(this, key, value);
			return this;
		}
		static [kHTTP1BuildRequest](origin, opts, handler) {
			return new Request(origin, opts, handler);
		}
		static [kHTTP2BuildRequest](origin, opts, handler) {
			const headers = opts.headers;
			opts = {
				...opts,
				headers: null
			};
			const request = new Request(origin, opts, handler);
			request.headers = {};
			if (Array.isArray(headers)) {
				if (headers.length % 2 !== 0) throw new InvalidArgumentError("headers array must be even");
				for (let i = 0; i < headers.length; i += 2) processHeader(request, headers[i], headers[i + 1], true);
			} else if (headers && typeof headers === "object") {
				const keys = Object.keys(headers);
				for (let i = 0; i < keys.length; i++) {
					const key = keys[i];
					processHeader(request, key, headers[key], true);
				}
			} else if (headers != null) throw new InvalidArgumentError("headers must be an object or an array");
			return request;
		}
		static [kHTTP2CopyHeaders](raw) {
			const rawHeaders = raw.split("\r\n");
			const headers = {};
			for (const header of rawHeaders) {
				const [key, value] = header.split(": ");
				if (value == null || value.length === 0) continue;
				if (headers[key]) headers[key] += `,${value}`;
				else headers[key] = value;
			}
			return headers;
		}
	};
	function processHeaderValue(key, val, skipAppend) {
		if (val && typeof val === "object") throw new InvalidArgumentError(`invalid ${key} header`);
		val = val != null ? `${val}` : "";
		if (headerCharRegex.exec(val) !== null) throw new InvalidArgumentError(`invalid ${key} header`);
		return skipAppend ? val : `${key}: ${val}\r\n`;
	}
	function processHeader(request, key, val, skipAppend = false) {
		if (val && typeof val === "object" && !Array.isArray(val)) throw new InvalidArgumentError(`invalid ${key} header`);
		else if (val === void 0) return;
		if (request.host === null && key.length === 4 && key.toLowerCase() === "host") {
			if (headerCharRegex.exec(val) !== null) throw new InvalidArgumentError(`invalid ${key} header`);
			request.host = val;
		} else if (request.contentLength === null && key.length === 14 && key.toLowerCase() === "content-length") {
			request.contentLength = parseInt(val, 10);
			if (!Number.isFinite(request.contentLength)) throw new InvalidArgumentError("invalid content-length header");
		} else if (request.contentType === null && key.length === 12 && key.toLowerCase() === "content-type") {
			request.contentType = val;
			if (skipAppend) request.headers[key] = processHeaderValue(key, val, skipAppend);
			else request.headers += processHeaderValue(key, val);
		} else if (key.length === 17 && key.toLowerCase() === "transfer-encoding") throw new InvalidArgumentError("invalid transfer-encoding header");
		else if (key.length === 10 && key.toLowerCase() === "connection") {
			const value = typeof val === "string" ? val.toLowerCase() : null;
			if (value !== "close" && value !== "keep-alive") throw new InvalidArgumentError("invalid connection header");
			else if (value === "close") request.reset = true;
		} else if (key.length === 10 && key.toLowerCase() === "keep-alive") throw new InvalidArgumentError("invalid keep-alive header");
		else if (key.length === 7 && key.toLowerCase() === "upgrade") throw new InvalidArgumentError("invalid upgrade header");
		else if (key.length === 6 && key.toLowerCase() === "expect") throw new NotSupportedError("expect header not supported");
		else if (tokenRegExp.exec(key) === null) throw new InvalidArgumentError("invalid header key");
		else if (Array.isArray(val)) for (let i = 0; i < val.length; i++) if (skipAppend) {
			if (request.headers[key]) request.headers[key] += `,${processHeaderValue(key, val[i], skipAppend)}`;
			else request.headers[key] = processHeaderValue(key, val[i], skipAppend);
		} else request.headers += processHeaderValue(key, val[i]);
		else if (skipAppend) request.headers[key] = processHeaderValue(key, val, skipAppend);
		else request.headers += processHeaderValue(key, val);
	}
	module.exports = Request;
}));
//#endregion
//#region node_modules/undici/lib/dispatcher.js
var require_dispatcher = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var EventEmitter = __require("events");
	var Dispatcher = class extends EventEmitter {
		dispatch() {
			throw new Error("not implemented");
		}
		close() {
			throw new Error("not implemented");
		}
		destroy() {
			throw new Error("not implemented");
		}
	};
	module.exports = Dispatcher;
}));
//#endregion
//#region node_modules/undici/lib/dispatcher-base.js
var require_dispatcher_base = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Dispatcher = require_dispatcher();
	var { ClientDestroyedError, ClientClosedError, InvalidArgumentError } = require_errors();
	var { kDestroy, kClose, kDispatch, kInterceptors } = require_symbols$4();
	var kDestroyed = Symbol("destroyed");
	var kClosed = Symbol("closed");
	var kOnDestroyed = Symbol("onDestroyed");
	var kOnClosed = Symbol("onClosed");
	var kInterceptedDispatch = Symbol("Intercepted Dispatch");
	var DispatcherBase = class extends Dispatcher {
		constructor() {
			super();
			this[kDestroyed] = false;
			this[kOnDestroyed] = null;
			this[kClosed] = false;
			this[kOnClosed] = [];
		}
		get destroyed() {
			return this[kDestroyed];
		}
		get closed() {
			return this[kClosed];
		}
		get interceptors() {
			return this[kInterceptors];
		}
		set interceptors(newInterceptors) {
			if (newInterceptors) {
				for (let i = newInterceptors.length - 1; i >= 0; i--) if (typeof this[kInterceptors][i] !== "function") throw new InvalidArgumentError("interceptor must be an function");
			}
			this[kInterceptors] = newInterceptors;
		}
		close(callback) {
			if (callback === void 0) return new Promise((resolve, reject) => {
				this.close((err, data) => {
					return err ? reject(err) : resolve(data);
				});
			});
			if (typeof callback !== "function") throw new InvalidArgumentError("invalid callback");
			if (this[kDestroyed]) {
				queueMicrotask(() => callback(new ClientDestroyedError(), null));
				return;
			}
			if (this[kClosed]) {
				if (this[kOnClosed]) this[kOnClosed].push(callback);
				else queueMicrotask(() => callback(null, null));
				return;
			}
			this[kClosed] = true;
			this[kOnClosed].push(callback);
			const onClosed = () => {
				const callbacks = this[kOnClosed];
				this[kOnClosed] = null;
				for (let i = 0; i < callbacks.length; i++) callbacks[i](null, null);
			};
			this[kClose]().then(() => this.destroy()).then(() => {
				queueMicrotask(onClosed);
			});
		}
		destroy(err, callback) {
			if (typeof err === "function") {
				callback = err;
				err = null;
			}
			if (callback === void 0) return new Promise((resolve, reject) => {
				this.destroy(err, (err, data) => {
					return err ? /* istanbul ignore next: should never error */ reject(err) : resolve(data);
				});
			});
			if (typeof callback !== "function") throw new InvalidArgumentError("invalid callback");
			if (this[kDestroyed]) {
				if (this[kOnDestroyed]) this[kOnDestroyed].push(callback);
				else queueMicrotask(() => callback(null, null));
				return;
			}
			if (!err) err = new ClientDestroyedError();
			this[kDestroyed] = true;
			this[kOnDestroyed] = this[kOnDestroyed] || [];
			this[kOnDestroyed].push(callback);
			const onDestroyed = () => {
				const callbacks = this[kOnDestroyed];
				this[kOnDestroyed] = null;
				for (let i = 0; i < callbacks.length; i++) callbacks[i](null, null);
			};
			this[kDestroy](err).then(() => {
				queueMicrotask(onDestroyed);
			});
		}
		[kInterceptedDispatch](opts, handler) {
			if (!this[kInterceptors] || this[kInterceptors].length === 0) {
				this[kInterceptedDispatch] = this[kDispatch];
				return this[kDispatch](opts, handler);
			}
			let dispatch = this[kDispatch].bind(this);
			for (let i = this[kInterceptors].length - 1; i >= 0; i--) dispatch = this[kInterceptors][i](dispatch);
			this[kInterceptedDispatch] = dispatch;
			return dispatch(opts, handler);
		}
		dispatch(opts, handler) {
			if (!handler || typeof handler !== "object") throw new InvalidArgumentError("handler must be an object");
			try {
				if (!opts || typeof opts !== "object") throw new InvalidArgumentError("opts must be an object.");
				if (this[kDestroyed] || this[kOnDestroyed]) throw new ClientDestroyedError();
				if (this[kClosed]) throw new ClientClosedError();
				return this[kInterceptedDispatch](opts, handler);
			} catch (err) {
				if (typeof handler.onError !== "function") throw new InvalidArgumentError("invalid onError method");
				handler.onError(err);
				return false;
			}
		}
	};
	module.exports = DispatcherBase;
}));
//#endregion
//#region node_modules/undici/lib/core/connect.js
var require_connect = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var net$1 = __require("net");
	var assert$15 = __require("assert");
	var util = require_util$6();
	var { InvalidArgumentError, ConnectTimeoutError } = require_errors();
	var tls;
	var SessionCache;
	if (global.FinalizationRegistry && !process.env.NODE_V8_COVERAGE) SessionCache = class WeakSessionCache {
		constructor(maxCachedSessions) {
			this._maxCachedSessions = maxCachedSessions;
			this._sessionCache = /* @__PURE__ */ new Map();
			this._sessionRegistry = new global.FinalizationRegistry((key) => {
				if (this._sessionCache.size < this._maxCachedSessions) return;
				const ref = this._sessionCache.get(key);
				if (ref !== void 0 && ref.deref() === void 0) this._sessionCache.delete(key);
			});
		}
		get(sessionKey) {
			const ref = this._sessionCache.get(sessionKey);
			return ref ? ref.deref() : null;
		}
		set(sessionKey, session) {
			if (this._maxCachedSessions === 0) return;
			this._sessionCache.set(sessionKey, new WeakRef(session));
			this._sessionRegistry.register(session, sessionKey);
		}
	};
	else SessionCache = class SimpleSessionCache {
		constructor(maxCachedSessions) {
			this._maxCachedSessions = maxCachedSessions;
			this._sessionCache = /* @__PURE__ */ new Map();
		}
		get(sessionKey) {
			return this._sessionCache.get(sessionKey);
		}
		set(sessionKey, session) {
			if (this._maxCachedSessions === 0) return;
			if (this._sessionCache.size >= this._maxCachedSessions) {
				const { value: oldestKey } = this._sessionCache.keys().next();
				this._sessionCache.delete(oldestKey);
			}
			this._sessionCache.set(sessionKey, session);
		}
	};
	function buildConnector({ allowH2, maxCachedSessions, socketPath, timeout, ...opts }) {
		if (maxCachedSessions != null && (!Number.isInteger(maxCachedSessions) || maxCachedSessions < 0)) throw new InvalidArgumentError("maxCachedSessions must be a positive integer or zero");
		const options = {
			path: socketPath,
			...opts
		};
		const sessionCache = new SessionCache(maxCachedSessions == null ? 100 : maxCachedSessions);
		timeout = timeout == null ? 1e4 : timeout;
		allowH2 = allowH2 != null ? allowH2 : false;
		return function connect({ hostname, host, protocol, port, servername, localAddress, httpSocket }, callback) {
			let socket;
			if (protocol === "https:") {
				if (!tls) tls = __require("tls");
				servername = servername || options.servername || util.getServerName(host) || null;
				const sessionKey = servername || hostname;
				const session = sessionCache.get(sessionKey) || null;
				assert$15(sessionKey);
				socket = tls.connect({
					highWaterMark: 16384,
					...options,
					servername,
					session,
					localAddress,
					ALPNProtocols: allowH2 ? ["http/1.1", "h2"] : ["http/1.1"],
					socket: httpSocket,
					port: port || 443,
					host: hostname
				});
				socket.on("session", function(session) {
					sessionCache.set(sessionKey, session);
				});
			} else {
				assert$15(!httpSocket, "httpSocket can only be sent on TLS update");
				socket = net$1.connect({
					highWaterMark: 65536,
					...options,
					localAddress,
					port: port || 80,
					host: hostname
				});
			}
			if (options.keepAlive == null || options.keepAlive) {
				const keepAliveInitialDelay = options.keepAliveInitialDelay === void 0 ? 6e4 : options.keepAliveInitialDelay;
				socket.setKeepAlive(true, keepAliveInitialDelay);
			}
			const cancelTimeout = setupTimeout(() => onConnectTimeout(socket), timeout);
			socket.setNoDelay(true).once(protocol === "https:" ? "secureConnect" : "connect", function() {
				cancelTimeout();
				if (callback) {
					const cb = callback;
					callback = null;
					cb(null, this);
				}
			}).on("error", function(err) {
				cancelTimeout();
				if (callback) {
					const cb = callback;
					callback = null;
					cb(err);
				}
			});
			return socket;
		};
	}
	function setupTimeout(onConnectTimeout, timeout) {
		if (!timeout) return () => {};
		let s1 = null;
		let s2 = null;
		const timeoutId = setTimeout(() => {
			s1 = setImmediate(() => {
				if (process.platform === "win32") s2 = setImmediate(() => onConnectTimeout());
				else onConnectTimeout();
			});
		}, timeout);
		return () => {
			clearTimeout(timeoutId);
			clearImmediate(s1);
			clearImmediate(s2);
		};
	}
	function onConnectTimeout(socket) {
		util.destroy(socket, new ConnectTimeoutError());
	}
	module.exports = buildConnector;
}));
//#endregion
//#region node_modules/undici/lib/llhttp/utils.js
var require_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.enumToMap = void 0;
	function enumToMap(obj) {
		const res = {};
		Object.keys(obj).forEach((key) => {
			const value = obj[key];
			if (typeof value === "number") res[key] = value;
		});
		return res;
	}
	exports.enumToMap = enumToMap;
}));
//#endregion
//#region node_modules/undici/lib/llhttp/constants.js
var require_constants$2 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SPECIAL_HEADERS = exports.HEADER_STATE = exports.MINOR = exports.MAJOR = exports.CONNECTION_TOKEN_CHARS = exports.HEADER_CHARS = exports.TOKEN = exports.STRICT_TOKEN = exports.HEX = exports.URL_CHAR = exports.STRICT_URL_CHAR = exports.USERINFO_CHARS = exports.MARK = exports.ALPHANUM = exports.NUM = exports.HEX_MAP = exports.NUM_MAP = exports.ALPHA = exports.FINISH = exports.H_METHOD_MAP = exports.METHOD_MAP = exports.METHODS_RTSP = exports.METHODS_ICE = exports.METHODS_HTTP = exports.METHODS = exports.LENIENT_FLAGS = exports.FLAGS = exports.TYPE = exports.ERROR = void 0;
	var utils_1 = require_utils();
	(function(ERROR) {
		ERROR[ERROR["OK"] = 0] = "OK";
		ERROR[ERROR["INTERNAL"] = 1] = "INTERNAL";
		ERROR[ERROR["STRICT"] = 2] = "STRICT";
		ERROR[ERROR["LF_EXPECTED"] = 3] = "LF_EXPECTED";
		ERROR[ERROR["UNEXPECTED_CONTENT_LENGTH"] = 4] = "UNEXPECTED_CONTENT_LENGTH";
		ERROR[ERROR["CLOSED_CONNECTION"] = 5] = "CLOSED_CONNECTION";
		ERROR[ERROR["INVALID_METHOD"] = 6] = "INVALID_METHOD";
		ERROR[ERROR["INVALID_URL"] = 7] = "INVALID_URL";
		ERROR[ERROR["INVALID_CONSTANT"] = 8] = "INVALID_CONSTANT";
		ERROR[ERROR["INVALID_VERSION"] = 9] = "INVALID_VERSION";
		ERROR[ERROR["INVALID_HEADER_TOKEN"] = 10] = "INVALID_HEADER_TOKEN";
		ERROR[ERROR["INVALID_CONTENT_LENGTH"] = 11] = "INVALID_CONTENT_LENGTH";
		ERROR[ERROR["INVALID_CHUNK_SIZE"] = 12] = "INVALID_CHUNK_SIZE";
		ERROR[ERROR["INVALID_STATUS"] = 13] = "INVALID_STATUS";
		ERROR[ERROR["INVALID_EOF_STATE"] = 14] = "INVALID_EOF_STATE";
		ERROR[ERROR["INVALID_TRANSFER_ENCODING"] = 15] = "INVALID_TRANSFER_ENCODING";
		ERROR[ERROR["CB_MESSAGE_BEGIN"] = 16] = "CB_MESSAGE_BEGIN";
		ERROR[ERROR["CB_HEADERS_COMPLETE"] = 17] = "CB_HEADERS_COMPLETE";
		ERROR[ERROR["CB_MESSAGE_COMPLETE"] = 18] = "CB_MESSAGE_COMPLETE";
		ERROR[ERROR["CB_CHUNK_HEADER"] = 19] = "CB_CHUNK_HEADER";
		ERROR[ERROR["CB_CHUNK_COMPLETE"] = 20] = "CB_CHUNK_COMPLETE";
		ERROR[ERROR["PAUSED"] = 21] = "PAUSED";
		ERROR[ERROR["PAUSED_UPGRADE"] = 22] = "PAUSED_UPGRADE";
		ERROR[ERROR["PAUSED_H2_UPGRADE"] = 23] = "PAUSED_H2_UPGRADE";
		ERROR[ERROR["USER"] = 24] = "USER";
	})(exports.ERROR || (exports.ERROR = {}));
	(function(TYPE) {
		TYPE[TYPE["BOTH"] = 0] = "BOTH";
		TYPE[TYPE["REQUEST"] = 1] = "REQUEST";
		TYPE[TYPE["RESPONSE"] = 2] = "RESPONSE";
	})(exports.TYPE || (exports.TYPE = {}));
	(function(FLAGS) {
		FLAGS[FLAGS["CONNECTION_KEEP_ALIVE"] = 1] = "CONNECTION_KEEP_ALIVE";
		FLAGS[FLAGS["CONNECTION_CLOSE"] = 2] = "CONNECTION_CLOSE";
		FLAGS[FLAGS["CONNECTION_UPGRADE"] = 4] = "CONNECTION_UPGRADE";
		FLAGS[FLAGS["CHUNKED"] = 8] = "CHUNKED";
		FLAGS[FLAGS["UPGRADE"] = 16] = "UPGRADE";
		FLAGS[FLAGS["CONTENT_LENGTH"] = 32] = "CONTENT_LENGTH";
		FLAGS[FLAGS["SKIPBODY"] = 64] = "SKIPBODY";
		FLAGS[FLAGS["TRAILING"] = 128] = "TRAILING";
		FLAGS[FLAGS["TRANSFER_ENCODING"] = 512] = "TRANSFER_ENCODING";
	})(exports.FLAGS || (exports.FLAGS = {}));
	(function(LENIENT_FLAGS) {
		LENIENT_FLAGS[LENIENT_FLAGS["HEADERS"] = 1] = "HEADERS";
		LENIENT_FLAGS[LENIENT_FLAGS["CHUNKED_LENGTH"] = 2] = "CHUNKED_LENGTH";
		LENIENT_FLAGS[LENIENT_FLAGS["KEEP_ALIVE"] = 4] = "KEEP_ALIVE";
	})(exports.LENIENT_FLAGS || (exports.LENIENT_FLAGS = {}));
	var METHODS;
	(function(METHODS) {
		METHODS[METHODS["DELETE"] = 0] = "DELETE";
		METHODS[METHODS["GET"] = 1] = "GET";
		METHODS[METHODS["HEAD"] = 2] = "HEAD";
		METHODS[METHODS["POST"] = 3] = "POST";
		METHODS[METHODS["PUT"] = 4] = "PUT";
		METHODS[METHODS["CONNECT"] = 5] = "CONNECT";
		METHODS[METHODS["OPTIONS"] = 6] = "OPTIONS";
		METHODS[METHODS["TRACE"] = 7] = "TRACE";
		METHODS[METHODS["COPY"] = 8] = "COPY";
		METHODS[METHODS["LOCK"] = 9] = "LOCK";
		METHODS[METHODS["MKCOL"] = 10] = "MKCOL";
		METHODS[METHODS["MOVE"] = 11] = "MOVE";
		METHODS[METHODS["PROPFIND"] = 12] = "PROPFIND";
		METHODS[METHODS["PROPPATCH"] = 13] = "PROPPATCH";
		METHODS[METHODS["SEARCH"] = 14] = "SEARCH";
		METHODS[METHODS["UNLOCK"] = 15] = "UNLOCK";
		METHODS[METHODS["BIND"] = 16] = "BIND";
		METHODS[METHODS["REBIND"] = 17] = "REBIND";
		METHODS[METHODS["UNBIND"] = 18] = "UNBIND";
		METHODS[METHODS["ACL"] = 19] = "ACL";
		METHODS[METHODS["REPORT"] = 20] = "REPORT";
		METHODS[METHODS["MKACTIVITY"] = 21] = "MKACTIVITY";
		METHODS[METHODS["CHECKOUT"] = 22] = "CHECKOUT";
		METHODS[METHODS["MERGE"] = 23] = "MERGE";
		METHODS[METHODS["M-SEARCH"] = 24] = "M-SEARCH";
		METHODS[METHODS["NOTIFY"] = 25] = "NOTIFY";
		METHODS[METHODS["SUBSCRIBE"] = 26] = "SUBSCRIBE";
		METHODS[METHODS["UNSUBSCRIBE"] = 27] = "UNSUBSCRIBE";
		METHODS[METHODS["PATCH"] = 28] = "PATCH";
		METHODS[METHODS["PURGE"] = 29] = "PURGE";
		METHODS[METHODS["MKCALENDAR"] = 30] = "MKCALENDAR";
		METHODS[METHODS["LINK"] = 31] = "LINK";
		METHODS[METHODS["UNLINK"] = 32] = "UNLINK";
		METHODS[METHODS["SOURCE"] = 33] = "SOURCE";
		METHODS[METHODS["PRI"] = 34] = "PRI";
		METHODS[METHODS["DESCRIBE"] = 35] = "DESCRIBE";
		METHODS[METHODS["ANNOUNCE"] = 36] = "ANNOUNCE";
		METHODS[METHODS["SETUP"] = 37] = "SETUP";
		METHODS[METHODS["PLAY"] = 38] = "PLAY";
		METHODS[METHODS["PAUSE"] = 39] = "PAUSE";
		METHODS[METHODS["TEARDOWN"] = 40] = "TEARDOWN";
		METHODS[METHODS["GET_PARAMETER"] = 41] = "GET_PARAMETER";
		METHODS[METHODS["SET_PARAMETER"] = 42] = "SET_PARAMETER";
		METHODS[METHODS["REDIRECT"] = 43] = "REDIRECT";
		METHODS[METHODS["RECORD"] = 44] = "RECORD";
		METHODS[METHODS["FLUSH"] = 45] = "FLUSH";
	})(METHODS = exports.METHODS || (exports.METHODS = {}));
	exports.METHODS_HTTP = [
		METHODS.DELETE,
		METHODS.GET,
		METHODS.HEAD,
		METHODS.POST,
		METHODS.PUT,
		METHODS.CONNECT,
		METHODS.OPTIONS,
		METHODS.TRACE,
		METHODS.COPY,
		METHODS.LOCK,
		METHODS.MKCOL,
		METHODS.MOVE,
		METHODS.PROPFIND,
		METHODS.PROPPATCH,
		METHODS.SEARCH,
		METHODS.UNLOCK,
		METHODS.BIND,
		METHODS.REBIND,
		METHODS.UNBIND,
		METHODS.ACL,
		METHODS.REPORT,
		METHODS.MKACTIVITY,
		METHODS.CHECKOUT,
		METHODS.MERGE,
		METHODS["M-SEARCH"],
		METHODS.NOTIFY,
		METHODS.SUBSCRIBE,
		METHODS.UNSUBSCRIBE,
		METHODS.PATCH,
		METHODS.PURGE,
		METHODS.MKCALENDAR,
		METHODS.LINK,
		METHODS.UNLINK,
		METHODS.PRI,
		METHODS.SOURCE
	];
	exports.METHODS_ICE = [METHODS.SOURCE];
	exports.METHODS_RTSP = [
		METHODS.OPTIONS,
		METHODS.DESCRIBE,
		METHODS.ANNOUNCE,
		METHODS.SETUP,
		METHODS.PLAY,
		METHODS.PAUSE,
		METHODS.TEARDOWN,
		METHODS.GET_PARAMETER,
		METHODS.SET_PARAMETER,
		METHODS.REDIRECT,
		METHODS.RECORD,
		METHODS.FLUSH,
		METHODS.GET,
		METHODS.POST
	];
	exports.METHOD_MAP = utils_1.enumToMap(METHODS);
	exports.H_METHOD_MAP = {};
	Object.keys(exports.METHOD_MAP).forEach((key) => {
		if (/^H/.test(key)) exports.H_METHOD_MAP[key] = exports.METHOD_MAP[key];
	});
	(function(FINISH) {
		FINISH[FINISH["SAFE"] = 0] = "SAFE";
		FINISH[FINISH["SAFE_WITH_CB"] = 1] = "SAFE_WITH_CB";
		FINISH[FINISH["UNSAFE"] = 2] = "UNSAFE";
	})(exports.FINISH || (exports.FINISH = {}));
	exports.ALPHA = [];
	for (let i = "A".charCodeAt(0); i <= "Z".charCodeAt(0); i++) {
		exports.ALPHA.push(String.fromCharCode(i));
		exports.ALPHA.push(String.fromCharCode(i + 32));
	}
	exports.NUM_MAP = {
		0: 0,
		1: 1,
		2: 2,
		3: 3,
		4: 4,
		5: 5,
		6: 6,
		7: 7,
		8: 8,
		9: 9
	};
	exports.HEX_MAP = {
		0: 0,
		1: 1,
		2: 2,
		3: 3,
		4: 4,
		5: 5,
		6: 6,
		7: 7,
		8: 8,
		9: 9,
		A: 10,
		B: 11,
		C: 12,
		D: 13,
		E: 14,
		F: 15,
		a: 10,
		b: 11,
		c: 12,
		d: 13,
		e: 14,
		f: 15
	};
	exports.NUM = [
		"0",
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9"
	];
	exports.ALPHANUM = exports.ALPHA.concat(exports.NUM);
	exports.MARK = [
		"-",
		"_",
		".",
		"!",
		"~",
		"*",
		"'",
		"(",
		")"
	];
	exports.USERINFO_CHARS = exports.ALPHANUM.concat(exports.MARK).concat([
		"%",
		";",
		":",
		"&",
		"=",
		"+",
		"$",
		","
	]);
	exports.STRICT_URL_CHAR = [
		"!",
		"\"",
		"$",
		"%",
		"&",
		"'",
		"(",
		")",
		"*",
		"+",
		",",
		"-",
		".",
		"/",
		":",
		";",
		"<",
		"=",
		">",
		"@",
		"[",
		"\\",
		"]",
		"^",
		"_",
		"`",
		"{",
		"|",
		"}",
		"~"
	].concat(exports.ALPHANUM);
	exports.URL_CHAR = exports.STRICT_URL_CHAR.concat(["	", "\f"]);
	for (let i = 128; i <= 255; i++) exports.URL_CHAR.push(i);
	exports.HEX = exports.NUM.concat([
		"a",
		"b",
		"c",
		"d",
		"e",
		"f",
		"A",
		"B",
		"C",
		"D",
		"E",
		"F"
	]);
	exports.STRICT_TOKEN = [
		"!",
		"#",
		"$",
		"%",
		"&",
		"'",
		"*",
		"+",
		"-",
		".",
		"^",
		"_",
		"`",
		"|",
		"~"
	].concat(exports.ALPHANUM);
	exports.TOKEN = exports.STRICT_TOKEN.concat([" "]);
	exports.HEADER_CHARS = ["	"];
	for (let i = 32; i <= 255; i++) if (i !== 127) exports.HEADER_CHARS.push(i);
	exports.CONNECTION_TOKEN_CHARS = exports.HEADER_CHARS.filter((c) => c !== 44);
	exports.MAJOR = exports.NUM_MAP;
	exports.MINOR = exports.MAJOR;
	var HEADER_STATE;
	(function(HEADER_STATE) {
		HEADER_STATE[HEADER_STATE["GENERAL"] = 0] = "GENERAL";
		HEADER_STATE[HEADER_STATE["CONNECTION"] = 1] = "CONNECTION";
		HEADER_STATE[HEADER_STATE["CONTENT_LENGTH"] = 2] = "CONTENT_LENGTH";
		HEADER_STATE[HEADER_STATE["TRANSFER_ENCODING"] = 3] = "TRANSFER_ENCODING";
		HEADER_STATE[HEADER_STATE["UPGRADE"] = 4] = "UPGRADE";
		HEADER_STATE[HEADER_STATE["CONNECTION_KEEP_ALIVE"] = 5] = "CONNECTION_KEEP_ALIVE";
		HEADER_STATE[HEADER_STATE["CONNECTION_CLOSE"] = 6] = "CONNECTION_CLOSE";
		HEADER_STATE[HEADER_STATE["CONNECTION_UPGRADE"] = 7] = "CONNECTION_UPGRADE";
		HEADER_STATE[HEADER_STATE["TRANSFER_ENCODING_CHUNKED"] = 8] = "TRANSFER_ENCODING_CHUNKED";
	})(HEADER_STATE = exports.HEADER_STATE || (exports.HEADER_STATE = {}));
	exports.SPECIAL_HEADERS = {
		"connection": HEADER_STATE.CONNECTION,
		"content-length": HEADER_STATE.CONTENT_LENGTH,
		"proxy-connection": HEADER_STATE.CONNECTION,
		"transfer-encoding": HEADER_STATE.TRANSFER_ENCODING,
		"upgrade": HEADER_STATE.UPGRADE
	};
}));
//#endregion
//#region node_modules/undici/lib/handler/RedirectHandler.js
var require_RedirectHandler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var util = require_util$6();
	var { kBodyUsed } = require_symbols$4();
	var assert$14 = __require("assert");
	var { InvalidArgumentError } = require_errors();
	var EE$1 = __require("events");
	var redirectableStatusCodes = [
		300,
		301,
		302,
		303,
		307,
		308
	];
	var kBody = Symbol("body");
	var BodyAsyncIterable = class {
		constructor(body) {
			this[kBody] = body;
			this[kBodyUsed] = false;
		}
		async *[Symbol.asyncIterator]() {
			assert$14(!this[kBodyUsed], "disturbed");
			this[kBodyUsed] = true;
			yield* this[kBody];
		}
	};
	var RedirectHandler = class {
		constructor(dispatch, maxRedirections, opts, handler) {
			if (maxRedirections != null && (!Number.isInteger(maxRedirections) || maxRedirections < 0)) throw new InvalidArgumentError("maxRedirections must be a positive number");
			util.validateHandler(handler, opts.method, opts.upgrade);
			this.dispatch = dispatch;
			this.location = null;
			this.abort = null;
			this.opts = {
				...opts,
				maxRedirections: 0
			};
			this.maxRedirections = maxRedirections;
			this.handler = handler;
			this.history = [];
			if (util.isStream(this.opts.body)) {
				if (util.bodyLength(this.opts.body) === 0) this.opts.body.on("data", function() {
					assert$14(false);
				});
				if (typeof this.opts.body.readableDidRead !== "boolean") {
					this.opts.body[kBodyUsed] = false;
					EE$1.prototype.on.call(this.opts.body, "data", function() {
						this[kBodyUsed] = true;
					});
				}
			} else if (this.opts.body && typeof this.opts.body.pipeTo === "function") this.opts.body = new BodyAsyncIterable(this.opts.body);
			else if (this.opts.body && typeof this.opts.body !== "string" && !ArrayBuffer.isView(this.opts.body) && util.isIterable(this.opts.body)) this.opts.body = new BodyAsyncIterable(this.opts.body);
		}
		onConnect(abort) {
			this.abort = abort;
			this.handler.onConnect(abort, { history: this.history });
		}
		onUpgrade(statusCode, headers, socket) {
			this.handler.onUpgrade(statusCode, headers, socket);
		}
		onError(error) {
			this.handler.onError(error);
		}
		onHeaders(statusCode, headers, resume, statusText) {
			this.location = this.history.length >= this.maxRedirections || util.isDisturbed(this.opts.body) ? null : parseLocation(statusCode, headers);
			if (this.opts.origin) this.history.push(new URL(this.opts.path, this.opts.origin));
			if (!this.location) return this.handler.onHeaders(statusCode, headers, resume, statusText);
			const { origin, pathname, search } = util.parseURL(new URL(this.location, this.opts.origin && new URL(this.opts.path, this.opts.origin)));
			const path = search ? `${pathname}${search}` : pathname;
			this.opts.headers = cleanRequestHeaders(this.opts.headers, statusCode === 303, this.opts.origin !== origin);
			this.opts.path = path;
			this.opts.origin = origin;
			this.opts.maxRedirections = 0;
			this.opts.query = null;
			if (statusCode === 303 && this.opts.method !== "HEAD") {
				this.opts.method = "GET";
				this.opts.body = null;
			}
		}
		onData(chunk) {
			if (this.location) {} else return this.handler.onData(chunk);
		}
		onComplete(trailers) {
			if (this.location) {
				this.location = null;
				this.abort = null;
				this.dispatch(this.opts, this);
			} else this.handler.onComplete(trailers);
		}
		onBodySent(chunk) {
			if (this.handler.onBodySent) this.handler.onBodySent(chunk);
		}
	};
	function parseLocation(statusCode, headers) {
		if (redirectableStatusCodes.indexOf(statusCode) === -1) return null;
		for (let i = 0; i < headers.length; i += 2) if (headers[i].toString().toLowerCase() === "location") return headers[i + 1];
	}
	function shouldRemoveHeader(header, removeContent, unknownOrigin) {
		if (header.length === 4) return util.headerNameToString(header) === "host";
		if (removeContent && util.headerNameToString(header).startsWith("content-")) return true;
		if (unknownOrigin && (header.length === 13 || header.length === 6 || header.length === 19)) {
			const name = util.headerNameToString(header);
			return name === "authorization" || name === "cookie" || name === "proxy-authorization";
		}
		return false;
	}
	function cleanRequestHeaders(headers, removeContent, unknownOrigin) {
		const ret = [];
		if (Array.isArray(headers)) {
			for (let i = 0; i < headers.length; i += 2) if (!shouldRemoveHeader(headers[i], removeContent, unknownOrigin)) ret.push(headers[i], headers[i + 1]);
		} else if (headers && typeof headers === "object") {
			for (const key of Object.keys(headers)) if (!shouldRemoveHeader(key, removeContent, unknownOrigin)) ret.push(key, headers[key]);
		} else assert$14(headers == null, "headers must be an object or an array");
		return ret;
	}
	module.exports = RedirectHandler;
}));
//#endregion
//#region node_modules/undici/lib/interceptor/redirectInterceptor.js
var require_redirectInterceptor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var RedirectHandler = require_RedirectHandler();
	function createRedirectInterceptor({ maxRedirections: defaultMaxRedirections }) {
		return (dispatch) => {
			return function Intercept(opts, handler) {
				const { maxRedirections = defaultMaxRedirections } = opts;
				if (!maxRedirections) return dispatch(opts, handler);
				const redirectHandler = new RedirectHandler(dispatch, maxRedirections, opts, handler);
				opts = {
					...opts,
					maxRedirections: 0
				};
				return dispatch(opts, redirectHandler);
			};
		};
	}
	module.exports = createRedirectInterceptor;
}));
//#endregion
//#region node_modules/undici/lib/llhttp/llhttp-wasm.js
var require_llhttp_wasm = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = "AGFzbQEAAAABMAhgAX8Bf2ADf39/AX9gBH9/f38Bf2AAAGADf39/AGABfwBgAn9/AGAGf39/f39/AALLAQgDZW52GHdhc21fb25faGVhZGVyc19jb21wbGV0ZQACA2VudhV3YXNtX29uX21lc3NhZ2VfYmVnaW4AAANlbnYLd2FzbV9vbl91cmwAAQNlbnYOd2FzbV9vbl9zdGF0dXMAAQNlbnYUd2FzbV9vbl9oZWFkZXJfZmllbGQAAQNlbnYUd2FzbV9vbl9oZWFkZXJfdmFsdWUAAQNlbnYMd2FzbV9vbl9ib2R5AAEDZW52GHdhc21fb25fbWVzc2FnZV9jb21wbGV0ZQAAA0ZFAwMEAAAFAAAAAAAABQEFAAUFBQAABgAAAAAGBgYGAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAAABAQcAAAUFAwABBAUBcAESEgUDAQACBggBfwFBgNQECwfRBSIGbWVtb3J5AgALX2luaXRpYWxpemUACRlfX2luZGlyZWN0X2Z1bmN0aW9uX3RhYmxlAQALbGxodHRwX2luaXQAChhsbGh0dHBfc2hvdWxkX2tlZXBfYWxpdmUAQQxsbGh0dHBfYWxsb2MADAZtYWxsb2MARgtsbGh0dHBfZnJlZQANBGZyZWUASA9sbGh0dHBfZ2V0X3R5cGUADhVsbGh0dHBfZ2V0X2h0dHBfbWFqb3IADxVsbGh0dHBfZ2V0X2h0dHBfbWlub3IAEBFsbGh0dHBfZ2V0X21ldGhvZAARFmxsaHR0cF9nZXRfc3RhdHVzX2NvZGUAEhJsbGh0dHBfZ2V0X3VwZ3JhZGUAEwxsbGh0dHBfcmVzZXQAFA5sbGh0dHBfZXhlY3V0ZQAVFGxsaHR0cF9zZXR0aW5nc19pbml0ABYNbGxodHRwX2ZpbmlzaAAXDGxsaHR0cF9wYXVzZQAYDWxsaHR0cF9yZXN1bWUAGRtsbGh0dHBfcmVzdW1lX2FmdGVyX3VwZ3JhZGUAGhBsbGh0dHBfZ2V0X2Vycm5vABsXbGxodHRwX2dldF9lcnJvcl9yZWFzb24AHBdsbGh0dHBfc2V0X2Vycm9yX3JlYXNvbgAdFGxsaHR0cF9nZXRfZXJyb3JfcG9zAB4RbGxodHRwX2Vycm5vX25hbWUAHxJsbGh0dHBfbWV0aG9kX25hbWUAIBJsbGh0dHBfc3RhdHVzX25hbWUAIRpsbGh0dHBfc2V0X2xlbmllbnRfaGVhZGVycwAiIWxsaHR0cF9zZXRfbGVuaWVudF9jaHVua2VkX2xlbmd0aAAjHWxsaHR0cF9zZXRfbGVuaWVudF9rZWVwX2FsaXZlACQkbGxodHRwX3NldF9sZW5pZW50X3RyYW5zZmVyX2VuY29kaW5nACUYbGxodHRwX21lc3NhZ2VfbmVlZHNfZW9mAD8JFwEAQQELEQECAwQFCwYHNTk3MS8tJyspCsLgAkUCAAsIABCIgICAAAsZACAAEMKAgIAAGiAAIAI2AjggACABOgAoCxwAIAAgAC8BMiAALQAuIAAQwYCAgAAQgICAgAALKgEBf0HAABDGgICAACIBEMKAgIAAGiABQYCIgIAANgI4IAEgADoAKCABCwoAIAAQyICAgAALBwAgAC0AKAsHACAALQAqCwcAIAAtACsLBwAgAC0AKQsHACAALwEyCwcAIAAtAC4LRQEEfyAAKAIYIQEgAC0ALSECIAAtACghAyAAKAI4IQQgABDCgICAABogACAENgI4IAAgAzoAKCAAIAI6AC0gACABNgIYCxEAIAAgASABIAJqEMOAgIAACxAAIABBAEHcABDMgICAABoLZwEBf0EAIQECQCAAKAIMDQACQAJAAkACQCAALQAvDgMBAAMCCyAAKAI4IgFFDQAgASgCLCIBRQ0AIAAgARGAgICAAAAiAQ0DC0EADwsQyoCAgAAACyAAQcOWgIAANgIQQQ4hAQsgAQseAAJAIAAoAgwNACAAQdGbgIAANgIQIABBFTYCDAsLFgACQCAAKAIMQRVHDQAgAEEANgIMCwsWAAJAIAAoAgxBFkcNACAAQQA2AgwLCwcAIAAoAgwLBwAgACgCEAsJACAAIAE2AhALBwAgACgCFAsiAAJAIABBJEkNABDKgICAAAALIABBAnRBoLOAgABqKAIACyIAAkAgAEEuSQ0AEMqAgIAAAAsgAEECdEGwtICAAGooAgAL7gsBAX9B66iAgAAhAQJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIABBnH9qDvQDY2IAAWFhYWFhYQIDBAVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhBgcICQoLDA0OD2FhYWFhEGFhYWFhYWFhYWFhEWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYRITFBUWFxgZGhthYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhHB0eHyAhIiMkJSYnKCkqKywtLi8wMTIzNDU2YTc4OTphYWFhYWFhYTthYWE8YWFhYT0+P2FhYWFhYWFhQGFhQWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYUJDREVGR0hJSktMTU5PUFFSU2FhYWFhYWFhVFVWV1hZWlthXF1hYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFeYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhX2BhC0Hhp4CAAA8LQaShgIAADwtBy6yAgAAPC0H+sYCAAA8LQcCkgIAADwtBq6SAgAAPC0GNqICAAA8LQeKmgIAADwtBgLCAgAAPC0G5r4CAAA8LQdekgIAADwtB75+AgAAPC0Hhn4CAAA8LQfqfgIAADwtB8qCAgAAPC0Gor4CAAA8LQa6ygIAADwtBiLCAgAAPC0Hsp4CAAA8LQYKigIAADwtBjp2AgAAPC0HQroCAAA8LQcqjgIAADwtBxbKAgAAPC0HfnICAAA8LQdKcgIAADwtBxKCAgAAPC0HXoICAAA8LQaKfgIAADwtB7a6AgAAPC0GrsICAAA8LQdSlgIAADwtBzK6AgAAPC0H6roCAAA8LQfyrgIAADwtB0rCAgAAPC0HxnYCAAA8LQbuggIAADwtB96uAgAAPC0GQsYCAAA8LQdexgIAADwtBoq2AgAAPC0HUp4CAAA8LQeCrgIAADwtBn6yAgAAPC0HrsYCAAA8LQdWfgIAADwtByrGAgAAPC0HepYCAAA8LQdSegIAADwtB9JyAgAAPC0GnsoCAAA8LQbGdgIAADwtBoJ2AgAAPC0G5sYCAAA8LQbywgIAADwtBkqGAgAAPC0GzpoCAAA8LQemsgIAADwtBrJ6AgAAPC0HUq4CAAA8LQfemgIAADwtBgKaAgAAPC0GwoYCAAA8LQf6egIAADwtBjaOAgAAPC0GJrYCAAA8LQfeigIAADwtBoLGAgAAPC0Gun4CAAA8LQcalgIAADwtB6J6AgAAPC0GTooCAAA8LQcKvgIAADwtBw52AgAAPC0GLrICAAA8LQeGdgIAADwtBja+AgAAPC0HqoYCAAA8LQbStgIAADwtB0q+AgAAPC0HfsoCAAA8LQdKygIAADwtB8LCAgAAPC0GpooCAAA8LQfmjgIAADwtBmZ6AgAAPC0G1rICAAA8LQZuwgIAADwtBkrKAgAAPC0G2q4CAAA8LQcKigIAADwtB+LKAgAAPC0GepYCAAA8LQdCigIAADwtBup6AgAAPC0GBnoCAAA8LEMqAgIAAAAtB1qGAgAAhAQsgAQsWACAAIAAtAC1B/gFxIAFBAEdyOgAtCxkAIAAgAC0ALUH9AXEgAUEAR0EBdHI6AC0LGQAgACAALQAtQfsBcSABQQBHQQJ0cjoALQsZACAAIAAtAC1B9wFxIAFBAEdBA3RyOgAtCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAgAiBEUNACAAIAQRgICAgAAAIQMLIAMLSQECf0EAIQMCQCAAKAI4IgRFDQAgBCgCBCIERQ0AIAAgASACIAFrIAQRgYCAgAAAIgNBf0cNACAAQcaRgIAANgIQQRghAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIwIgRFDQAgACAEEYCAgIAAACEDCyADC0kBAn9BACEDAkAgACgCOCIERQ0AIAQoAggiBEUNACAAIAEgAiABayAEEYGAgIAAACIDQX9HDQAgAEH2ioCAADYCEEEYIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCNCIERQ0AIAAgBBGAgICAAAAhAwsgAwtJAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIMIgRFDQAgACABIAIgAWsgBBGBgICAAAAiA0F/Rw0AIABB7ZqAgAA2AhBBGCEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAjgiBEUNACAAIAQRgICAgAAAIQMLIAMLSQECf0EAIQMCQCAAKAI4IgRFDQAgBCgCECIERQ0AIAAgASACIAFrIAQRgYCAgAAAIgNBf0cNACAAQZWQgIAANgIQQRghAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAI8IgRFDQAgACAEEYCAgIAAACEDCyADC0kBAn9BACEDAkAgACgCOCIERQ0AIAQoAhQiBEUNACAAIAEgAiABayAEEYGAgIAAACIDQX9HDQAgAEGqm4CAADYCEEEYIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCQCIERQ0AIAAgBBGAgICAAAAhAwsgAwtJAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIYIgRFDQAgACABIAIgAWsgBBGBgICAAAAiA0F/Rw0AIABB7ZOAgAA2AhBBGCEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAkQiBEUNACAAIAQRgICAgAAAIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCJCIERQ0AIAAgBBGAgICAAAAhAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIsIgRFDQAgACAEEYCAgIAAACEDCyADC0kBAn9BACEDAkAgACgCOCIERQ0AIAQoAigiBEUNACAAIAEgAiABayAEEYGAgIAAACIDQX9HDQAgAEH2iICAADYCEEEYIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCUCIERQ0AIAAgBBGAgICAAAAhAwsgAwtJAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIcIgRFDQAgACABIAIgAWsgBBGBgICAAAAiA0F/Rw0AIABBwpmAgAA2AhBBGCEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAkgiBEUNACAAIAQRgICAgAAAIQMLIAMLSQECf0EAIQMCQCAAKAI4IgRFDQAgBCgCICIERQ0AIAAgASACIAFrIAQRgYCAgAAAIgNBf0cNACAAQZSUgIAANgIQQRghAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAJMIgRFDQAgACAEEYCAgIAAACEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAlQiBEUNACAAIAQRgICAgAAAIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCWCIERQ0AIAAgBBGAgICAAAAhAwsgAwtFAQF/AkACQCAALwEwQRRxQRRHDQBBASEDIAAtAChBAUYNASAALwEyQeUARiEDDAELIAAtAClBBUYhAwsgACADOgAuQQAL/gEBA39BASEDAkAgAC8BMCIEQQhxDQAgACkDIEIAUiEDCwJAAkAgAC0ALkUNAEEBIQUgAC0AKUEFRg0BQQEhBSAEQcAAcUUgA3FBAUcNAQtBACEFIARBwABxDQBBAiEFIARB//8DcSIDQQhxDQACQCADQYAEcUUNAAJAIAAtAChBAUcNACAALQAtQQpxDQBBBQ8LQQQPCwJAIANBIHENAAJAIAAtAChBAUYNACAALwEyQf//A3EiAEGcf2pB5ABJDQAgAEHMAUYNACAAQbACRg0AQQQhBSAEQShxRQ0CIANBiARxQYAERg0CC0EADwtBAEEDIAApAyBQGyEFCyAFC2IBAn9BACEBAkAgAC0AKEEBRg0AIAAvATJB//8DcSICQZx/akHkAEkNACACQcwBRg0AIAJBsAJGDQAgAC8BMCIAQcAAcQ0AQQEhASAAQYgEcUGABEYNACAAQShxRSEBCyABC6cBAQN/AkACQAJAIAAtACpFDQAgAC0AK0UNAEEAIQMgAC8BMCIEQQJxRQ0BDAILQQAhAyAALwEwIgRBAXFFDQELQQEhAyAALQAoQQFGDQAgAC8BMkH//wNxIgVBnH9qQeQASQ0AIAVBzAFGDQAgBUGwAkYNACAEQcAAcQ0AQQAhAyAEQYgEcUGABEYNACAEQShxQQBHIQMLIABBADsBMCAAQQA6AC8gAwuZAQECfwJAAkACQCAALQAqRQ0AIAAtACtFDQBBACEBIAAvATAiAkECcUUNAQwCC0EAIQEgAC8BMCICQQFxRQ0BC0EBIQEgAC0AKEEBRg0AIAAvATJB//8DcSIAQZx/akHkAEkNACAAQcwBRg0AIABBsAJGDQAgAkHAAHENAEEAIQEgAkGIBHFBgARGDQAgAkEocUEARyEBCyABC1kAIABBGGpCADcDACAAQgA3AwAgAEE4akIANwMAIABBMGpCADcDACAAQShqQgA3AwAgAEEgakIANwMAIABBEGpCADcDACAAQQhqQgA3AwAgAEHdATYCHEEAC3sBAX8CQCAAKAIMIgMNAAJAIAAoAgRFDQAgACABNgIECwJAIAAgASACEMSAgIAAIgMNACAAKAIMDwsgACADNgIcQQAhAyAAKAIEIgFFDQAgACABIAIgACgCCBGBgICAAAAiAUUNACAAIAI2AhQgACABNgIMIAEhAwsgAwvk8wEDDn8DfgR/I4CAgIAAQRBrIgMkgICAgAAgASEEIAEhBSABIQYgASEHIAEhCCABIQkgASEKIAEhCyABIQwgASENIAEhDiABIQ8CQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgACgCHCIQQX9qDt0B2gEB2QECAwQFBgcICQoLDA0O2AEPENcBERLWARMUFRYXGBkaG+AB3wEcHR7VAR8gISIjJCXUASYnKCkqKyzTAdIBLS7RAdABLzAxMjM0NTY3ODk6Ozw9Pj9AQUJDREVG2wFHSElKzwHOAUvNAUzMAU1OT1BRUlNUVVZXWFlaW1xdXl9gYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXp7fH1+f4ABgQGCAYMBhAGFAYYBhwGIAYkBigGLAYwBjQGOAY8BkAGRAZIBkwGUAZUBlgGXAZgBmQGaAZsBnAGdAZ4BnwGgAaEBogGjAaQBpQGmAacBqAGpAaoBqwGsAa0BrgGvAbABsQGyAbMBtAG1AbYBtwHLAcoBuAHJAbkByAG6AbsBvAG9Ab4BvwHAAcEBwgHDAcQBxQHGAQDcAQtBACEQDMYBC0EOIRAMxQELQQ0hEAzEAQtBDyEQDMMBC0EQIRAMwgELQRMhEAzBAQtBFCEQDMABC0EVIRAMvwELQRYhEAy+AQtBFyEQDL0BC0EYIRAMvAELQRkhEAy7AQtBGiEQDLoBC0EbIRAMuQELQRwhEAy4AQtBCCEQDLcBC0EdIRAMtgELQSAhEAy1AQtBHyEQDLQBC0EHIRAMswELQSEhEAyyAQtBIiEQDLEBC0EeIRAMsAELQSMhEAyvAQtBEiEQDK4BC0ERIRAMrQELQSQhEAysAQtBJSEQDKsBC0EmIRAMqgELQSchEAypAQtBwwEhEAyoAQtBKSEQDKcBC0ErIRAMpgELQSwhEAylAQtBLSEQDKQBC0EuIRAMowELQS8hEAyiAQtBxAEhEAyhAQtBMCEQDKABC0E0IRAMnwELQQwhEAyeAQtBMSEQDJ0BC0EyIRAMnAELQTMhEAybAQtBOSEQDJoBC0E1IRAMmQELQcUBIRAMmAELQQshEAyXAQtBOiEQDJYBC0E2IRAMlQELQQohEAyUAQtBNyEQDJMBC0E4IRAMkgELQTwhEAyRAQtBOyEQDJABC0E9IRAMjwELQQkhEAyOAQtBKCEQDI0BC0E+IRAMjAELQT8hEAyLAQtBwAAhEAyKAQtBwQAhEAyJAQtBwgAhEAyIAQtBwwAhEAyHAQtBxAAhEAyGAQtBxQAhEAyFAQtBxgAhEAyEAQtBKiEQDIMBC0HHACEQDIIBC0HIACEQDIEBC0HJACEQDIABC0HKACEQDH8LQcsAIRAMfgtBzQAhEAx9C0HMACEQDHwLQc4AIRAMewtBzwAhEAx6C0HQACEQDHkLQdEAIRAMeAtB0gAhEAx3C0HTACEQDHYLQdQAIRAMdQtB1gAhEAx0C0HVACEQDHMLQQYhEAxyC0HXACEQDHELQQUhEAxwC0HYACEQDG8LQQQhEAxuC0HZACEQDG0LQdoAIRAMbAtB2wAhEAxrC0HcACEQDGoLQQMhEAxpC0HdACEQDGgLQd4AIRAMZwtB3wAhEAxmC0HhACEQDGULQeAAIRAMZAtB4gAhEAxjC0HjACEQDGILQQIhEAxhC0HkACEQDGALQeUAIRAMXwtB5gAhEAxeC0HnACEQDF0LQegAIRAMXAtB6QAhEAxbC0HqACEQDFoLQesAIRAMWQtB7AAhEAxYC0HtACEQDFcLQe4AIRAMVgtB7wAhEAxVC0HwACEQDFQLQfEAIRAMUwtB8gAhEAxSC0HzACEQDFELQfQAIRAMUAtB9QAhEAxPC0H2ACEQDE4LQfcAIRAMTQtB+AAhEAxMC0H5ACEQDEsLQfoAIRAMSgtB+wAhEAxJC0H8ACEQDEgLQf0AIRAMRwtB/gAhEAxGC0H/ACEQDEULQYABIRAMRAtBgQEhEAxDC0GCASEQDEILQYMBIRAMQQtBhAEhEAxAC0GFASEQDD8LQYYBIRAMPgtBhwEhEAw9C0GIASEQDDwLQYkBIRAMOwtBigEhEAw6C0GLASEQDDkLQYwBIRAMOAtBjQEhEAw3C0GOASEQDDYLQY8BIRAMNQtBkAEhEAw0C0GRASEQDDMLQZIBIRAMMgtBkwEhEAwxC0GUASEQDDALQZUBIRAMLwtBlgEhEAwuC0GXASEQDC0LQZgBIRAMLAtBmQEhEAwrC0GaASEQDCoLQZsBIRAMKQtBnAEhEAwoC0GdASEQDCcLQZ4BIRAMJgtBnwEhEAwlC0GgASEQDCQLQaEBIRAMIwtBogEhEAwiC0GjASEQDCELQaQBIRAMIAtBpQEhEAwfC0GmASEQDB4LQacBIRAMHQtBqAEhEAwcC0GpASEQDBsLQaoBIRAMGgtBqwEhEAwZC0GsASEQDBgLQa0BIRAMFwtBrgEhEAwWC0EBIRAMFQtBrwEhEAwUC0GwASEQDBMLQbEBIRAMEgtBswEhEAwRC0GyASEQDBALQbQBIRAMDwtBtQEhEAwOC0G2ASEQDA0LQbcBIRAMDAtBuAEhEAwLC0G5ASEQDAoLQboBIRAMCQtBuwEhEAwIC0HGASEQDAcLQbwBIRAMBgtBvQEhEAwFC0G+ASEQDAQLQb8BIRAMAwtBwAEhEAwCC0HCASEQDAELQcEBIRALA0ACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAQDscBAAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxweHyAhIyUoP0BBREVGR0hJSktMTU9QUVJT3gNXWVtcXWBiZWZnaGlqa2xtb3BxcnN0dXZ3eHl6e3x9foABggGFAYYBhwGJAYsBjAGNAY4BjwGQAZEBlAGVAZYBlwGYAZkBmgGbAZwBnQGeAZ8BoAGhAaIBowGkAaUBpgGnAagBqQGqAasBrAGtAa4BrwGwAbEBsgGzAbQBtQG2AbcBuAG5AboBuwG8Ab0BvgG/AcABwQHCAcMBxAHFAcYBxwHIAckBygHLAcwBzQHOAc8B0AHRAdIB0wHUAdUB1gHXAdgB2QHaAdsB3AHdAd4B4AHhAeIB4wHkAeUB5gHnAegB6QHqAesB7AHtAe4B7wHwAfEB8gHzAZkCpAKwAv4C/gILIAEiBCACRw3zAUHdASEQDP8DCyABIhAgAkcN3QFBwwEhEAz+AwsgASIBIAJHDZABQfcAIRAM/QMLIAEiASACRw2GAUHvACEQDPwDCyABIgEgAkcNf0HqACEQDPsDCyABIgEgAkcNe0HoACEQDPoDCyABIgEgAkcNeEHmACEQDPkDCyABIgEgAkcNGkEYIRAM+AMLIAEiASACRw0UQRIhEAz3AwsgASIBIAJHDVlBxQAhEAz2AwsgASIBIAJHDUpBPyEQDPUDCyABIgEgAkcNSEE8IRAM9AMLIAEiASACRw1BQTEhEAzzAwsgAC0ALkEBRg3rAwyHAgsgACABIgEgAhDAgICAAEEBRw3mASAAQgA3AyAM5wELIAAgASIBIAIQtICAgAAiEA3nASABIQEM9QILAkAgASIBIAJHDQBBBiEQDPADCyAAIAFBAWoiASACELuAgIAAIhAN6AEgASEBDDELIABCADcDIEESIRAM1QMLIAEiECACRw0rQR0hEAztAwsCQCABIgEgAkYNACABQQFqIQFBECEQDNQDC0EHIRAM7AMLIABCACAAKQMgIhEgAiABIhBrrSISfSITIBMgEVYbNwMgIBEgElYiFEUN5QFBCCEQDOsDCwJAIAEiASACRg0AIABBiYCAgAA2AgggACABNgIEIAEhAUEUIRAM0gMLQQkhEAzqAwsgASEBIAApAyBQDeQBIAEhAQzyAgsCQCABIgEgAkcNAEELIRAM6QMLIAAgAUEBaiIBIAIQtoCAgAAiEA3lASABIQEM8gILIAAgASIBIAIQuICAgAAiEA3lASABIQEM8gILIAAgASIBIAIQuICAgAAiEA3mASABIQEMDQsgACABIgEgAhC6gICAACIQDecBIAEhAQzwAgsCQCABIgEgAkcNAEEPIRAM5QMLIAEtAAAiEEE7Rg0IIBBBDUcN6AEgAUEBaiEBDO8CCyAAIAEiASACELqAgIAAIhAN6AEgASEBDPICCwNAAkAgAS0AAEHwtYCAAGotAAAiEEEBRg0AIBBBAkcN6wEgACgCBCEQIABBADYCBCAAIBAgAUEBaiIBELmAgIAAIhAN6gEgASEBDPQCCyABQQFqIgEgAkcNAAtBEiEQDOIDCyAAIAEiASACELqAgIAAIhAN6QEgASEBDAoLIAEiASACRw0GQRshEAzgAwsCQCABIgEgAkcNAEEWIRAM4AMLIABBioCAgAA2AgggACABNgIEIAAgASACELiAgIAAIhAN6gEgASEBQSAhEAzGAwsCQCABIgEgAkYNAANAAkAgAS0AAEHwt4CAAGotAAAiEEECRg0AAkAgEEF/ag4E5QHsAQDrAewBCyABQQFqIQFBCCEQDMgDCyABQQFqIgEgAkcNAAtBFSEQDN8DC0EVIRAM3gMLA0ACQCABLQAAQfC5gIAAai0AACIQQQJGDQAgEEF/ag4E3gHsAeAB6wHsAQsgAUEBaiIBIAJHDQALQRghEAzdAwsCQCABIgEgAkYNACAAQYuAgIAANgIIIAAgATYCBCABIQFBByEQDMQDC0EZIRAM3AMLIAFBAWohAQwCCwJAIAEiFCACRw0AQRohEAzbAwsgFCEBAkAgFC0AAEFzag4U3QLuAu4C7gLuAu4C7gLuAu4C7gLuAu4C7gLuAu4C7gLuAu4C7gIA7gILQQAhECAAQQA2AhwgAEGvi4CAADYCECAAQQI2AgwgACAUQQFqNgIUDNoDCwJAIAEtAAAiEEE7Rg0AIBBBDUcN6AEgAUEBaiEBDOUCCyABQQFqIQELQSIhEAy/AwsCQCABIhAgAkcNAEEcIRAM2AMLQgAhESAQIQEgEC0AAEFQag435wHmAQECAwQFBgcIAAAAAAAAAAkKCwwNDgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADxAREhMUAAtBHiEQDL0DC0ICIREM5QELQgMhEQzkAQtCBCERDOMBC0IFIREM4gELQgYhEQzhAQtCByERDOABC0IIIREM3wELQgkhEQzeAQtCCiERDN0BC0ILIREM3AELQgwhEQzbAQtCDSERDNoBC0IOIREM2QELQg8hEQzYAQtCCiERDNcBC0ILIREM1gELQgwhEQzVAQtCDSERDNQBC0IOIREM0wELQg8hEQzSAQtCACERAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAQLQAAQVBqDjflAeQBAAECAwQFBgfmAeYB5gHmAeYB5gHmAQgJCgsMDeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gEODxAREhPmAQtCAiERDOQBC0IDIREM4wELQgQhEQziAQtCBSERDOEBC0IGIREM4AELQgchEQzfAQtCCCERDN4BC0IJIREM3QELQgohEQzcAQtCCyERDNsBC0IMIREM2gELQg0hEQzZAQtCDiERDNgBC0IPIREM1wELQgohEQzWAQtCCyERDNUBC0IMIREM1AELQg0hEQzTAQtCDiERDNIBC0IPIREM0QELIABCACAAKQMgIhEgAiABIhBrrSISfSITIBMgEVYbNwMgIBEgElYiFEUN0gFBHyEQDMADCwJAIAEiASACRg0AIABBiYCAgAA2AgggACABNgIEIAEhAUEkIRAMpwMLQSAhEAy/AwsgACABIhAgAhC+gICAAEF/ag4FtgEAxQIB0QHSAQtBESEQDKQDCyAAQQE6AC8gECEBDLsDCyABIgEgAkcN0gFBJCEQDLsDCyABIg0gAkcNHkHGACEQDLoDCyAAIAEiASACELKAgIAAIhAN1AEgASEBDLUBCyABIhAgAkcNJkHQACEQDLgDCwJAIAEiASACRw0AQSghEAy4AwsgAEEANgIEIABBjICAgAA2AgggACABIAEQsYCAgAAiEA3TASABIQEM2AELAkAgASIQIAJHDQBBKSEQDLcDCyAQLQAAIgFBIEYNFCABQQlHDdMBIBBBAWohAQwVCwJAIAEiASACRg0AIAFBAWohAQwXC0EqIRAMtQMLAkAgASIQIAJHDQBBKyEQDLUDCwJAIBAtAAAiAUEJRg0AIAFBIEcN1QELIAAtACxBCEYN0wEgECEBDJEDCwJAIAEiASACRw0AQSwhEAy0AwsgAS0AAEEKRw3VASABQQFqIQEMyQILIAEiDiACRw3VAUEvIRAMsgMLA0ACQCABLQAAIhBBIEYNAAJAIBBBdmoOBADcAdwBANoBCyABIQEM4AELIAFBAWoiASACRw0AC0ExIRAMsQMLQTIhECABIhQgAkYNsAMgAiAUayAAKAIAIgFqIRUgFCABa0EDaiEWAkADQCAULQAAIhdBIHIgFyAXQb9/akH/AXFBGkkbQf8BcSABQfC7gIAAai0AAEcNAQJAIAFBA0cNAEEGIQEMlgMLIAFBAWohASAUQQFqIhQgAkcNAAsgACAVNgIADLEDCyAAQQA2AgAgFCEBDNkBC0EzIRAgASIUIAJGDa8DIAIgFGsgACgCACIBaiEVIBQgAWtBCGohFgJAA0AgFC0AACIXQSByIBcgF0G/f2pB/wFxQRpJG0H/AXEgAUH0u4CAAGotAABHDQECQCABQQhHDQBBBSEBDJUDCyABQQFqIQEgFEEBaiIUIAJHDQALIAAgFTYCAAywAwsgAEEANgIAIBQhAQzYAQtBNCEQIAEiFCACRg2uAyACIBRrIAAoAgAiAWohFSAUIAFrQQVqIRYCQANAIBQtAAAiF0EgciAXIBdBv39qQf8BcUEaSRtB/wFxIAFB0MKAgABqLQAARw0BAkAgAUEFRw0AQQchAQyUAwsgAUEBaiEBIBRBAWoiFCACRw0ACyAAIBU2AgAMrwMLIABBADYCACAUIQEM1wELAkAgASIBIAJGDQADQAJAIAEtAABBgL6AgABqLQAAIhBBAUYNACAQQQJGDQogASEBDN0BCyABQQFqIgEgAkcNAAtBMCEQDK4DC0EwIRAMrQMLAkAgASIBIAJGDQADQAJAIAEtAAAiEEEgRg0AIBBBdmoOBNkB2gHaAdkB2gELIAFBAWoiASACRw0AC0E4IRAMrQMLQTghEAysAwsDQAJAIAEtAAAiEEEgRg0AIBBBCUcNAwsgAUEBaiIBIAJHDQALQTwhEAyrAwsDQAJAIAEtAAAiEEEgRg0AAkACQCAQQXZqDgTaAQEB2gEACyAQQSxGDdsBCyABIQEMBAsgAUEBaiIBIAJHDQALQT8hEAyqAwsgASEBDNsBC0HAACEQIAEiFCACRg2oAyACIBRrIAAoAgAiAWohFiAUIAFrQQZqIRcCQANAIBQtAABBIHIgAUGAwICAAGotAABHDQEgAUEGRg2OAyABQQFqIQEgFEEBaiIUIAJHDQALIAAgFjYCAAypAwsgAEEANgIAIBQhAQtBNiEQDI4DCwJAIAEiDyACRw0AQcEAIRAMpwMLIABBjICAgAA2AgggACAPNgIEIA8hASAALQAsQX9qDgTNAdUB1wHZAYcDCyABQQFqIQEMzAELAkAgASIBIAJGDQADQAJAIAEtAAAiEEEgciAQIBBBv39qQf8BcUEaSRtB/wFxIhBBCUYNACAQQSBGDQACQAJAAkACQCAQQZ1/ag4TAAMDAwMDAwMBAwMDAwMDAwMDAgMLIAFBAWohAUExIRAMkQMLIAFBAWohAUEyIRAMkAMLIAFBAWohAUEzIRAMjwMLIAEhAQzQAQsgAUEBaiIBIAJHDQALQTUhEAylAwtBNSEQDKQDCwJAIAEiASACRg0AA0ACQCABLQAAQYC8gIAAai0AAEEBRg0AIAEhAQzTAQsgAUEBaiIBIAJHDQALQT0hEAykAwtBPSEQDKMDCyAAIAEiASACELCAgIAAIhAN1gEgASEBDAELIBBBAWohAQtBPCEQDIcDCwJAIAEiASACRw0AQcIAIRAMoAMLAkADQAJAIAEtAABBd2oOGAAC/gL+AoQD/gL+Av4C/gL+Av4C/gL+Av4C/gL+Av4C/gL+Av4C/gL+Av4CAP4CCyABQQFqIgEgAkcNAAtBwgAhEAygAwsgAUEBaiEBIAAtAC1BAXFFDb0BIAEhAQtBLCEQDIUDCyABIgEgAkcN0wFBxAAhEAydAwsDQAJAIAEtAABBkMCAgABqLQAAQQFGDQAgASEBDLcCCyABQQFqIgEgAkcNAAtBxQAhEAycAwsgDS0AACIQQSBGDbMBIBBBOkcNgQMgACgCBCEBIABBADYCBCAAIAEgDRCvgICAACIBDdABIA1BAWohAQyzAgtBxwAhECABIg0gAkYNmgMgAiANayAAKAIAIgFqIRYgDSABa0EFaiEXA0AgDS0AACIUQSByIBQgFEG/f2pB/wFxQRpJG0H/AXEgAUGQwoCAAGotAABHDYADIAFBBUYN9AIgAUEBaiEBIA1BAWoiDSACRw0ACyAAIBY2AgAMmgMLQcgAIRAgASINIAJGDZkDIAIgDWsgACgCACIBaiEWIA0gAWtBCWohFwNAIA0tAAAiFEEgciAUIBRBv39qQf8BcUEaSRtB/wFxIAFBlsKAgABqLQAARw3/AgJAIAFBCUcNAEECIQEM9QILIAFBAWohASANQQFqIg0gAkcNAAsgACAWNgIADJkDCwJAIAEiDSACRw0AQckAIRAMmQMLAkACQCANLQAAIgFBIHIgASABQb9/akH/AXFBGkkbQf8BcUGSf2oOBwCAA4ADgAOAA4ADAYADCyANQQFqIQFBPiEQDIADCyANQQFqIQFBPyEQDP8CC0HKACEQIAEiDSACRg2XAyACIA1rIAAoAgAiAWohFiANIAFrQQFqIRcDQCANLQAAIhRBIHIgFCAUQb9/akH/AXFBGkkbQf8BcSABQaDCgIAAai0AAEcN/QIgAUEBRg3wAiABQQFqIQEgDUEBaiINIAJHDQALIAAgFjYCAAyXAwtBywAhECABIg0gAkYNlgMgAiANayAAKAIAIgFqIRYgDSABa0EOaiEXA0AgDS0AACIUQSByIBQgFEG/f2pB/wFxQRpJG0H/AXEgAUGiwoCAAGotAABHDfwCIAFBDkYN8AIgAUEBaiEBIA1BAWoiDSACRw0ACyAAIBY2AgAMlgMLQcwAIRAgASINIAJGDZUDIAIgDWsgACgCACIBaiEWIA0gAWtBD2ohFwNAIA0tAAAiFEEgciAUIBRBv39qQf8BcUEaSRtB/wFxIAFBwMKAgABqLQAARw37AgJAIAFBD0cNAEEDIQEM8QILIAFBAWohASANQQFqIg0gAkcNAAsgACAWNgIADJUDC0HNACEQIAEiDSACRg2UAyACIA1rIAAoAgAiAWohFiANIAFrQQVqIRcDQCANLQAAIhRBIHIgFCAUQb9/akH/AXFBGkkbQf8BcSABQdDCgIAAai0AAEcN+gICQCABQQVHDQBBBCEBDPACCyABQQFqIQEgDUEBaiINIAJHDQALIAAgFjYCAAyUAwsCQCABIg0gAkcNAEHOACEQDJQDCwJAAkACQAJAIA0tAAAiAUEgciABIAFBv39qQf8BcUEaSRtB/wFxQZ1/ag4TAP0C/QL9Av0C/QL9Av0C/QL9Av0C/QL9AgH9Av0C/QICA/0CCyANQQFqIQFBwQAhEAz9AgsgDUEBaiEBQcIAIRAM/AILIA1BAWohAUHDACEQDPsCCyANQQFqIQFBxAAhEAz6AgsCQCABIgEgAkYNACAAQY2AgIAANgIIIAAgATYCBCABIQFBxQAhEAz6AgtBzwAhEAySAwsgECEBAkACQCAQLQAAQXZqDgQBqAKoAgCoAgsgEEEBaiEBC0EnIRAM+AILAkAgASIBIAJHDQBB0QAhEAyRAwsCQCABLQAAQSBGDQAgASEBDI0BCyABQQFqIQEgAC0ALUEBcUUNxwEgASEBDIwBCyABIhcgAkcNyAFB0gAhEAyPAwtB0wAhECABIhQgAkYNjgMgAiAUayAAKAIAIgFqIRYgFCABa0EBaiEXA0AgFC0AACABQdbCgIAAai0AAEcNzAEgAUEBRg3HASABQQFqIQEgFEEBaiIUIAJHDQALIAAgFjYCAAyOAwsCQCABIgEgAkcNAEHVACEQDI4DCyABLQAAQQpHDcwBIAFBAWohAQzHAQsCQCABIgEgAkcNAEHWACEQDI0DCwJAAkAgAS0AAEF2ag4EAM0BzQEBzQELIAFBAWohAQzHAQsgAUEBaiEBQcoAIRAM8wILIAAgASIBIAIQroCAgAAiEA3LASABIQFBzQAhEAzyAgsgAC0AKUEiRg2FAwymAgsCQCABIgEgAkcNAEHbACEQDIoDC0EAIRRBASEXQQEhFkEAIRACQAJAAkACQAJAAkACQAJAAkAgAS0AAEFQag4K1AHTAQABAgMEBQYI1QELQQIhEAwGC0EDIRAMBQtBBCEQDAQLQQUhEAwDC0EGIRAMAgtBByEQDAELQQghEAtBACEXQQAhFkEAIRQMzAELQQkhEEEBIRRBACEXQQAhFgzLAQsCQCABIgEgAkcNAEHdACEQDIkDCyABLQAAQS5HDcwBIAFBAWohAQymAgsgASIBIAJHDcwBQd8AIRAMhwMLAkAgASIBIAJGDQAgAEGOgICAADYCCCAAIAE2AgQgASEBQdAAIRAM7gILQeAAIRAMhgMLQeEAIRAgASIBIAJGDYUDIAIgAWsgACgCACIUaiEWIAEgFGtBA2ohFwNAIAEtAAAgFEHiwoCAAGotAABHDc0BIBRBA0YNzAEgFEEBaiEUIAFBAWoiASACRw0ACyAAIBY2AgAMhQMLQeIAIRAgASIBIAJGDYQDIAIgAWsgACgCACIUaiEWIAEgFGtBAmohFwNAIAEtAAAgFEHmwoCAAGotAABHDcwBIBRBAkYNzgEgFEEBaiEUIAFBAWoiASACRw0ACyAAIBY2AgAMhAMLQeMAIRAgASIBIAJGDYMDIAIgAWsgACgCACIUaiEWIAEgFGtBA2ohFwNAIAEtAAAgFEHpwoCAAGotAABHDcsBIBRBA0YNzgEgFEEBaiEUIAFBAWoiASACRw0ACyAAIBY2AgAMgwMLAkAgASIBIAJHDQBB5QAhEAyDAwsgACABQQFqIgEgAhCogICAACIQDc0BIAEhAUHWACEQDOkCCwJAIAEiASACRg0AA0ACQCABLQAAIhBBIEYNAAJAAkACQCAQQbh/ag4LAAHPAc8BzwHPAc8BzwHPAc8BAs8BCyABQQFqIQFB0gAhEAztAgsgAUEBaiEBQdMAIRAM7AILIAFBAWohAUHUACEQDOsCCyABQQFqIgEgAkcNAAtB5AAhEAyCAwtB5AAhEAyBAwsDQAJAIAEtAABB8MKAgABqLQAAIhBBAUYNACAQQX5qDgPPAdAB0QHSAQsgAUEBaiIBIAJHDQALQeYAIRAMgAMLAkAgASIBIAJGDQAgAUEBaiEBDAMLQecAIRAM/wILA0ACQCABLQAAQfDEgIAAai0AACIQQQFGDQACQCAQQX5qDgTSAdMB1AEA1QELIAEhAUHXACEQDOcCCyABQQFqIgEgAkcNAAtB6AAhEAz+AgsCQCABIgEgAkcNAEHpACEQDP4CCwJAIAEtAAAiEEF2ag4augHVAdUBvAHVAdUB1QHVAdUB1QHVAdUB1QHVAdUB1QHVAdUB1QHVAdUB1QHKAdUB1QEA0wELIAFBAWohAQtBBiEQDOMCCwNAAkAgAS0AAEHwxoCAAGotAABBAUYNACABIQEMngILIAFBAWoiASACRw0AC0HqACEQDPsCCwJAIAEiASACRg0AIAFBAWohAQwDC0HrACEQDPoCCwJAIAEiASACRw0AQewAIRAM+gILIAFBAWohAQwBCwJAIAEiASACRw0AQe0AIRAM+QILIAFBAWohAQtBBCEQDN4CCwJAIAEiFCACRw0AQe4AIRAM9wILIBQhAQJAAkACQCAULQAAQfDIgIAAai0AAEF/ag4H1AHVAdYBAJwCAQLXAQsgFEEBaiEBDAoLIBRBAWohAQzNAQtBACEQIABBADYCHCAAQZuSgIAANgIQIABBBzYCDCAAIBRBAWo2AhQM9gILAkADQAJAIAEtAABB8MiAgABqLQAAIhBBBEYNAAJAAkAgEEF/ag4H0gHTAdQB2QEABAHZAQsgASEBQdoAIRAM4AILIAFBAWohAUHcACEQDN8CCyABQQFqIgEgAkcNAAtB7wAhEAz2AgsgAUEBaiEBDMsBCwJAIAEiFCACRw0AQfAAIRAM9QILIBQtAABBL0cN1AEgFEEBaiEBDAYLAkAgASIUIAJHDQBB8QAhEAz0AgsCQCAULQAAIgFBL0cNACAUQQFqIQFB3QAhEAzbAgsgAUF2aiIEQRZLDdMBQQEgBHRBiYCAAnFFDdMBDMoCCwJAIAEiASACRg0AIAFBAWohAUHeACEQDNoCC0HyACEQDPICCwJAIAEiFCACRw0AQfQAIRAM8gILIBQhAQJAIBQtAABB8MyAgABqLQAAQX9qDgPJApQCANQBC0HhACEQDNgCCwJAIAEiFCACRg0AA0ACQCAULQAAQfDKgIAAai0AACIBQQNGDQACQCABQX9qDgLLAgDVAQsgFCEBQd8AIRAM2gILIBRBAWoiFCACRw0AC0HzACEQDPECC0HzACEQDPACCwJAIAEiASACRg0AIABBj4CAgAA2AgggACABNgIEIAEhAUHgACEQDNcCC0H1ACEQDO8CCwJAIAEiASACRw0AQfYAIRAM7wILIABBj4CAgAA2AgggACABNgIEIAEhAQtBAyEQDNQCCwNAIAEtAABBIEcNwwIgAUEBaiIBIAJHDQALQfcAIRAM7AILAkAgASIBIAJHDQBB+AAhEAzsAgsgAS0AAEEgRw3OASABQQFqIQEM7wELIAAgASIBIAIQrICAgAAiEA3OASABIQEMjgILAkAgASIEIAJHDQBB+gAhEAzqAgsgBC0AAEHMAEcN0QEgBEEBaiEBQRMhEAzPAQsCQCABIgQgAkcNAEH7ACEQDOkCCyACIARrIAAoAgAiAWohFCAEIAFrQQVqIRADQCAELQAAIAFB8M6AgABqLQAARw3QASABQQVGDc4BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQfsAIRAM6AILAkAgASIEIAJHDQBB/AAhEAzoAgsCQAJAIAQtAABBvX9qDgwA0QHRAdEB0QHRAdEB0QHRAdEB0QEB0QELIARBAWohAUHmACEQDM8CCyAEQQFqIQFB5wAhEAzOAgsCQCABIgQgAkcNAEH9ACEQDOcCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHtz4CAAGotAABHDc8BIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEH9ACEQDOcCCyAAQQA2AgAgEEEBaiEBQRAhEAzMAQsCQCABIgQgAkcNAEH+ACEQDOYCCyACIARrIAAoAgAiAWohFCAEIAFrQQVqIRACQANAIAQtAAAgAUH2zoCAAGotAABHDc4BIAFBBUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEH+ACEQDOYCCyAAQQA2AgAgEEEBaiEBQRYhEAzLAQsCQCABIgQgAkcNAEH/ACEQDOUCCyACIARrIAAoAgAiAWohFCAEIAFrQQNqIRACQANAIAQtAAAgAUH8zoCAAGotAABHDc0BIAFBA0YNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEH/ACEQDOUCCyAAQQA2AgAgEEEBaiEBQQUhEAzKAQsCQCABIgQgAkcNAEGAASEQDOQCCyAELQAAQdkARw3LASAEQQFqIQFBCCEQDMkBCwJAIAEiBCACRw0AQYEBIRAM4wILAkACQCAELQAAQbJ/ag4DAMwBAcwBCyAEQQFqIQFB6wAhEAzKAgsgBEEBaiEBQewAIRAMyQILAkAgASIEIAJHDQBBggEhEAziAgsCQAJAIAQtAABBuH9qDggAywHLAcsBywHLAcsBAcsBCyAEQQFqIQFB6gAhEAzJAgsgBEEBaiEBQe0AIRAMyAILAkAgASIEIAJHDQBBgwEhEAzhAgsgAiAEayAAKAIAIgFqIRAgBCABa0ECaiEUAkADQCAELQAAIAFBgM+AgABqLQAARw3JASABQQJGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBA2AgBBgwEhEAzhAgtBACEQIABBADYCACAUQQFqIQEMxgELAkAgASIEIAJHDQBBhAEhEAzgAgsgAiAEayAAKAIAIgFqIRQgBCABa0EEaiEQAkADQCAELQAAIAFBg8+AgABqLQAARw3IASABQQRGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBhAEhEAzgAgsgAEEANgIAIBBBAWohAUEjIRAMxQELAkAgASIEIAJHDQBBhQEhEAzfAgsCQAJAIAQtAABBtH9qDggAyAHIAcgByAHIAcgBAcgBCyAEQQFqIQFB7wAhEAzGAgsgBEEBaiEBQfAAIRAMxQILAkAgASIEIAJHDQBBhgEhEAzeAgsgBC0AAEHFAEcNxQEgBEEBaiEBDIMCCwJAIAEiBCACRw0AQYcBIRAM3QILIAIgBGsgACgCACIBaiEUIAQgAWtBA2ohEAJAA0AgBC0AACABQYjPgIAAai0AAEcNxQEgAUEDRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQYcBIRAM3QILIABBADYCACAQQQFqIQFBLSEQDMIBCwJAIAEiBCACRw0AQYgBIRAM3AILIAIgBGsgACgCACIBaiEUIAQgAWtBCGohEAJAA0AgBC0AACABQdDPgIAAai0AAEcNxAEgAUEIRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQYgBIRAM3AILIABBADYCACAQQQFqIQFBKSEQDMEBCwJAIAEiASACRw0AQYkBIRAM2wILQQEhECABLQAAQd8ARw3AASABQQFqIQEMgQILAkAgASIEIAJHDQBBigEhEAzaAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQA0AgBC0AACABQYzPgIAAai0AAEcNwQEgAUEBRg2vAiABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGKASEQDNkCCwJAIAEiBCACRw0AQYsBIRAM2QILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQY7PgIAAai0AAEcNwQEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQYsBIRAM2QILIABBADYCACAQQQFqIQFBAiEQDL4BCwJAIAEiBCACRw0AQYwBIRAM2AILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQfDPgIAAai0AAEcNwAEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQYwBIRAM2AILIABBADYCACAQQQFqIQFBHyEQDL0BCwJAIAEiBCACRw0AQY0BIRAM1wILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQfLPgIAAai0AAEcNvwEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQY0BIRAM1wILIABBADYCACAQQQFqIQFBCSEQDLwBCwJAIAEiBCACRw0AQY4BIRAM1gILAkACQCAELQAAQbd/ag4HAL8BvwG/Ab8BvwEBvwELIARBAWohAUH4ACEQDL0CCyAEQQFqIQFB+QAhEAy8AgsCQCABIgQgAkcNAEGPASEQDNUCCyACIARrIAAoAgAiAWohFCAEIAFrQQVqIRACQANAIAQtAAAgAUGRz4CAAGotAABHDb0BIAFBBUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGPASEQDNUCCyAAQQA2AgAgEEEBaiEBQRghEAy6AQsCQCABIgQgAkcNAEGQASEQDNQCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUGXz4CAAGotAABHDbwBIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGQASEQDNQCCyAAQQA2AgAgEEEBaiEBQRchEAy5AQsCQCABIgQgAkcNAEGRASEQDNMCCyACIARrIAAoAgAiAWohFCAEIAFrQQZqIRACQANAIAQtAAAgAUGaz4CAAGotAABHDbsBIAFBBkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGRASEQDNMCCyAAQQA2AgAgEEEBaiEBQRUhEAy4AQsCQCABIgQgAkcNAEGSASEQDNICCyACIARrIAAoAgAiAWohFCAEIAFrQQVqIRACQANAIAQtAAAgAUGhz4CAAGotAABHDboBIAFBBUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGSASEQDNICCyAAQQA2AgAgEEEBaiEBQR4hEAy3AQsCQCABIgQgAkcNAEGTASEQDNECCyAELQAAQcwARw24ASAEQQFqIQFBCiEQDLYBCwJAIAQgAkcNAEGUASEQDNACCwJAAkAgBC0AAEG/f2oODwC5AbkBuQG5AbkBuQG5AbkBuQG5AbkBuQG5AQG5AQsgBEEBaiEBQf4AIRAMtwILIARBAWohAUH/ACEQDLYCCwJAIAQgAkcNAEGVASEQDM8CCwJAAkAgBC0AAEG/f2oOAwC4AQG4AQsgBEEBaiEBQf0AIRAMtgILIARBAWohBEGAASEQDLUCCwJAIAQgAkcNAEGWASEQDM4CCyACIARrIAAoAgAiAWohFCAEIAFrQQFqIRACQANAIAQtAAAgAUGnz4CAAGotAABHDbYBIAFBAUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGWASEQDM4CCyAAQQA2AgAgEEEBaiEBQQshEAyzAQsCQCAEIAJHDQBBlwEhEAzNAgsCQAJAAkACQCAELQAAQVNqDiMAuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AQG4AbgBuAG4AbgBArgBuAG4AQO4AQsgBEEBaiEBQfsAIRAMtgILIARBAWohAUH8ACEQDLUCCyAEQQFqIQRBgQEhEAy0AgsgBEEBaiEEQYIBIRAMswILAkAgBCACRw0AQZgBIRAMzAILIAIgBGsgACgCACIBaiEUIAQgAWtBBGohEAJAA0AgBC0AACABQanPgIAAai0AAEcNtAEgAUEERg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZgBIRAMzAILIABBADYCACAQQQFqIQFBGSEQDLEBCwJAIAQgAkcNAEGZASEQDMsCCyACIARrIAAoAgAiAWohFCAEIAFrQQVqIRACQANAIAQtAAAgAUGuz4CAAGotAABHDbMBIAFBBUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGZASEQDMsCCyAAQQA2AgAgEEEBaiEBQQYhEAywAQsCQCAEIAJHDQBBmgEhEAzKAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFBtM+AgABqLQAARw2yASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBmgEhEAzKAgsgAEEANgIAIBBBAWohAUEcIRAMrwELAkAgBCACRw0AQZsBIRAMyQILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQbbPgIAAai0AAEcNsQEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZsBIRAMyQILIABBADYCACAQQQFqIQFBJyEQDK4BCwJAIAQgAkcNAEGcASEQDMgCCwJAAkAgBC0AAEGsf2oOAgABsQELIARBAWohBEGGASEQDK8CCyAEQQFqIQRBhwEhEAyuAgsCQCAEIAJHDQBBnQEhEAzHAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFBuM+AgABqLQAARw2vASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBnQEhEAzHAgsgAEEANgIAIBBBAWohAUEmIRAMrAELAkAgBCACRw0AQZ4BIRAMxgILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQbrPgIAAai0AAEcNrgEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZ4BIRAMxgILIABBADYCACAQQQFqIQFBAyEQDKsBCwJAIAQgAkcNAEGfASEQDMUCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHtz4CAAGotAABHDa0BIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGfASEQDMUCCyAAQQA2AgAgEEEBaiEBQQwhEAyqAQsCQCAEIAJHDQBBoAEhEAzEAgsgAiAEayAAKAIAIgFqIRQgBCABa0EDaiEQAkADQCAELQAAIAFBvM+AgABqLQAARw2sASABQQNGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBoAEhEAzEAgsgAEEANgIAIBBBAWohAUENIRAMqQELAkAgBCACRw0AQaEBIRAMwwILAkACQCAELQAAQbp/ag4LAKwBrAGsAawBrAGsAawBrAGsAQGsAQsgBEEBaiEEQYsBIRAMqgILIARBAWohBEGMASEQDKkCCwJAIAQgAkcNAEGiASEQDMICCyAELQAAQdAARw2pASAEQQFqIQQM6QELAkAgBCACRw0AQaMBIRAMwQILAkACQCAELQAAQbd/ag4HAaoBqgGqAaoBqgEAqgELIARBAWohBEGOASEQDKgCCyAEQQFqIQFBIiEQDKYBCwJAIAQgAkcNAEGkASEQDMACCyACIARrIAAoAgAiAWohFCAEIAFrQQFqIRACQANAIAQtAAAgAUHAz4CAAGotAABHDagBIAFBAUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGkASEQDMACCyAAQQA2AgAgEEEBaiEBQR0hEAylAQsCQCAEIAJHDQBBpQEhEAy/AgsCQAJAIAQtAABBrn9qDgMAqAEBqAELIARBAWohBEGQASEQDKYCCyAEQQFqIQFBBCEQDKQBCwJAIAQgAkcNAEGmASEQDL4CCwJAAkACQAJAAkAgBC0AAEG/f2oOFQCqAaoBqgGqAaoBqgGqAaoBqgGqAQGqAaoBAqoBqgEDqgGqAQSqAQsgBEEBaiEEQYgBIRAMqAILIARBAWohBEGJASEQDKcCCyAEQQFqIQRBigEhEAymAgsgBEEBaiEEQY8BIRAMpQILIARBAWohBEGRASEQDKQCCwJAIAQgAkcNAEGnASEQDL0CCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHtz4CAAGotAABHDaUBIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGnASEQDL0CCyAAQQA2AgAgEEEBaiEBQREhEAyiAQsCQCAEIAJHDQBBqAEhEAy8AgsgAiAEayAAKAIAIgFqIRQgBCABa0ECaiEQAkADQCAELQAAIAFBws+AgABqLQAARw2kASABQQJGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBqAEhEAy8AgsgAEEANgIAIBBBAWohAUEsIRAMoQELAkAgBCACRw0AQakBIRAMuwILIAIgBGsgACgCACIBaiEUIAQgAWtBBGohEAJAA0AgBC0AACABQcXPgIAAai0AAEcNowEgAUEERg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQakBIRAMuwILIABBADYCACAQQQFqIQFBKyEQDKABCwJAIAQgAkcNAEGqASEQDLoCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHKz4CAAGotAABHDaIBIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGqASEQDLoCCyAAQQA2AgAgEEEBaiEBQRQhEAyfAQsCQCAEIAJHDQBBqwEhEAy5AgsCQAJAAkACQCAELQAAQb5/ag4PAAECpAGkAaQBpAGkAaQBpAGkAaQBpAGkAQOkAQsgBEEBaiEEQZMBIRAMogILIARBAWohBEGUASEQDKECCyAEQQFqIQRBlQEhEAygAgsgBEEBaiEEQZYBIRAMnwILAkAgBCACRw0AQawBIRAMuAILIAQtAABBxQBHDZ8BIARBAWohBAzgAQsCQCAEIAJHDQBBrQEhEAy3AgsgAiAEayAAKAIAIgFqIRQgBCABa0ECaiEQAkADQCAELQAAIAFBzc+AgABqLQAARw2fASABQQJGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBrQEhEAy3AgsgAEEANgIAIBBBAWohAUEOIRAMnAELAkAgBCACRw0AQa4BIRAMtgILIAQtAABB0ABHDZ0BIARBAWohAUElIRAMmwELAkAgBCACRw0AQa8BIRAMtQILIAIgBGsgACgCACIBaiEUIAQgAWtBCGohEAJAA0AgBC0AACABQdDPgIAAai0AAEcNnQEgAUEIRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQa8BIRAMtQILIABBADYCACAQQQFqIQFBKiEQDJoBCwJAIAQgAkcNAEGwASEQDLQCCwJAAkAgBC0AAEGrf2oOCwCdAZ0BnQGdAZ0BnQGdAZ0BnQEBnQELIARBAWohBEGaASEQDJsCCyAEQQFqIQRBmwEhEAyaAgsCQCAEIAJHDQBBsQEhEAyzAgsCQAJAIAQtAABBv39qDhQAnAGcAZwBnAGcAZwBnAGcAZwBnAGcAZwBnAGcAZwBnAGcAZwBAZwBCyAEQQFqIQRBmQEhEAyaAgsgBEEBaiEEQZwBIRAMmQILAkAgBCACRw0AQbIBIRAMsgILIAIgBGsgACgCACIBaiEUIAQgAWtBA2ohEAJAA0AgBC0AACABQdnPgIAAai0AAEcNmgEgAUEDRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQbIBIRAMsgILIABBADYCACAQQQFqIQFBISEQDJcBCwJAIAQgAkcNAEGzASEQDLECCyACIARrIAAoAgAiAWohFCAEIAFrQQZqIRACQANAIAQtAAAgAUHdz4CAAGotAABHDZkBIAFBBkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGzASEQDLECCyAAQQA2AgAgEEEBaiEBQRohEAyWAQsCQCAEIAJHDQBBtAEhEAywAgsCQAJAAkAgBC0AAEG7f2oOEQCaAZoBmgGaAZoBmgGaAZoBmgEBmgGaAZoBmgGaAQKaAQsgBEEBaiEEQZ0BIRAMmAILIARBAWohBEGeASEQDJcCCyAEQQFqIQRBnwEhEAyWAgsCQCAEIAJHDQBBtQEhEAyvAgsgAiAEayAAKAIAIgFqIRQgBCABa0EFaiEQAkADQCAELQAAIAFB5M+AgABqLQAARw2XASABQQVGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBtQEhEAyvAgsgAEEANgIAIBBBAWohAUEoIRAMlAELAkAgBCACRw0AQbYBIRAMrgILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQerPgIAAai0AAEcNlgEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQbYBIRAMrgILIABBADYCACAQQQFqIQFBByEQDJMBCwJAIAQgAkcNAEG3ASEQDK0CCwJAAkAgBC0AAEG7f2oODgCWAZYBlgGWAZYBlgGWAZYBlgGWAZYBlgEBlgELIARBAWohBEGhASEQDJQCCyAEQQFqIQRBogEhEAyTAgsCQCAEIAJHDQBBuAEhEAysAgsgAiAEayAAKAIAIgFqIRQgBCABa0ECaiEQAkADQCAELQAAIAFB7c+AgABqLQAARw2UASABQQJGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBuAEhEAysAgsgAEEANgIAIBBBAWohAUESIRAMkQELAkAgBCACRw0AQbkBIRAMqwILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQfDPgIAAai0AAEcNkwEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQbkBIRAMqwILIABBADYCACAQQQFqIQFBICEQDJABCwJAIAQgAkcNAEG6ASEQDKoCCyACIARrIAAoAgAiAWohFCAEIAFrQQFqIRACQANAIAQtAAAgAUHyz4CAAGotAABHDZIBIAFBAUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEG6ASEQDKoCCyAAQQA2AgAgEEEBaiEBQQ8hEAyPAQsCQCAEIAJHDQBBuwEhEAypAgsCQAJAIAQtAABBt39qDgcAkgGSAZIBkgGSAQGSAQsgBEEBaiEEQaUBIRAMkAILIARBAWohBEGmASEQDI8CCwJAIAQgAkcNAEG8ASEQDKgCCyACIARrIAAoAgAiAWohFCAEIAFrQQdqIRACQANAIAQtAAAgAUH0z4CAAGotAABHDZABIAFBB0YNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEG8ASEQDKgCCyAAQQA2AgAgEEEBaiEBQRshEAyNAQsCQCAEIAJHDQBBvQEhEAynAgsCQAJAAkAgBC0AAEG+f2oOEgCRAZEBkQGRAZEBkQGRAZEBkQEBkQGRAZEBkQGRAZEBApEBCyAEQQFqIQRBpAEhEAyPAgsgBEEBaiEEQacBIRAMjgILIARBAWohBEGoASEQDI0CCwJAIAQgAkcNAEG+ASEQDKYCCyAELQAAQc4ARw2NASAEQQFqIQQMzwELAkAgBCACRw0AQb8BIRAMpQILAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgBC0AAEG/f2oOFQABAgOcAQQFBpwBnAGcAQcICQoLnAEMDQ4PnAELIARBAWohAUHoACEQDJoCCyAEQQFqIQFB6QAhEAyZAgsgBEEBaiEBQe4AIRAMmAILIARBAWohAUHyACEQDJcCCyAEQQFqIQFB8wAhEAyWAgsgBEEBaiEBQfYAIRAMlQILIARBAWohAUH3ACEQDJQCCyAEQQFqIQFB+gAhEAyTAgsgBEEBaiEEQYMBIRAMkgILIARBAWohBEGEASEQDJECCyAEQQFqIQRBhQEhEAyQAgsgBEEBaiEEQZIBIRAMjwILIARBAWohBEGYASEQDI4CCyAEQQFqIQRBoAEhEAyNAgsgBEEBaiEEQaMBIRAMjAILIARBAWohBEGqASEQDIsCCwJAIAQgAkYNACAAQZCAgIAANgIIIAAgBDYCBEGrASEQDIsCC0HAASEQDKMCCyAAIAUgAhCqgICAACIBDYsBIAUhAQxcCwJAIAYgAkYNACAGQQFqIQUMjQELQcIBIRAMoQILA0ACQCAQLQAAQXZqDgSMAQAAjwEACyAQQQFqIhAgAkcNAAtBwwEhEAygAgsCQCAHIAJGDQAgAEGRgICAADYCCCAAIAc2AgQgByEBQQEhEAyHAgtBxAEhEAyfAgsCQCAHIAJHDQBBxQEhEAyfAgsCQAJAIActAABBdmoOBAHOAc4BAM4BCyAHQQFqIQYMjQELIAdBAWohBQyJAQsCQCAHIAJHDQBBxgEhEAyeAgsCQAJAIActAABBdmoOFwGPAY8BAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAQCPAQsgB0EBaiEHC0GwASEQDIQCCwJAIAggAkcNAEHIASEQDJ0CCyAILQAAQSBHDY0BIABBADsBMiAIQQFqIQFBswEhEAyDAgsgASEXAkADQCAXIgcgAkYNASAHLQAAQVBqQf8BcSIQQQpPDcwBAkAgAC8BMiIUQZkzSw0AIAAgFEEKbCIUOwEyIBBB//8DcyAUQf7/A3FJDQAgB0EBaiEXIAAgFCAQaiIQOwEyIBBB//8DcUHoB0kNAQsLQQAhECAAQQA2AhwgAEHBiYCAADYCECAAQQ02AgwgACAHQQFqNgIUDJwCC0HHASEQDJsCCyAAIAggAhCugICAACIQRQ3KASAQQRVHDYwBIABByAE2AhwgACAINgIUIABByZeAgAA2AhAgAEEVNgIMQQAhEAyaAgsCQCAJIAJHDQBBzAEhEAyaAgtBACEUQQEhF0EBIRZBACEQAkACQAJAAkACQAJAAkACQAJAIAktAABBUGoOCpYBlQEAAQIDBAUGCJcBC0ECIRAMBgtBAyEQDAULQQQhEAwEC0EFIRAMAwtBBiEQDAILQQchEAwBC0EIIRALQQAhF0EAIRZBACEUDI4BC0EJIRBBASEUQQAhF0EAIRYMjQELAkAgCiACRw0AQc4BIRAMmQILIAotAABBLkcNjgEgCkEBaiEJDMoBCyALIAJHDY4BQdABIRAMlwILAkAgCyACRg0AIABBjoCAgAA2AgggACALNgIEQbcBIRAM/gELQdEBIRAMlgILAkAgBCACRw0AQdIBIRAMlgILIAIgBGsgACgCACIQaiEUIAQgEGtBBGohCwNAIAQtAAAgEEH8z4CAAGotAABHDY4BIBBBBEYN6QEgEEEBaiEQIARBAWoiBCACRw0ACyAAIBQ2AgBB0gEhEAyVAgsgACAMIAIQrICAgAAiAQ2NASAMIQEMuAELAkAgBCACRw0AQdQBIRAMlAILIAIgBGsgACgCACIQaiEUIAQgEGtBAWohDANAIAQtAAAgEEGB0ICAAGotAABHDY8BIBBBAUYNjgEgEEEBaiEQIARBAWoiBCACRw0ACyAAIBQ2AgBB1AEhEAyTAgsCQCAEIAJHDQBB1gEhEAyTAgsgAiAEayAAKAIAIhBqIRQgBCAQa0ECaiELA0AgBC0AACAQQYPQgIAAai0AAEcNjgEgEEECRg2QASAQQQFqIRAgBEEBaiIEIAJHDQALIAAgFDYCAEHWASEQDJICCwJAIAQgAkcNAEHXASEQDJICCwJAAkAgBC0AAEG7f2oOEACPAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BAY8BCyAEQQFqIQRBuwEhEAz5AQsgBEEBaiEEQbwBIRAM+AELAkAgBCACRw0AQdgBIRAMkQILIAQtAABByABHDYwBIARBAWohBAzEAQsCQCAEIAJGDQAgAEGQgICAADYCCCAAIAQ2AgRBvgEhEAz3AQtB2QEhEAyPAgsCQCAEIAJHDQBB2gEhEAyPAgsgBC0AAEHIAEYNwwEgAEEBOgAoDLkBCyAAQQI6AC8gACAEIAIQpoCAgAAiEA2NAUHCASEQDPQBCyAALQAoQX9qDgK3AbkBuAELA0ACQCAELQAAQXZqDgQAjgGOAQCOAQsgBEEBaiIEIAJHDQALQd0BIRAMiwILIABBADoALyAALQAtQQRxRQ2EAgsgAEEAOgAvIABBAToANCABIQEMjAELIBBBFUYN2gEgAEEANgIcIAAgATYCFCAAQaeOgIAANgIQIABBEjYCDEEAIRAMiAILAkAgACAQIAIQtICAgAAiBA0AIBAhAQyBAgsCQCAEQRVHDQAgAEEDNgIcIAAgEDYCFCAAQbCYgIAANgIQIABBFTYCDEEAIRAMiAILIABBADYCHCAAIBA2AhQgAEGnjoCAADYCECAAQRI2AgxBACEQDIcCCyAQQRVGDdYBIABBADYCHCAAIAE2AhQgAEHajYCAADYCECAAQRQ2AgxBACEQDIYCCyAAKAIEIRcgAEEANgIEIBAgEadqIhYhASAAIBcgECAWIBQbIhAQtYCAgAAiFEUNjQEgAEEHNgIcIAAgEDYCFCAAIBQ2AgxBACEQDIUCCyAAIAAvATBBgAFyOwEwIAEhAQtBKiEQDOoBCyAQQRVGDdEBIABBADYCHCAAIAE2AhQgAEGDjICAADYCECAAQRM2AgxBACEQDIICCyAQQRVGDc8BIABBADYCHCAAIAE2AhQgAEGaj4CAADYCECAAQSI2AgxBACEQDIECCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQt4CAgAAiEA0AIAFBAWohAQyNAQsgAEEMNgIcIAAgEDYCDCAAIAFBAWo2AhRBACEQDIACCyAQQRVGDcwBIABBADYCHCAAIAE2AhQgAEGaj4CAADYCECAAQSI2AgxBACEQDP8BCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQt4CAgAAiEA0AIAFBAWohAQyMAQsgAEENNgIcIAAgEDYCDCAAIAFBAWo2AhRBACEQDP4BCyAQQRVGDckBIABBADYCHCAAIAE2AhQgAEHGjICAADYCECAAQSM2AgxBACEQDP0BCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQuYCAgAAiEA0AIAFBAWohAQyLAQsgAEEONgIcIAAgEDYCDCAAIAFBAWo2AhRBACEQDPwBCyAAQQA2AhwgACABNgIUIABBwJWAgAA2AhAgAEECNgIMQQAhEAz7AQsgEEEVRg3FASAAQQA2AhwgACABNgIUIABBxoyAgAA2AhAgAEEjNgIMQQAhEAz6AQsgAEEQNgIcIAAgATYCFCAAIBA2AgxBACEQDPkBCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQuYCAgAAiBA0AIAFBAWohAQzxAQsgAEERNgIcIAAgBDYCDCAAIAFBAWo2AhRBACEQDPgBCyAQQRVGDcEBIABBADYCHCAAIAE2AhQgAEHGjICAADYCECAAQSM2AgxBACEQDPcBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQuYCAgAAiEA0AIAFBAWohAQyIAQsgAEETNgIcIAAgEDYCDCAAIAFBAWo2AhRBACEQDPYBCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQuYCAgAAiBA0AIAFBAWohAQztAQsgAEEUNgIcIAAgBDYCDCAAIAFBAWo2AhRBACEQDPUBCyAQQRVGDb0BIABBADYCHCAAIAE2AhQgAEGaj4CAADYCECAAQSI2AgxBACEQDPQBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQt4CAgAAiEA0AIAFBAWohAQyGAQsgAEEWNgIcIAAgEDYCDCAAIAFBAWo2AhRBACEQDPMBCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQt4CAgAAiBA0AIAFBAWohAQzpAQsgAEEXNgIcIAAgBDYCDCAAIAFBAWo2AhRBACEQDPIBCyAAQQA2AhwgACABNgIUIABBzZOAgAA2AhAgAEEMNgIMQQAhEAzxAQtCASERCyAQQQFqIQECQCAAKQMgIhJC//////////8PVg0AIAAgEkIEhiARhDcDICABIQEMhAELIABBADYCHCAAIAE2AhQgAEGtiYCAADYCECAAQQw2AgxBACEQDO8BCyAAQQA2AhwgACAQNgIUIABBzZOAgAA2AhAgAEEMNgIMQQAhEAzuAQsgACgCBCEXIABBADYCBCAQIBGnaiIWIQEgACAXIBAgFiAUGyIQELWAgIAAIhRFDXMgAEEFNgIcIAAgEDYCFCAAIBQ2AgxBACEQDO0BCyAAQQA2AhwgACAQNgIUIABBqpyAgAA2AhAgAEEPNgIMQQAhEAzsAQsgACAQIAIQtICAgAAiAQ0BIBAhAQtBDiEQDNEBCwJAIAFBFUcNACAAQQI2AhwgACAQNgIUIABBsJiAgAA2AhAgAEEVNgIMQQAhEAzqAQsgAEEANgIcIAAgEDYCFCAAQaeOgIAANgIQIABBEjYCDEEAIRAM6QELIAFBAWohEAJAIAAvATAiAUGAAXFFDQACQCAAIBAgAhC7gICAACIBDQAgECEBDHALIAFBFUcNugEgAEEFNgIcIAAgEDYCFCAAQfmXgIAANgIQIABBFTYCDEEAIRAM6QELAkAgAUGgBHFBoARHDQAgAC0ALUECcQ0AIABBADYCHCAAIBA2AhQgAEGWk4CAADYCECAAQQQ2AgxBACEQDOkBCyAAIBAgAhC9gICAABogECEBAkACQAJAAkACQCAAIBAgAhCzgICAAA4WAgEABAQEBAQEBAQEBAQEBAQEBAQEAwQLIABBAToALgsgACAALwEwQcAAcjsBMCAQIQELQSYhEAzRAQsgAEEjNgIcIAAgEDYCFCAAQaWWgIAANgIQIABBFTYCDEEAIRAM6QELIABBADYCHCAAIBA2AhQgAEHVi4CAADYCECAAQRE2AgxBACEQDOgBCyAALQAtQQFxRQ0BQcMBIRAMzgELAkAgDSACRg0AA0ACQCANLQAAQSBGDQAgDSEBDMQBCyANQQFqIg0gAkcNAAtBJSEQDOcBC0ElIRAM5gELIAAoAgQhBCAAQQA2AgQgACAEIA0Qr4CAgAAiBEUNrQEgAEEmNgIcIAAgBDYCDCAAIA1BAWo2AhRBACEQDOUBCyAQQRVGDasBIABBADYCHCAAIAE2AhQgAEH9jYCAADYCECAAQR02AgxBACEQDOQBCyAAQSc2AhwgACABNgIUIAAgEDYCDEEAIRAM4wELIBAhAUEBIRQCQAJAAkACQAJAAkACQCAALQAsQX5qDgcGBQUDAQIABQsgACAALwEwQQhyOwEwDAMLQQIhFAwBC0EEIRQLIABBAToALCAAIAAvATAgFHI7ATALIBAhAQtBKyEQDMoBCyAAQQA2AhwgACAQNgIUIABBq5KAgAA2AhAgAEELNgIMQQAhEAziAQsgAEEANgIcIAAgATYCFCAAQeGPgIAANgIQIABBCjYCDEEAIRAM4QELIABBADoALCAQIQEMvQELIBAhAUEBIRQCQAJAAkACQAJAIAAtACxBe2oOBAMBAgAFCyAAIAAvATBBCHI7ATAMAwtBAiEUDAELQQQhFAsgAEEBOgAsIAAgAC8BMCAUcjsBMAsgECEBC0EpIRAMxQELIABBADYCHCAAIAE2AhQgAEHwlICAADYCECAAQQM2AgxBACEQDN0BCwJAIA4tAABBDUcNACAAKAIEIQEgAEEANgIEAkAgACABIA4QsYCAgAAiAQ0AIA5BAWohAQx1CyAAQSw2AhwgACABNgIMIAAgDkEBajYCFEEAIRAM3QELIAAtAC1BAXFFDQFBxAEhEAzDAQsCQCAOIAJHDQBBLSEQDNwBCwJAAkADQAJAIA4tAABBdmoOBAIAAAMACyAOQQFqIg4gAkcNAAtBLSEQDN0BCyAAKAIEIQEgAEEANgIEAkAgACABIA4QsYCAgAAiAQ0AIA4hAQx0CyAAQSw2AhwgACAONgIUIAAgATYCDEEAIRAM3AELIAAoAgQhASAAQQA2AgQCQCAAIAEgDhCxgICAACIBDQAgDkEBaiEBDHMLIABBLDYCHCAAIAE2AgwgACAOQQFqNgIUQQAhEAzbAQsgACgCBCEEIABBADYCBCAAIAQgDhCxgICAACIEDaABIA4hAQzOAQsgEEEsRw0BIAFBAWohEEEBIQECQAJAAkACQAJAIAAtACxBe2oOBAMBAgQACyAQIQEMBAtBAiEBDAELQQQhAQsgAEEBOgAsIAAgAC8BMCABcjsBMCAQIQEMAQsgACAALwEwQQhyOwEwIBAhAQtBOSEQDL8BCyAAQQA6ACwgASEBC0E0IRAMvQELIAAgAC8BMEEgcjsBMCABIQEMAgsgACgCBCEEIABBADYCBAJAIAAgBCABELGAgIAAIgQNACABIQEMxwELIABBNzYCHCAAIAE2AhQgACAENgIMQQAhEAzUAQsgAEEIOgAsIAEhAQtBMCEQDLkBCwJAIAAtAChBAUYNACABIQEMBAsgAC0ALUEIcUUNkwEgASEBDAMLIAAtADBBIHENlAFBxQEhEAy3AQsCQCAPIAJGDQACQANAAkAgDy0AAEFQaiIBQf8BcUEKSQ0AIA8hAUE1IRAMugELIAApAyAiEUKZs+bMmbPmzBlWDQEgACARQgp+IhE3AyAgESABrUL/AYMiEkJ/hVYNASAAIBEgEnw3AyAgD0EBaiIPIAJHDQALQTkhEAzRAQsgACgCBCECIABBADYCBCAAIAIgD0EBaiIEELGAgIAAIgINlQEgBCEBDMMBC0E5IRAMzwELAkAgAC8BMCIBQQhxRQ0AIAAtAChBAUcNACAALQAtQQhxRQ2QAQsgACABQff7A3FBgARyOwEwIA8hAQtBNyEQDLQBCyAAIAAvATBBEHI7ATAMqwELIBBBFUYNiwEgAEEANgIcIAAgATYCFCAAQfCOgIAANgIQIABBHDYCDEEAIRAMywELIABBwwA2AhwgACABNgIMIAAgDUEBajYCFEEAIRAMygELAkAgAS0AAEE6Rw0AIAAoAgQhECAAQQA2AgQCQCAAIBAgARCvgICAACIQDQAgAUEBaiEBDGMLIABBwwA2AhwgACAQNgIMIAAgAUEBajYCFEEAIRAMygELIABBADYCHCAAIAE2AhQgAEGxkYCAADYCECAAQQo2AgxBACEQDMkBCyAAQQA2AhwgACABNgIUIABBoJmAgAA2AhAgAEEeNgIMQQAhEAzIAQsgAEEANgIACyAAQYASOwEqIAAgF0EBaiIBIAIQqICAgAAiEA0BIAEhAQtBxwAhEAysAQsgEEEVRw2DASAAQdEANgIcIAAgATYCFCAAQeOXgIAANgIQIABBFTYCDEEAIRAMxAELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDF4LIABB0gA2AhwgACABNgIUIAAgEDYCDEEAIRAMwwELIABBADYCHCAAIBQ2AhQgAEHBqICAADYCECAAQQc2AgwgAEEANgIAQQAhEAzCAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMXQsgAEHTADYCHCAAIAE2AhQgACAQNgIMQQAhEAzBAQtBACEQIABBADYCHCAAIAE2AhQgAEGAkYCAADYCECAAQQk2AgwMwAELIBBBFUYNfSAAQQA2AhwgACABNgIUIABBlI2AgAA2AhAgAEEhNgIMQQAhEAy/AQtBASEWQQAhF0EAIRRBASEQCyAAIBA6ACsgAUEBaiEBAkACQCAALQAtQRBxDQACQAJAAkAgAC0AKg4DAQACBAsgFkUNAwwCCyAUDQEMAgsgF0UNAQsgACgCBCEQIABBADYCBAJAIAAgECABEK2AgIAAIhANACABIQEMXAsgAEHYADYCHCAAIAE2AhQgACAQNgIMQQAhEAy+AQsgACgCBCEEIABBADYCBAJAIAAgBCABEK2AgIAAIgQNACABIQEMrQELIABB2QA2AhwgACABNgIUIAAgBDYCDEEAIRAMvQELIAAoAgQhBCAAQQA2AgQCQCAAIAQgARCtgICAACIEDQAgASEBDKsBCyAAQdoANgIcIAAgATYCFCAAIAQ2AgxBACEQDLwBCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQrYCAgAAiBA0AIAEhAQypAQsgAEHcADYCHCAAIAE2AhQgACAENgIMQQAhEAy7AQsCQCABLQAAQVBqIhBB/wFxQQpPDQAgACAQOgAqIAFBAWohAUHPACEQDKIBCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQrYCAgAAiBA0AIAEhAQynAQsgAEHeADYCHCAAIAE2AhQgACAENgIMQQAhEAy6AQsgAEEANgIAIBdBAWohAQJAIAAtAClBI08NACABIQEMWQsgAEEANgIcIAAgATYCFCAAQdOJgIAANgIQIABBCDYCDEEAIRAMuQELIABBADYCAAtBACEQIABBADYCHCAAIAE2AhQgAEGQs4CAADYCECAAQQg2AgwMtwELIABBADYCACAXQQFqIQECQCAALQApQSFHDQAgASEBDFYLIABBADYCHCAAIAE2AhQgAEGbioCAADYCECAAQQg2AgxBACEQDLYBCyAAQQA2AgAgF0EBaiEBAkAgAC0AKSIQQV1qQQtPDQAgASEBDFULAkAgEEEGSw0AQQEgEHRBygBxRQ0AIAEhAQxVC0EAIRAgAEEANgIcIAAgATYCFCAAQfeJgIAANgIQIABBCDYCDAy1AQsgEEEVRg1xIABBADYCHCAAIAE2AhQgAEG5jYCAADYCECAAQRo2AgxBACEQDLQBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxUCyAAQeUANgIcIAAgATYCFCAAIBA2AgxBACEQDLMBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxNCyAAQdIANgIcIAAgATYCFCAAIBA2AgxBACEQDLIBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxNCyAAQdMANgIcIAAgATYCFCAAIBA2AgxBACEQDLEBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxRCyAAQeUANgIcIAAgATYCFCAAIBA2AgxBACEQDLABCyAAQQA2AhwgACABNgIUIABBxoqAgAA2AhAgAEEHNgIMQQAhEAyvAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMSQsgAEHSADYCHCAAIAE2AhQgACAQNgIMQQAhEAyuAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMSQsgAEHTADYCHCAAIAE2AhQgACAQNgIMQQAhEAytAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMTQsgAEHlADYCHCAAIAE2AhQgACAQNgIMQQAhEAysAQsgAEEANgIcIAAgATYCFCAAQdyIgIAANgIQIABBBzYCDEEAIRAMqwELIBBBP0cNASABQQFqIQELQQUhEAyQAQtBACEQIABBADYCHCAAIAE2AhQgAEH9koCAADYCECAAQQc2AgwMqAELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDEILIABB0gA2AhwgACABNgIUIAAgEDYCDEEAIRAMpwELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDEILIABB0wA2AhwgACABNgIUIAAgEDYCDEEAIRAMpgELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDEYLIABB5QA2AhwgACABNgIUIAAgEDYCDEEAIRAMpQELIAAoAgQhASAAQQA2AgQCQCAAIAEgFBCngICAACIBDQAgFCEBDD8LIABB0gA2AhwgACAUNgIUIAAgATYCDEEAIRAMpAELIAAoAgQhASAAQQA2AgQCQCAAIAEgFBCngICAACIBDQAgFCEBDD8LIABB0wA2AhwgACAUNgIUIAAgATYCDEEAIRAMowELIAAoAgQhASAAQQA2AgQCQCAAIAEgFBCngICAACIBDQAgFCEBDEMLIABB5QA2AhwgACAUNgIUIAAgATYCDEEAIRAMogELIABBADYCHCAAIBQ2AhQgAEHDj4CAADYCECAAQQc2AgxBACEQDKEBCyAAQQA2AhwgACABNgIUIABBw4+AgAA2AhAgAEEHNgIMQQAhEAygAQtBACEQIABBADYCHCAAIBQ2AhQgAEGMnICAADYCECAAQQc2AgwMnwELIABBADYCHCAAIBQ2AhQgAEGMnICAADYCECAAQQc2AgxBACEQDJ4BCyAAQQA2AhwgACAUNgIUIABB/pGAgAA2AhAgAEEHNgIMQQAhEAydAQsgAEEANgIcIAAgATYCFCAAQY6bgIAANgIQIABBBjYCDEEAIRAMnAELIBBBFUYNVyAAQQA2AhwgACABNgIUIABBzI6AgAA2AhAgAEEgNgIMQQAhEAybAQsgAEEANgIAIBBBAWohAUEkIRALIAAgEDoAKSAAKAIEIRAgAEEANgIEIAAgECABEKuAgIAAIhANVCABIQEMPgsgAEEANgIAC0EAIRAgAEEANgIcIAAgBDYCFCAAQfGbgIAANgIQIABBBjYCDAyXAQsgAUEVRg1QIABBADYCHCAAIAU2AhQgAEHwjICAADYCECAAQRs2AgxBACEQDJYBCyAAKAIEIQUgAEEANgIEIAAgBSAQEKmAgIAAIgUNASAQQQFqIQULQa0BIRAMewsgAEHBATYCHCAAIAU2AgwgACAQQQFqNgIUQQAhEAyTAQsgACgCBCEGIABBADYCBCAAIAYgEBCpgICAACIGDQEgEEEBaiEGC0GuASEQDHgLIABBwgE2AhwgACAGNgIMIAAgEEEBajYCFEEAIRAMkAELIABBADYCHCAAIAc2AhQgAEGXi4CAADYCECAAQQ02AgxBACEQDI8BCyAAQQA2AhwgACAINgIUIABB45CAgAA2AhAgAEEJNgIMQQAhEAyOAQsgAEEANgIcIAAgCDYCFCAAQZSNgIAANgIQIABBITYCDEEAIRAMjQELQQEhFkEAIRdBACEUQQEhEAsgACAQOgArIAlBAWohCAJAAkAgAC0ALUEQcQ0AAkACQAJAIAAtACoOAwEAAgQLIBZFDQMMAgsgFA0BDAILIBdFDQELIAAoAgQhECAAQQA2AgQgACAQIAgQrYCAgAAiEEUNPSAAQckBNgIcIAAgCDYCFCAAIBA2AgxBACEQDIwBCyAAKAIEIQQgAEEANgIEIAAgBCAIEK2AgIAAIgRFDXYgAEHKATYCHCAAIAg2AhQgACAENgIMQQAhEAyLAQsgACgCBCEEIABBADYCBCAAIAQgCRCtgICAACIERQ10IABBywE2AhwgACAJNgIUIAAgBDYCDEEAIRAMigELIAAoAgQhBCAAQQA2AgQgACAEIAoQrYCAgAAiBEUNciAAQc0BNgIcIAAgCjYCFCAAIAQ2AgxBACEQDIkBCwJAIAstAABBUGoiEEH/AXFBCk8NACAAIBA6ACogC0EBaiEKQbYBIRAMcAsgACgCBCEEIABBADYCBCAAIAQgCxCtgICAACIERQ1wIABBzwE2AhwgACALNgIUIAAgBDYCDEEAIRAMiAELIABBADYCHCAAIAQ2AhQgAEGQs4CAADYCECAAQQg2AgwgAEEANgIAQQAhEAyHAQsgAUEVRg0/IABBADYCHCAAIAw2AhQgAEHMjoCAADYCECAAQSA2AgxBACEQDIYBCyAAQYEEOwEoIAAoAgQhECAAQgA3AwAgACAQIAxBAWoiDBCrgICAACIQRQ04IABB0wE2AhwgACAMNgIUIAAgEDYCDEEAIRAMhQELIABBADYCAAtBACEQIABBADYCHCAAIAQ2AhQgAEHYm4CAADYCECAAQQg2AgwMgwELIAAoAgQhECAAQgA3AwAgACAQIAtBAWoiCxCrgICAACIQDQFBxgEhEAxpCyAAQQI6ACgMVQsgAEHVATYCHCAAIAs2AhQgACAQNgIMQQAhEAyAAQsgEEEVRg03IABBADYCHCAAIAQ2AhQgAEGkjICAADYCECAAQRA2AgxBACEQDH8LIAAtADRBAUcNNCAAIAQgAhC8gICAACIQRQ00IBBBFUcNNSAAQdwBNgIcIAAgBDYCFCAAQdWWgIAANgIQIABBFTYCDEEAIRAMfgtBACEQIABBADYCHCAAQa+LgIAANgIQIABBAjYCDCAAIBRBAWo2AhQMfQtBACEQDGMLQQIhEAxiC0ENIRAMYQtBDyEQDGALQSUhEAxfC0ETIRAMXgtBFSEQDF0LQRYhEAxcC0EXIRAMWwtBGCEQDFoLQRkhEAxZC0EaIRAMWAtBGyEQDFcLQRwhEAxWC0EdIRAMVQtBHyEQDFQLQSEhEAxTC0EjIRAMUgtBxgAhEAxRC0EuIRAMUAtBLyEQDE8LQTshEAxOC0E9IRAMTQtByAAhEAxMC0HJACEQDEsLQcsAIRAMSgtBzAAhEAxJC0HOACEQDEgLQdEAIRAMRwtB1QAhEAxGC0HYACEQDEULQdkAIRAMRAtB2wAhEAxDC0HkACEQDEILQeUAIRAMQQtB8QAhEAxAC0H0ACEQDD8LQY0BIRAMPgtBlwEhEAw9C0GpASEQDDwLQawBIRAMOwtBwAEhEAw6C0G5ASEQDDkLQa8BIRAMOAtBsQEhEAw3C0GyASEQDDYLQbQBIRAMNQtBtQEhEAw0C0G6ASEQDDMLQb0BIRAMMgtBvwEhEAwxC0HBASEQDDALIABBADYCHCAAIAQ2AhQgAEHpi4CAADYCECAAQR82AgxBACEQDEgLIABB2wE2AhwgACAENgIUIABB+paAgAA2AhAgAEEVNgIMQQAhEAxHCyAAQfgANgIcIAAgDDYCFCAAQcqYgIAANgIQIABBFTYCDEEAIRAMRgsgAEHRADYCHCAAIAU2AhQgAEGwl4CAADYCECAAQRU2AgxBACEQDEULIABB+QA2AhwgACABNgIUIAAgEDYCDEEAIRAMRAsgAEH4ADYCHCAAIAE2AhQgAEHKmICAADYCECAAQRU2AgxBACEQDEMLIABB5AA2AhwgACABNgIUIABB45eAgAA2AhAgAEEVNgIMQQAhEAxCCyAAQdcANgIcIAAgATYCFCAAQcmXgIAANgIQIABBFTYCDEEAIRAMQQsgAEEANgIcIAAgATYCFCAAQbmNgIAANgIQIABBGjYCDEEAIRAMQAsgAEHCADYCHCAAIAE2AhQgAEHjmICAADYCECAAQRU2AgxBACEQDD8LIABBADYCBCAAIA8gDxCxgICAACIERQ0BIABBOjYCHCAAIAQ2AgwgACAPQQFqNgIUQQAhEAw+CyAAKAIEIQQgAEEANgIEAkAgACAEIAEQsYCAgAAiBEUNACAAQTs2AhwgACAENgIMIAAgAUEBajYCFEEAIRAMPgsgAUEBaiEBDC0LIA9BAWohAQwtCyAAQQA2AhwgACAPNgIUIABB5JKAgAA2AhAgAEEENgIMQQAhEAw7CyAAQTY2AhwgACAENgIUIAAgAjYCDEEAIRAMOgsgAEEuNgIcIAAgDjYCFCAAIAQ2AgxBACEQDDkLIABB0AA2AhwgACABNgIUIABBkZiAgAA2AhAgAEEVNgIMQQAhEAw4CyANQQFqIQEMLAsgAEEVNgIcIAAgATYCFCAAQYKZgIAANgIQIABBFTYCDEEAIRAMNgsgAEEbNgIcIAAgATYCFCAAQZGXgIAANgIQIABBFTYCDEEAIRAMNQsgAEEPNgIcIAAgATYCFCAAQZGXgIAANgIQIABBFTYCDEEAIRAMNAsgAEELNgIcIAAgATYCFCAAQZGXgIAANgIQIABBFTYCDEEAIRAMMwsgAEEaNgIcIAAgATYCFCAAQYKZgIAANgIQIABBFTYCDEEAIRAMMgsgAEELNgIcIAAgATYCFCAAQYKZgIAANgIQIABBFTYCDEEAIRAMMQsgAEEKNgIcIAAgATYCFCAAQeSWgIAANgIQIABBFTYCDEEAIRAMMAsgAEEeNgIcIAAgATYCFCAAQfmXgIAANgIQIABBFTYCDEEAIRAMLwsgAEEANgIcIAAgEDYCFCAAQdqNgIAANgIQIABBFDYCDEEAIRAMLgsgAEEENgIcIAAgATYCFCAAQbCYgIAANgIQIABBFTYCDEEAIRAMLQsgAEEANgIAIAtBAWohCwtBuAEhEAwSCyAAQQA2AgAgEEEBaiEBQfUAIRAMEQsgASEBAkAgAC0AKUEFRw0AQeMAIRAMEQtB4gAhEAwQC0EAIRAgAEEANgIcIABB5JGAgAA2AhAgAEEHNgIMIAAgFEEBajYCFAwoCyAAQQA2AgAgF0EBaiEBQcAAIRAMDgtBASEBCyAAIAE6ACwgAEEANgIAIBdBAWohAQtBKCEQDAsLIAEhAQtBOCEQDAkLAkAgASIPIAJGDQADQAJAIA8tAABBgL6AgABqLQAAIgFBAUYNACABQQJHDQMgD0EBaiEBDAQLIA9BAWoiDyACRw0AC0E+IRAMIgtBPiEQDCELIABBADoALCAPIQEMAQtBCyEQDAYLQTohEAwFCyABQQFqIQFBLSEQDAQLIAAgAToALCAAQQA2AgAgFkEBaiEBQQwhEAwDCyAAQQA2AgAgF0EBaiEBQQohEAwCCyAAQQA2AgALIABBADoALCANIQFBCSEQDAALC0EAIRAgAEEANgIcIAAgCzYCFCAAQc2QgIAANgIQIABBCTYCDAwXC0EAIRAgAEEANgIcIAAgCjYCFCAAQemKgIAANgIQIABBCTYCDAwWC0EAIRAgAEEANgIcIAAgCTYCFCAAQbeQgIAANgIQIABBCTYCDAwVC0EAIRAgAEEANgIcIAAgCDYCFCAAQZyRgIAANgIQIABBCTYCDAwUC0EAIRAgAEEANgIcIAAgATYCFCAAQc2QgIAANgIQIABBCTYCDAwTC0EAIRAgAEEANgIcIAAgATYCFCAAQemKgIAANgIQIABBCTYCDAwSC0EAIRAgAEEANgIcIAAgATYCFCAAQbeQgIAANgIQIABBCTYCDAwRC0EAIRAgAEEANgIcIAAgATYCFCAAQZyRgIAANgIQIABBCTYCDAwQC0EAIRAgAEEANgIcIAAgATYCFCAAQZeVgIAANgIQIABBDzYCDAwPC0EAIRAgAEEANgIcIAAgATYCFCAAQZeVgIAANgIQIABBDzYCDAwOC0EAIRAgAEEANgIcIAAgATYCFCAAQcCSgIAANgIQIABBCzYCDAwNC0EAIRAgAEEANgIcIAAgATYCFCAAQZWJgIAANgIQIABBCzYCDAwMC0EAIRAgAEEANgIcIAAgATYCFCAAQeGPgIAANgIQIABBCjYCDAwLC0EAIRAgAEEANgIcIAAgATYCFCAAQfuPgIAANgIQIABBCjYCDAwKC0EAIRAgAEEANgIcIAAgATYCFCAAQfGZgIAANgIQIABBAjYCDAwJC0EAIRAgAEEANgIcIAAgATYCFCAAQcSUgIAANgIQIABBAjYCDAwIC0EAIRAgAEEANgIcIAAgATYCFCAAQfKVgIAANgIQIABBAjYCDAwHCyAAQQI2AhwgACABNgIUIABBnJqAgAA2AhAgAEEWNgIMQQAhEAwGC0EBIRAMBQtB1AAhECABIgQgAkYNBCADQQhqIAAgBCACQdjCgIAAQQoQxYCAgAAgAygCDCEEIAMoAggOAwEEAgALEMqAgIAAAAsgAEEANgIcIABBtZqAgAA2AhAgAEEXNgIMIAAgBEEBajYCFEEAIRAMAgsgAEEANgIcIAAgBDYCFCAAQcqagIAANgIQIABBCTYCDEEAIRAMAQsCQCABIgQgAkcNAEEiIRAMAQsgAEGJgICAADYCCCAAIAQ2AgRBISEQCyADQRBqJICAgIAAIBALrwEBAn8gASgCACEGAkACQCACIANGDQAgBCAGaiEEIAYgA2ogAmshByACIAZBf3MgBWoiBmohBQNAAkAgAi0AACAELQAARg0AQQIhBAwDCwJAIAYNAEEAIQQgBSECDAMLIAZBf2ohBiAEQQFqIQQgAkEBaiICIANHDQALIAchBiADIQILIABBATYCACABIAY2AgAgACACNgIEDwsgAUEANgIAIAAgBDYCACAAIAI2AgQLCgAgABDHgICAAAvyNgELfyOAgICAAEEQayIBJICAgIAAAkBBACgCoNCAgAANAEEAEMuAgIAAQYDUhIAAayICQdkASQ0AQQAhAwJAQQAoAuDTgIAAIgQNAEEAQn83AuzTgIAAQQBCgICEgICAwAA3AuTTgIAAQQAgAUEIakFwcUHYqtWqBXMiBDYC4NOAgABBAEEANgL004CAAEEAQQA2AsTTgIAAC0EAIAI2AszTgIAAQQBBgNSEgAA2AsjTgIAAQQBBgNSEgAA2ApjQgIAAQQAgBDYCrNCAgABBAEF/NgKo0ICAAANAIANBxNCAgABqIANBuNCAgABqIgQ2AgAgBCADQbDQgIAAaiIFNgIAIANBvNCAgABqIAU2AgAgA0HM0ICAAGogA0HA0ICAAGoiBTYCACAFIAQ2AgAgA0HU0ICAAGogA0HI0ICAAGoiBDYCACAEIAU2AgAgA0HQ0ICAAGogBDYCACADQSBqIgNBgAJHDQALQYDUhIAAQXhBgNSEgABrQQ9xQQBBgNSEgABBCGpBD3EbIgNqIgRBBGogAkFIaiIFIANrIgNBAXI2AgBBAEEAKALw04CAADYCpNCAgABBACADNgKU0ICAAEEAIAQ2AqDQgIAAQYDUhIAAIAVqQTg2AgQLAkACQAJAAkACQAJAAkACQAJAAkACQAJAIABB7AFLDQACQEEAKAKI0ICAACIGQRAgAEETakFwcSAAQQtJGyICQQN2IgR2IgNBA3FFDQACQAJAIANBAXEgBHJBAXMiBUEDdCIEQbDQgIAAaiIDIARBuNCAgABqKAIAIgQoAggiAkcNAEEAIAZBfiAFd3E2AojQgIAADAELIAMgAjYCCCACIAM2AgwLIARBCGohAyAEIAVBA3QiBUEDcjYCBCAEIAVqIgQgBCgCBEEBcjYCBAwMCyACQQAoApDQgIAAIgdNDQECQCADRQ0AAkACQCADIAR0QQIgBHQiA0EAIANrcnEiA0EAIANrcUF/aiIDIANBDHZBEHEiA3YiBEEFdkEIcSIFIANyIAQgBXYiA0ECdkEEcSIEciADIAR2IgNBAXZBAnEiBHIgAyAEdiIDQQF2QQFxIgRyIAMgBHZqIgRBA3QiA0Gw0ICAAGoiBSADQbjQgIAAaigCACIDKAIIIgBHDQBBACAGQX4gBHdxIgY2AojQgIAADAELIAUgADYCCCAAIAU2AgwLIAMgAkEDcjYCBCADIARBA3QiBGogBCACayIFNgIAIAMgAmoiACAFQQFyNgIEAkAgB0UNACAHQXhxQbDQgIAAaiECQQAoApzQgIAAIQQCQAJAIAZBASAHQQN2dCIIcQ0AQQAgBiAIcjYCiNCAgAAgAiEIDAELIAIoAgghCAsgCCAENgIMIAIgBDYCCCAEIAI2AgwgBCAINgIICyADQQhqIQNBACAANgKc0ICAAEEAIAU2ApDQgIAADAwLQQAoAozQgIAAIglFDQEgCUEAIAlrcUF/aiIDIANBDHZBEHEiA3YiBEEFdkEIcSIFIANyIAQgBXYiA0ECdkEEcSIEciADIAR2IgNBAXZBAnEiBHIgAyAEdiIDQQF2QQFxIgRyIAMgBHZqQQJ0QbjSgIAAaigCACIAKAIEQXhxIAJrIQQgACEFAkADQAJAIAUoAhAiAw0AIAVBFGooAgAiA0UNAgsgAygCBEF4cSACayIFIAQgBSAESSIFGyEEIAMgACAFGyEAIAMhBQwACwsgACgCGCEKAkAgACgCDCIIIABGDQAgACgCCCIDQQAoApjQgIAASRogCCADNgIIIAMgCDYCDAwLCwJAIABBFGoiBSgCACIDDQAgACgCECIDRQ0DIABBEGohBQsDQCAFIQsgAyIIQRRqIgUoAgAiAw0AIAhBEGohBSAIKAIQIgMNAAsgC0EANgIADAoLQX8hAiAAQb9/Sw0AIABBE2oiA0FwcSECQQAoAozQgIAAIgdFDQBBACELAkAgAkGAAkkNAEEfIQsgAkH///8HSw0AIANBCHYiAyADQYD+P2pBEHZBCHEiA3QiBCAEQYDgH2pBEHZBBHEiBHQiBSAFQYCAD2pBEHZBAnEiBXRBD3YgAyAEciAFcmsiA0EBdCACIANBFWp2QQFxckEcaiELC0EAIAJrIQQCQAJAAkACQCALQQJ0QbjSgIAAaigCACIFDQBBACEDQQAhCAwBC0EAIQMgAkEAQRkgC0EBdmsgC0EfRht0IQBBACEIA0ACQCAFKAIEQXhxIAJrIgYgBE8NACAGIQQgBSEIIAYNAEEAIQQgBSEIIAUhAwwDCyADIAVBFGooAgAiBiAGIAUgAEEddkEEcWpBEGooAgAiBUYbIAMgBhshAyAAQQF0IQAgBQ0ACwsCQCADIAhyDQBBACEIQQIgC3QiA0EAIANrciAHcSIDRQ0DIANBACADa3FBf2oiAyADQQx2QRBxIgN2IgVBBXZBCHEiACADciAFIAB2IgNBAnZBBHEiBXIgAyAFdiIDQQF2QQJxIgVyIAMgBXYiA0EBdkEBcSIFciADIAV2akECdEG40oCAAGooAgAhAwsgA0UNAQsDQCADKAIEQXhxIAJrIgYgBEkhAAJAIAMoAhAiBQ0AIANBFGooAgAhBQsgBiAEIAAbIQQgAyAIIAAbIQggBSEDIAUNAAsLIAhFDQAgBEEAKAKQ0ICAACACa08NACAIKAIYIQsCQCAIKAIMIgAgCEYNACAIKAIIIgNBACgCmNCAgABJGiAAIAM2AgggAyAANgIMDAkLAkAgCEEUaiIFKAIAIgMNACAIKAIQIgNFDQMgCEEQaiEFCwNAIAUhBiADIgBBFGoiBSgCACIDDQAgAEEQaiEFIAAoAhAiAw0ACyAGQQA2AgAMCAsCQEEAKAKQ0ICAACIDIAJJDQBBACgCnNCAgAAhBAJAAkAgAyACayIFQRBJDQAgBCACaiIAIAVBAXI2AgRBACAFNgKQ0ICAAEEAIAA2ApzQgIAAIAQgA2ogBTYCACAEIAJBA3I2AgQMAQsgBCADQQNyNgIEIAQgA2oiAyADKAIEQQFyNgIEQQBBADYCnNCAgABBAEEANgKQ0ICAAAsgBEEIaiEDDAoLAkBBACgClNCAgAAiACACTQ0AQQAoAqDQgIAAIgMgAmoiBCAAIAJrIgVBAXI2AgRBACAFNgKU0ICAAEEAIAQ2AqDQgIAAIAMgAkEDcjYCBCADQQhqIQMMCgsCQAJAQQAoAuDTgIAARQ0AQQAoAujTgIAAIQQMAQtBAEJ/NwLs04CAAEEAQoCAhICAgMAANwLk04CAAEEAIAFBDGpBcHFB2KrVqgVzNgLg04CAAEEAQQA2AvTTgIAAQQBBADYCxNOAgABBgIAEIQQLQQAhAwJAIAQgAkHHAGoiB2oiBkEAIARrIgtxIgggAksNAEEAQTA2AvjTgIAADAoLAkBBACgCwNOAgAAiA0UNAAJAQQAoArjTgIAAIgQgCGoiBSAETQ0AIAUgA00NAQtBACEDQQBBMDYC+NOAgAAMCgtBAC0AxNOAgABBBHENBAJAAkACQEEAKAKg0ICAACIERQ0AQcjTgIAAIQMDQAJAIAMoAgAiBSAESw0AIAUgAygCBGogBEsNAwsgAygCCCIDDQALC0EAEMuAgIAAIgBBf0YNBSAIIQYCQEEAKALk04CAACIDQX9qIgQgAHFFDQAgCCAAayAEIABqQQAgA2txaiEGCyAGIAJNDQUgBkH+////B0sNBQJAQQAoAsDTgIAAIgNFDQBBACgCuNOAgAAiBCAGaiIFIARNDQYgBSADSw0GCyAGEMuAgIAAIgMgAEcNAQwHCyAGIABrIAtxIgZB/v///wdLDQQgBhDLgICAACIAIAMoAgAgAygCBGpGDQMgACEDCwJAIANBf0YNACACQcgAaiAGTQ0AAkAgByAGa0EAKALo04CAACIEakEAIARrcSIEQf7///8HTQ0AIAMhAAwHCwJAIAQQy4CAgABBf0YNACAEIAZqIQYgAyEADAcLQQAgBmsQy4CAgAAaDAQLIAMhACADQX9HDQUMAwtBACEIDAcLQQAhAAwFCyAAQX9HDQILQQBBACgCxNOAgABBBHI2AsTTgIAACyAIQf7///8HSw0BIAgQy4CAgAAhAEEAEMuAgIAAIQMgAEF/Rg0BIANBf0YNASAAIANPDQEgAyAAayIGIAJBOGpNDQELQQBBACgCuNOAgAAgBmoiAzYCuNOAgAACQCADQQAoArzTgIAATQ0AQQAgAzYCvNOAgAALAkACQAJAAkBBACgCoNCAgAAiBEUNAEHI04CAACEDA0AgACADKAIAIgUgAygCBCIIakYNAiADKAIIIgMNAAwDCwsCQAJAQQAoApjQgIAAIgNFDQAgACADTw0BC0EAIAA2ApjQgIAAC0EAIQNBACAGNgLM04CAAEEAIAA2AsjTgIAAQQBBfzYCqNCAgABBAEEAKALg04CAADYCrNCAgABBAEEANgLU04CAAANAIANBxNCAgABqIANBuNCAgABqIgQ2AgAgBCADQbDQgIAAaiIFNgIAIANBvNCAgABqIAU2AgAgA0HM0ICAAGogA0HA0ICAAGoiBTYCACAFIAQ2AgAgA0HU0ICAAGogA0HI0ICAAGoiBDYCACAEIAU2AgAgA0HQ0ICAAGogBDYCACADQSBqIgNBgAJHDQALIABBeCAAa0EPcUEAIABBCGpBD3EbIgNqIgQgBkFIaiIFIANrIgNBAXI2AgRBAEEAKALw04CAADYCpNCAgABBACADNgKU0ICAAEEAIAQ2AqDQgIAAIAAgBWpBODYCBAwCCyADLQAMQQhxDQAgBCAFSQ0AIAQgAE8NACAEQXggBGtBD3FBACAEQQhqQQ9xGyIFaiIAQQAoApTQgIAAIAZqIgsgBWsiBUEBcjYCBCADIAggBmo2AgRBAEEAKALw04CAADYCpNCAgABBACAFNgKU0ICAAEEAIAA2AqDQgIAAIAQgC2pBODYCBAwBCwJAIABBACgCmNCAgAAiCE8NAEEAIAA2ApjQgIAAIAAhCAsgACAGaiEFQcjTgIAAIQMCQAJAAkACQAJAAkACQANAIAMoAgAgBUYNASADKAIIIgMNAAwCCwsgAy0ADEEIcUUNAQtByNOAgAAhAwNAAkAgAygCACIFIARLDQAgBSADKAIEaiIFIARLDQMLIAMoAgghAwwACwsgAyAANgIAIAMgAygCBCAGajYCBCAAQXggAGtBD3FBACAAQQhqQQ9xG2oiCyACQQNyNgIEIAVBeCAFa0EPcUEAIAVBCGpBD3EbaiIGIAsgAmoiAmshAwJAIAYgBEcNAEEAIAI2AqDQgIAAQQBBACgClNCAgAAgA2oiAzYClNCAgAAgAiADQQFyNgIEDAMLAkAgBkEAKAKc0ICAAEcNAEEAIAI2ApzQgIAAQQBBACgCkNCAgAAgA2oiAzYCkNCAgAAgAiADQQFyNgIEIAIgA2ogAzYCAAwDCwJAIAYoAgQiBEEDcUEBRw0AIARBeHEhBwJAAkAgBEH/AUsNACAGKAIIIgUgBEEDdiIIQQN0QbDQgIAAaiIARhoCQCAGKAIMIgQgBUcNAEEAQQAoAojQgIAAQX4gCHdxNgKI0ICAAAwCCyAEIABGGiAEIAU2AgggBSAENgIMDAELIAYoAhghCQJAAkAgBigCDCIAIAZGDQAgBigCCCIEIAhJGiAAIAQ2AgggBCAANgIMDAELAkAgBkEUaiIEKAIAIgUNACAGQRBqIgQoAgAiBQ0AQQAhAAwBCwNAIAQhCCAFIgBBFGoiBCgCACIFDQAgAEEQaiEEIAAoAhAiBQ0ACyAIQQA2AgALIAlFDQACQAJAIAYgBigCHCIFQQJ0QbjSgIAAaiIEKAIARw0AIAQgADYCACAADQFBAEEAKAKM0ICAAEF+IAV3cTYCjNCAgAAMAgsgCUEQQRQgCSgCECAGRhtqIAA2AgAgAEUNAQsgACAJNgIYAkAgBigCECIERQ0AIAAgBDYCECAEIAA2AhgLIAYoAhQiBEUNACAAQRRqIAQ2AgAgBCAANgIYCyAHIANqIQMgBiAHaiIGKAIEIQQLIAYgBEF+cTYCBCACIANqIAM2AgAgAiADQQFyNgIEAkAgA0H/AUsNACADQXhxQbDQgIAAaiEEAkACQEEAKAKI0ICAACIFQQEgA0EDdnQiA3ENAEEAIAUgA3I2AojQgIAAIAQhAwwBCyAEKAIIIQMLIAMgAjYCDCAEIAI2AgggAiAENgIMIAIgAzYCCAwDC0EfIQQCQCADQf///wdLDQAgA0EIdiIEIARBgP4/akEQdkEIcSIEdCIFIAVBgOAfakEQdkEEcSIFdCIAIABBgIAPakEQdkECcSIAdEEPdiAEIAVyIAByayIEQQF0IAMgBEEVanZBAXFyQRxqIQQLIAIgBDYCHCACQgA3AhAgBEECdEG40oCAAGohBQJAQQAoAozQgIAAIgBBASAEdCIIcQ0AIAUgAjYCAEEAIAAgCHI2AozQgIAAIAIgBTYCGCACIAI2AgggAiACNgIMDAMLIANBAEEZIARBAXZrIARBH0YbdCEEIAUoAgAhAANAIAAiBSgCBEF4cSADRg0CIARBHXYhACAEQQF0IQQgBSAAQQRxakEQaiIIKAIAIgANAAsgCCACNgIAIAIgBTYCGCACIAI2AgwgAiACNgIIDAILIABBeCAAa0EPcUEAIABBCGpBD3EbIgNqIgsgBkFIaiIIIANrIgNBAXI2AgQgACAIakE4NgIEIAQgBUE3IAVrQQ9xQQAgBUFJakEPcRtqQUFqIgggCCAEQRBqSRsiCEEjNgIEQQBBACgC8NOAgAA2AqTQgIAAQQAgAzYClNCAgABBACALNgKg0ICAACAIQRBqQQApAtDTgIAANwIAIAhBACkCyNOAgAA3AghBACAIQQhqNgLQ04CAAEEAIAY2AszTgIAAQQAgADYCyNOAgABBAEEANgLU04CAACAIQSRqIQMDQCADQQc2AgAgA0EEaiIDIAVJDQALIAggBEYNAyAIIAgoAgRBfnE2AgQgCCAIIARrIgA2AgAgBCAAQQFyNgIEAkAgAEH/AUsNACAAQXhxQbDQgIAAaiEDAkACQEEAKAKI0ICAACIFQQEgAEEDdnQiAHENAEEAIAUgAHI2AojQgIAAIAMhBQwBCyADKAIIIQULIAUgBDYCDCADIAQ2AgggBCADNgIMIAQgBTYCCAwEC0EfIQMCQCAAQf///wdLDQAgAEEIdiIDIANBgP4/akEQdkEIcSIDdCIFIAVBgOAfakEQdkEEcSIFdCIIIAhBgIAPakEQdkECcSIIdEEPdiADIAVyIAhyayIDQQF0IAAgA0EVanZBAXFyQRxqIQMLIAQgAzYCHCAEQgA3AhAgA0ECdEG40oCAAGohBQJAQQAoAozQgIAAIghBASADdCIGcQ0AIAUgBDYCAEEAIAggBnI2AozQgIAAIAQgBTYCGCAEIAQ2AgggBCAENgIMDAQLIABBAEEZIANBAXZrIANBH0YbdCEDIAUoAgAhCANAIAgiBSgCBEF4cSAARg0DIANBHXYhCCADQQF0IQMgBSAIQQRxakEQaiIGKAIAIggNAAsgBiAENgIAIAQgBTYCGCAEIAQ2AgwgBCAENgIIDAMLIAUoAggiAyACNgIMIAUgAjYCCCACQQA2AhggAiAFNgIMIAIgAzYCCAsgC0EIaiEDDAULIAUoAggiAyAENgIMIAUgBDYCCCAEQQA2AhggBCAFNgIMIAQgAzYCCAtBACgClNCAgAAiAyACTQ0AQQAoAqDQgIAAIgQgAmoiBSADIAJrIgNBAXI2AgRBACADNgKU0ICAAEEAIAU2AqDQgIAAIAQgAkEDcjYCBCAEQQhqIQMMAwtBACEDQQBBMDYC+NOAgAAMAgsCQCALRQ0AAkACQCAIIAgoAhwiBUECdEG40oCAAGoiAygCAEcNACADIAA2AgAgAA0BQQAgB0F+IAV3cSIHNgKM0ICAAAwCCyALQRBBFCALKAIQIAhGG2ogADYCACAARQ0BCyAAIAs2AhgCQCAIKAIQIgNFDQAgACADNgIQIAMgADYCGAsgCEEUaigCACIDRQ0AIABBFGogAzYCACADIAA2AhgLAkACQCAEQQ9LDQAgCCAEIAJqIgNBA3I2AgQgCCADaiIDIAMoAgRBAXI2AgQMAQsgCCACaiIAIARBAXI2AgQgCCACQQNyNgIEIAAgBGogBDYCAAJAIARB/wFLDQAgBEF4cUGw0ICAAGohAwJAAkBBACgCiNCAgAAiBUEBIARBA3Z0IgRxDQBBACAFIARyNgKI0ICAACADIQQMAQsgAygCCCEECyAEIAA2AgwgAyAANgIIIAAgAzYCDCAAIAQ2AggMAQtBHyEDAkAgBEH///8HSw0AIARBCHYiAyADQYD+P2pBEHZBCHEiA3QiBSAFQYDgH2pBEHZBBHEiBXQiAiACQYCAD2pBEHZBAnEiAnRBD3YgAyAFciACcmsiA0EBdCAEIANBFWp2QQFxckEcaiEDCyAAIAM2AhwgAEIANwIQIANBAnRBuNKAgABqIQUCQCAHQQEgA3QiAnENACAFIAA2AgBBACAHIAJyNgKM0ICAACAAIAU2AhggACAANgIIIAAgADYCDAwBCyAEQQBBGSADQQF2ayADQR9GG3QhAyAFKAIAIQICQANAIAIiBSgCBEF4cSAERg0BIANBHXYhAiADQQF0IQMgBSACQQRxakEQaiIGKAIAIgINAAsgBiAANgIAIAAgBTYCGCAAIAA2AgwgACAANgIIDAELIAUoAggiAyAANgIMIAUgADYCCCAAQQA2AhggACAFNgIMIAAgAzYCCAsgCEEIaiEDDAELAkAgCkUNAAJAAkAgACAAKAIcIgVBAnRBuNKAgABqIgMoAgBHDQAgAyAINgIAIAgNAUEAIAlBfiAFd3E2AozQgIAADAILIApBEEEUIAooAhAgAEYbaiAINgIAIAhFDQELIAggCjYCGAJAIAAoAhAiA0UNACAIIAM2AhAgAyAINgIYCyAAQRRqKAIAIgNFDQAgCEEUaiADNgIAIAMgCDYCGAsCQAJAIARBD0sNACAAIAQgAmoiA0EDcjYCBCAAIANqIgMgAygCBEEBcjYCBAwBCyAAIAJqIgUgBEEBcjYCBCAAIAJBA3I2AgQgBSAEaiAENgIAAkAgB0UNACAHQXhxQbDQgIAAaiECQQAoApzQgIAAIQMCQAJAQQEgB0EDdnQiCCAGcQ0AQQAgCCAGcjYCiNCAgAAgAiEIDAELIAIoAgghCAsgCCADNgIMIAIgAzYCCCADIAI2AgwgAyAINgIIC0EAIAU2ApzQgIAAQQAgBDYCkNCAgAALIABBCGohAwsgAUEQaiSAgICAACADCwoAIAAQyYCAgAAL4g0BB38CQCAARQ0AIABBeGoiASAAQXxqKAIAIgJBeHEiAGohAwJAIAJBAXENACACQQNxRQ0BIAEgASgCACICayIBQQAoApjQgIAAIgRJDQEgAiAAaiEAAkAgAUEAKAKc0ICAAEYNAAJAIAJB/wFLDQAgASgCCCIEIAJBA3YiBUEDdEGw0ICAAGoiBkYaAkAgASgCDCICIARHDQBBAEEAKAKI0ICAAEF+IAV3cTYCiNCAgAAMAwsgAiAGRhogAiAENgIIIAQgAjYCDAwCCyABKAIYIQcCQAJAIAEoAgwiBiABRg0AIAEoAggiAiAESRogBiACNgIIIAIgBjYCDAwBCwJAIAFBFGoiAigCACIEDQAgAUEQaiICKAIAIgQNAEEAIQYMAQsDQCACIQUgBCIGQRRqIgIoAgAiBA0AIAZBEGohAiAGKAIQIgQNAAsgBUEANgIACyAHRQ0BAkACQCABIAEoAhwiBEECdEG40oCAAGoiAigCAEcNACACIAY2AgAgBg0BQQBBACgCjNCAgABBfiAEd3E2AozQgIAADAMLIAdBEEEUIAcoAhAgAUYbaiAGNgIAIAZFDQILIAYgBzYCGAJAIAEoAhAiAkUNACAGIAI2AhAgAiAGNgIYCyABKAIUIgJFDQEgBkEUaiACNgIAIAIgBjYCGAwBCyADKAIEIgJBA3FBA0cNACADIAJBfnE2AgRBACAANgKQ0ICAACABIABqIAA2AgAgASAAQQFyNgIEDwsgASADTw0AIAMoAgQiAkEBcUUNAAJAAkAgAkECcQ0AAkAgA0EAKAKg0ICAAEcNAEEAIAE2AqDQgIAAQQBBACgClNCAgAAgAGoiADYClNCAgAAgASAAQQFyNgIEIAFBACgCnNCAgABHDQNBAEEANgKQ0ICAAEEAQQA2ApzQgIAADwsCQCADQQAoApzQgIAARw0AQQAgATYCnNCAgABBAEEAKAKQ0ICAACAAaiIANgKQ0ICAACABIABBAXI2AgQgASAAaiAANgIADwsgAkF4cSAAaiEAAkACQCACQf8BSw0AIAMoAggiBCACQQN2IgVBA3RBsNCAgABqIgZGGgJAIAMoAgwiAiAERw0AQQBBACgCiNCAgABBfiAFd3E2AojQgIAADAILIAIgBkYaIAIgBDYCCCAEIAI2AgwMAQsgAygCGCEHAkACQCADKAIMIgYgA0YNACADKAIIIgJBACgCmNCAgABJGiAGIAI2AgggAiAGNgIMDAELAkAgA0EUaiICKAIAIgQNACADQRBqIgIoAgAiBA0AQQAhBgwBCwNAIAIhBSAEIgZBFGoiAigCACIEDQAgBkEQaiECIAYoAhAiBA0ACyAFQQA2AgALIAdFDQACQAJAIAMgAygCHCIEQQJ0QbjSgIAAaiICKAIARw0AIAIgBjYCACAGDQFBAEEAKAKM0ICAAEF+IAR3cTYCjNCAgAAMAgsgB0EQQRQgBygCECADRhtqIAY2AgAgBkUNAQsgBiAHNgIYAkAgAygCECICRQ0AIAYgAjYCECACIAY2AhgLIAMoAhQiAkUNACAGQRRqIAI2AgAgAiAGNgIYCyABIABqIAA2AgAgASAAQQFyNgIEIAFBACgCnNCAgABHDQFBACAANgKQ0ICAAA8LIAMgAkF+cTYCBCABIABqIAA2AgAgASAAQQFyNgIECwJAIABB/wFLDQAgAEF4cUGw0ICAAGohAgJAAkBBACgCiNCAgAAiBEEBIABBA3Z0IgBxDQBBACAEIAByNgKI0ICAACACIQAMAQsgAigCCCEACyAAIAE2AgwgAiABNgIIIAEgAjYCDCABIAA2AggPC0EfIQICQCAAQf///wdLDQAgAEEIdiICIAJBgP4/akEQdkEIcSICdCIEIARBgOAfakEQdkEEcSIEdCIGIAZBgIAPakEQdkECcSIGdEEPdiACIARyIAZyayICQQF0IAAgAkEVanZBAXFyQRxqIQILIAEgAjYCHCABQgA3AhAgAkECdEG40oCAAGohBAJAAkBBACgCjNCAgAAiBkEBIAJ0IgNxDQAgBCABNgIAQQAgBiADcjYCjNCAgAAgASAENgIYIAEgATYCCCABIAE2AgwMAQsgAEEAQRkgAkEBdmsgAkEfRht0IQIgBCgCACEGAkADQCAGIgQoAgRBeHEgAEYNASACQR12IQYgAkEBdCECIAQgBkEEcWpBEGoiAygCACIGDQALIAMgATYCACABIAQ2AhggASABNgIMIAEgATYCCAwBCyAEKAIIIgAgATYCDCAEIAE2AgggAUEANgIYIAEgBDYCDCABIAA2AggLQQBBACgCqNCAgABBf2oiAUF/IAEbNgKo0ICAAAsLBAAAAAtOAAJAIAANAD8AQRB0DwsCQCAAQf//A3ENACAAQX9MDQACQCAAQRB2QAAiAEF/Rw0AQQBBMDYC+NOAgABBfw8LIABBEHQPCxDKgICAAAAL8gICA38BfgJAIAJFDQAgACABOgAAIAIgAGoiA0F/aiABOgAAIAJBA0kNACAAIAE6AAIgACABOgABIANBfWogAToAACADQX5qIAE6AAAgAkEHSQ0AIAAgAToAAyADQXxqIAE6AAAgAkEJSQ0AIABBACAAa0EDcSIEaiIDIAFB/wFxQYGChAhsIgE2AgAgAyACIARrQXxxIgRqIgJBfGogATYCACAEQQlJDQAgAyABNgIIIAMgATYCBCACQXhqIAE2AgAgAkF0aiABNgIAIARBGUkNACADIAE2AhggAyABNgIUIAMgATYCECADIAE2AgwgAkFwaiABNgIAIAJBbGogATYCACACQWhqIAE2AgAgAkFkaiABNgIAIAQgA0EEcUEYciIFayICQSBJDQAgAa1CgYCAgBB+IQYgAyAFaiEBA0AgASAGNwMYIAEgBjcDECABIAY3AwggASAGNwMAIAFBIGohASACQWBqIgJBH0sNAAsLIAALC45IAQBBgAgLhkgBAAAAAgAAAAMAAAAAAAAAAAAAAAQAAAAFAAAAAAAAAAAAAAAGAAAABwAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEludmFsaWQgY2hhciBpbiB1cmwgcXVlcnkAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9ib2R5AENvbnRlbnQtTGVuZ3RoIG92ZXJmbG93AENodW5rIHNpemUgb3ZlcmZsb3cAUmVzcG9uc2Ugb3ZlcmZsb3cASW52YWxpZCBtZXRob2QgZm9yIEhUVFAveC54IHJlcXVlc3QASW52YWxpZCBtZXRob2QgZm9yIFJUU1AveC54IHJlcXVlc3QARXhwZWN0ZWQgU09VUkNFIG1ldGhvZCBmb3IgSUNFL3gueCByZXF1ZXN0AEludmFsaWQgY2hhciBpbiB1cmwgZnJhZ21lbnQgc3RhcnQARXhwZWN0ZWQgZG90AFNwYW4gY2FsbGJhY2sgZXJyb3IgaW4gb25fc3RhdHVzAEludmFsaWQgcmVzcG9uc2Ugc3RhdHVzAEludmFsaWQgY2hhcmFjdGVyIGluIGNodW5rIGV4dGVuc2lvbnMAVXNlciBjYWxsYmFjayBlcnJvcgBgb25fcmVzZXRgIGNhbGxiYWNrIGVycm9yAGBvbl9jaHVua19oZWFkZXJgIGNhbGxiYWNrIGVycm9yAGBvbl9tZXNzYWdlX2JlZ2luYCBjYWxsYmFjayBlcnJvcgBgb25fY2h1bmtfZXh0ZW5zaW9uX3ZhbHVlYCBjYWxsYmFjayBlcnJvcgBgb25fc3RhdHVzX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25fdmVyc2lvbl9jb21wbGV0ZWAgY2FsbGJhY2sgZXJyb3IAYG9uX3VybF9jb21wbGV0ZWAgY2FsbGJhY2sgZXJyb3IAYG9uX2NodW5rX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25faGVhZGVyX3ZhbHVlX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25fbWVzc2FnZV9jb21wbGV0ZWAgY2FsbGJhY2sgZXJyb3IAYG9uX21ldGhvZF9jb21wbGV0ZWAgY2FsbGJhY2sgZXJyb3IAYG9uX2hlYWRlcl9maWVsZF9jb21wbGV0ZWAgY2FsbGJhY2sgZXJyb3IAYG9uX2NodW5rX2V4dGVuc2lvbl9uYW1lYCBjYWxsYmFjayBlcnJvcgBVbmV4cGVjdGVkIGNoYXIgaW4gdXJsIHNlcnZlcgBJbnZhbGlkIGhlYWRlciB2YWx1ZSBjaGFyAEludmFsaWQgaGVhZGVyIGZpZWxkIGNoYXIAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl92ZXJzaW9uAEludmFsaWQgbWlub3IgdmVyc2lvbgBJbnZhbGlkIG1ham9yIHZlcnNpb24ARXhwZWN0ZWQgc3BhY2UgYWZ0ZXIgdmVyc2lvbgBFeHBlY3RlZCBDUkxGIGFmdGVyIHZlcnNpb24ASW52YWxpZCBIVFRQIHZlcnNpb24ASW52YWxpZCBoZWFkZXIgdG9rZW4AU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl91cmwASW52YWxpZCBjaGFyYWN0ZXJzIGluIHVybABVbmV4cGVjdGVkIHN0YXJ0IGNoYXIgaW4gdXJsAERvdWJsZSBAIGluIHVybABFbXB0eSBDb250ZW50LUxlbmd0aABJbnZhbGlkIGNoYXJhY3RlciBpbiBDb250ZW50LUxlbmd0aABEdXBsaWNhdGUgQ29udGVudC1MZW5ndGgASW52YWxpZCBjaGFyIGluIHVybCBwYXRoAENvbnRlbnQtTGVuZ3RoIGNhbid0IGJlIHByZXNlbnQgd2l0aCBUcmFuc2Zlci1FbmNvZGluZwBJbnZhbGlkIGNoYXJhY3RlciBpbiBjaHVuayBzaXplAFNwYW4gY2FsbGJhY2sgZXJyb3IgaW4gb25faGVhZGVyX3ZhbHVlAFNwYW4gY2FsbGJhY2sgZXJyb3IgaW4gb25fY2h1bmtfZXh0ZW5zaW9uX3ZhbHVlAEludmFsaWQgY2hhcmFjdGVyIGluIGNodW5rIGV4dGVuc2lvbnMgdmFsdWUATWlzc2luZyBleHBlY3RlZCBMRiBhZnRlciBoZWFkZXIgdmFsdWUASW52YWxpZCBgVHJhbnNmZXItRW5jb2RpbmdgIGhlYWRlciB2YWx1ZQBJbnZhbGlkIGNoYXJhY3RlciBpbiBjaHVuayBleHRlbnNpb25zIHF1b3RlIHZhbHVlAEludmFsaWQgY2hhcmFjdGVyIGluIGNodW5rIGV4dGVuc2lvbnMgcXVvdGVkIHZhbHVlAFBhdXNlZCBieSBvbl9oZWFkZXJzX2NvbXBsZXRlAEludmFsaWQgRU9GIHN0YXRlAG9uX3Jlc2V0IHBhdXNlAG9uX2NodW5rX2hlYWRlciBwYXVzZQBvbl9tZXNzYWdlX2JlZ2luIHBhdXNlAG9uX2NodW5rX2V4dGVuc2lvbl92YWx1ZSBwYXVzZQBvbl9zdGF0dXNfY29tcGxldGUgcGF1c2UAb25fdmVyc2lvbl9jb21wbGV0ZSBwYXVzZQBvbl91cmxfY29tcGxldGUgcGF1c2UAb25fY2h1bmtfY29tcGxldGUgcGF1c2UAb25faGVhZGVyX3ZhbHVlX2NvbXBsZXRlIHBhdXNlAG9uX21lc3NhZ2VfY29tcGxldGUgcGF1c2UAb25fbWV0aG9kX2NvbXBsZXRlIHBhdXNlAG9uX2hlYWRlcl9maWVsZF9jb21wbGV0ZSBwYXVzZQBvbl9jaHVua19leHRlbnNpb25fbmFtZSBwYXVzZQBVbmV4cGVjdGVkIHNwYWNlIGFmdGVyIHN0YXJ0IGxpbmUAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9jaHVua19leHRlbnNpb25fbmFtZQBJbnZhbGlkIGNoYXJhY3RlciBpbiBjaHVuayBleHRlbnNpb25zIG5hbWUAUGF1c2Ugb24gQ09OTkVDVC9VcGdyYWRlAFBhdXNlIG9uIFBSSS9VcGdyYWRlAEV4cGVjdGVkIEhUVFAvMiBDb25uZWN0aW9uIFByZWZhY2UAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9tZXRob2QARXhwZWN0ZWQgc3BhY2UgYWZ0ZXIgbWV0aG9kAFNwYW4gY2FsbGJhY2sgZXJyb3IgaW4gb25faGVhZGVyX2ZpZWxkAFBhdXNlZABJbnZhbGlkIHdvcmQgZW5jb3VudGVyZWQASW52YWxpZCBtZXRob2QgZW5jb3VudGVyZWQAVW5leHBlY3RlZCBjaGFyIGluIHVybCBzY2hlbWEAUmVxdWVzdCBoYXMgaW52YWxpZCBgVHJhbnNmZXItRW5jb2RpbmdgAFNXSVRDSF9QUk9YWQBVU0VfUFJPWFkATUtBQ1RJVklUWQBVTlBST0NFU1NBQkxFX0VOVElUWQBDT1BZAE1PVkVEX1BFUk1BTkVOVExZAFRPT19FQVJMWQBOT1RJRlkARkFJTEVEX0RFUEVOREVOQ1kAQkFEX0dBVEVXQVkAUExBWQBQVVQAQ0hFQ0tPVVQAR0FURVdBWV9USU1FT1VUAFJFUVVFU1RfVElNRU9VVABORVRXT1JLX0NPTk5FQ1RfVElNRU9VVABDT05ORUNUSU9OX1RJTUVPVVQATE9HSU5fVElNRU9VVABORVRXT1JLX1JFQURfVElNRU9VVABQT1NUAE1JU0RJUkVDVEVEX1JFUVVFU1QAQ0xJRU5UX0NMT1NFRF9SRVFVRVNUAENMSUVOVF9DTE9TRURfTE9BRF9CQUxBTkNFRF9SRVFVRVNUAEJBRF9SRVFVRVNUAEhUVFBfUkVRVUVTVF9TRU5UX1RPX0hUVFBTX1BPUlQAUkVQT1JUAElNX0FfVEVBUE9UAFJFU0VUX0NPTlRFTlQATk9fQ09OVEVOVABQQVJUSUFMX0NPTlRFTlQASFBFX0lOVkFMSURfQ09OU1RBTlQASFBFX0NCX1JFU0VUAEdFVABIUEVfU1RSSUNUAENPTkZMSUNUAFRFTVBPUkFSWV9SRURJUkVDVABQRVJNQU5FTlRfUkVESVJFQ1QAQ09OTkVDVABNVUxUSV9TVEFUVVMASFBFX0lOVkFMSURfU1RBVFVTAFRPT19NQU5ZX1JFUVVFU1RTAEVBUkxZX0hJTlRTAFVOQVZBSUxBQkxFX0ZPUl9MRUdBTF9SRUFTT05TAE9QVElPTlMAU1dJVENISU5HX1BST1RPQ09MUwBWQVJJQU5UX0FMU09fTkVHT1RJQVRFUwBNVUxUSVBMRV9DSE9JQ0VTAElOVEVSTkFMX1NFUlZFUl9FUlJPUgBXRUJfU0VSVkVSX1VOS05PV05fRVJST1IAUkFJTEdVTl9FUlJPUgBJREVOVElUWV9QUk9WSURFUl9BVVRIRU5USUNBVElPTl9FUlJPUgBTU0xfQ0VSVElGSUNBVEVfRVJST1IASU5WQUxJRF9YX0ZPUldBUkRFRF9GT1IAU0VUX1BBUkFNRVRFUgBHRVRfUEFSQU1FVEVSAEhQRV9VU0VSAFNFRV9PVEhFUgBIUEVfQ0JfQ0hVTktfSEVBREVSAE1LQ0FMRU5EQVIAU0VUVVAAV0VCX1NFUlZFUl9JU19ET1dOAFRFQVJET1dOAEhQRV9DTE9TRURfQ09OTkVDVElPTgBIRVVSSVNUSUNfRVhQSVJBVElPTgBESVNDT05ORUNURURfT1BFUkFUSU9OAE5PTl9BVVRIT1JJVEFUSVZFX0lORk9STUFUSU9OAEhQRV9JTlZBTElEX1ZFUlNJT04ASFBFX0NCX01FU1NBR0VfQkVHSU4AU0lURV9JU19GUk9aRU4ASFBFX0lOVkFMSURfSEVBREVSX1RPS0VOAElOVkFMSURfVE9LRU4ARk9SQklEREVOAEVOSEFOQ0VfWU9VUl9DQUxNAEhQRV9JTlZBTElEX1VSTABCTE9DS0VEX0JZX1BBUkVOVEFMX0NPTlRST0wATUtDT0wAQUNMAEhQRV9JTlRFUk5BTABSRVFVRVNUX0hFQURFUl9GSUVMRFNfVE9PX0xBUkdFX1VOT0ZGSUNJQUwASFBFX09LAFVOTElOSwBVTkxPQ0sAUFJJAFJFVFJZX1dJVEgASFBFX0lOVkFMSURfQ09OVEVOVF9MRU5HVEgASFBFX1VORVhQRUNURURfQ09OVEVOVF9MRU5HVEgARkxVU0gAUFJPUFBBVENIAE0tU0VBUkNIAFVSSV9UT09fTE9ORwBQUk9DRVNTSU5HAE1JU0NFTExBTkVPVVNfUEVSU0lTVEVOVF9XQVJOSU5HAE1JU0NFTExBTkVPVVNfV0FSTklORwBIUEVfSU5WQUxJRF9UUkFOU0ZFUl9FTkNPRElORwBFeHBlY3RlZCBDUkxGAEhQRV9JTlZBTElEX0NIVU5LX1NJWkUATU9WRQBDT05USU5VRQBIUEVfQ0JfU1RBVFVTX0NPTVBMRVRFAEhQRV9DQl9IRUFERVJTX0NPTVBMRVRFAEhQRV9DQl9WRVJTSU9OX0NPTVBMRVRFAEhQRV9DQl9VUkxfQ09NUExFVEUASFBFX0NCX0NIVU5LX0NPTVBMRVRFAEhQRV9DQl9IRUFERVJfVkFMVUVfQ09NUExFVEUASFBFX0NCX0NIVU5LX0VYVEVOU0lPTl9WQUxVRV9DT01QTEVURQBIUEVfQ0JfQ0hVTktfRVhURU5TSU9OX05BTUVfQ09NUExFVEUASFBFX0NCX01FU1NBR0VfQ09NUExFVEUASFBFX0NCX01FVEhPRF9DT01QTEVURQBIUEVfQ0JfSEVBREVSX0ZJRUxEX0NPTVBMRVRFAERFTEVURQBIUEVfSU5WQUxJRF9FT0ZfU1RBVEUASU5WQUxJRF9TU0xfQ0VSVElGSUNBVEUAUEFVU0UATk9fUkVTUE9OU0UAVU5TVVBQT1JURURfTUVESUFfVFlQRQBHT05FAE5PVF9BQ0NFUFRBQkxFAFNFUlZJQ0VfVU5BVkFJTEFCTEUAUkFOR0VfTk9UX1NBVElTRklBQkxFAE9SSUdJTl9JU19VTlJFQUNIQUJMRQBSRVNQT05TRV9JU19TVEFMRQBQVVJHRQBNRVJHRQBSRVFVRVNUX0hFQURFUl9GSUVMRFNfVE9PX0xBUkdFAFJFUVVFU1RfSEVBREVSX1RPT19MQVJHRQBQQVlMT0FEX1RPT19MQVJHRQBJTlNVRkZJQ0lFTlRfU1RPUkFHRQBIUEVfUEFVU0VEX1VQR1JBREUASFBFX1BBVVNFRF9IMl9VUEdSQURFAFNPVVJDRQBBTk5PVU5DRQBUUkFDRQBIUEVfVU5FWFBFQ1RFRF9TUEFDRQBERVNDUklCRQBVTlNVQlNDUklCRQBSRUNPUkQASFBFX0lOVkFMSURfTUVUSE9EAE5PVF9GT1VORABQUk9QRklORABVTkJJTkQAUkVCSU5EAFVOQVVUSE9SSVpFRABNRVRIT0RfTk9UX0FMTE9XRUQASFRUUF9WRVJTSU9OX05PVF9TVVBQT1JURUQAQUxSRUFEWV9SRVBPUlRFRABBQ0NFUFRFRABOT1RfSU1QTEVNRU5URUQATE9PUF9ERVRFQ1RFRABIUEVfQ1JfRVhQRUNURUQASFBFX0xGX0VYUEVDVEVEAENSRUFURUQASU1fVVNFRABIUEVfUEFVU0VEAFRJTUVPVVRfT0NDVVJFRABQQVlNRU5UX1JFUVVJUkVEAFBSRUNPTkRJVElPTl9SRVFVSVJFRABQUk9YWV9BVVRIRU5USUNBVElPTl9SRVFVSVJFRABORVRXT1JLX0FVVEhFTlRJQ0FUSU9OX1JFUVVJUkVEAExFTkdUSF9SRVFVSVJFRABTU0xfQ0VSVElGSUNBVEVfUkVRVUlSRUQAVVBHUkFERV9SRVFVSVJFRABQQUdFX0VYUElSRUQAUFJFQ09ORElUSU9OX0ZBSUxFRABFWFBFQ1RBVElPTl9GQUlMRUQAUkVWQUxJREFUSU9OX0ZBSUxFRABTU0xfSEFORFNIQUtFX0ZBSUxFRABMT0NLRUQAVFJBTlNGT1JNQVRJT05fQVBQTElFRABOT1RfTU9ESUZJRUQATk9UX0VYVEVOREVEAEJBTkRXSURUSF9MSU1JVF9FWENFRURFRABTSVRFX0lTX09WRVJMT0FERUQASEVBRABFeHBlY3RlZCBIVFRQLwAAXhMAACYTAAAwEAAA8BcAAJ0TAAAVEgAAORcAAPASAAAKEAAAdRIAAK0SAACCEwAATxQAAH8QAACgFQAAIxQAAIkSAACLFAAATRUAANQRAADPFAAAEBgAAMkWAADcFgAAwREAAOAXAAC7FAAAdBQAAHwVAADlFAAACBcAAB8QAABlFQAAoxQAACgVAAACFQAAmRUAACwQAACLGQAATw8AANQOAABqEAAAzhAAAAIXAACJDgAAbhMAABwTAABmFAAAVhcAAMETAADNEwAAbBMAAGgXAABmFwAAXxcAACITAADODwAAaQ4AANgOAABjFgAAyxMAAKoOAAAoFwAAJhcAAMUTAABdFgAA6BEAAGcTAABlEwAA8hYAAHMTAAAdFwAA+RYAAPMRAADPDgAAzhUAAAwSAACzEQAApREAAGEQAAAyFwAAuxMAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQIBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAIDAgICAgIAAAICAAICAAICAgICAgICAgIABAAAAAAAAgICAgICAgICAgICAgICAgICAgICAgICAgIAAAACAgICAgICAgICAgICAgICAgICAgICAgICAgICAgACAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAACAAICAgICAAACAgACAgACAgICAgICAgICAAMABAAAAAICAgICAgICAgICAgICAgICAgICAgICAgICAAAAAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAAgACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbG9zZWVlcC1hbGl2ZQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEBAQEBAQEBAQIBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBY2h1bmtlZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEAAQEBAQEAAAEBAAEBAAEBAQEBAQEBAQEAAAAAAAAAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABlY3Rpb25lbnQtbGVuZ3Rob25yb3h5LWNvbm5lY3Rpb24AAAAAAAAAAAAAAAAAAAByYW5zZmVyLWVuY29kaW5ncGdyYWRlDQoNCg0KU00NCg0KVFRQL0NFL1RTUC8AAAAAAAAAAAAAAAABAgABAwAAAAAAAAAAAAAAAAAAAAAAAAQBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAAAAAAAAAAAAQIAAQMAAAAAAAAAAAAAAAAAAAAAAAAEAQEFAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQAAAAAAAAAAAAEAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAAAAAAAAAAAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAMEAAAEBAQEBAQEBAQEBAUEBAQEBAQEBAQEBAQABAAGBwQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEAAQABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAEAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAADAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwAAAAAAAAMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAABAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAIAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAAAAAAAADAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOT1VOQ0VFQ0tPVVRORUNURVRFQ1JJQkVMVVNIRVRFQURTRUFSQ0hSR0VDVElWSVRZTEVOREFSVkVPVElGWVBUSU9OU0NIU0VBWVNUQVRDSEdFT1JESVJFQ1RPUlRSQ0hQQVJBTUVURVJVUkNFQlNDUklCRUFSRE9XTkFDRUlORE5LQ0tVQlNDUklCRUhUVFAvQURUUC8=";
}));
//#endregion
//#region node_modules/undici/lib/llhttp/llhttp_simd-wasm.js
var require_llhttp_simd_wasm = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = "AGFzbQEAAAABMAhgAX8Bf2ADf39/AX9gBH9/f38Bf2AAAGADf39/AGABfwBgAn9/AGAGf39/f39/AALLAQgDZW52GHdhc21fb25faGVhZGVyc19jb21wbGV0ZQACA2VudhV3YXNtX29uX21lc3NhZ2VfYmVnaW4AAANlbnYLd2FzbV9vbl91cmwAAQNlbnYOd2FzbV9vbl9zdGF0dXMAAQNlbnYUd2FzbV9vbl9oZWFkZXJfZmllbGQAAQNlbnYUd2FzbV9vbl9oZWFkZXJfdmFsdWUAAQNlbnYMd2FzbV9vbl9ib2R5AAEDZW52GHdhc21fb25fbWVzc2FnZV9jb21wbGV0ZQAAA0ZFAwMEAAAFAAAAAAAABQEFAAUFBQAABgAAAAAGBgYGAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAAABAQcAAAUFAwABBAUBcAESEgUDAQACBggBfwFBgNQECwfRBSIGbWVtb3J5AgALX2luaXRpYWxpemUACRlfX2luZGlyZWN0X2Z1bmN0aW9uX3RhYmxlAQALbGxodHRwX2luaXQAChhsbGh0dHBfc2hvdWxkX2tlZXBfYWxpdmUAQQxsbGh0dHBfYWxsb2MADAZtYWxsb2MARgtsbGh0dHBfZnJlZQANBGZyZWUASA9sbGh0dHBfZ2V0X3R5cGUADhVsbGh0dHBfZ2V0X2h0dHBfbWFqb3IADxVsbGh0dHBfZ2V0X2h0dHBfbWlub3IAEBFsbGh0dHBfZ2V0X21ldGhvZAARFmxsaHR0cF9nZXRfc3RhdHVzX2NvZGUAEhJsbGh0dHBfZ2V0X3VwZ3JhZGUAEwxsbGh0dHBfcmVzZXQAFA5sbGh0dHBfZXhlY3V0ZQAVFGxsaHR0cF9zZXR0aW5nc19pbml0ABYNbGxodHRwX2ZpbmlzaAAXDGxsaHR0cF9wYXVzZQAYDWxsaHR0cF9yZXN1bWUAGRtsbGh0dHBfcmVzdW1lX2FmdGVyX3VwZ3JhZGUAGhBsbGh0dHBfZ2V0X2Vycm5vABsXbGxodHRwX2dldF9lcnJvcl9yZWFzb24AHBdsbGh0dHBfc2V0X2Vycm9yX3JlYXNvbgAdFGxsaHR0cF9nZXRfZXJyb3JfcG9zAB4RbGxodHRwX2Vycm5vX25hbWUAHxJsbGh0dHBfbWV0aG9kX25hbWUAIBJsbGh0dHBfc3RhdHVzX25hbWUAIRpsbGh0dHBfc2V0X2xlbmllbnRfaGVhZGVycwAiIWxsaHR0cF9zZXRfbGVuaWVudF9jaHVua2VkX2xlbmd0aAAjHWxsaHR0cF9zZXRfbGVuaWVudF9rZWVwX2FsaXZlACQkbGxodHRwX3NldF9sZW5pZW50X3RyYW5zZmVyX2VuY29kaW5nACUYbGxodHRwX21lc3NhZ2VfbmVlZHNfZW9mAD8JFwEAQQELEQECAwQFCwYHNTk3MS8tJyspCrLgAkUCAAsIABCIgICAAAsZACAAEMKAgIAAGiAAIAI2AjggACABOgAoCxwAIAAgAC8BMiAALQAuIAAQwYCAgAAQgICAgAALKgEBf0HAABDGgICAACIBEMKAgIAAGiABQYCIgIAANgI4IAEgADoAKCABCwoAIAAQyICAgAALBwAgAC0AKAsHACAALQAqCwcAIAAtACsLBwAgAC0AKQsHACAALwEyCwcAIAAtAC4LRQEEfyAAKAIYIQEgAC0ALSECIAAtACghAyAAKAI4IQQgABDCgICAABogACAENgI4IAAgAzoAKCAAIAI6AC0gACABNgIYCxEAIAAgASABIAJqEMOAgIAACxAAIABBAEHcABDMgICAABoLZwEBf0EAIQECQCAAKAIMDQACQAJAAkACQCAALQAvDgMBAAMCCyAAKAI4IgFFDQAgASgCLCIBRQ0AIAAgARGAgICAAAAiAQ0DC0EADwsQyoCAgAAACyAAQcOWgIAANgIQQQ4hAQsgAQseAAJAIAAoAgwNACAAQdGbgIAANgIQIABBFTYCDAsLFgACQCAAKAIMQRVHDQAgAEEANgIMCwsWAAJAIAAoAgxBFkcNACAAQQA2AgwLCwcAIAAoAgwLBwAgACgCEAsJACAAIAE2AhALBwAgACgCFAsiAAJAIABBJEkNABDKgICAAAALIABBAnRBoLOAgABqKAIACyIAAkAgAEEuSQ0AEMqAgIAAAAsgAEECdEGwtICAAGooAgAL7gsBAX9B66iAgAAhAQJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIABBnH9qDvQDY2IAAWFhYWFhYQIDBAVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhBgcICQoLDA0OD2FhYWFhEGFhYWFhYWFhYWFhEWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYRITFBUWFxgZGhthYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhHB0eHyAhIiMkJSYnKCkqKywtLi8wMTIzNDU2YTc4OTphYWFhYWFhYTthYWE8YWFhYT0+P2FhYWFhYWFhQGFhQWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYUJDREVGR0hJSktMTU5PUFFSU2FhYWFhYWFhVFVWV1hZWlthXF1hYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFeYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhX2BhC0Hhp4CAAA8LQaShgIAADwtBy6yAgAAPC0H+sYCAAA8LQcCkgIAADwtBq6SAgAAPC0GNqICAAA8LQeKmgIAADwtBgLCAgAAPC0G5r4CAAA8LQdekgIAADwtB75+AgAAPC0Hhn4CAAA8LQfqfgIAADwtB8qCAgAAPC0Gor4CAAA8LQa6ygIAADwtBiLCAgAAPC0Hsp4CAAA8LQYKigIAADwtBjp2AgAAPC0HQroCAAA8LQcqjgIAADwtBxbKAgAAPC0HfnICAAA8LQdKcgIAADwtBxKCAgAAPC0HXoICAAA8LQaKfgIAADwtB7a6AgAAPC0GrsICAAA8LQdSlgIAADwtBzK6AgAAPC0H6roCAAA8LQfyrgIAADwtB0rCAgAAPC0HxnYCAAA8LQbuggIAADwtB96uAgAAPC0GQsYCAAA8LQdexgIAADwtBoq2AgAAPC0HUp4CAAA8LQeCrgIAADwtBn6yAgAAPC0HrsYCAAA8LQdWfgIAADwtByrGAgAAPC0HepYCAAA8LQdSegIAADwtB9JyAgAAPC0GnsoCAAA8LQbGdgIAADwtBoJ2AgAAPC0G5sYCAAA8LQbywgIAADwtBkqGAgAAPC0GzpoCAAA8LQemsgIAADwtBrJ6AgAAPC0HUq4CAAA8LQfemgIAADwtBgKaAgAAPC0GwoYCAAA8LQf6egIAADwtBjaOAgAAPC0GJrYCAAA8LQfeigIAADwtBoLGAgAAPC0Gun4CAAA8LQcalgIAADwtB6J6AgAAPC0GTooCAAA8LQcKvgIAADwtBw52AgAAPC0GLrICAAA8LQeGdgIAADwtBja+AgAAPC0HqoYCAAA8LQbStgIAADwtB0q+AgAAPC0HfsoCAAA8LQdKygIAADwtB8LCAgAAPC0GpooCAAA8LQfmjgIAADwtBmZ6AgAAPC0G1rICAAA8LQZuwgIAADwtBkrKAgAAPC0G2q4CAAA8LQcKigIAADwtB+LKAgAAPC0GepYCAAA8LQdCigIAADwtBup6AgAAPC0GBnoCAAA8LEMqAgIAAAAtB1qGAgAAhAQsgAQsWACAAIAAtAC1B/gFxIAFBAEdyOgAtCxkAIAAgAC0ALUH9AXEgAUEAR0EBdHI6AC0LGQAgACAALQAtQfsBcSABQQBHQQJ0cjoALQsZACAAIAAtAC1B9wFxIAFBAEdBA3RyOgAtCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAgAiBEUNACAAIAQRgICAgAAAIQMLIAMLSQECf0EAIQMCQCAAKAI4IgRFDQAgBCgCBCIERQ0AIAAgASACIAFrIAQRgYCAgAAAIgNBf0cNACAAQcaRgIAANgIQQRghAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIwIgRFDQAgACAEEYCAgIAAACEDCyADC0kBAn9BACEDAkAgACgCOCIERQ0AIAQoAggiBEUNACAAIAEgAiABayAEEYGAgIAAACIDQX9HDQAgAEH2ioCAADYCEEEYIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCNCIERQ0AIAAgBBGAgICAAAAhAwsgAwtJAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIMIgRFDQAgACABIAIgAWsgBBGBgICAAAAiA0F/Rw0AIABB7ZqAgAA2AhBBGCEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAjgiBEUNACAAIAQRgICAgAAAIQMLIAMLSQECf0EAIQMCQCAAKAI4IgRFDQAgBCgCECIERQ0AIAAgASACIAFrIAQRgYCAgAAAIgNBf0cNACAAQZWQgIAANgIQQRghAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAI8IgRFDQAgACAEEYCAgIAAACEDCyADC0kBAn9BACEDAkAgACgCOCIERQ0AIAQoAhQiBEUNACAAIAEgAiABayAEEYGAgIAAACIDQX9HDQAgAEGqm4CAADYCEEEYIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCQCIERQ0AIAAgBBGAgICAAAAhAwsgAwtJAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIYIgRFDQAgACABIAIgAWsgBBGBgICAAAAiA0F/Rw0AIABB7ZOAgAA2AhBBGCEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAkQiBEUNACAAIAQRgICAgAAAIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCJCIERQ0AIAAgBBGAgICAAAAhAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIsIgRFDQAgACAEEYCAgIAAACEDCyADC0kBAn9BACEDAkAgACgCOCIERQ0AIAQoAigiBEUNACAAIAEgAiABayAEEYGAgIAAACIDQX9HDQAgAEH2iICAADYCEEEYIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCUCIERQ0AIAAgBBGAgICAAAAhAwsgAwtJAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAIcIgRFDQAgACABIAIgAWsgBBGBgICAAAAiA0F/Rw0AIABBwpmAgAA2AhBBGCEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAkgiBEUNACAAIAQRgICAgAAAIQMLIAMLSQECf0EAIQMCQCAAKAI4IgRFDQAgBCgCICIERQ0AIAAgASACIAFrIAQRgYCAgAAAIgNBf0cNACAAQZSUgIAANgIQQRghAwsgAwsuAQJ/QQAhAwJAIAAoAjgiBEUNACAEKAJMIgRFDQAgACAEEYCAgIAAACEDCyADCy4BAn9BACEDAkAgACgCOCIERQ0AIAQoAlQiBEUNACAAIAQRgICAgAAAIQMLIAMLLgECf0EAIQMCQCAAKAI4IgRFDQAgBCgCWCIERQ0AIAAgBBGAgICAAAAhAwsgAwtFAQF/AkACQCAALwEwQRRxQRRHDQBBASEDIAAtAChBAUYNASAALwEyQeUARiEDDAELIAAtAClBBUYhAwsgACADOgAuQQAL/gEBA39BASEDAkAgAC8BMCIEQQhxDQAgACkDIEIAUiEDCwJAAkAgAC0ALkUNAEEBIQUgAC0AKUEFRg0BQQEhBSAEQcAAcUUgA3FBAUcNAQtBACEFIARBwABxDQBBAiEFIARB//8DcSIDQQhxDQACQCADQYAEcUUNAAJAIAAtAChBAUcNACAALQAtQQpxDQBBBQ8LQQQPCwJAIANBIHENAAJAIAAtAChBAUYNACAALwEyQf//A3EiAEGcf2pB5ABJDQAgAEHMAUYNACAAQbACRg0AQQQhBSAEQShxRQ0CIANBiARxQYAERg0CC0EADwtBAEEDIAApAyBQGyEFCyAFC2IBAn9BACEBAkAgAC0AKEEBRg0AIAAvATJB//8DcSICQZx/akHkAEkNACACQcwBRg0AIAJBsAJGDQAgAC8BMCIAQcAAcQ0AQQEhASAAQYgEcUGABEYNACAAQShxRSEBCyABC6cBAQN/AkACQAJAIAAtACpFDQAgAC0AK0UNAEEAIQMgAC8BMCIEQQJxRQ0BDAILQQAhAyAALwEwIgRBAXFFDQELQQEhAyAALQAoQQFGDQAgAC8BMkH//wNxIgVBnH9qQeQASQ0AIAVBzAFGDQAgBUGwAkYNACAEQcAAcQ0AQQAhAyAEQYgEcUGABEYNACAEQShxQQBHIQMLIABBADsBMCAAQQA6AC8gAwuZAQECfwJAAkACQCAALQAqRQ0AIAAtACtFDQBBACEBIAAvATAiAkECcUUNAQwCC0EAIQEgAC8BMCICQQFxRQ0BC0EBIQEgAC0AKEEBRg0AIAAvATJB//8DcSIAQZx/akHkAEkNACAAQcwBRg0AIABBsAJGDQAgAkHAAHENAEEAIQEgAkGIBHFBgARGDQAgAkEocUEARyEBCyABC0kBAXsgAEEQav0MAAAAAAAAAAAAAAAAAAAAACIB/QsDACAAIAH9CwMAIABBMGogAf0LAwAgAEEgaiAB/QsDACAAQd0BNgIcQQALewEBfwJAIAAoAgwiAw0AAkAgACgCBEUNACAAIAE2AgQLAkAgACABIAIQxICAgAAiAw0AIAAoAgwPCyAAIAM2AhxBACEDIAAoAgQiAUUNACAAIAEgAiAAKAIIEYGAgIAAACIBRQ0AIAAgAjYCFCAAIAE2AgwgASEDCyADC+TzAQMOfwN+BH8jgICAgABBEGsiAySAgICAACABIQQgASEFIAEhBiABIQcgASEIIAEhCSABIQogASELIAEhDCABIQ0gASEOIAEhDwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAAKAIcIhBBf2oO3QHaAQHZAQIDBAUGBwgJCgsMDQ7YAQ8Q1wEREtYBExQVFhcYGRob4AHfARwdHtUBHyAhIiMkJdQBJicoKSorLNMB0gEtLtEB0AEvMDEyMzQ1Njc4OTo7PD0+P0BBQkNERUbbAUdISUrPAc4BS80BTMwBTU5PUFFSU1RVVldYWVpbXF1eX2BhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ent8fX5/gAGBAYIBgwGEAYUBhgGHAYgBiQGKAYsBjAGNAY4BjwGQAZEBkgGTAZQBlQGWAZcBmAGZAZoBmwGcAZ0BngGfAaABoQGiAaMBpAGlAaYBpwGoAakBqgGrAawBrQGuAa8BsAGxAbIBswG0AbUBtgG3AcsBygG4AckBuQHIAboBuwG8Ab0BvgG/AcABwQHCAcMBxAHFAcYBANwBC0EAIRAMxgELQQ4hEAzFAQtBDSEQDMQBC0EPIRAMwwELQRAhEAzCAQtBEyEQDMEBC0EUIRAMwAELQRUhEAy/AQtBFiEQDL4BC0EXIRAMvQELQRghEAy8AQtBGSEQDLsBC0EaIRAMugELQRshEAy5AQtBHCEQDLgBC0EIIRAMtwELQR0hEAy2AQtBICEQDLUBC0EfIRAMtAELQQchEAyzAQtBISEQDLIBC0EiIRAMsQELQR4hEAywAQtBIyEQDK8BC0ESIRAMrgELQREhEAytAQtBJCEQDKwBC0ElIRAMqwELQSYhEAyqAQtBJyEQDKkBC0HDASEQDKgBC0EpIRAMpwELQSshEAymAQtBLCEQDKUBC0EtIRAMpAELQS4hEAyjAQtBLyEQDKIBC0HEASEQDKEBC0EwIRAMoAELQTQhEAyfAQtBDCEQDJ4BC0ExIRAMnQELQTIhEAycAQtBMyEQDJsBC0E5IRAMmgELQTUhEAyZAQtBxQEhEAyYAQtBCyEQDJcBC0E6IRAMlgELQTYhEAyVAQtBCiEQDJQBC0E3IRAMkwELQTghEAySAQtBPCEQDJEBC0E7IRAMkAELQT0hEAyPAQtBCSEQDI4BC0EoIRAMjQELQT4hEAyMAQtBPyEQDIsBC0HAACEQDIoBC0HBACEQDIkBC0HCACEQDIgBC0HDACEQDIcBC0HEACEQDIYBC0HFACEQDIUBC0HGACEQDIQBC0EqIRAMgwELQccAIRAMggELQcgAIRAMgQELQckAIRAMgAELQcoAIRAMfwtBywAhEAx+C0HNACEQDH0LQcwAIRAMfAtBzgAhEAx7C0HPACEQDHoLQdAAIRAMeQtB0QAhEAx4C0HSACEQDHcLQdMAIRAMdgtB1AAhEAx1C0HWACEQDHQLQdUAIRAMcwtBBiEQDHILQdcAIRAMcQtBBSEQDHALQdgAIRAMbwtBBCEQDG4LQdkAIRAMbQtB2gAhEAxsC0HbACEQDGsLQdwAIRAMagtBAyEQDGkLQd0AIRAMaAtB3gAhEAxnC0HfACEQDGYLQeEAIRAMZQtB4AAhEAxkC0HiACEQDGMLQeMAIRAMYgtBAiEQDGELQeQAIRAMYAtB5QAhEAxfC0HmACEQDF4LQecAIRAMXQtB6AAhEAxcC0HpACEQDFsLQeoAIRAMWgtB6wAhEAxZC0HsACEQDFgLQe0AIRAMVwtB7gAhEAxWC0HvACEQDFULQfAAIRAMVAtB8QAhEAxTC0HyACEQDFILQfMAIRAMUQtB9AAhEAxQC0H1ACEQDE8LQfYAIRAMTgtB9wAhEAxNC0H4ACEQDEwLQfkAIRAMSwtB+gAhEAxKC0H7ACEQDEkLQfwAIRAMSAtB/QAhEAxHC0H+ACEQDEYLQf8AIRAMRQtBgAEhEAxEC0GBASEQDEMLQYIBIRAMQgtBgwEhEAxBC0GEASEQDEALQYUBIRAMPwtBhgEhEAw+C0GHASEQDD0LQYgBIRAMPAtBiQEhEAw7C0GKASEQDDoLQYsBIRAMOQtBjAEhEAw4C0GNASEQDDcLQY4BIRAMNgtBjwEhEAw1C0GQASEQDDQLQZEBIRAMMwtBkgEhEAwyC0GTASEQDDELQZQBIRAMMAtBlQEhEAwvC0GWASEQDC4LQZcBIRAMLQtBmAEhEAwsC0GZASEQDCsLQZoBIRAMKgtBmwEhEAwpC0GcASEQDCgLQZ0BIRAMJwtBngEhEAwmC0GfASEQDCULQaABIRAMJAtBoQEhEAwjC0GiASEQDCILQaMBIRAMIQtBpAEhEAwgC0GlASEQDB8LQaYBIRAMHgtBpwEhEAwdC0GoASEQDBwLQakBIRAMGwtBqgEhEAwaC0GrASEQDBkLQawBIRAMGAtBrQEhEAwXC0GuASEQDBYLQQEhEAwVC0GvASEQDBQLQbABIRAMEwtBsQEhEAwSC0GzASEQDBELQbIBIRAMEAtBtAEhEAwPC0G1ASEQDA4LQbYBIRAMDQtBtwEhEAwMC0G4ASEQDAsLQbkBIRAMCgtBugEhEAwJC0G7ASEQDAgLQcYBIRAMBwtBvAEhEAwGC0G9ASEQDAULQb4BIRAMBAtBvwEhEAwDC0HAASEQDAILQcIBIRAMAQtBwQEhEAsDQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIBAOxwEAAQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB4fICEjJSg/QEFERUZHSElKS0xNT1BRUlPeA1dZW1xdYGJlZmdoaWprbG1vcHFyc3R1dnd4eXp7fH1+gAGCAYUBhgGHAYkBiwGMAY0BjgGPAZABkQGUAZUBlgGXAZgBmQGaAZsBnAGdAZ4BnwGgAaEBogGjAaQBpQGmAacBqAGpAaoBqwGsAa0BrgGvAbABsQGyAbMBtAG1AbYBtwG4AbkBugG7AbwBvQG+Ab8BwAHBAcIBwwHEAcUBxgHHAcgByQHKAcsBzAHNAc4BzwHQAdEB0gHTAdQB1QHWAdcB2AHZAdoB2wHcAd0B3gHgAeEB4gHjAeQB5QHmAecB6AHpAeoB6wHsAe0B7gHvAfAB8QHyAfMBmQKkArAC/gL+AgsgASIEIAJHDfMBQd0BIRAM/wMLIAEiECACRw3dAUHDASEQDP4DCyABIgEgAkcNkAFB9wAhEAz9AwsgASIBIAJHDYYBQe8AIRAM/AMLIAEiASACRw1/QeoAIRAM+wMLIAEiASACRw17QegAIRAM+gMLIAEiASACRw14QeYAIRAM+QMLIAEiASACRw0aQRghEAz4AwsgASIBIAJHDRRBEiEQDPcDCyABIgEgAkcNWUHFACEQDPYDCyABIgEgAkcNSkE/IRAM9QMLIAEiASACRw1IQTwhEAz0AwsgASIBIAJHDUFBMSEQDPMDCyAALQAuQQFGDesDDIcCCyAAIAEiASACEMCAgIAAQQFHDeYBIABCADcDIAznAQsgACABIgEgAhC0gICAACIQDecBIAEhAQz1AgsCQCABIgEgAkcNAEEGIRAM8AMLIAAgAUEBaiIBIAIQu4CAgAAiEA3oASABIQEMMQsgAEIANwMgQRIhEAzVAwsgASIQIAJHDStBHSEQDO0DCwJAIAEiASACRg0AIAFBAWohAUEQIRAM1AMLQQchEAzsAwsgAEIAIAApAyAiESACIAEiEGutIhJ9IhMgEyARVhs3AyAgESASViIURQ3lAUEIIRAM6wMLAkAgASIBIAJGDQAgAEGJgICAADYCCCAAIAE2AgQgASEBQRQhEAzSAwtBCSEQDOoDCyABIQEgACkDIFAN5AEgASEBDPICCwJAIAEiASACRw0AQQshEAzpAwsgACABQQFqIgEgAhC2gICAACIQDeUBIAEhAQzyAgsgACABIgEgAhC4gICAACIQDeUBIAEhAQzyAgsgACABIgEgAhC4gICAACIQDeYBIAEhAQwNCyAAIAEiASACELqAgIAAIhAN5wEgASEBDPACCwJAIAEiASACRw0AQQ8hEAzlAwsgAS0AACIQQTtGDQggEEENRw3oASABQQFqIQEM7wILIAAgASIBIAIQuoCAgAAiEA3oASABIQEM8gILA0ACQCABLQAAQfC1gIAAai0AACIQQQFGDQAgEEECRw3rASAAKAIEIRAgAEEANgIEIAAgECABQQFqIgEQuYCAgAAiEA3qASABIQEM9AILIAFBAWoiASACRw0AC0ESIRAM4gMLIAAgASIBIAIQuoCAgAAiEA3pASABIQEMCgsgASIBIAJHDQZBGyEQDOADCwJAIAEiASACRw0AQRYhEAzgAwsgAEGKgICAADYCCCAAIAE2AgQgACABIAIQuICAgAAiEA3qASABIQFBICEQDMYDCwJAIAEiASACRg0AA0ACQCABLQAAQfC3gIAAai0AACIQQQJGDQACQCAQQX9qDgTlAewBAOsB7AELIAFBAWohAUEIIRAMyAMLIAFBAWoiASACRw0AC0EVIRAM3wMLQRUhEAzeAwsDQAJAIAEtAABB8LmAgABqLQAAIhBBAkYNACAQQX9qDgTeAewB4AHrAewBCyABQQFqIgEgAkcNAAtBGCEQDN0DCwJAIAEiASACRg0AIABBi4CAgAA2AgggACABNgIEIAEhAUEHIRAMxAMLQRkhEAzcAwsgAUEBaiEBDAILAkAgASIUIAJHDQBBGiEQDNsDCyAUIQECQCAULQAAQXNqDhTdAu4C7gLuAu4C7gLuAu4C7gLuAu4C7gLuAu4C7gLuAu4C7gLuAgDuAgtBACEQIABBADYCHCAAQa+LgIAANgIQIABBAjYCDCAAIBRBAWo2AhQM2gMLAkAgAS0AACIQQTtGDQAgEEENRw3oASABQQFqIQEM5QILIAFBAWohAQtBIiEQDL8DCwJAIAEiECACRw0AQRwhEAzYAwtCACERIBAhASAQLQAAQVBqDjfnAeYBAQIDBAUGBwgAAAAAAAAACQoLDA0OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPEBESExQAC0EeIRAMvQMLQgIhEQzlAQtCAyERDOQBC0IEIREM4wELQgUhEQziAQtCBiERDOEBC0IHIREM4AELQgghEQzfAQtCCSERDN4BC0IKIREM3QELQgshEQzcAQtCDCERDNsBC0INIREM2gELQg4hEQzZAQtCDyERDNgBC0IKIREM1wELQgshEQzWAQtCDCERDNUBC0INIREM1AELQg4hEQzTAQtCDyERDNIBC0IAIRECQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIBAtAABBUGoON+UB5AEAAQIDBAUGB+YB5gHmAeYB5gHmAeYBCAkKCwwN5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAeYB5gHmAQ4PEBESE+YBC0ICIREM5AELQgMhEQzjAQtCBCERDOIBC0IFIREM4QELQgYhEQzgAQtCByERDN8BC0IIIREM3gELQgkhEQzdAQtCCiERDNwBC0ILIREM2wELQgwhEQzaAQtCDSERDNkBC0IOIREM2AELQg8hEQzXAQtCCiERDNYBC0ILIREM1QELQgwhEQzUAQtCDSERDNMBC0IOIREM0gELQg8hEQzRAQsgAEIAIAApAyAiESACIAEiEGutIhJ9IhMgEyARVhs3AyAgESASViIURQ3SAUEfIRAMwAMLAkAgASIBIAJGDQAgAEGJgICAADYCCCAAIAE2AgQgASEBQSQhEAynAwtBICEQDL8DCyAAIAEiECACEL6AgIAAQX9qDgW2AQDFAgHRAdIBC0ERIRAMpAMLIABBAToALyAQIQEMuwMLIAEiASACRw3SAUEkIRAMuwMLIAEiDSACRw0eQcYAIRAMugMLIAAgASIBIAIQsoCAgAAiEA3UASABIQEMtQELIAEiECACRw0mQdAAIRAMuAMLAkAgASIBIAJHDQBBKCEQDLgDCyAAQQA2AgQgAEGMgICAADYCCCAAIAEgARCxgICAACIQDdMBIAEhAQzYAQsCQCABIhAgAkcNAEEpIRAMtwMLIBAtAAAiAUEgRg0UIAFBCUcN0wEgEEEBaiEBDBULAkAgASIBIAJGDQAgAUEBaiEBDBcLQSohEAy1AwsCQCABIhAgAkcNAEErIRAMtQMLAkAgEC0AACIBQQlGDQAgAUEgRw3VAQsgAC0ALEEIRg3TASAQIQEMkQMLAkAgASIBIAJHDQBBLCEQDLQDCyABLQAAQQpHDdUBIAFBAWohAQzJAgsgASIOIAJHDdUBQS8hEAyyAwsDQAJAIAEtAAAiEEEgRg0AAkAgEEF2ag4EANwB3AEA2gELIAEhAQzgAQsgAUEBaiIBIAJHDQALQTEhEAyxAwtBMiEQIAEiFCACRg2wAyACIBRrIAAoAgAiAWohFSAUIAFrQQNqIRYCQANAIBQtAAAiF0EgciAXIBdBv39qQf8BcUEaSRtB/wFxIAFB8LuAgABqLQAARw0BAkAgAUEDRw0AQQYhAQyWAwsgAUEBaiEBIBRBAWoiFCACRw0ACyAAIBU2AgAMsQMLIABBADYCACAUIQEM2QELQTMhECABIhQgAkYNrwMgAiAUayAAKAIAIgFqIRUgFCABa0EIaiEWAkADQCAULQAAIhdBIHIgFyAXQb9/akH/AXFBGkkbQf8BcSABQfS7gIAAai0AAEcNAQJAIAFBCEcNAEEFIQEMlQMLIAFBAWohASAUQQFqIhQgAkcNAAsgACAVNgIADLADCyAAQQA2AgAgFCEBDNgBC0E0IRAgASIUIAJGDa4DIAIgFGsgACgCACIBaiEVIBQgAWtBBWohFgJAA0AgFC0AACIXQSByIBcgF0G/f2pB/wFxQRpJG0H/AXEgAUHQwoCAAGotAABHDQECQCABQQVHDQBBByEBDJQDCyABQQFqIQEgFEEBaiIUIAJHDQALIAAgFTYCAAyvAwsgAEEANgIAIBQhAQzXAQsCQCABIgEgAkYNAANAAkAgAS0AAEGAvoCAAGotAAAiEEEBRg0AIBBBAkYNCiABIQEM3QELIAFBAWoiASACRw0AC0EwIRAMrgMLQTAhEAytAwsCQCABIgEgAkYNAANAAkAgAS0AACIQQSBGDQAgEEF2ag4E2QHaAdoB2QHaAQsgAUEBaiIBIAJHDQALQTghEAytAwtBOCEQDKwDCwNAAkAgAS0AACIQQSBGDQAgEEEJRw0DCyABQQFqIgEgAkcNAAtBPCEQDKsDCwNAAkAgAS0AACIQQSBGDQACQAJAIBBBdmoOBNoBAQHaAQALIBBBLEYN2wELIAEhAQwECyABQQFqIgEgAkcNAAtBPyEQDKoDCyABIQEM2wELQcAAIRAgASIUIAJGDagDIAIgFGsgACgCACIBaiEWIBQgAWtBBmohFwJAA0AgFC0AAEEgciABQYDAgIAAai0AAEcNASABQQZGDY4DIAFBAWohASAUQQFqIhQgAkcNAAsgACAWNgIADKkDCyAAQQA2AgAgFCEBC0E2IRAMjgMLAkAgASIPIAJHDQBBwQAhEAynAwsgAEGMgICAADYCCCAAIA82AgQgDyEBIAAtACxBf2oOBM0B1QHXAdkBhwMLIAFBAWohAQzMAQsCQCABIgEgAkYNAANAAkAgAS0AACIQQSByIBAgEEG/f2pB/wFxQRpJG0H/AXEiEEEJRg0AIBBBIEYNAAJAAkACQAJAIBBBnX9qDhMAAwMDAwMDAwEDAwMDAwMDAwMCAwsgAUEBaiEBQTEhEAyRAwsgAUEBaiEBQTIhEAyQAwsgAUEBaiEBQTMhEAyPAwsgASEBDNABCyABQQFqIgEgAkcNAAtBNSEQDKUDC0E1IRAMpAMLAkAgASIBIAJGDQADQAJAIAEtAABBgLyAgABqLQAAQQFGDQAgASEBDNMBCyABQQFqIgEgAkcNAAtBPSEQDKQDC0E9IRAMowMLIAAgASIBIAIQsICAgAAiEA3WASABIQEMAQsgEEEBaiEBC0E8IRAMhwMLAkAgASIBIAJHDQBBwgAhEAygAwsCQANAAkAgAS0AAEF3ag4YAAL+Av4ChAP+Av4C/gL+Av4C/gL+Av4C/gL+Av4C/gL+Av4C/gL+Av4C/gIA/gILIAFBAWoiASACRw0AC0HCACEQDKADCyABQQFqIQEgAC0ALUEBcUUNvQEgASEBC0EsIRAMhQMLIAEiASACRw3TAUHEACEQDJ0DCwNAAkAgAS0AAEGQwICAAGotAABBAUYNACABIQEMtwILIAFBAWoiASACRw0AC0HFACEQDJwDCyANLQAAIhBBIEYNswEgEEE6Rw2BAyAAKAIEIQEgAEEANgIEIAAgASANEK+AgIAAIgEN0AEgDUEBaiEBDLMCC0HHACEQIAEiDSACRg2aAyACIA1rIAAoAgAiAWohFiANIAFrQQVqIRcDQCANLQAAIhRBIHIgFCAUQb9/akH/AXFBGkkbQf8BcSABQZDCgIAAai0AAEcNgAMgAUEFRg30AiABQQFqIQEgDUEBaiINIAJHDQALIAAgFjYCAAyaAwtByAAhECABIg0gAkYNmQMgAiANayAAKAIAIgFqIRYgDSABa0EJaiEXA0AgDS0AACIUQSByIBQgFEG/f2pB/wFxQRpJG0H/AXEgAUGWwoCAAGotAABHDf8CAkAgAUEJRw0AQQIhAQz1AgsgAUEBaiEBIA1BAWoiDSACRw0ACyAAIBY2AgAMmQMLAkAgASINIAJHDQBByQAhEAyZAwsCQAJAIA0tAAAiAUEgciABIAFBv39qQf8BcUEaSRtB/wFxQZJ/ag4HAIADgAOAA4ADgAMBgAMLIA1BAWohAUE+IRAMgAMLIA1BAWohAUE/IRAM/wILQcoAIRAgASINIAJGDZcDIAIgDWsgACgCACIBaiEWIA0gAWtBAWohFwNAIA0tAAAiFEEgciAUIBRBv39qQf8BcUEaSRtB/wFxIAFBoMKAgABqLQAARw39AiABQQFGDfACIAFBAWohASANQQFqIg0gAkcNAAsgACAWNgIADJcDC0HLACEQIAEiDSACRg2WAyACIA1rIAAoAgAiAWohFiANIAFrQQ5qIRcDQCANLQAAIhRBIHIgFCAUQb9/akH/AXFBGkkbQf8BcSABQaLCgIAAai0AAEcN/AIgAUEORg3wAiABQQFqIQEgDUEBaiINIAJHDQALIAAgFjYCAAyWAwtBzAAhECABIg0gAkYNlQMgAiANayAAKAIAIgFqIRYgDSABa0EPaiEXA0AgDS0AACIUQSByIBQgFEG/f2pB/wFxQRpJG0H/AXEgAUHAwoCAAGotAABHDfsCAkAgAUEPRw0AQQMhAQzxAgsgAUEBaiEBIA1BAWoiDSACRw0ACyAAIBY2AgAMlQMLQc0AIRAgASINIAJGDZQDIAIgDWsgACgCACIBaiEWIA0gAWtBBWohFwNAIA0tAAAiFEEgciAUIBRBv39qQf8BcUEaSRtB/wFxIAFB0MKAgABqLQAARw36AgJAIAFBBUcNAEEEIQEM8AILIAFBAWohASANQQFqIg0gAkcNAAsgACAWNgIADJQDCwJAIAEiDSACRw0AQc4AIRAMlAMLAkACQAJAAkAgDS0AACIBQSByIAEgAUG/f2pB/wFxQRpJG0H/AXFBnX9qDhMA/QL9Av0C/QL9Av0C/QL9Av0C/QL9Av0CAf0C/QL9AgID/QILIA1BAWohAUHBACEQDP0CCyANQQFqIQFBwgAhEAz8AgsgDUEBaiEBQcMAIRAM+wILIA1BAWohAUHEACEQDPoCCwJAIAEiASACRg0AIABBjYCAgAA2AgggACABNgIEIAEhAUHFACEQDPoCC0HPACEQDJIDCyAQIQECQAJAIBAtAABBdmoOBAGoAqgCAKgCCyAQQQFqIQELQSchEAz4AgsCQCABIgEgAkcNAEHRACEQDJEDCwJAIAEtAABBIEYNACABIQEMjQELIAFBAWohASAALQAtQQFxRQ3HASABIQEMjAELIAEiFyACRw3IAUHSACEQDI8DC0HTACEQIAEiFCACRg2OAyACIBRrIAAoAgAiAWohFiAUIAFrQQFqIRcDQCAULQAAIAFB1sKAgABqLQAARw3MASABQQFGDccBIAFBAWohASAUQQFqIhQgAkcNAAsgACAWNgIADI4DCwJAIAEiASACRw0AQdUAIRAMjgMLIAEtAABBCkcNzAEgAUEBaiEBDMcBCwJAIAEiASACRw0AQdYAIRAMjQMLAkACQCABLQAAQXZqDgQAzQHNAQHNAQsgAUEBaiEBDMcBCyABQQFqIQFBygAhEAzzAgsgACABIgEgAhCugICAACIQDcsBIAEhAUHNACEQDPICCyAALQApQSJGDYUDDKYCCwJAIAEiASACRw0AQdsAIRAMigMLQQAhFEEBIRdBASEWQQAhEAJAAkACQAJAAkACQAJAAkACQCABLQAAQVBqDgrUAdMBAAECAwQFBgjVAQtBAiEQDAYLQQMhEAwFC0EEIRAMBAtBBSEQDAMLQQYhEAwCC0EHIRAMAQtBCCEQC0EAIRdBACEWQQAhFAzMAQtBCSEQQQEhFEEAIRdBACEWDMsBCwJAIAEiASACRw0AQd0AIRAMiQMLIAEtAABBLkcNzAEgAUEBaiEBDKYCCyABIgEgAkcNzAFB3wAhEAyHAwsCQCABIgEgAkYNACAAQY6AgIAANgIIIAAgATYCBCABIQFB0AAhEAzuAgtB4AAhEAyGAwtB4QAhECABIgEgAkYNhQMgAiABayAAKAIAIhRqIRYgASAUa0EDaiEXA0AgAS0AACAUQeLCgIAAai0AAEcNzQEgFEEDRg3MASAUQQFqIRQgAUEBaiIBIAJHDQALIAAgFjYCAAyFAwtB4gAhECABIgEgAkYNhAMgAiABayAAKAIAIhRqIRYgASAUa0ECaiEXA0AgAS0AACAUQebCgIAAai0AAEcNzAEgFEECRg3OASAUQQFqIRQgAUEBaiIBIAJHDQALIAAgFjYCAAyEAwtB4wAhECABIgEgAkYNgwMgAiABayAAKAIAIhRqIRYgASAUa0EDaiEXA0AgAS0AACAUQenCgIAAai0AAEcNywEgFEEDRg3OASAUQQFqIRQgAUEBaiIBIAJHDQALIAAgFjYCAAyDAwsCQCABIgEgAkcNAEHlACEQDIMDCyAAIAFBAWoiASACEKiAgIAAIhANzQEgASEBQdYAIRAM6QILAkAgASIBIAJGDQADQAJAIAEtAAAiEEEgRg0AAkACQAJAIBBBuH9qDgsAAc8BzwHPAc8BzwHPAc8BzwECzwELIAFBAWohAUHSACEQDO0CCyABQQFqIQFB0wAhEAzsAgsgAUEBaiEBQdQAIRAM6wILIAFBAWoiASACRw0AC0HkACEQDIIDC0HkACEQDIEDCwNAAkAgAS0AAEHwwoCAAGotAAAiEEEBRg0AIBBBfmoOA88B0AHRAdIBCyABQQFqIgEgAkcNAAtB5gAhEAyAAwsCQCABIgEgAkYNACABQQFqIQEMAwtB5wAhEAz/AgsDQAJAIAEtAABB8MSAgABqLQAAIhBBAUYNAAJAIBBBfmoOBNIB0wHUAQDVAQsgASEBQdcAIRAM5wILIAFBAWoiASACRw0AC0HoACEQDP4CCwJAIAEiASACRw0AQekAIRAM/gILAkAgAS0AACIQQXZqDhq6AdUB1QG8AdUB1QHVAdUB1QHVAdUB1QHVAdUB1QHVAdUB1QHVAdUB1QHVAcoB1QHVAQDTAQsgAUEBaiEBC0EGIRAM4wILA0ACQCABLQAAQfDGgIAAai0AAEEBRg0AIAEhAQyeAgsgAUEBaiIBIAJHDQALQeoAIRAM+wILAkAgASIBIAJGDQAgAUEBaiEBDAMLQesAIRAM+gILAkAgASIBIAJHDQBB7AAhEAz6AgsgAUEBaiEBDAELAkAgASIBIAJHDQBB7QAhEAz5AgsgAUEBaiEBC0EEIRAM3gILAkAgASIUIAJHDQBB7gAhEAz3AgsgFCEBAkACQAJAIBQtAABB8MiAgABqLQAAQX9qDgfUAdUB1gEAnAIBAtcBCyAUQQFqIQEMCgsgFEEBaiEBDM0BC0EAIRAgAEEANgIcIABBm5KAgAA2AhAgAEEHNgIMIAAgFEEBajYCFAz2AgsCQANAAkAgAS0AAEHwyICAAGotAAAiEEEERg0AAkACQCAQQX9qDgfSAdMB1AHZAQAEAdkBCyABIQFB2gAhEAzgAgsgAUEBaiEBQdwAIRAM3wILIAFBAWoiASACRw0AC0HvACEQDPYCCyABQQFqIQEMywELAkAgASIUIAJHDQBB8AAhEAz1AgsgFC0AAEEvRw3UASAUQQFqIQEMBgsCQCABIhQgAkcNAEHxACEQDPQCCwJAIBQtAAAiAUEvRw0AIBRBAWohAUHdACEQDNsCCyABQXZqIgRBFksN0wFBASAEdEGJgIACcUUN0wEMygILAkAgASIBIAJGDQAgAUEBaiEBQd4AIRAM2gILQfIAIRAM8gILAkAgASIUIAJHDQBB9AAhEAzyAgsgFCEBAkAgFC0AAEHwzICAAGotAABBf2oOA8kClAIA1AELQeEAIRAM2AILAkAgASIUIAJGDQADQAJAIBQtAABB8MqAgABqLQAAIgFBA0YNAAJAIAFBf2oOAssCANUBCyAUIQFB3wAhEAzaAgsgFEEBaiIUIAJHDQALQfMAIRAM8QILQfMAIRAM8AILAkAgASIBIAJGDQAgAEGPgICAADYCCCAAIAE2AgQgASEBQeAAIRAM1wILQfUAIRAM7wILAkAgASIBIAJHDQBB9gAhEAzvAgsgAEGPgICAADYCCCAAIAE2AgQgASEBC0EDIRAM1AILA0AgAS0AAEEgRw3DAiABQQFqIgEgAkcNAAtB9wAhEAzsAgsCQCABIgEgAkcNAEH4ACEQDOwCCyABLQAAQSBHDc4BIAFBAWohAQzvAQsgACABIgEgAhCsgICAACIQDc4BIAEhAQyOAgsCQCABIgQgAkcNAEH6ACEQDOoCCyAELQAAQcwARw3RASAEQQFqIQFBEyEQDM8BCwJAIAEiBCACRw0AQfsAIRAM6QILIAIgBGsgACgCACIBaiEUIAQgAWtBBWohEANAIAQtAAAgAUHwzoCAAGotAABHDdABIAFBBUYNzgEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBB+wAhEAzoAgsCQCABIgQgAkcNAEH8ACEQDOgCCwJAAkAgBC0AAEG9f2oODADRAdEB0QHRAdEB0QHRAdEB0QHRAQHRAQsgBEEBaiEBQeYAIRAMzwILIARBAWohAUHnACEQDM4CCwJAIAEiBCACRw0AQf0AIRAM5wILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQe3PgIAAai0AAEcNzwEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQf0AIRAM5wILIABBADYCACAQQQFqIQFBECEQDMwBCwJAIAEiBCACRw0AQf4AIRAM5gILIAIgBGsgACgCACIBaiEUIAQgAWtBBWohEAJAA0AgBC0AACABQfbOgIAAai0AAEcNzgEgAUEFRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQf4AIRAM5gILIABBADYCACAQQQFqIQFBFiEQDMsBCwJAIAEiBCACRw0AQf8AIRAM5QILIAIgBGsgACgCACIBaiEUIAQgAWtBA2ohEAJAA0AgBC0AACABQfzOgIAAai0AAEcNzQEgAUEDRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQf8AIRAM5QILIABBADYCACAQQQFqIQFBBSEQDMoBCwJAIAEiBCACRw0AQYABIRAM5AILIAQtAABB2QBHDcsBIARBAWohAUEIIRAMyQELAkAgASIEIAJHDQBBgQEhEAzjAgsCQAJAIAQtAABBsn9qDgMAzAEBzAELIARBAWohAUHrACEQDMoCCyAEQQFqIQFB7AAhEAzJAgsCQCABIgQgAkcNAEGCASEQDOICCwJAAkAgBC0AAEG4f2oOCADLAcsBywHLAcsBywEBywELIARBAWohAUHqACEQDMkCCyAEQQFqIQFB7QAhEAzIAgsCQCABIgQgAkcNAEGDASEQDOECCyACIARrIAAoAgAiAWohECAEIAFrQQJqIRQCQANAIAQtAAAgAUGAz4CAAGotAABHDckBIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgEDYCAEGDASEQDOECC0EAIRAgAEEANgIAIBRBAWohAQzGAQsCQCABIgQgAkcNAEGEASEQDOACCyACIARrIAAoAgAiAWohFCAEIAFrQQRqIRACQANAIAQtAAAgAUGDz4CAAGotAABHDcgBIAFBBEYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGEASEQDOACCyAAQQA2AgAgEEEBaiEBQSMhEAzFAQsCQCABIgQgAkcNAEGFASEQDN8CCwJAAkAgBC0AAEG0f2oOCADIAcgByAHIAcgByAEByAELIARBAWohAUHvACEQDMYCCyAEQQFqIQFB8AAhEAzFAgsCQCABIgQgAkcNAEGGASEQDN4CCyAELQAAQcUARw3FASAEQQFqIQEMgwILAkAgASIEIAJHDQBBhwEhEAzdAgsgAiAEayAAKAIAIgFqIRQgBCABa0EDaiEQAkADQCAELQAAIAFBiM+AgABqLQAARw3FASABQQNGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBhwEhEAzdAgsgAEEANgIAIBBBAWohAUEtIRAMwgELAkAgASIEIAJHDQBBiAEhEAzcAgsgAiAEayAAKAIAIgFqIRQgBCABa0EIaiEQAkADQCAELQAAIAFB0M+AgABqLQAARw3EASABQQhGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBiAEhEAzcAgsgAEEANgIAIBBBAWohAUEpIRAMwQELAkAgASIBIAJHDQBBiQEhEAzbAgtBASEQIAEtAABB3wBHDcABIAFBAWohAQyBAgsCQCABIgQgAkcNAEGKASEQDNoCCyACIARrIAAoAgAiAWohFCAEIAFrQQFqIRADQCAELQAAIAFBjM+AgABqLQAARw3BASABQQFGDa8CIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQYoBIRAM2QILAkAgASIEIAJHDQBBiwEhEAzZAgsgAiAEayAAKAIAIgFqIRQgBCABa0ECaiEQAkADQCAELQAAIAFBjs+AgABqLQAARw3BASABQQJGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBiwEhEAzZAgsgAEEANgIAIBBBAWohAUECIRAMvgELAkAgASIEIAJHDQBBjAEhEAzYAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFB8M+AgABqLQAARw3AASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBjAEhEAzYAgsgAEEANgIAIBBBAWohAUEfIRAMvQELAkAgASIEIAJHDQBBjQEhEAzXAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFB8s+AgABqLQAARw2/ASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBjQEhEAzXAgsgAEEANgIAIBBBAWohAUEJIRAMvAELAkAgASIEIAJHDQBBjgEhEAzWAgsCQAJAIAQtAABBt39qDgcAvwG/Ab8BvwG/AQG/AQsgBEEBaiEBQfgAIRAMvQILIARBAWohAUH5ACEQDLwCCwJAIAEiBCACRw0AQY8BIRAM1QILIAIgBGsgACgCACIBaiEUIAQgAWtBBWohEAJAA0AgBC0AACABQZHPgIAAai0AAEcNvQEgAUEFRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQY8BIRAM1QILIABBADYCACAQQQFqIQFBGCEQDLoBCwJAIAEiBCACRw0AQZABIRAM1AILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQZfPgIAAai0AAEcNvAEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZABIRAM1AILIABBADYCACAQQQFqIQFBFyEQDLkBCwJAIAEiBCACRw0AQZEBIRAM0wILIAIgBGsgACgCACIBaiEUIAQgAWtBBmohEAJAA0AgBC0AACABQZrPgIAAai0AAEcNuwEgAUEGRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZEBIRAM0wILIABBADYCACAQQQFqIQFBFSEQDLgBCwJAIAEiBCACRw0AQZIBIRAM0gILIAIgBGsgACgCACIBaiEUIAQgAWtBBWohEAJAA0AgBC0AACABQaHPgIAAai0AAEcNugEgAUEFRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZIBIRAM0gILIABBADYCACAQQQFqIQFBHiEQDLcBCwJAIAEiBCACRw0AQZMBIRAM0QILIAQtAABBzABHDbgBIARBAWohAUEKIRAMtgELAkAgBCACRw0AQZQBIRAM0AILAkACQCAELQAAQb9/ag4PALkBuQG5AbkBuQG5AbkBuQG5AbkBuQG5AbkBAbkBCyAEQQFqIQFB/gAhEAy3AgsgBEEBaiEBQf8AIRAMtgILAkAgBCACRw0AQZUBIRAMzwILAkACQCAELQAAQb9/ag4DALgBAbgBCyAEQQFqIQFB/QAhEAy2AgsgBEEBaiEEQYABIRAMtQILAkAgBCACRw0AQZYBIRAMzgILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQafPgIAAai0AAEcNtgEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZYBIRAMzgILIABBADYCACAQQQFqIQFBCyEQDLMBCwJAIAQgAkcNAEGXASEQDM0CCwJAAkACQAJAIAQtAABBU2oOIwC4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBuAG4AbgBAbgBuAG4AbgBuAECuAG4AbgBA7gBCyAEQQFqIQFB+wAhEAy2AgsgBEEBaiEBQfwAIRAMtQILIARBAWohBEGBASEQDLQCCyAEQQFqIQRBggEhEAyzAgsCQCAEIAJHDQBBmAEhEAzMAgsgAiAEayAAKAIAIgFqIRQgBCABa0EEaiEQAkADQCAELQAAIAFBqc+AgABqLQAARw20ASABQQRGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBmAEhEAzMAgsgAEEANgIAIBBBAWohAUEZIRAMsQELAkAgBCACRw0AQZkBIRAMywILIAIgBGsgACgCACIBaiEUIAQgAWtBBWohEAJAA0AgBC0AACABQa7PgIAAai0AAEcNswEgAUEFRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZkBIRAMywILIABBADYCACAQQQFqIQFBBiEQDLABCwJAIAQgAkcNAEGaASEQDMoCCyACIARrIAAoAgAiAWohFCAEIAFrQQFqIRACQANAIAQtAAAgAUG0z4CAAGotAABHDbIBIAFBAUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGaASEQDMoCCyAAQQA2AgAgEEEBaiEBQRwhEAyvAQsCQCAEIAJHDQBBmwEhEAzJAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFBts+AgABqLQAARw2xASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBmwEhEAzJAgsgAEEANgIAIBBBAWohAUEnIRAMrgELAkAgBCACRw0AQZwBIRAMyAILAkACQCAELQAAQax/ag4CAAGxAQsgBEEBaiEEQYYBIRAMrwILIARBAWohBEGHASEQDK4CCwJAIAQgAkcNAEGdASEQDMcCCyACIARrIAAoAgAiAWohFCAEIAFrQQFqIRACQANAIAQtAAAgAUG4z4CAAGotAABHDa8BIAFBAUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGdASEQDMcCCyAAQQA2AgAgEEEBaiEBQSYhEAysAQsCQCAEIAJHDQBBngEhEAzGAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFBus+AgABqLQAARw2uASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBngEhEAzGAgsgAEEANgIAIBBBAWohAUEDIRAMqwELAkAgBCACRw0AQZ8BIRAMxQILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQe3PgIAAai0AAEcNrQEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQZ8BIRAMxQILIABBADYCACAQQQFqIQFBDCEQDKoBCwJAIAQgAkcNAEGgASEQDMQCCyACIARrIAAoAgAiAWohFCAEIAFrQQNqIRACQANAIAQtAAAgAUG8z4CAAGotAABHDawBIAFBA0YNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGgASEQDMQCCyAAQQA2AgAgEEEBaiEBQQ0hEAypAQsCQCAEIAJHDQBBoQEhEAzDAgsCQAJAIAQtAABBun9qDgsArAGsAawBrAGsAawBrAGsAawBAawBCyAEQQFqIQRBiwEhEAyqAgsgBEEBaiEEQYwBIRAMqQILAkAgBCACRw0AQaIBIRAMwgILIAQtAABB0ABHDakBIARBAWohBAzpAQsCQCAEIAJHDQBBowEhEAzBAgsCQAJAIAQtAABBt39qDgcBqgGqAaoBqgGqAQCqAQsgBEEBaiEEQY4BIRAMqAILIARBAWohAUEiIRAMpgELAkAgBCACRw0AQaQBIRAMwAILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQcDPgIAAai0AAEcNqAEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQaQBIRAMwAILIABBADYCACAQQQFqIQFBHSEQDKUBCwJAIAQgAkcNAEGlASEQDL8CCwJAAkAgBC0AAEGuf2oOAwCoAQGoAQsgBEEBaiEEQZABIRAMpgILIARBAWohAUEEIRAMpAELAkAgBCACRw0AQaYBIRAMvgILAkACQAJAAkACQCAELQAAQb9/ag4VAKoBqgGqAaoBqgGqAaoBqgGqAaoBAaoBqgECqgGqAQOqAaoBBKoBCyAEQQFqIQRBiAEhEAyoAgsgBEEBaiEEQYkBIRAMpwILIARBAWohBEGKASEQDKYCCyAEQQFqIQRBjwEhEAylAgsgBEEBaiEEQZEBIRAMpAILAkAgBCACRw0AQacBIRAMvQILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQe3PgIAAai0AAEcNpQEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQacBIRAMvQILIABBADYCACAQQQFqIQFBESEQDKIBCwJAIAQgAkcNAEGoASEQDLwCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHCz4CAAGotAABHDaQBIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGoASEQDLwCCyAAQQA2AgAgEEEBaiEBQSwhEAyhAQsCQCAEIAJHDQBBqQEhEAy7AgsgAiAEayAAKAIAIgFqIRQgBCABa0EEaiEQAkADQCAELQAAIAFBxc+AgABqLQAARw2jASABQQRGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBqQEhEAy7AgsgAEEANgIAIBBBAWohAUErIRAMoAELAkAgBCACRw0AQaoBIRAMugILIAIgBGsgACgCACIBaiEUIAQgAWtBAmohEAJAA0AgBC0AACABQcrPgIAAai0AAEcNogEgAUECRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQaoBIRAMugILIABBADYCACAQQQFqIQFBFCEQDJ8BCwJAIAQgAkcNAEGrASEQDLkCCwJAAkACQAJAIAQtAABBvn9qDg8AAQKkAaQBpAGkAaQBpAGkAaQBpAGkAaQBA6QBCyAEQQFqIQRBkwEhEAyiAgsgBEEBaiEEQZQBIRAMoQILIARBAWohBEGVASEQDKACCyAEQQFqIQRBlgEhEAyfAgsCQCAEIAJHDQBBrAEhEAy4AgsgBC0AAEHFAEcNnwEgBEEBaiEEDOABCwJAIAQgAkcNAEGtASEQDLcCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHNz4CAAGotAABHDZ8BIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEGtASEQDLcCCyAAQQA2AgAgEEEBaiEBQQ4hEAycAQsCQCAEIAJHDQBBrgEhEAy2AgsgBC0AAEHQAEcNnQEgBEEBaiEBQSUhEAybAQsCQCAEIAJHDQBBrwEhEAy1AgsgAiAEayAAKAIAIgFqIRQgBCABa0EIaiEQAkADQCAELQAAIAFB0M+AgABqLQAARw2dASABQQhGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBrwEhEAy1AgsgAEEANgIAIBBBAWohAUEqIRAMmgELAkAgBCACRw0AQbABIRAMtAILAkACQCAELQAAQat/ag4LAJ0BnQGdAZ0BnQGdAZ0BnQGdAQGdAQsgBEEBaiEEQZoBIRAMmwILIARBAWohBEGbASEQDJoCCwJAIAQgAkcNAEGxASEQDLMCCwJAAkAgBC0AAEG/f2oOFACcAZwBnAGcAZwBnAGcAZwBnAGcAZwBnAGcAZwBnAGcAZwBnAEBnAELIARBAWohBEGZASEQDJoCCyAEQQFqIQRBnAEhEAyZAgsCQCAEIAJHDQBBsgEhEAyyAgsgAiAEayAAKAIAIgFqIRQgBCABa0EDaiEQAkADQCAELQAAIAFB2c+AgABqLQAARw2aASABQQNGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBsgEhEAyyAgsgAEEANgIAIBBBAWohAUEhIRAMlwELAkAgBCACRw0AQbMBIRAMsQILIAIgBGsgACgCACIBaiEUIAQgAWtBBmohEAJAA0AgBC0AACABQd3PgIAAai0AAEcNmQEgAUEGRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQbMBIRAMsQILIABBADYCACAQQQFqIQFBGiEQDJYBCwJAIAQgAkcNAEG0ASEQDLACCwJAAkACQCAELQAAQbt/ag4RAJoBmgGaAZoBmgGaAZoBmgGaAQGaAZoBmgGaAZoBApoBCyAEQQFqIQRBnQEhEAyYAgsgBEEBaiEEQZ4BIRAMlwILIARBAWohBEGfASEQDJYCCwJAIAQgAkcNAEG1ASEQDK8CCyACIARrIAAoAgAiAWohFCAEIAFrQQVqIRACQANAIAQtAAAgAUHkz4CAAGotAABHDZcBIAFBBUYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEG1ASEQDK8CCyAAQQA2AgAgEEEBaiEBQSghEAyUAQsCQCAEIAJHDQBBtgEhEAyuAgsgAiAEayAAKAIAIgFqIRQgBCABa0ECaiEQAkADQCAELQAAIAFB6s+AgABqLQAARw2WASABQQJGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBtgEhEAyuAgsgAEEANgIAIBBBAWohAUEHIRAMkwELAkAgBCACRw0AQbcBIRAMrQILAkACQCAELQAAQbt/ag4OAJYBlgGWAZYBlgGWAZYBlgGWAZYBlgGWAQGWAQsgBEEBaiEEQaEBIRAMlAILIARBAWohBEGiASEQDJMCCwJAIAQgAkcNAEG4ASEQDKwCCyACIARrIAAoAgAiAWohFCAEIAFrQQJqIRACQANAIAQtAAAgAUHtz4CAAGotAABHDZQBIAFBAkYNASABQQFqIQEgBEEBaiIEIAJHDQALIAAgFDYCAEG4ASEQDKwCCyAAQQA2AgAgEEEBaiEBQRIhEAyRAQsCQCAEIAJHDQBBuQEhEAyrAgsgAiAEayAAKAIAIgFqIRQgBCABa0EBaiEQAkADQCAELQAAIAFB8M+AgABqLQAARw2TASABQQFGDQEgAUEBaiEBIARBAWoiBCACRw0ACyAAIBQ2AgBBuQEhEAyrAgsgAEEANgIAIBBBAWohAUEgIRAMkAELAkAgBCACRw0AQboBIRAMqgILIAIgBGsgACgCACIBaiEUIAQgAWtBAWohEAJAA0AgBC0AACABQfLPgIAAai0AAEcNkgEgAUEBRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQboBIRAMqgILIABBADYCACAQQQFqIQFBDyEQDI8BCwJAIAQgAkcNAEG7ASEQDKkCCwJAAkAgBC0AAEG3f2oOBwCSAZIBkgGSAZIBAZIBCyAEQQFqIQRBpQEhEAyQAgsgBEEBaiEEQaYBIRAMjwILAkAgBCACRw0AQbwBIRAMqAILIAIgBGsgACgCACIBaiEUIAQgAWtBB2ohEAJAA0AgBC0AACABQfTPgIAAai0AAEcNkAEgAUEHRg0BIAFBAWohASAEQQFqIgQgAkcNAAsgACAUNgIAQbwBIRAMqAILIABBADYCACAQQQFqIQFBGyEQDI0BCwJAIAQgAkcNAEG9ASEQDKcCCwJAAkACQCAELQAAQb5/ag4SAJEBkQGRAZEBkQGRAZEBkQGRAQGRAZEBkQGRAZEBkQECkQELIARBAWohBEGkASEQDI8CCyAEQQFqIQRBpwEhEAyOAgsgBEEBaiEEQagBIRAMjQILAkAgBCACRw0AQb4BIRAMpgILIAQtAABBzgBHDY0BIARBAWohBAzPAQsCQCAEIAJHDQBBvwEhEAylAgsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAELQAAQb9/ag4VAAECA5wBBAUGnAGcAZwBBwgJCgucAQwNDg+cAQsgBEEBaiEBQegAIRAMmgILIARBAWohAUHpACEQDJkCCyAEQQFqIQFB7gAhEAyYAgsgBEEBaiEBQfIAIRAMlwILIARBAWohAUHzACEQDJYCCyAEQQFqIQFB9gAhEAyVAgsgBEEBaiEBQfcAIRAMlAILIARBAWohAUH6ACEQDJMCCyAEQQFqIQRBgwEhEAySAgsgBEEBaiEEQYQBIRAMkQILIARBAWohBEGFASEQDJACCyAEQQFqIQRBkgEhEAyPAgsgBEEBaiEEQZgBIRAMjgILIARBAWohBEGgASEQDI0CCyAEQQFqIQRBowEhEAyMAgsgBEEBaiEEQaoBIRAMiwILAkAgBCACRg0AIABBkICAgAA2AgggACAENgIEQasBIRAMiwILQcABIRAMowILIAAgBSACEKqAgIAAIgENiwEgBSEBDFwLAkAgBiACRg0AIAZBAWohBQyNAQtBwgEhEAyhAgsDQAJAIBAtAABBdmoOBIwBAACPAQALIBBBAWoiECACRw0AC0HDASEQDKACCwJAIAcgAkYNACAAQZGAgIAANgIIIAAgBzYCBCAHIQFBASEQDIcCC0HEASEQDJ8CCwJAIAcgAkcNAEHFASEQDJ8CCwJAAkAgBy0AAEF2ag4EAc4BzgEAzgELIAdBAWohBgyNAQsgB0EBaiEFDIkBCwJAIAcgAkcNAEHGASEQDJ4CCwJAAkAgBy0AAEF2ag4XAY8BjwEBjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BAI8BCyAHQQFqIQcLQbABIRAMhAILAkAgCCACRw0AQcgBIRAMnQILIAgtAABBIEcNjQEgAEEAOwEyIAhBAWohAUGzASEQDIMCCyABIRcCQANAIBciByACRg0BIActAABBUGpB/wFxIhBBCk8NzAECQCAALwEyIhRBmTNLDQAgACAUQQpsIhQ7ATIgEEH//wNzIBRB/v8DcUkNACAHQQFqIRcgACAUIBBqIhA7ATIgEEH//wNxQegHSQ0BCwtBACEQIABBADYCHCAAQcGJgIAANgIQIABBDTYCDCAAIAdBAWo2AhQMnAILQccBIRAMmwILIAAgCCACEK6AgIAAIhBFDcoBIBBBFUcNjAEgAEHIATYCHCAAIAg2AhQgAEHJl4CAADYCECAAQRU2AgxBACEQDJoCCwJAIAkgAkcNAEHMASEQDJoCC0EAIRRBASEXQQEhFkEAIRACQAJAAkACQAJAAkACQAJAAkAgCS0AAEFQag4KlgGVAQABAgMEBQYIlwELQQIhEAwGC0EDIRAMBQtBBCEQDAQLQQUhEAwDC0EGIRAMAgtBByEQDAELQQghEAtBACEXQQAhFkEAIRQMjgELQQkhEEEBIRRBACEXQQAhFgyNAQsCQCAKIAJHDQBBzgEhEAyZAgsgCi0AAEEuRw2OASAKQQFqIQkMygELIAsgAkcNjgFB0AEhEAyXAgsCQCALIAJGDQAgAEGOgICAADYCCCAAIAs2AgRBtwEhEAz+AQtB0QEhEAyWAgsCQCAEIAJHDQBB0gEhEAyWAgsgAiAEayAAKAIAIhBqIRQgBCAQa0EEaiELA0AgBC0AACAQQfzPgIAAai0AAEcNjgEgEEEERg3pASAQQQFqIRAgBEEBaiIEIAJHDQALIAAgFDYCAEHSASEQDJUCCyAAIAwgAhCsgICAACIBDY0BIAwhAQy4AQsCQCAEIAJHDQBB1AEhEAyUAgsgAiAEayAAKAIAIhBqIRQgBCAQa0EBaiEMA0AgBC0AACAQQYHQgIAAai0AAEcNjwEgEEEBRg2OASAQQQFqIRAgBEEBaiIEIAJHDQALIAAgFDYCAEHUASEQDJMCCwJAIAQgAkcNAEHWASEQDJMCCyACIARrIAAoAgAiEGohFCAEIBBrQQJqIQsDQCAELQAAIBBBg9CAgABqLQAARw2OASAQQQJGDZABIBBBAWohECAEQQFqIgQgAkcNAAsgACAUNgIAQdYBIRAMkgILAkAgBCACRw0AQdcBIRAMkgILAkACQCAELQAAQbt/ag4QAI8BjwGPAY8BjwGPAY8BjwGPAY8BjwGPAY8BjwEBjwELIARBAWohBEG7ASEQDPkBCyAEQQFqIQRBvAEhEAz4AQsCQCAEIAJHDQBB2AEhEAyRAgsgBC0AAEHIAEcNjAEgBEEBaiEEDMQBCwJAIAQgAkYNACAAQZCAgIAANgIIIAAgBDYCBEG+ASEQDPcBC0HZASEQDI8CCwJAIAQgAkcNAEHaASEQDI8CCyAELQAAQcgARg3DASAAQQE6ACgMuQELIABBAjoALyAAIAQgAhCmgICAACIQDY0BQcIBIRAM9AELIAAtAChBf2oOArcBuQG4AQsDQAJAIAQtAABBdmoOBACOAY4BAI4BCyAEQQFqIgQgAkcNAAtB3QEhEAyLAgsgAEEAOgAvIAAtAC1BBHFFDYQCCyAAQQA6AC8gAEEBOgA0IAEhAQyMAQsgEEEVRg3aASAAQQA2AhwgACABNgIUIABBp46AgAA2AhAgAEESNgIMQQAhEAyIAgsCQCAAIBAgAhC0gICAACIEDQAgECEBDIECCwJAIARBFUcNACAAQQM2AhwgACAQNgIUIABBsJiAgAA2AhAgAEEVNgIMQQAhEAyIAgsgAEEANgIcIAAgEDYCFCAAQaeOgIAANgIQIABBEjYCDEEAIRAMhwILIBBBFUYN1gEgAEEANgIcIAAgATYCFCAAQdqNgIAANgIQIABBFDYCDEEAIRAMhgILIAAoAgQhFyAAQQA2AgQgECARp2oiFiEBIAAgFyAQIBYgFBsiEBC1gICAACIURQ2NASAAQQc2AhwgACAQNgIUIAAgFDYCDEEAIRAMhQILIAAgAC8BMEGAAXI7ATAgASEBC0EqIRAM6gELIBBBFUYN0QEgAEEANgIcIAAgATYCFCAAQYOMgIAANgIQIABBEzYCDEEAIRAMggILIBBBFUYNzwEgAEEANgIcIAAgATYCFCAAQZqPgIAANgIQIABBIjYCDEEAIRAMgQILIAAoAgQhECAAQQA2AgQCQCAAIBAgARC3gICAACIQDQAgAUEBaiEBDI0BCyAAQQw2AhwgACAQNgIMIAAgAUEBajYCFEEAIRAMgAILIBBBFUYNzAEgAEEANgIcIAAgATYCFCAAQZqPgIAANgIQIABBIjYCDEEAIRAM/wELIAAoAgQhECAAQQA2AgQCQCAAIBAgARC3gICAACIQDQAgAUEBaiEBDIwBCyAAQQ02AhwgACAQNgIMIAAgAUEBajYCFEEAIRAM/gELIBBBFUYNyQEgAEEANgIcIAAgATYCFCAAQcaMgIAANgIQIABBIzYCDEEAIRAM/QELIAAoAgQhECAAQQA2AgQCQCAAIBAgARC5gICAACIQDQAgAUEBaiEBDIsBCyAAQQ42AhwgACAQNgIMIAAgAUEBajYCFEEAIRAM/AELIABBADYCHCAAIAE2AhQgAEHAlYCAADYCECAAQQI2AgxBACEQDPsBCyAQQRVGDcUBIABBADYCHCAAIAE2AhQgAEHGjICAADYCECAAQSM2AgxBACEQDPoBCyAAQRA2AhwgACABNgIUIAAgEDYCDEEAIRAM+QELIAAoAgQhBCAAQQA2AgQCQCAAIAQgARC5gICAACIEDQAgAUEBaiEBDPEBCyAAQRE2AhwgACAENgIMIAAgAUEBajYCFEEAIRAM+AELIBBBFUYNwQEgAEEANgIcIAAgATYCFCAAQcaMgIAANgIQIABBIzYCDEEAIRAM9wELIAAoAgQhECAAQQA2AgQCQCAAIBAgARC5gICAACIQDQAgAUEBaiEBDIgBCyAAQRM2AhwgACAQNgIMIAAgAUEBajYCFEEAIRAM9gELIAAoAgQhBCAAQQA2AgQCQCAAIAQgARC5gICAACIEDQAgAUEBaiEBDO0BCyAAQRQ2AhwgACAENgIMIAAgAUEBajYCFEEAIRAM9QELIBBBFUYNvQEgAEEANgIcIAAgATYCFCAAQZqPgIAANgIQIABBIjYCDEEAIRAM9AELIAAoAgQhECAAQQA2AgQCQCAAIBAgARC3gICAACIQDQAgAUEBaiEBDIYBCyAAQRY2AhwgACAQNgIMIAAgAUEBajYCFEEAIRAM8wELIAAoAgQhBCAAQQA2AgQCQCAAIAQgARC3gICAACIEDQAgAUEBaiEBDOkBCyAAQRc2AhwgACAENgIMIAAgAUEBajYCFEEAIRAM8gELIABBADYCHCAAIAE2AhQgAEHNk4CAADYCECAAQQw2AgxBACEQDPEBC0IBIRELIBBBAWohAQJAIAApAyAiEkL//////////w9WDQAgACASQgSGIBGENwMgIAEhAQyEAQsgAEEANgIcIAAgATYCFCAAQa2JgIAANgIQIABBDDYCDEEAIRAM7wELIABBADYCHCAAIBA2AhQgAEHNk4CAADYCECAAQQw2AgxBACEQDO4BCyAAKAIEIRcgAEEANgIEIBAgEadqIhYhASAAIBcgECAWIBQbIhAQtYCAgAAiFEUNcyAAQQU2AhwgACAQNgIUIAAgFDYCDEEAIRAM7QELIABBADYCHCAAIBA2AhQgAEGqnICAADYCECAAQQ82AgxBACEQDOwBCyAAIBAgAhC0gICAACIBDQEgECEBC0EOIRAM0QELAkAgAUEVRw0AIABBAjYCHCAAIBA2AhQgAEGwmICAADYCECAAQRU2AgxBACEQDOoBCyAAQQA2AhwgACAQNgIUIABBp46AgAA2AhAgAEESNgIMQQAhEAzpAQsgAUEBaiEQAkAgAC8BMCIBQYABcUUNAAJAIAAgECACELuAgIAAIgENACAQIQEMcAsgAUEVRw26ASAAQQU2AhwgACAQNgIUIABB+ZeAgAA2AhAgAEEVNgIMQQAhEAzpAQsCQCABQaAEcUGgBEcNACAALQAtQQJxDQAgAEEANgIcIAAgEDYCFCAAQZaTgIAANgIQIABBBDYCDEEAIRAM6QELIAAgECACEL2AgIAAGiAQIQECQAJAAkACQAJAIAAgECACELOAgIAADhYCAQAEBAQEBAQEBAQEBAQEBAQEBAQDBAsgAEEBOgAuCyAAIAAvATBBwAByOwEwIBAhAQtBJiEQDNEBCyAAQSM2AhwgACAQNgIUIABBpZaAgAA2AhAgAEEVNgIMQQAhEAzpAQsgAEEANgIcIAAgEDYCFCAAQdWLgIAANgIQIABBETYCDEEAIRAM6AELIAAtAC1BAXFFDQFBwwEhEAzOAQsCQCANIAJGDQADQAJAIA0tAABBIEYNACANIQEMxAELIA1BAWoiDSACRw0AC0ElIRAM5wELQSUhEAzmAQsgACgCBCEEIABBADYCBCAAIAQgDRCvgICAACIERQ2tASAAQSY2AhwgACAENgIMIAAgDUEBajYCFEEAIRAM5QELIBBBFUYNqwEgAEEANgIcIAAgATYCFCAAQf2NgIAANgIQIABBHTYCDEEAIRAM5AELIABBJzYCHCAAIAE2AhQgACAQNgIMQQAhEAzjAQsgECEBQQEhFAJAAkACQAJAAkACQAJAIAAtACxBfmoOBwYFBQMBAgAFCyAAIAAvATBBCHI7ATAMAwtBAiEUDAELQQQhFAsgAEEBOgAsIAAgAC8BMCAUcjsBMAsgECEBC0ErIRAMygELIABBADYCHCAAIBA2AhQgAEGrkoCAADYCECAAQQs2AgxBACEQDOIBCyAAQQA2AhwgACABNgIUIABB4Y+AgAA2AhAgAEEKNgIMQQAhEAzhAQsgAEEAOgAsIBAhAQy9AQsgECEBQQEhFAJAAkACQAJAAkAgAC0ALEF7ag4EAwECAAULIAAgAC8BMEEIcjsBMAwDC0ECIRQMAQtBBCEUCyAAQQE6ACwgACAALwEwIBRyOwEwCyAQIQELQSkhEAzFAQsgAEEANgIcIAAgATYCFCAAQfCUgIAANgIQIABBAzYCDEEAIRAM3QELAkAgDi0AAEENRw0AIAAoAgQhASAAQQA2AgQCQCAAIAEgDhCxgICAACIBDQAgDkEBaiEBDHULIABBLDYCHCAAIAE2AgwgACAOQQFqNgIUQQAhEAzdAQsgAC0ALUEBcUUNAUHEASEQDMMBCwJAIA4gAkcNAEEtIRAM3AELAkACQANAAkAgDi0AAEF2ag4EAgAAAwALIA5BAWoiDiACRw0AC0EtIRAM3QELIAAoAgQhASAAQQA2AgQCQCAAIAEgDhCxgICAACIBDQAgDiEBDHQLIABBLDYCHCAAIA42AhQgACABNgIMQQAhEAzcAQsgACgCBCEBIABBADYCBAJAIAAgASAOELGAgIAAIgENACAOQQFqIQEMcwsgAEEsNgIcIAAgATYCDCAAIA5BAWo2AhRBACEQDNsBCyAAKAIEIQQgAEEANgIEIAAgBCAOELGAgIAAIgQNoAEgDiEBDM4BCyAQQSxHDQEgAUEBaiEQQQEhAQJAAkACQAJAAkAgAC0ALEF7ag4EAwECBAALIBAhAQwEC0ECIQEMAQtBBCEBCyAAQQE6ACwgACAALwEwIAFyOwEwIBAhAQwBCyAAIAAvATBBCHI7ATAgECEBC0E5IRAMvwELIABBADoALCABIQELQTQhEAy9AQsgACAALwEwQSByOwEwIAEhAQwCCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQsYCAgAAiBA0AIAEhAQzHAQsgAEE3NgIcIAAgATYCFCAAIAQ2AgxBACEQDNQBCyAAQQg6ACwgASEBC0EwIRAMuQELAkAgAC0AKEEBRg0AIAEhAQwECyAALQAtQQhxRQ2TASABIQEMAwsgAC0AMEEgcQ2UAUHFASEQDLcBCwJAIA8gAkYNAAJAA0ACQCAPLQAAQVBqIgFB/wFxQQpJDQAgDyEBQTUhEAy6AQsgACkDICIRQpmz5syZs+bMGVYNASAAIBFCCn4iETcDICARIAGtQv8BgyISQn+FVg0BIAAgESASfDcDICAPQQFqIg8gAkcNAAtBOSEQDNEBCyAAKAIEIQIgAEEANgIEIAAgAiAPQQFqIgQQsYCAgAAiAg2VASAEIQEMwwELQTkhEAzPAQsCQCAALwEwIgFBCHFFDQAgAC0AKEEBRw0AIAAtAC1BCHFFDZABCyAAIAFB9/sDcUGABHI7ATAgDyEBC0E3IRAMtAELIAAgAC8BMEEQcjsBMAyrAQsgEEEVRg2LASAAQQA2AhwgACABNgIUIABB8I6AgAA2AhAgAEEcNgIMQQAhEAzLAQsgAEHDADYCHCAAIAE2AgwgACANQQFqNgIUQQAhEAzKAQsCQCABLQAAQTpHDQAgACgCBCEQIABBADYCBAJAIAAgECABEK+AgIAAIhANACABQQFqIQEMYwsgAEHDADYCHCAAIBA2AgwgACABQQFqNgIUQQAhEAzKAQsgAEEANgIcIAAgATYCFCAAQbGRgIAANgIQIABBCjYCDEEAIRAMyQELIABBADYCHCAAIAE2AhQgAEGgmYCAADYCECAAQR42AgxBACEQDMgBCyAAQQA2AgALIABBgBI7ASogACAXQQFqIgEgAhCogICAACIQDQEgASEBC0HHACEQDKwBCyAQQRVHDYMBIABB0QA2AhwgACABNgIUIABB45eAgAA2AhAgAEEVNgIMQQAhEAzEAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMXgsgAEHSADYCHCAAIAE2AhQgACAQNgIMQQAhEAzDAQsgAEEANgIcIAAgFDYCFCAAQcGogIAANgIQIABBBzYCDCAAQQA2AgBBACEQDMIBCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxdCyAAQdMANgIcIAAgATYCFCAAIBA2AgxBACEQDMEBC0EAIRAgAEEANgIcIAAgATYCFCAAQYCRgIAANgIQIABBCTYCDAzAAQsgEEEVRg19IABBADYCHCAAIAE2AhQgAEGUjYCAADYCECAAQSE2AgxBACEQDL8BC0EBIRZBACEXQQAhFEEBIRALIAAgEDoAKyABQQFqIQECQAJAIAAtAC1BEHENAAJAAkACQCAALQAqDgMBAAIECyAWRQ0DDAILIBQNAQwCCyAXRQ0BCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQrYCAgAAiEA0AIAEhAQxcCyAAQdgANgIcIAAgATYCFCAAIBA2AgxBACEQDL4BCyAAKAIEIQQgAEEANgIEAkAgACAEIAEQrYCAgAAiBA0AIAEhAQytAQsgAEHZADYCHCAAIAE2AhQgACAENgIMQQAhEAy9AQsgACgCBCEEIABBADYCBAJAIAAgBCABEK2AgIAAIgQNACABIQEMqwELIABB2gA2AhwgACABNgIUIAAgBDYCDEEAIRAMvAELIAAoAgQhBCAAQQA2AgQCQCAAIAQgARCtgICAACIEDQAgASEBDKkBCyAAQdwANgIcIAAgATYCFCAAIAQ2AgxBACEQDLsBCwJAIAEtAABBUGoiEEH/AXFBCk8NACAAIBA6ACogAUEBaiEBQc8AIRAMogELIAAoAgQhBCAAQQA2AgQCQCAAIAQgARCtgICAACIEDQAgASEBDKcBCyAAQd4ANgIcIAAgATYCFCAAIAQ2AgxBACEQDLoBCyAAQQA2AgAgF0EBaiEBAkAgAC0AKUEjTw0AIAEhAQxZCyAAQQA2AhwgACABNgIUIABB04mAgAA2AhAgAEEINgIMQQAhEAy5AQsgAEEANgIAC0EAIRAgAEEANgIcIAAgATYCFCAAQZCzgIAANgIQIABBCDYCDAy3AQsgAEEANgIAIBdBAWohAQJAIAAtAClBIUcNACABIQEMVgsgAEEANgIcIAAgATYCFCAAQZuKgIAANgIQIABBCDYCDEEAIRAMtgELIABBADYCACAXQQFqIQECQCAALQApIhBBXWpBC08NACABIQEMVQsCQCAQQQZLDQBBASAQdEHKAHFFDQAgASEBDFULQQAhECAAQQA2AhwgACABNgIUIABB94mAgAA2AhAgAEEINgIMDLUBCyAQQRVGDXEgAEEANgIcIAAgATYCFCAAQbmNgIAANgIQIABBGjYCDEEAIRAMtAELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDFQLIABB5QA2AhwgACABNgIUIAAgEDYCDEEAIRAMswELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDE0LIABB0gA2AhwgACABNgIUIAAgEDYCDEEAIRAMsgELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDE0LIABB0wA2AhwgACABNgIUIAAgEDYCDEEAIRAMsQELIAAoAgQhECAAQQA2AgQCQCAAIBAgARCngICAACIQDQAgASEBDFELIABB5QA2AhwgACABNgIUIAAgEDYCDEEAIRAMsAELIABBADYCHCAAIAE2AhQgAEHGioCAADYCECAAQQc2AgxBACEQDK8BCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxJCyAAQdIANgIcIAAgATYCFCAAIBA2AgxBACEQDK4BCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxJCyAAQdMANgIcIAAgATYCFCAAIBA2AgxBACEQDK0BCyAAKAIEIRAgAEEANgIEAkAgACAQIAEQp4CAgAAiEA0AIAEhAQxNCyAAQeUANgIcIAAgATYCFCAAIBA2AgxBACEQDKwBCyAAQQA2AhwgACABNgIUIABB3IiAgAA2AhAgAEEHNgIMQQAhEAyrAQsgEEE/Rw0BIAFBAWohAQtBBSEQDJABC0EAIRAgAEEANgIcIAAgATYCFCAAQf2SgIAANgIQIABBBzYCDAyoAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMQgsgAEHSADYCHCAAIAE2AhQgACAQNgIMQQAhEAynAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMQgsgAEHTADYCHCAAIAE2AhQgACAQNgIMQQAhEAymAQsgACgCBCEQIABBADYCBAJAIAAgECABEKeAgIAAIhANACABIQEMRgsgAEHlADYCHCAAIAE2AhQgACAQNgIMQQAhEAylAQsgACgCBCEBIABBADYCBAJAIAAgASAUEKeAgIAAIgENACAUIQEMPwsgAEHSADYCHCAAIBQ2AhQgACABNgIMQQAhEAykAQsgACgCBCEBIABBADYCBAJAIAAgASAUEKeAgIAAIgENACAUIQEMPwsgAEHTADYCHCAAIBQ2AhQgACABNgIMQQAhEAyjAQsgACgCBCEBIABBADYCBAJAIAAgASAUEKeAgIAAIgENACAUIQEMQwsgAEHlADYCHCAAIBQ2AhQgACABNgIMQQAhEAyiAQsgAEEANgIcIAAgFDYCFCAAQcOPgIAANgIQIABBBzYCDEEAIRAMoQELIABBADYCHCAAIAE2AhQgAEHDj4CAADYCECAAQQc2AgxBACEQDKABC0EAIRAgAEEANgIcIAAgFDYCFCAAQYycgIAANgIQIABBBzYCDAyfAQsgAEEANgIcIAAgFDYCFCAAQYycgIAANgIQIABBBzYCDEEAIRAMngELIABBADYCHCAAIBQ2AhQgAEH+kYCAADYCECAAQQc2AgxBACEQDJ0BCyAAQQA2AhwgACABNgIUIABBjpuAgAA2AhAgAEEGNgIMQQAhEAycAQsgEEEVRg1XIABBADYCHCAAIAE2AhQgAEHMjoCAADYCECAAQSA2AgxBACEQDJsBCyAAQQA2AgAgEEEBaiEBQSQhEAsgACAQOgApIAAoAgQhECAAQQA2AgQgACAQIAEQq4CAgAAiEA1UIAEhAQw+CyAAQQA2AgALQQAhECAAQQA2AhwgACAENgIUIABB8ZuAgAA2AhAgAEEGNgIMDJcBCyABQRVGDVAgAEEANgIcIAAgBTYCFCAAQfCMgIAANgIQIABBGzYCDEEAIRAMlgELIAAoAgQhBSAAQQA2AgQgACAFIBAQqYCAgAAiBQ0BIBBBAWohBQtBrQEhEAx7CyAAQcEBNgIcIAAgBTYCDCAAIBBBAWo2AhRBACEQDJMBCyAAKAIEIQYgAEEANgIEIAAgBiAQEKmAgIAAIgYNASAQQQFqIQYLQa4BIRAMeAsgAEHCATYCHCAAIAY2AgwgACAQQQFqNgIUQQAhEAyQAQsgAEEANgIcIAAgBzYCFCAAQZeLgIAANgIQIABBDTYCDEEAIRAMjwELIABBADYCHCAAIAg2AhQgAEHjkICAADYCECAAQQk2AgxBACEQDI4BCyAAQQA2AhwgACAINgIUIABBlI2AgAA2AhAgAEEhNgIMQQAhEAyNAQtBASEWQQAhF0EAIRRBASEQCyAAIBA6ACsgCUEBaiEIAkACQCAALQAtQRBxDQACQAJAAkAgAC0AKg4DAQACBAsgFkUNAwwCCyAUDQEMAgsgF0UNAQsgACgCBCEQIABBADYCBCAAIBAgCBCtgICAACIQRQ09IABByQE2AhwgACAINgIUIAAgEDYCDEEAIRAMjAELIAAoAgQhBCAAQQA2AgQgACAEIAgQrYCAgAAiBEUNdiAAQcoBNgIcIAAgCDYCFCAAIAQ2AgxBACEQDIsBCyAAKAIEIQQgAEEANgIEIAAgBCAJEK2AgIAAIgRFDXQgAEHLATYCHCAAIAk2AhQgACAENgIMQQAhEAyKAQsgACgCBCEEIABBADYCBCAAIAQgChCtgICAACIERQ1yIABBzQE2AhwgACAKNgIUIAAgBDYCDEEAIRAMiQELAkAgCy0AAEFQaiIQQf8BcUEKTw0AIAAgEDoAKiALQQFqIQpBtgEhEAxwCyAAKAIEIQQgAEEANgIEIAAgBCALEK2AgIAAIgRFDXAgAEHPATYCHCAAIAs2AhQgACAENgIMQQAhEAyIAQsgAEEANgIcIAAgBDYCFCAAQZCzgIAANgIQIABBCDYCDCAAQQA2AgBBACEQDIcBCyABQRVGDT8gAEEANgIcIAAgDDYCFCAAQcyOgIAANgIQIABBIDYCDEEAIRAMhgELIABBgQQ7ASggACgCBCEQIABCADcDACAAIBAgDEEBaiIMEKuAgIAAIhBFDTggAEHTATYCHCAAIAw2AhQgACAQNgIMQQAhEAyFAQsgAEEANgIAC0EAIRAgAEEANgIcIAAgBDYCFCAAQdibgIAANgIQIABBCDYCDAyDAQsgACgCBCEQIABCADcDACAAIBAgC0EBaiILEKuAgIAAIhANAUHGASEQDGkLIABBAjoAKAxVCyAAQdUBNgIcIAAgCzYCFCAAIBA2AgxBACEQDIABCyAQQRVGDTcgAEEANgIcIAAgBDYCFCAAQaSMgIAANgIQIABBEDYCDEEAIRAMfwsgAC0ANEEBRw00IAAgBCACELyAgIAAIhBFDTQgEEEVRw01IABB3AE2AhwgACAENgIUIABB1ZaAgAA2AhAgAEEVNgIMQQAhEAx+C0EAIRAgAEEANgIcIABBr4uAgAA2AhAgAEECNgIMIAAgFEEBajYCFAx9C0EAIRAMYwtBAiEQDGILQQ0hEAxhC0EPIRAMYAtBJSEQDF8LQRMhEAxeC0EVIRAMXQtBFiEQDFwLQRchEAxbC0EYIRAMWgtBGSEQDFkLQRohEAxYC0EbIRAMVwtBHCEQDFYLQR0hEAxVC0EfIRAMVAtBISEQDFMLQSMhEAxSC0HGACEQDFELQS4hEAxQC0EvIRAMTwtBOyEQDE4LQT0hEAxNC0HIACEQDEwLQckAIRAMSwtBywAhEAxKC0HMACEQDEkLQc4AIRAMSAtB0QAhEAxHC0HVACEQDEYLQdgAIRAMRQtB2QAhEAxEC0HbACEQDEMLQeQAIRAMQgtB5QAhEAxBC0HxACEQDEALQfQAIRAMPwtBjQEhEAw+C0GXASEQDD0LQakBIRAMPAtBrAEhEAw7C0HAASEQDDoLQbkBIRAMOQtBrwEhEAw4C0GxASEQDDcLQbIBIRAMNgtBtAEhEAw1C0G1ASEQDDQLQboBIRAMMwtBvQEhEAwyC0G/ASEQDDELQcEBIRAMMAsgAEEANgIcIAAgBDYCFCAAQemLgIAANgIQIABBHzYCDEEAIRAMSAsgAEHbATYCHCAAIAQ2AhQgAEH6loCAADYCECAAQRU2AgxBACEQDEcLIABB+AA2AhwgACAMNgIUIABBypiAgAA2AhAgAEEVNgIMQQAhEAxGCyAAQdEANgIcIAAgBTYCFCAAQbCXgIAANgIQIABBFTYCDEEAIRAMRQsgAEH5ADYCHCAAIAE2AhQgACAQNgIMQQAhEAxECyAAQfgANgIcIAAgATYCFCAAQcqYgIAANgIQIABBFTYCDEEAIRAMQwsgAEHkADYCHCAAIAE2AhQgAEHjl4CAADYCECAAQRU2AgxBACEQDEILIABB1wA2AhwgACABNgIUIABByZeAgAA2AhAgAEEVNgIMQQAhEAxBCyAAQQA2AhwgACABNgIUIABBuY2AgAA2AhAgAEEaNgIMQQAhEAxACyAAQcIANgIcIAAgATYCFCAAQeOYgIAANgIQIABBFTYCDEEAIRAMPwsgAEEANgIEIAAgDyAPELGAgIAAIgRFDQEgAEE6NgIcIAAgBDYCDCAAIA9BAWo2AhRBACEQDD4LIAAoAgQhBCAAQQA2AgQCQCAAIAQgARCxgICAACIERQ0AIABBOzYCHCAAIAQ2AgwgACABQQFqNgIUQQAhEAw+CyABQQFqIQEMLQsgD0EBaiEBDC0LIABBADYCHCAAIA82AhQgAEHkkoCAADYCECAAQQQ2AgxBACEQDDsLIABBNjYCHCAAIAQ2AhQgACACNgIMQQAhEAw6CyAAQS42AhwgACAONgIUIAAgBDYCDEEAIRAMOQsgAEHQADYCHCAAIAE2AhQgAEGRmICAADYCECAAQRU2AgxBACEQDDgLIA1BAWohAQwsCyAAQRU2AhwgACABNgIUIABBgpmAgAA2AhAgAEEVNgIMQQAhEAw2CyAAQRs2AhwgACABNgIUIABBkZeAgAA2AhAgAEEVNgIMQQAhEAw1CyAAQQ82AhwgACABNgIUIABBkZeAgAA2AhAgAEEVNgIMQQAhEAw0CyAAQQs2AhwgACABNgIUIABBkZeAgAA2AhAgAEEVNgIMQQAhEAwzCyAAQRo2AhwgACABNgIUIABBgpmAgAA2AhAgAEEVNgIMQQAhEAwyCyAAQQs2AhwgACABNgIUIABBgpmAgAA2AhAgAEEVNgIMQQAhEAwxCyAAQQo2AhwgACABNgIUIABB5JaAgAA2AhAgAEEVNgIMQQAhEAwwCyAAQR42AhwgACABNgIUIABB+ZeAgAA2AhAgAEEVNgIMQQAhEAwvCyAAQQA2AhwgACAQNgIUIABB2o2AgAA2AhAgAEEUNgIMQQAhEAwuCyAAQQQ2AhwgACABNgIUIABBsJiAgAA2AhAgAEEVNgIMQQAhEAwtCyAAQQA2AgAgC0EBaiELC0G4ASEQDBILIABBADYCACAQQQFqIQFB9QAhEAwRCyABIQECQCAALQApQQVHDQBB4wAhEAwRC0HiACEQDBALQQAhECAAQQA2AhwgAEHkkYCAADYCECAAQQc2AgwgACAUQQFqNgIUDCgLIABBADYCACAXQQFqIQFBwAAhEAwOC0EBIQELIAAgAToALCAAQQA2AgAgF0EBaiEBC0EoIRAMCwsgASEBC0E4IRAMCQsCQCABIg8gAkYNAANAAkAgDy0AAEGAvoCAAGotAAAiAUEBRg0AIAFBAkcNAyAPQQFqIQEMBAsgD0EBaiIPIAJHDQALQT4hEAwiC0E+IRAMIQsgAEEAOgAsIA8hAQwBC0ELIRAMBgtBOiEQDAULIAFBAWohAUEtIRAMBAsgACABOgAsIABBADYCACAWQQFqIQFBDCEQDAMLIABBADYCACAXQQFqIQFBCiEQDAILIABBADYCAAsgAEEAOgAsIA0hAUEJIRAMAAsLQQAhECAAQQA2AhwgACALNgIUIABBzZCAgAA2AhAgAEEJNgIMDBcLQQAhECAAQQA2AhwgACAKNgIUIABB6YqAgAA2AhAgAEEJNgIMDBYLQQAhECAAQQA2AhwgACAJNgIUIABBt5CAgAA2AhAgAEEJNgIMDBULQQAhECAAQQA2AhwgACAINgIUIABBnJGAgAA2AhAgAEEJNgIMDBQLQQAhECAAQQA2AhwgACABNgIUIABBzZCAgAA2AhAgAEEJNgIMDBMLQQAhECAAQQA2AhwgACABNgIUIABB6YqAgAA2AhAgAEEJNgIMDBILQQAhECAAQQA2AhwgACABNgIUIABBt5CAgAA2AhAgAEEJNgIMDBELQQAhECAAQQA2AhwgACABNgIUIABBnJGAgAA2AhAgAEEJNgIMDBALQQAhECAAQQA2AhwgACABNgIUIABBl5WAgAA2AhAgAEEPNgIMDA8LQQAhECAAQQA2AhwgACABNgIUIABBl5WAgAA2AhAgAEEPNgIMDA4LQQAhECAAQQA2AhwgACABNgIUIABBwJKAgAA2AhAgAEELNgIMDA0LQQAhECAAQQA2AhwgACABNgIUIABBlYmAgAA2AhAgAEELNgIMDAwLQQAhECAAQQA2AhwgACABNgIUIABB4Y+AgAA2AhAgAEEKNgIMDAsLQQAhECAAQQA2AhwgACABNgIUIABB+4+AgAA2AhAgAEEKNgIMDAoLQQAhECAAQQA2AhwgACABNgIUIABB8ZmAgAA2AhAgAEECNgIMDAkLQQAhECAAQQA2AhwgACABNgIUIABBxJSAgAA2AhAgAEECNgIMDAgLQQAhECAAQQA2AhwgACABNgIUIABB8pWAgAA2AhAgAEECNgIMDAcLIABBAjYCHCAAIAE2AhQgAEGcmoCAADYCECAAQRY2AgxBACEQDAYLQQEhEAwFC0HUACEQIAEiBCACRg0EIANBCGogACAEIAJB2MKAgABBChDFgICAACADKAIMIQQgAygCCA4DAQQCAAsQyoCAgAAACyAAQQA2AhwgAEG1moCAADYCECAAQRc2AgwgACAEQQFqNgIUQQAhEAwCCyAAQQA2AhwgACAENgIUIABBypqAgAA2AhAgAEEJNgIMQQAhEAwBCwJAIAEiBCACRw0AQSIhEAwBCyAAQYmAgIAANgIIIAAgBDYCBEEhIRALIANBEGokgICAgAAgEAuvAQECfyABKAIAIQYCQAJAIAIgA0YNACAEIAZqIQQgBiADaiACayEHIAIgBkF/cyAFaiIGaiEFA0ACQCACLQAAIAQtAABGDQBBAiEEDAMLAkAgBg0AQQAhBCAFIQIMAwsgBkF/aiEGIARBAWohBCACQQFqIgIgA0cNAAsgByEGIAMhAgsgAEEBNgIAIAEgBjYCACAAIAI2AgQPCyABQQA2AgAgACAENgIAIAAgAjYCBAsKACAAEMeAgIAAC/I2AQt/I4CAgIAAQRBrIgEkgICAgAACQEEAKAKg0ICAAA0AQQAQy4CAgABBgNSEgABrIgJB2QBJDQBBACEDAkBBACgC4NOAgAAiBA0AQQBCfzcC7NOAgABBAEKAgISAgIDAADcC5NOAgABBACABQQhqQXBxQdiq1aoFcyIENgLg04CAAEEAQQA2AvTTgIAAQQBBADYCxNOAgAALQQAgAjYCzNOAgABBAEGA1ISAADYCyNOAgABBAEGA1ISAADYCmNCAgABBACAENgKs0ICAAEEAQX82AqjQgIAAA0AgA0HE0ICAAGogA0G40ICAAGoiBDYCACAEIANBsNCAgABqIgU2AgAgA0G80ICAAGogBTYCACADQczQgIAAaiADQcDQgIAAaiIFNgIAIAUgBDYCACADQdTQgIAAaiADQcjQgIAAaiIENgIAIAQgBTYCACADQdDQgIAAaiAENgIAIANBIGoiA0GAAkcNAAtBgNSEgABBeEGA1ISAAGtBD3FBAEGA1ISAAEEIakEPcRsiA2oiBEEEaiACQUhqIgUgA2siA0EBcjYCAEEAQQAoAvDTgIAANgKk0ICAAEEAIAM2ApTQgIAAQQAgBDYCoNCAgABBgNSEgAAgBWpBODYCBAsCQAJAAkACQAJAAkACQAJAAkACQAJAAkAgAEHsAUsNAAJAQQAoAojQgIAAIgZBECAAQRNqQXBxIABBC0kbIgJBA3YiBHYiA0EDcUUNAAJAAkAgA0EBcSAEckEBcyIFQQN0IgRBsNCAgABqIgMgBEG40ICAAGooAgAiBCgCCCICRw0AQQAgBkF+IAV3cTYCiNCAgAAMAQsgAyACNgIIIAIgAzYCDAsgBEEIaiEDIAQgBUEDdCIFQQNyNgIEIAQgBWoiBCAEKAIEQQFyNgIEDAwLIAJBACgCkNCAgAAiB00NAQJAIANFDQACQAJAIAMgBHRBAiAEdCIDQQAgA2tycSIDQQAgA2txQX9qIgMgA0EMdkEQcSIDdiIEQQV2QQhxIgUgA3IgBCAFdiIDQQJ2QQRxIgRyIAMgBHYiA0EBdkECcSIEciADIAR2IgNBAXZBAXEiBHIgAyAEdmoiBEEDdCIDQbDQgIAAaiIFIANBuNCAgABqKAIAIgMoAggiAEcNAEEAIAZBfiAEd3EiBjYCiNCAgAAMAQsgBSAANgIIIAAgBTYCDAsgAyACQQNyNgIEIAMgBEEDdCIEaiAEIAJrIgU2AgAgAyACaiIAIAVBAXI2AgQCQCAHRQ0AIAdBeHFBsNCAgABqIQJBACgCnNCAgAAhBAJAAkAgBkEBIAdBA3Z0IghxDQBBACAGIAhyNgKI0ICAACACIQgMAQsgAigCCCEICyAIIAQ2AgwgAiAENgIIIAQgAjYCDCAEIAg2AggLIANBCGohA0EAIAA2ApzQgIAAQQAgBTYCkNCAgAAMDAtBACgCjNCAgAAiCUUNASAJQQAgCWtxQX9qIgMgA0EMdkEQcSIDdiIEQQV2QQhxIgUgA3IgBCAFdiIDQQJ2QQRxIgRyIAMgBHYiA0EBdkECcSIEciADIAR2IgNBAXZBAXEiBHIgAyAEdmpBAnRBuNKAgABqKAIAIgAoAgRBeHEgAmshBCAAIQUCQANAAkAgBSgCECIDDQAgBUEUaigCACIDRQ0CCyADKAIEQXhxIAJrIgUgBCAFIARJIgUbIQQgAyAAIAUbIQAgAyEFDAALCyAAKAIYIQoCQCAAKAIMIgggAEYNACAAKAIIIgNBACgCmNCAgABJGiAIIAM2AgggAyAINgIMDAsLAkAgAEEUaiIFKAIAIgMNACAAKAIQIgNFDQMgAEEQaiEFCwNAIAUhCyADIghBFGoiBSgCACIDDQAgCEEQaiEFIAgoAhAiAw0ACyALQQA2AgAMCgtBfyECIABBv39LDQAgAEETaiIDQXBxIQJBACgCjNCAgAAiB0UNAEEAIQsCQCACQYACSQ0AQR8hCyACQf///wdLDQAgA0EIdiIDIANBgP4/akEQdkEIcSIDdCIEIARBgOAfakEQdkEEcSIEdCIFIAVBgIAPakEQdkECcSIFdEEPdiADIARyIAVyayIDQQF0IAIgA0EVanZBAXFyQRxqIQsLQQAgAmshBAJAAkACQAJAIAtBAnRBuNKAgABqKAIAIgUNAEEAIQNBACEIDAELQQAhAyACQQBBGSALQQF2ayALQR9GG3QhAEEAIQgDQAJAIAUoAgRBeHEgAmsiBiAETw0AIAYhBCAFIQggBg0AQQAhBCAFIQggBSEDDAMLIAMgBUEUaigCACIGIAYgBSAAQR12QQRxakEQaigCACIFRhsgAyAGGyEDIABBAXQhACAFDQALCwJAIAMgCHINAEEAIQhBAiALdCIDQQAgA2tyIAdxIgNFDQMgA0EAIANrcUF/aiIDIANBDHZBEHEiA3YiBUEFdkEIcSIAIANyIAUgAHYiA0ECdkEEcSIFciADIAV2IgNBAXZBAnEiBXIgAyAFdiIDQQF2QQFxIgVyIAMgBXZqQQJ0QbjSgIAAaigCACEDCyADRQ0BCwNAIAMoAgRBeHEgAmsiBiAESSEAAkAgAygCECIFDQAgA0EUaigCACEFCyAGIAQgABshBCADIAggABshCCAFIQMgBQ0ACwsgCEUNACAEQQAoApDQgIAAIAJrTw0AIAgoAhghCwJAIAgoAgwiACAIRg0AIAgoAggiA0EAKAKY0ICAAEkaIAAgAzYCCCADIAA2AgwMCQsCQCAIQRRqIgUoAgAiAw0AIAgoAhAiA0UNAyAIQRBqIQULA0AgBSEGIAMiAEEUaiIFKAIAIgMNACAAQRBqIQUgACgCECIDDQALIAZBADYCAAwICwJAQQAoApDQgIAAIgMgAkkNAEEAKAKc0ICAACEEAkACQCADIAJrIgVBEEkNACAEIAJqIgAgBUEBcjYCBEEAIAU2ApDQgIAAQQAgADYCnNCAgAAgBCADaiAFNgIAIAQgAkEDcjYCBAwBCyAEIANBA3I2AgQgBCADaiIDIAMoAgRBAXI2AgRBAEEANgKc0ICAAEEAQQA2ApDQgIAACyAEQQhqIQMMCgsCQEEAKAKU0ICAACIAIAJNDQBBACgCoNCAgAAiAyACaiIEIAAgAmsiBUEBcjYCBEEAIAU2ApTQgIAAQQAgBDYCoNCAgAAgAyACQQNyNgIEIANBCGohAwwKCwJAAkBBACgC4NOAgABFDQBBACgC6NOAgAAhBAwBC0EAQn83AuzTgIAAQQBCgICEgICAwAA3AuTTgIAAQQAgAUEMakFwcUHYqtWqBXM2AuDTgIAAQQBBADYC9NOAgABBAEEANgLE04CAAEGAgAQhBAtBACEDAkAgBCACQccAaiIHaiIGQQAgBGsiC3EiCCACSw0AQQBBMDYC+NOAgAAMCgsCQEEAKALA04CAACIDRQ0AAkBBACgCuNOAgAAiBCAIaiIFIARNDQAgBSADTQ0BC0EAIQNBAEEwNgL404CAAAwKC0EALQDE04CAAEEEcQ0EAkACQAJAQQAoAqDQgIAAIgRFDQBByNOAgAAhAwNAAkAgAygCACIFIARLDQAgBSADKAIEaiAESw0DCyADKAIIIgMNAAsLQQAQy4CAgAAiAEF/Rg0FIAghBgJAQQAoAuTTgIAAIgNBf2oiBCAAcUUNACAIIABrIAQgAGpBACADa3FqIQYLIAYgAk0NBSAGQf7///8HSw0FAkBBACgCwNOAgAAiA0UNAEEAKAK404CAACIEIAZqIgUgBE0NBiAFIANLDQYLIAYQy4CAgAAiAyAARw0BDAcLIAYgAGsgC3EiBkH+////B0sNBCAGEMuAgIAAIgAgAygCACADKAIEakYNAyAAIQMLAkAgA0F/Rg0AIAJByABqIAZNDQACQCAHIAZrQQAoAujTgIAAIgRqQQAgBGtxIgRB/v///wdNDQAgAyEADAcLAkAgBBDLgICAAEF/Rg0AIAQgBmohBiADIQAMBwtBACAGaxDLgICAABoMBAsgAyEAIANBf0cNBQwDC0EAIQgMBwtBACEADAULIABBf0cNAgtBAEEAKALE04CAAEEEcjYCxNOAgAALIAhB/v///wdLDQEgCBDLgICAACEAQQAQy4CAgAAhAyAAQX9GDQEgA0F/Rg0BIAAgA08NASADIABrIgYgAkE4ak0NAQtBAEEAKAK404CAACAGaiIDNgK404CAAAJAIANBACgCvNOAgABNDQBBACADNgK804CAAAsCQAJAAkACQEEAKAKg0ICAACIERQ0AQcjTgIAAIQMDQCAAIAMoAgAiBSADKAIEIghqRg0CIAMoAggiAw0ADAMLCwJAAkBBACgCmNCAgAAiA0UNACAAIANPDQELQQAgADYCmNCAgAALQQAhA0EAIAY2AszTgIAAQQAgADYCyNOAgABBAEF/NgKo0ICAAEEAQQAoAuDTgIAANgKs0ICAAEEAQQA2AtTTgIAAA0AgA0HE0ICAAGogA0G40ICAAGoiBDYCACAEIANBsNCAgABqIgU2AgAgA0G80ICAAGogBTYCACADQczQgIAAaiADQcDQgIAAaiIFNgIAIAUgBDYCACADQdTQgIAAaiADQcjQgIAAaiIENgIAIAQgBTYCACADQdDQgIAAaiAENgIAIANBIGoiA0GAAkcNAAsgAEF4IABrQQ9xQQAgAEEIakEPcRsiA2oiBCAGQUhqIgUgA2siA0EBcjYCBEEAQQAoAvDTgIAANgKk0ICAAEEAIAM2ApTQgIAAQQAgBDYCoNCAgAAgACAFakE4NgIEDAILIAMtAAxBCHENACAEIAVJDQAgBCAATw0AIARBeCAEa0EPcUEAIARBCGpBD3EbIgVqIgBBACgClNCAgAAgBmoiCyAFayIFQQFyNgIEIAMgCCAGajYCBEEAQQAoAvDTgIAANgKk0ICAAEEAIAU2ApTQgIAAQQAgADYCoNCAgAAgBCALakE4NgIEDAELAkAgAEEAKAKY0ICAACIITw0AQQAgADYCmNCAgAAgACEICyAAIAZqIQVByNOAgAAhAwJAAkACQAJAAkACQAJAA0AgAygCACAFRg0BIAMoAggiAw0ADAILCyADLQAMQQhxRQ0BC0HI04CAACEDA0ACQCADKAIAIgUgBEsNACAFIAMoAgRqIgUgBEsNAwsgAygCCCEDDAALCyADIAA2AgAgAyADKAIEIAZqNgIEIABBeCAAa0EPcUEAIABBCGpBD3EbaiILIAJBA3I2AgQgBUF4IAVrQQ9xQQAgBUEIakEPcRtqIgYgCyACaiICayEDAkAgBiAERw0AQQAgAjYCoNCAgABBAEEAKAKU0ICAACADaiIDNgKU0ICAACACIANBAXI2AgQMAwsCQCAGQQAoApzQgIAARw0AQQAgAjYCnNCAgABBAEEAKAKQ0ICAACADaiIDNgKQ0ICAACACIANBAXI2AgQgAiADaiADNgIADAMLAkAgBigCBCIEQQNxQQFHDQAgBEF4cSEHAkACQCAEQf8BSw0AIAYoAggiBSAEQQN2IghBA3RBsNCAgABqIgBGGgJAIAYoAgwiBCAFRw0AQQBBACgCiNCAgABBfiAId3E2AojQgIAADAILIAQgAEYaIAQgBTYCCCAFIAQ2AgwMAQsgBigCGCEJAkACQCAGKAIMIgAgBkYNACAGKAIIIgQgCEkaIAAgBDYCCCAEIAA2AgwMAQsCQCAGQRRqIgQoAgAiBQ0AIAZBEGoiBCgCACIFDQBBACEADAELA0AgBCEIIAUiAEEUaiIEKAIAIgUNACAAQRBqIQQgACgCECIFDQALIAhBADYCAAsgCUUNAAJAAkAgBiAGKAIcIgVBAnRBuNKAgABqIgQoAgBHDQAgBCAANgIAIAANAUEAQQAoAozQgIAAQX4gBXdxNgKM0ICAAAwCCyAJQRBBFCAJKAIQIAZGG2ogADYCACAARQ0BCyAAIAk2AhgCQCAGKAIQIgRFDQAgACAENgIQIAQgADYCGAsgBigCFCIERQ0AIABBFGogBDYCACAEIAA2AhgLIAcgA2ohAyAGIAdqIgYoAgQhBAsgBiAEQX5xNgIEIAIgA2ogAzYCACACIANBAXI2AgQCQCADQf8BSw0AIANBeHFBsNCAgABqIQQCQAJAQQAoAojQgIAAIgVBASADQQN2dCIDcQ0AQQAgBSADcjYCiNCAgAAgBCEDDAELIAQoAgghAwsgAyACNgIMIAQgAjYCCCACIAQ2AgwgAiADNgIIDAMLQR8hBAJAIANB////B0sNACADQQh2IgQgBEGA/j9qQRB2QQhxIgR0IgUgBUGA4B9qQRB2QQRxIgV0IgAgAEGAgA9qQRB2QQJxIgB0QQ92IAQgBXIgAHJrIgRBAXQgAyAEQRVqdkEBcXJBHGohBAsgAiAENgIcIAJCADcCECAEQQJ0QbjSgIAAaiEFAkBBACgCjNCAgAAiAEEBIAR0IghxDQAgBSACNgIAQQAgACAIcjYCjNCAgAAgAiAFNgIYIAIgAjYCCCACIAI2AgwMAwsgA0EAQRkgBEEBdmsgBEEfRht0IQQgBSgCACEAA0AgACIFKAIEQXhxIANGDQIgBEEddiEAIARBAXQhBCAFIABBBHFqQRBqIggoAgAiAA0ACyAIIAI2AgAgAiAFNgIYIAIgAjYCDCACIAI2AggMAgsgAEF4IABrQQ9xQQAgAEEIakEPcRsiA2oiCyAGQUhqIgggA2siA0EBcjYCBCAAIAhqQTg2AgQgBCAFQTcgBWtBD3FBACAFQUlqQQ9xG2pBQWoiCCAIIARBEGpJGyIIQSM2AgRBAEEAKALw04CAADYCpNCAgABBACADNgKU0ICAAEEAIAs2AqDQgIAAIAhBEGpBACkC0NOAgAA3AgAgCEEAKQLI04CAADcCCEEAIAhBCGo2AtDTgIAAQQAgBjYCzNOAgABBACAANgLI04CAAEEAQQA2AtTTgIAAIAhBJGohAwNAIANBBzYCACADQQRqIgMgBUkNAAsgCCAERg0DIAggCCgCBEF+cTYCBCAIIAggBGsiADYCACAEIABBAXI2AgQCQCAAQf8BSw0AIABBeHFBsNCAgABqIQMCQAJAQQAoAojQgIAAIgVBASAAQQN2dCIAcQ0AQQAgBSAAcjYCiNCAgAAgAyEFDAELIAMoAgghBQsgBSAENgIMIAMgBDYCCCAEIAM2AgwgBCAFNgIIDAQLQR8hAwJAIABB////B0sNACAAQQh2IgMgA0GA/j9qQRB2QQhxIgN0IgUgBUGA4B9qQRB2QQRxIgV0IgggCEGAgA9qQRB2QQJxIgh0QQ92IAMgBXIgCHJrIgNBAXQgACADQRVqdkEBcXJBHGohAwsgBCADNgIcIARCADcCECADQQJ0QbjSgIAAaiEFAkBBACgCjNCAgAAiCEEBIAN0IgZxDQAgBSAENgIAQQAgCCAGcjYCjNCAgAAgBCAFNgIYIAQgBDYCCCAEIAQ2AgwMBAsgAEEAQRkgA0EBdmsgA0EfRht0IQMgBSgCACEIA0AgCCIFKAIEQXhxIABGDQMgA0EddiEIIANBAXQhAyAFIAhBBHFqQRBqIgYoAgAiCA0ACyAGIAQ2AgAgBCAFNgIYIAQgBDYCDCAEIAQ2AggMAwsgBSgCCCIDIAI2AgwgBSACNgIIIAJBADYCGCACIAU2AgwgAiADNgIICyALQQhqIQMMBQsgBSgCCCIDIAQ2AgwgBSAENgIIIARBADYCGCAEIAU2AgwgBCADNgIIC0EAKAKU0ICAACIDIAJNDQBBACgCoNCAgAAiBCACaiIFIAMgAmsiA0EBcjYCBEEAIAM2ApTQgIAAQQAgBTYCoNCAgAAgBCACQQNyNgIEIARBCGohAwwDC0EAIQNBAEEwNgL404CAAAwCCwJAIAtFDQACQAJAIAggCCgCHCIFQQJ0QbjSgIAAaiIDKAIARw0AIAMgADYCACAADQFBACAHQX4gBXdxIgc2AozQgIAADAILIAtBEEEUIAsoAhAgCEYbaiAANgIAIABFDQELIAAgCzYCGAJAIAgoAhAiA0UNACAAIAM2AhAgAyAANgIYCyAIQRRqKAIAIgNFDQAgAEEUaiADNgIAIAMgADYCGAsCQAJAIARBD0sNACAIIAQgAmoiA0EDcjYCBCAIIANqIgMgAygCBEEBcjYCBAwBCyAIIAJqIgAgBEEBcjYCBCAIIAJBA3I2AgQgACAEaiAENgIAAkAgBEH/AUsNACAEQXhxQbDQgIAAaiEDAkACQEEAKAKI0ICAACIFQQEgBEEDdnQiBHENAEEAIAUgBHI2AojQgIAAIAMhBAwBCyADKAIIIQQLIAQgADYCDCADIAA2AgggACADNgIMIAAgBDYCCAwBC0EfIQMCQCAEQf///wdLDQAgBEEIdiIDIANBgP4/akEQdkEIcSIDdCIFIAVBgOAfakEQdkEEcSIFdCICIAJBgIAPakEQdkECcSICdEEPdiADIAVyIAJyayIDQQF0IAQgA0EVanZBAXFyQRxqIQMLIAAgAzYCHCAAQgA3AhAgA0ECdEG40oCAAGohBQJAIAdBASADdCICcQ0AIAUgADYCAEEAIAcgAnI2AozQgIAAIAAgBTYCGCAAIAA2AgggACAANgIMDAELIARBAEEZIANBAXZrIANBH0YbdCEDIAUoAgAhAgJAA0AgAiIFKAIEQXhxIARGDQEgA0EddiECIANBAXQhAyAFIAJBBHFqQRBqIgYoAgAiAg0ACyAGIAA2AgAgACAFNgIYIAAgADYCDCAAIAA2AggMAQsgBSgCCCIDIAA2AgwgBSAANgIIIABBADYCGCAAIAU2AgwgACADNgIICyAIQQhqIQMMAQsCQCAKRQ0AAkACQCAAIAAoAhwiBUECdEG40oCAAGoiAygCAEcNACADIAg2AgAgCA0BQQAgCUF+IAV3cTYCjNCAgAAMAgsgCkEQQRQgCigCECAARhtqIAg2AgAgCEUNAQsgCCAKNgIYAkAgACgCECIDRQ0AIAggAzYCECADIAg2AhgLIABBFGooAgAiA0UNACAIQRRqIAM2AgAgAyAINgIYCwJAAkAgBEEPSw0AIAAgBCACaiIDQQNyNgIEIAAgA2oiAyADKAIEQQFyNgIEDAELIAAgAmoiBSAEQQFyNgIEIAAgAkEDcjYCBCAFIARqIAQ2AgACQCAHRQ0AIAdBeHFBsNCAgABqIQJBACgCnNCAgAAhAwJAAkBBASAHQQN2dCIIIAZxDQBBACAIIAZyNgKI0ICAACACIQgMAQsgAigCCCEICyAIIAM2AgwgAiADNgIIIAMgAjYCDCADIAg2AggLQQAgBTYCnNCAgABBACAENgKQ0ICAAAsgAEEIaiEDCyABQRBqJICAgIAAIAMLCgAgABDJgICAAAviDQEHfwJAIABFDQAgAEF4aiIBIABBfGooAgAiAkF4cSIAaiEDAkAgAkEBcQ0AIAJBA3FFDQEgASABKAIAIgJrIgFBACgCmNCAgAAiBEkNASACIABqIQACQCABQQAoApzQgIAARg0AAkAgAkH/AUsNACABKAIIIgQgAkEDdiIFQQN0QbDQgIAAaiIGRhoCQCABKAIMIgIgBEcNAEEAQQAoAojQgIAAQX4gBXdxNgKI0ICAAAwDCyACIAZGGiACIAQ2AgggBCACNgIMDAILIAEoAhghBwJAAkAgASgCDCIGIAFGDQAgASgCCCICIARJGiAGIAI2AgggAiAGNgIMDAELAkAgAUEUaiICKAIAIgQNACABQRBqIgIoAgAiBA0AQQAhBgwBCwNAIAIhBSAEIgZBFGoiAigCACIEDQAgBkEQaiECIAYoAhAiBA0ACyAFQQA2AgALIAdFDQECQAJAIAEgASgCHCIEQQJ0QbjSgIAAaiICKAIARw0AIAIgBjYCACAGDQFBAEEAKAKM0ICAAEF+IAR3cTYCjNCAgAAMAwsgB0EQQRQgBygCECABRhtqIAY2AgAgBkUNAgsgBiAHNgIYAkAgASgCECICRQ0AIAYgAjYCECACIAY2AhgLIAEoAhQiAkUNASAGQRRqIAI2AgAgAiAGNgIYDAELIAMoAgQiAkEDcUEDRw0AIAMgAkF+cTYCBEEAIAA2ApDQgIAAIAEgAGogADYCACABIABBAXI2AgQPCyABIANPDQAgAygCBCICQQFxRQ0AAkACQCACQQJxDQACQCADQQAoAqDQgIAARw0AQQAgATYCoNCAgABBAEEAKAKU0ICAACAAaiIANgKU0ICAACABIABBAXI2AgQgAUEAKAKc0ICAAEcNA0EAQQA2ApDQgIAAQQBBADYCnNCAgAAPCwJAIANBACgCnNCAgABHDQBBACABNgKc0ICAAEEAQQAoApDQgIAAIABqIgA2ApDQgIAAIAEgAEEBcjYCBCABIABqIAA2AgAPCyACQXhxIABqIQACQAJAIAJB/wFLDQAgAygCCCIEIAJBA3YiBUEDdEGw0ICAAGoiBkYaAkAgAygCDCICIARHDQBBAEEAKAKI0ICAAEF+IAV3cTYCiNCAgAAMAgsgAiAGRhogAiAENgIIIAQgAjYCDAwBCyADKAIYIQcCQAJAIAMoAgwiBiADRg0AIAMoAggiAkEAKAKY0ICAAEkaIAYgAjYCCCACIAY2AgwMAQsCQCADQRRqIgIoAgAiBA0AIANBEGoiAigCACIEDQBBACEGDAELA0AgAiEFIAQiBkEUaiICKAIAIgQNACAGQRBqIQIgBigCECIEDQALIAVBADYCAAsgB0UNAAJAAkAgAyADKAIcIgRBAnRBuNKAgABqIgIoAgBHDQAgAiAGNgIAIAYNAUEAQQAoAozQgIAAQX4gBHdxNgKM0ICAAAwCCyAHQRBBFCAHKAIQIANGG2ogBjYCACAGRQ0BCyAGIAc2AhgCQCADKAIQIgJFDQAgBiACNgIQIAIgBjYCGAsgAygCFCICRQ0AIAZBFGogAjYCACACIAY2AhgLIAEgAGogADYCACABIABBAXI2AgQgAUEAKAKc0ICAAEcNAUEAIAA2ApDQgIAADwsgAyACQX5xNgIEIAEgAGogADYCACABIABBAXI2AgQLAkAgAEH/AUsNACAAQXhxQbDQgIAAaiECAkACQEEAKAKI0ICAACIEQQEgAEEDdnQiAHENAEEAIAQgAHI2AojQgIAAIAIhAAwBCyACKAIIIQALIAAgATYCDCACIAE2AgggASACNgIMIAEgADYCCA8LQR8hAgJAIABB////B0sNACAAQQh2IgIgAkGA/j9qQRB2QQhxIgJ0IgQgBEGA4B9qQRB2QQRxIgR0IgYgBkGAgA9qQRB2QQJxIgZ0QQ92IAIgBHIgBnJrIgJBAXQgACACQRVqdkEBcXJBHGohAgsgASACNgIcIAFCADcCECACQQJ0QbjSgIAAaiEEAkACQEEAKAKM0ICAACIGQQEgAnQiA3ENACAEIAE2AgBBACAGIANyNgKM0ICAACABIAQ2AhggASABNgIIIAEgATYCDAwBCyAAQQBBGSACQQF2ayACQR9GG3QhAiAEKAIAIQYCQANAIAYiBCgCBEF4cSAARg0BIAJBHXYhBiACQQF0IQIgBCAGQQRxakEQaiIDKAIAIgYNAAsgAyABNgIAIAEgBDYCGCABIAE2AgwgASABNgIIDAELIAQoAggiACABNgIMIAQgATYCCCABQQA2AhggASAENgIMIAEgADYCCAtBAEEAKAKo0ICAAEF/aiIBQX8gARs2AqjQgIAACwsEAAAAC04AAkAgAA0APwBBEHQPCwJAIABB//8DcQ0AIABBf0wNAAJAIABBEHZAACIAQX9HDQBBAEEwNgL404CAAEF/DwsgAEEQdA8LEMqAgIAAAAvyAgIDfwF+AkAgAkUNACAAIAE6AAAgAiAAaiIDQX9qIAE6AAAgAkEDSQ0AIAAgAToAAiAAIAE6AAEgA0F9aiABOgAAIANBfmogAToAACACQQdJDQAgACABOgADIANBfGogAToAACACQQlJDQAgAEEAIABrQQNxIgRqIgMgAUH/AXFBgYKECGwiATYCACADIAIgBGtBfHEiBGoiAkF8aiABNgIAIARBCUkNACADIAE2AgggAyABNgIEIAJBeGogATYCACACQXRqIAE2AgAgBEEZSQ0AIAMgATYCGCADIAE2AhQgAyABNgIQIAMgATYCDCACQXBqIAE2AgAgAkFsaiABNgIAIAJBaGogATYCACACQWRqIAE2AgAgBCADQQRxQRhyIgVrIgJBIEkNACABrUKBgICAEH4hBiADIAVqIQEDQCABIAY3AxggASAGNwMQIAEgBjcDCCABIAY3AwAgAUEgaiEBIAJBYGoiAkEfSw0ACwsgAAsLjkgBAEGACAuGSAEAAAACAAAAAwAAAAAAAAAAAAAABAAAAAUAAAAAAAAAAAAAAAYAAAAHAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASW52YWxpZCBjaGFyIGluIHVybCBxdWVyeQBTcGFuIGNhbGxiYWNrIGVycm9yIGluIG9uX2JvZHkAQ29udGVudC1MZW5ndGggb3ZlcmZsb3cAQ2h1bmsgc2l6ZSBvdmVyZmxvdwBSZXNwb25zZSBvdmVyZmxvdwBJbnZhbGlkIG1ldGhvZCBmb3IgSFRUUC94LnggcmVxdWVzdABJbnZhbGlkIG1ldGhvZCBmb3IgUlRTUC94LnggcmVxdWVzdABFeHBlY3RlZCBTT1VSQ0UgbWV0aG9kIGZvciBJQ0UveC54IHJlcXVlc3QASW52YWxpZCBjaGFyIGluIHVybCBmcmFnbWVudCBzdGFydABFeHBlY3RlZCBkb3QAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9zdGF0dXMASW52YWxpZCByZXNwb25zZSBzdGF0dXMASW52YWxpZCBjaGFyYWN0ZXIgaW4gY2h1bmsgZXh0ZW5zaW9ucwBVc2VyIGNhbGxiYWNrIGVycm9yAGBvbl9yZXNldGAgY2FsbGJhY2sgZXJyb3IAYG9uX2NodW5rX2hlYWRlcmAgY2FsbGJhY2sgZXJyb3IAYG9uX21lc3NhZ2VfYmVnaW5gIGNhbGxiYWNrIGVycm9yAGBvbl9jaHVua19leHRlbnNpb25fdmFsdWVgIGNhbGxiYWNrIGVycm9yAGBvbl9zdGF0dXNfY29tcGxldGVgIGNhbGxiYWNrIGVycm9yAGBvbl92ZXJzaW9uX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25fdXJsX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25fY2h1bmtfY29tcGxldGVgIGNhbGxiYWNrIGVycm9yAGBvbl9oZWFkZXJfdmFsdWVfY29tcGxldGVgIGNhbGxiYWNrIGVycm9yAGBvbl9tZXNzYWdlX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25fbWV0aG9kX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25faGVhZGVyX2ZpZWxkX2NvbXBsZXRlYCBjYWxsYmFjayBlcnJvcgBgb25fY2h1bmtfZXh0ZW5zaW9uX25hbWVgIGNhbGxiYWNrIGVycm9yAFVuZXhwZWN0ZWQgY2hhciBpbiB1cmwgc2VydmVyAEludmFsaWQgaGVhZGVyIHZhbHVlIGNoYXIASW52YWxpZCBoZWFkZXIgZmllbGQgY2hhcgBTcGFuIGNhbGxiYWNrIGVycm9yIGluIG9uX3ZlcnNpb24ASW52YWxpZCBtaW5vciB2ZXJzaW9uAEludmFsaWQgbWFqb3IgdmVyc2lvbgBFeHBlY3RlZCBzcGFjZSBhZnRlciB2ZXJzaW9uAEV4cGVjdGVkIENSTEYgYWZ0ZXIgdmVyc2lvbgBJbnZhbGlkIEhUVFAgdmVyc2lvbgBJbnZhbGlkIGhlYWRlciB0b2tlbgBTcGFuIGNhbGxiYWNrIGVycm9yIGluIG9uX3VybABJbnZhbGlkIGNoYXJhY3RlcnMgaW4gdXJsAFVuZXhwZWN0ZWQgc3RhcnQgY2hhciBpbiB1cmwARG91YmxlIEAgaW4gdXJsAEVtcHR5IENvbnRlbnQtTGVuZ3RoAEludmFsaWQgY2hhcmFjdGVyIGluIENvbnRlbnQtTGVuZ3RoAER1cGxpY2F0ZSBDb250ZW50LUxlbmd0aABJbnZhbGlkIGNoYXIgaW4gdXJsIHBhdGgAQ29udGVudC1MZW5ndGggY2FuJ3QgYmUgcHJlc2VudCB3aXRoIFRyYW5zZmVyLUVuY29kaW5nAEludmFsaWQgY2hhcmFjdGVyIGluIGNodW5rIHNpemUAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9oZWFkZXJfdmFsdWUAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9jaHVua19leHRlbnNpb25fdmFsdWUASW52YWxpZCBjaGFyYWN0ZXIgaW4gY2h1bmsgZXh0ZW5zaW9ucyB2YWx1ZQBNaXNzaW5nIGV4cGVjdGVkIExGIGFmdGVyIGhlYWRlciB2YWx1ZQBJbnZhbGlkIGBUcmFuc2Zlci1FbmNvZGluZ2AgaGVhZGVyIHZhbHVlAEludmFsaWQgY2hhcmFjdGVyIGluIGNodW5rIGV4dGVuc2lvbnMgcXVvdGUgdmFsdWUASW52YWxpZCBjaGFyYWN0ZXIgaW4gY2h1bmsgZXh0ZW5zaW9ucyBxdW90ZWQgdmFsdWUAUGF1c2VkIGJ5IG9uX2hlYWRlcnNfY29tcGxldGUASW52YWxpZCBFT0Ygc3RhdGUAb25fcmVzZXQgcGF1c2UAb25fY2h1bmtfaGVhZGVyIHBhdXNlAG9uX21lc3NhZ2VfYmVnaW4gcGF1c2UAb25fY2h1bmtfZXh0ZW5zaW9uX3ZhbHVlIHBhdXNlAG9uX3N0YXR1c19jb21wbGV0ZSBwYXVzZQBvbl92ZXJzaW9uX2NvbXBsZXRlIHBhdXNlAG9uX3VybF9jb21wbGV0ZSBwYXVzZQBvbl9jaHVua19jb21wbGV0ZSBwYXVzZQBvbl9oZWFkZXJfdmFsdWVfY29tcGxldGUgcGF1c2UAb25fbWVzc2FnZV9jb21wbGV0ZSBwYXVzZQBvbl9tZXRob2RfY29tcGxldGUgcGF1c2UAb25faGVhZGVyX2ZpZWxkX2NvbXBsZXRlIHBhdXNlAG9uX2NodW5rX2V4dGVuc2lvbl9uYW1lIHBhdXNlAFVuZXhwZWN0ZWQgc3BhY2UgYWZ0ZXIgc3RhcnQgbGluZQBTcGFuIGNhbGxiYWNrIGVycm9yIGluIG9uX2NodW5rX2V4dGVuc2lvbl9uYW1lAEludmFsaWQgY2hhcmFjdGVyIGluIGNodW5rIGV4dGVuc2lvbnMgbmFtZQBQYXVzZSBvbiBDT05ORUNUL1VwZ3JhZGUAUGF1c2Ugb24gUFJJL1VwZ3JhZGUARXhwZWN0ZWQgSFRUUC8yIENvbm5lY3Rpb24gUHJlZmFjZQBTcGFuIGNhbGxiYWNrIGVycm9yIGluIG9uX21ldGhvZABFeHBlY3RlZCBzcGFjZSBhZnRlciBtZXRob2QAU3BhbiBjYWxsYmFjayBlcnJvciBpbiBvbl9oZWFkZXJfZmllbGQAUGF1c2VkAEludmFsaWQgd29yZCBlbmNvdW50ZXJlZABJbnZhbGlkIG1ldGhvZCBlbmNvdW50ZXJlZABVbmV4cGVjdGVkIGNoYXIgaW4gdXJsIHNjaGVtYQBSZXF1ZXN0IGhhcyBpbnZhbGlkIGBUcmFuc2Zlci1FbmNvZGluZ2AAU1dJVENIX1BST1hZAFVTRV9QUk9YWQBNS0FDVElWSVRZAFVOUFJPQ0VTU0FCTEVfRU5USVRZAENPUFkATU9WRURfUEVSTUFORU5UTFkAVE9PX0VBUkxZAE5PVElGWQBGQUlMRURfREVQRU5ERU5DWQBCQURfR0FURVdBWQBQTEFZAFBVVABDSEVDS09VVABHQVRFV0FZX1RJTUVPVVQAUkVRVUVTVF9USU1FT1VUAE5FVFdPUktfQ09OTkVDVF9USU1FT1VUAENPTk5FQ1RJT05fVElNRU9VVABMT0dJTl9USU1FT1VUAE5FVFdPUktfUkVBRF9USU1FT1VUAFBPU1QATUlTRElSRUNURURfUkVRVUVTVABDTElFTlRfQ0xPU0VEX1JFUVVFU1QAQ0xJRU5UX0NMT1NFRF9MT0FEX0JBTEFOQ0VEX1JFUVVFU1QAQkFEX1JFUVVFU1QASFRUUF9SRVFVRVNUX1NFTlRfVE9fSFRUUFNfUE9SVABSRVBPUlQASU1fQV9URUFQT1QAUkVTRVRfQ09OVEVOVABOT19DT05URU5UAFBBUlRJQUxfQ09OVEVOVABIUEVfSU5WQUxJRF9DT05TVEFOVABIUEVfQ0JfUkVTRVQAR0VUAEhQRV9TVFJJQ1QAQ09ORkxJQ1QAVEVNUE9SQVJZX1JFRElSRUNUAFBFUk1BTkVOVF9SRURJUkVDVABDT05ORUNUAE1VTFRJX1NUQVRVUwBIUEVfSU5WQUxJRF9TVEFUVVMAVE9PX01BTllfUkVRVUVTVFMARUFSTFlfSElOVFMAVU5BVkFJTEFCTEVfRk9SX0xFR0FMX1JFQVNPTlMAT1BUSU9OUwBTV0lUQ0hJTkdfUFJPVE9DT0xTAFZBUklBTlRfQUxTT19ORUdPVElBVEVTAE1VTFRJUExFX0NIT0lDRVMASU5URVJOQUxfU0VSVkVSX0VSUk9SAFdFQl9TRVJWRVJfVU5LTk9XTl9FUlJPUgBSQUlMR1VOX0VSUk9SAElERU5USVRZX1BST1ZJREVSX0FVVEhFTlRJQ0FUSU9OX0VSUk9SAFNTTF9DRVJUSUZJQ0FURV9FUlJPUgBJTlZBTElEX1hfRk9SV0FSREVEX0ZPUgBTRVRfUEFSQU1FVEVSAEdFVF9QQVJBTUVURVIASFBFX1VTRVIAU0VFX09USEVSAEhQRV9DQl9DSFVOS19IRUFERVIATUtDQUxFTkRBUgBTRVRVUABXRUJfU0VSVkVSX0lTX0RPV04AVEVBUkRPV04ASFBFX0NMT1NFRF9DT05ORUNUSU9OAEhFVVJJU1RJQ19FWFBJUkFUSU9OAERJU0NPTk5FQ1RFRF9PUEVSQVRJT04ATk9OX0FVVEhPUklUQVRJVkVfSU5GT1JNQVRJT04ASFBFX0lOVkFMSURfVkVSU0lPTgBIUEVfQ0JfTUVTU0FHRV9CRUdJTgBTSVRFX0lTX0ZST1pFTgBIUEVfSU5WQUxJRF9IRUFERVJfVE9LRU4ASU5WQUxJRF9UT0tFTgBGT1JCSURERU4ARU5IQU5DRV9ZT1VSX0NBTE0ASFBFX0lOVkFMSURfVVJMAEJMT0NLRURfQllfUEFSRU5UQUxfQ09OVFJPTABNS0NPTABBQ0wASFBFX0lOVEVSTkFMAFJFUVVFU1RfSEVBREVSX0ZJRUxEU19UT09fTEFSR0VfVU5PRkZJQ0lBTABIUEVfT0sAVU5MSU5LAFVOTE9DSwBQUkkAUkVUUllfV0lUSABIUEVfSU5WQUxJRF9DT05URU5UX0xFTkdUSABIUEVfVU5FWFBFQ1RFRF9DT05URU5UX0xFTkdUSABGTFVTSABQUk9QUEFUQ0gATS1TRUFSQ0gAVVJJX1RPT19MT05HAFBST0NFU1NJTkcATUlTQ0VMTEFORU9VU19QRVJTSVNURU5UX1dBUk5JTkcATUlTQ0VMTEFORU9VU19XQVJOSU5HAEhQRV9JTlZBTElEX1RSQU5TRkVSX0VOQ09ESU5HAEV4cGVjdGVkIENSTEYASFBFX0lOVkFMSURfQ0hVTktfU0laRQBNT1ZFAENPTlRJTlVFAEhQRV9DQl9TVEFUVVNfQ09NUExFVEUASFBFX0NCX0hFQURFUlNfQ09NUExFVEUASFBFX0NCX1ZFUlNJT05fQ09NUExFVEUASFBFX0NCX1VSTF9DT01QTEVURQBIUEVfQ0JfQ0hVTktfQ09NUExFVEUASFBFX0NCX0hFQURFUl9WQUxVRV9DT01QTEVURQBIUEVfQ0JfQ0hVTktfRVhURU5TSU9OX1ZBTFVFX0NPTVBMRVRFAEhQRV9DQl9DSFVOS19FWFRFTlNJT05fTkFNRV9DT01QTEVURQBIUEVfQ0JfTUVTU0FHRV9DT01QTEVURQBIUEVfQ0JfTUVUSE9EX0NPTVBMRVRFAEhQRV9DQl9IRUFERVJfRklFTERfQ09NUExFVEUAREVMRVRFAEhQRV9JTlZBTElEX0VPRl9TVEFURQBJTlZBTElEX1NTTF9DRVJUSUZJQ0FURQBQQVVTRQBOT19SRVNQT05TRQBVTlNVUFBPUlRFRF9NRURJQV9UWVBFAEdPTkUATk9UX0FDQ0VQVEFCTEUAU0VSVklDRV9VTkFWQUlMQUJMRQBSQU5HRV9OT1RfU0FUSVNGSUFCTEUAT1JJR0lOX0lTX1VOUkVBQ0hBQkxFAFJFU1BPTlNFX0lTX1NUQUxFAFBVUkdFAE1FUkdFAFJFUVVFU1RfSEVBREVSX0ZJRUxEU19UT09fTEFSR0UAUkVRVUVTVF9IRUFERVJfVE9PX0xBUkdFAFBBWUxPQURfVE9PX0xBUkdFAElOU1VGRklDSUVOVF9TVE9SQUdFAEhQRV9QQVVTRURfVVBHUkFERQBIUEVfUEFVU0VEX0gyX1VQR1JBREUAU09VUkNFAEFOTk9VTkNFAFRSQUNFAEhQRV9VTkVYUEVDVEVEX1NQQUNFAERFU0NSSUJFAFVOU1VCU0NSSUJFAFJFQ09SRABIUEVfSU5WQUxJRF9NRVRIT0QATk9UX0ZPVU5EAFBST1BGSU5EAFVOQklORABSRUJJTkQAVU5BVVRIT1JJWkVEAE1FVEhPRF9OT1RfQUxMT1dFRABIVFRQX1ZFUlNJT05fTk9UX1NVUFBPUlRFRABBTFJFQURZX1JFUE9SVEVEAEFDQ0VQVEVEAE5PVF9JTVBMRU1FTlRFRABMT09QX0RFVEVDVEVEAEhQRV9DUl9FWFBFQ1RFRABIUEVfTEZfRVhQRUNURUQAQ1JFQVRFRABJTV9VU0VEAEhQRV9QQVVTRUQAVElNRU9VVF9PQ0NVUkVEAFBBWU1FTlRfUkVRVUlSRUQAUFJFQ09ORElUSU9OX1JFUVVJUkVEAFBST1hZX0FVVEhFTlRJQ0FUSU9OX1JFUVVJUkVEAE5FVFdPUktfQVVUSEVOVElDQVRJT05fUkVRVUlSRUQATEVOR1RIX1JFUVVJUkVEAFNTTF9DRVJUSUZJQ0FURV9SRVFVSVJFRABVUEdSQURFX1JFUVVJUkVEAFBBR0VfRVhQSVJFRABQUkVDT05ESVRJT05fRkFJTEVEAEVYUEVDVEFUSU9OX0ZBSUxFRABSRVZBTElEQVRJT05fRkFJTEVEAFNTTF9IQU5EU0hBS0VfRkFJTEVEAExPQ0tFRABUUkFOU0ZPUk1BVElPTl9BUFBMSUVEAE5PVF9NT0RJRklFRABOT1RfRVhURU5ERUQAQkFORFdJRFRIX0xJTUlUX0VYQ0VFREVEAFNJVEVfSVNfT1ZFUkxPQURFRABIRUFEAEV4cGVjdGVkIEhUVFAvAABeEwAAJhMAADAQAADwFwAAnRMAABUSAAA5FwAA8BIAAAoQAAB1EgAArRIAAIITAABPFAAAfxAAAKAVAAAjFAAAiRIAAIsUAABNFQAA1BEAAM8UAAAQGAAAyRYAANwWAADBEQAA4BcAALsUAAB0FAAAfBUAAOUUAAAIFwAAHxAAAGUVAACjFAAAKBUAAAIVAACZFQAALBAAAIsZAABPDwAA1A4AAGoQAADOEAAAAhcAAIkOAABuEwAAHBMAAGYUAABWFwAAwRMAAM0TAABsEwAAaBcAAGYXAABfFwAAIhMAAM4PAABpDgAA2A4AAGMWAADLEwAAqg4AACgXAAAmFwAAxRMAAF0WAADoEQAAZxMAAGUTAADyFgAAcxMAAB0XAAD5FgAA8xEAAM8OAADOFQAADBIAALMRAAClEQAAYRAAADIXAAC7EwAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAgEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAgMCAgICAgAAAgIAAgIAAgICAgICAgICAgAEAAAAAAACAgICAgICAgICAgICAgICAgICAgICAgICAgAAAAICAgICAgICAgICAgICAgICAgICAgICAgICAgICAAIAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAIAAgICAgIAAAICAAICAAICAgICAgICAgIAAwAEAAAAAgICAgICAgICAgICAgICAgICAgICAgICAgIAAAACAgICAgICAgICAgICAgICAgICAgICAgICAgICAgACAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABsb3NlZWVwLWFsaXZlAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQEBAQEBAQEBAgEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQFjaHVua2VkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQABAQEBAQAAAQEAAQEAAQEBAQEBAQEBAQAAAAAAAAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQAAAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGVjdGlvbmVudC1sZW5ndGhvbnJveHktY29ubmVjdGlvbgAAAAAAAAAAAAAAAAAAAHJhbnNmZXItZW5jb2RpbmdwZ3JhZGUNCg0KDQpTTQ0KDQpUVFAvQ0UvVFNQLwAAAAAAAAAAAAAAAAECAAEDAAAAAAAAAAAAAAAAAAAAAAAABAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAAAAAAAAAAABAgABAwAAAAAAAAAAAAAAAAAAAAAAAAQBAQUBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAAAAAAAAAAAAQAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAQEAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQAAAAAAAAAAAAABAAACAAAAAAAAAAAAAAAAAAAAAAAAAwQAAAQEBAQEBAQEBAQEBQQEBAQEBAQEBAQEBAAEAAYHBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEAAQABAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAQAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAAAAAMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAAAAAAAAAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAEAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAgAAAAACAAAAAAAAAAAAAAAAAAAAAAADAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwAAAAAAAAMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE5PVU5DRUVDS09VVE5FQ1RFVEVDUklCRUxVU0hFVEVBRFNFQVJDSFJHRUNUSVZJVFlMRU5EQVJWRU9USUZZUFRJT05TQ0hTRUFZU1RBVENIR0VPUkRJUkVDVE9SVFJDSFBBUkFNRVRFUlVSQ0VCU0NSSUJFQVJET1dOQUNFSU5ETktDS1VCU0NSSUJFSFRUUC9BRFRQLw==";
}));
//#endregion
//#region node_modules/undici/lib/client.js
var require_client = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$13 = __require("assert");
	var net = __require("net");
	var http = __require("http");
	var { pipeline: pipeline$1 } = __require("stream");
	var util = require_util$6();
	var timers = require_timers();
	var Request = require_request$1();
	var DispatcherBase = require_dispatcher_base();
	var { RequestContentLengthMismatchError, ResponseContentLengthMismatchError, InvalidArgumentError, RequestAbortedError, HeadersTimeoutError, HeadersOverflowError, SocketError, InformationalError, BodyTimeoutError, HTTPParserError, ResponseExceededMaxSizeError, ClientDestroyedError } = require_errors();
	var buildConnector = require_connect();
	var { kUrl, kReset, kServerName, kClient, kBusy, kParser, kConnect, kBlocking, kResuming, kRunning, kPending, kSize, kWriting, kQueue, kConnected, kConnecting, kNeedDrain, kNoRef, kKeepAliveDefaultTimeout, kHostHeader, kPendingIdx, kRunningIdx, kError, kPipelining, kSocket, kKeepAliveTimeoutValue, kMaxHeadersSize, kKeepAliveMaxTimeout, kKeepAliveTimeoutThreshold, kHeadersTimeout, kBodyTimeout, kStrictContentLength, kConnector, kMaxRedirections, kMaxRequests, kCounter, kClose, kDestroy, kDispatch, kInterceptors, kLocalAddress, kMaxResponseSize, kHTTPConnVersion, kHost, kHTTP2Session, kHTTP2SessionState, kHTTP2BuildRequest, kHTTP2CopyHeaders, kHTTP1BuildRequest } = require_symbols$4();
	/** @type {import('http2')} */
	var http2;
	try {
		http2 = __require("http2");
	} catch {
		http2 = { constants: {} };
	}
	var { constants: { HTTP2_HEADER_AUTHORITY, HTTP2_HEADER_METHOD, HTTP2_HEADER_PATH, HTTP2_HEADER_SCHEME, HTTP2_HEADER_CONTENT_LENGTH, HTTP2_HEADER_EXPECT, HTTP2_HEADER_STATUS } } = http2;
	var h2ExperimentalWarned = false;
	var FastBuffer = Buffer[Symbol.species];
	var kClosedResolve = Symbol("kClosedResolve");
	var channels = {};
	try {
		const diagnosticsChannel = __require("diagnostics_channel");
		channels.sendHeaders = diagnosticsChannel.channel("undici:client:sendHeaders");
		channels.beforeConnect = diagnosticsChannel.channel("undici:client:beforeConnect");
		channels.connectError = diagnosticsChannel.channel("undici:client:connectError");
		channels.connected = diagnosticsChannel.channel("undici:client:connected");
	} catch {
		channels.sendHeaders = { hasSubscribers: false };
		channels.beforeConnect = { hasSubscribers: false };
		channels.connectError = { hasSubscribers: false };
		channels.connected = { hasSubscribers: false };
	}
	/**
	* @type {import('../types/client').default}
	*/
	var Client = class extends DispatcherBase {
		/**
		*
		* @param {string|URL} url
		* @param {import('../types/client').Client.Options} options
		*/
		constructor(url, { interceptors, maxHeaderSize, headersTimeout, socketTimeout, requestTimeout, connectTimeout, bodyTimeout, idleTimeout, keepAlive, keepAliveTimeout, maxKeepAliveTimeout, keepAliveMaxTimeout, keepAliveTimeoutThreshold, socketPath, pipelining, tls, strictContentLength, maxCachedSessions, maxRedirections, connect, maxRequestsPerClient, localAddress, maxResponseSize, autoSelectFamily, autoSelectFamilyAttemptTimeout, allowH2, maxConcurrentStreams } = {}) {
			super();
			if (keepAlive !== void 0) throw new InvalidArgumentError("unsupported keepAlive, use pipelining=0 instead");
			if (socketTimeout !== void 0) throw new InvalidArgumentError("unsupported socketTimeout, use headersTimeout & bodyTimeout instead");
			if (requestTimeout !== void 0) throw new InvalidArgumentError("unsupported requestTimeout, use headersTimeout & bodyTimeout instead");
			if (idleTimeout !== void 0) throw new InvalidArgumentError("unsupported idleTimeout, use keepAliveTimeout instead");
			if (maxKeepAliveTimeout !== void 0) throw new InvalidArgumentError("unsupported maxKeepAliveTimeout, use keepAliveMaxTimeout instead");
			if (maxHeaderSize != null && !Number.isFinite(maxHeaderSize)) throw new InvalidArgumentError("invalid maxHeaderSize");
			if (socketPath != null && typeof socketPath !== "string") throw new InvalidArgumentError("invalid socketPath");
			if (connectTimeout != null && (!Number.isFinite(connectTimeout) || connectTimeout < 0)) throw new InvalidArgumentError("invalid connectTimeout");
			if (keepAliveTimeout != null && (!Number.isFinite(keepAliveTimeout) || keepAliveTimeout <= 0)) throw new InvalidArgumentError("invalid keepAliveTimeout");
			if (keepAliveMaxTimeout != null && (!Number.isFinite(keepAliveMaxTimeout) || keepAliveMaxTimeout <= 0)) throw new InvalidArgumentError("invalid keepAliveMaxTimeout");
			if (keepAliveTimeoutThreshold != null && !Number.isFinite(keepAliveTimeoutThreshold)) throw new InvalidArgumentError("invalid keepAliveTimeoutThreshold");
			if (headersTimeout != null && (!Number.isInteger(headersTimeout) || headersTimeout < 0)) throw new InvalidArgumentError("headersTimeout must be a positive integer or zero");
			if (bodyTimeout != null && (!Number.isInteger(bodyTimeout) || bodyTimeout < 0)) throw new InvalidArgumentError("bodyTimeout must be a positive integer or zero");
			if (connect != null && typeof connect !== "function" && typeof connect !== "object") throw new InvalidArgumentError("connect must be a function or an object");
			if (maxRedirections != null && (!Number.isInteger(maxRedirections) || maxRedirections < 0)) throw new InvalidArgumentError("maxRedirections must be a positive number");
			if (maxRequestsPerClient != null && (!Number.isInteger(maxRequestsPerClient) || maxRequestsPerClient < 0)) throw new InvalidArgumentError("maxRequestsPerClient must be a positive number");
			if (localAddress != null && (typeof localAddress !== "string" || net.isIP(localAddress) === 0)) throw new InvalidArgumentError("localAddress must be valid string IP address");
			if (maxResponseSize != null && (!Number.isInteger(maxResponseSize) || maxResponseSize < -1)) throw new InvalidArgumentError("maxResponseSize must be a positive number");
			if (autoSelectFamilyAttemptTimeout != null && (!Number.isInteger(autoSelectFamilyAttemptTimeout) || autoSelectFamilyAttemptTimeout < -1)) throw new InvalidArgumentError("autoSelectFamilyAttemptTimeout must be a positive number");
			if (allowH2 != null && typeof allowH2 !== "boolean") throw new InvalidArgumentError("allowH2 must be a valid boolean value");
			if (maxConcurrentStreams != null && (typeof maxConcurrentStreams !== "number" || maxConcurrentStreams < 1)) throw new InvalidArgumentError("maxConcurrentStreams must be a possitive integer, greater than 0");
			if (typeof connect !== "function") connect = buildConnector({
				...tls,
				maxCachedSessions,
				allowH2,
				socketPath,
				timeout: connectTimeout,
				...util.nodeHasAutoSelectFamily && autoSelectFamily ? {
					autoSelectFamily,
					autoSelectFamilyAttemptTimeout
				} : void 0,
				...connect
			});
			this[kInterceptors] = interceptors && interceptors.Client && Array.isArray(interceptors.Client) ? interceptors.Client : [createRedirectInterceptor({ maxRedirections })];
			this[kUrl] = util.parseOrigin(url);
			this[kConnector] = connect;
			this[kSocket] = null;
			this[kPipelining] = pipelining != null ? pipelining : 1;
			this[kMaxHeadersSize] = maxHeaderSize || http.maxHeaderSize;
			this[kKeepAliveDefaultTimeout] = keepAliveTimeout == null ? 4e3 : keepAliveTimeout;
			this[kKeepAliveMaxTimeout] = keepAliveMaxTimeout == null ? 6e5 : keepAliveMaxTimeout;
			this[kKeepAliveTimeoutThreshold] = keepAliveTimeoutThreshold == null ? 1e3 : keepAliveTimeoutThreshold;
			this[kKeepAliveTimeoutValue] = this[kKeepAliveDefaultTimeout];
			this[kServerName] = null;
			this[kLocalAddress] = localAddress != null ? localAddress : null;
			this[kResuming] = 0;
			this[kNeedDrain] = 0;
			this[kHostHeader] = `host: ${this[kUrl].hostname}${this[kUrl].port ? `:${this[kUrl].port}` : ""}\r\n`;
			this[kBodyTimeout] = bodyTimeout != null ? bodyTimeout : 3e5;
			this[kHeadersTimeout] = headersTimeout != null ? headersTimeout : 3e5;
			this[kStrictContentLength] = strictContentLength == null ? true : strictContentLength;
			this[kMaxRedirections] = maxRedirections;
			this[kMaxRequests] = maxRequestsPerClient;
			this[kClosedResolve] = null;
			this[kMaxResponseSize] = maxResponseSize > -1 ? maxResponseSize : -1;
			this[kHTTPConnVersion] = "h1";
			this[kHTTP2Session] = null;
			this[kHTTP2SessionState] = !allowH2 ? null : {
				openStreams: 0,
				maxConcurrentStreams: maxConcurrentStreams != null ? maxConcurrentStreams : 100
			};
			this[kHost] = `${this[kUrl].hostname}${this[kUrl].port ? `:${this[kUrl].port}` : ""}`;
			this[kQueue] = [];
			this[kRunningIdx] = 0;
			this[kPendingIdx] = 0;
		}
		get pipelining() {
			return this[kPipelining];
		}
		set pipelining(value) {
			this[kPipelining] = value;
			resume(this, true);
		}
		get [kPending]() {
			return this[kQueue].length - this[kPendingIdx];
		}
		get [kRunning]() {
			return this[kPendingIdx] - this[kRunningIdx];
		}
		get [kSize]() {
			return this[kQueue].length - this[kRunningIdx];
		}
		get [kConnected]() {
			return !!this[kSocket] && !this[kConnecting] && !this[kSocket].destroyed;
		}
		get [kBusy]() {
			const socket = this[kSocket];
			return socket && (socket[kReset] || socket[kWriting] || socket[kBlocking]) || this[kSize] >= (this[kPipelining] || 1) || this[kPending] > 0;
		}
		/* istanbul ignore: only used for test */
		[kConnect](cb) {
			connect(this);
			this.once("connect", cb);
		}
		[kDispatch](opts, handler) {
			const origin = opts.origin || this[kUrl].origin;
			const request = this[kHTTPConnVersion] === "h2" ? Request[kHTTP2BuildRequest](origin, opts, handler) : Request[kHTTP1BuildRequest](origin, opts, handler);
			this[kQueue].push(request);
			if (this[kResuming]) {} else if (util.bodyLength(request.body) == null && util.isIterable(request.body)) {
				this[kResuming] = 1;
				process.nextTick(resume, this);
			} else resume(this, true);
			if (this[kResuming] && this[kNeedDrain] !== 2 && this[kBusy]) this[kNeedDrain] = 2;
			return this[kNeedDrain] < 2;
		}
		async [kClose]() {
			return new Promise((resolve) => {
				if (!this[kSize]) resolve(null);
				else this[kClosedResolve] = resolve;
			});
		}
		async [kDestroy](err) {
			return new Promise((resolve) => {
				const requests = this[kQueue].splice(this[kPendingIdx]);
				for (let i = 0; i < requests.length; i++) {
					const request = requests[i];
					errorRequest(this, request, err);
				}
				const callback = () => {
					if (this[kClosedResolve]) {
						this[kClosedResolve]();
						this[kClosedResolve] = null;
					}
					resolve();
				};
				if (this[kHTTP2Session] != null) {
					util.destroy(this[kHTTP2Session], err);
					this[kHTTP2Session] = null;
					this[kHTTP2SessionState] = null;
				}
				if (!this[kSocket]) queueMicrotask(callback);
				else util.destroy(this[kSocket].on("close", callback), err);
				resume(this);
			});
		}
	};
	function onHttp2SessionError(err) {
		assert$13(err.code !== "ERR_TLS_CERT_ALTNAME_INVALID");
		this[kSocket][kError] = err;
		onError(this[kClient], err);
	}
	function onHttp2FrameError(type, code, id) {
		const err = new InformationalError(`HTTP/2: "frameError" received - type ${type}, code ${code}`);
		if (id === 0) {
			this[kSocket][kError] = err;
			onError(this[kClient], err);
		}
	}
	function onHttp2SessionEnd() {
		util.destroy(this, new SocketError("other side closed"));
		util.destroy(this[kSocket], new SocketError("other side closed"));
	}
	function onHTTP2GoAway(code) {
		const client = this[kClient];
		const err = new InformationalError(`HTTP/2: "GOAWAY" frame received with code ${code}`);
		client[kSocket] = null;
		client[kHTTP2Session] = null;
		if (client.destroyed) {
			assert$13(this[kPending] === 0);
			const requests = client[kQueue].splice(client[kRunningIdx]);
			for (let i = 0; i < requests.length; i++) {
				const request = requests[i];
				errorRequest(this, request, err);
			}
		} else if (client[kRunning] > 0) {
			const request = client[kQueue][client[kRunningIdx]];
			client[kQueue][client[kRunningIdx]++] = null;
			errorRequest(client, request, err);
		}
		client[kPendingIdx] = client[kRunningIdx];
		assert$13(client[kRunning] === 0);
		client.emit("disconnect", client[kUrl], [client], err);
		resume(client);
	}
	var constants = require_constants$2();
	var createRedirectInterceptor = require_redirectInterceptor();
	var EMPTY_BUF = Buffer.alloc(0);
	async function lazyllhttp() {
		const llhttpWasmData = process.env.JEST_WORKER_ID ? require_llhttp_wasm() : void 0;
		let mod;
		try {
			mod = await WebAssembly.compile(Buffer.from(require_llhttp_simd_wasm(), "base64"));
		} catch (e) {
			/* istanbul ignore next */
			mod = await WebAssembly.compile(Buffer.from(llhttpWasmData || require_llhttp_wasm(), "base64"));
		}
		return await WebAssembly.instantiate(mod, { env: {
			wasm_on_url: (p, at, len) => {
				/* istanbul ignore next */
				return 0;
			},
			wasm_on_status: (p, at, len) => {
				assert$13.strictEqual(currentParser.ptr, p);
				const start = at - currentBufferPtr + currentBufferRef.byteOffset;
				return currentParser.onStatus(new FastBuffer(currentBufferRef.buffer, start, len)) || 0;
			},
			wasm_on_message_begin: (p) => {
				assert$13.strictEqual(currentParser.ptr, p);
				return currentParser.onMessageBegin() || 0;
			},
			wasm_on_header_field: (p, at, len) => {
				assert$13.strictEqual(currentParser.ptr, p);
				const start = at - currentBufferPtr + currentBufferRef.byteOffset;
				return currentParser.onHeaderField(new FastBuffer(currentBufferRef.buffer, start, len)) || 0;
			},
			wasm_on_header_value: (p, at, len) => {
				assert$13.strictEqual(currentParser.ptr, p);
				const start = at - currentBufferPtr + currentBufferRef.byteOffset;
				return currentParser.onHeaderValue(new FastBuffer(currentBufferRef.buffer, start, len)) || 0;
			},
			wasm_on_headers_complete: (p, statusCode, upgrade, shouldKeepAlive) => {
				assert$13.strictEqual(currentParser.ptr, p);
				return currentParser.onHeadersComplete(statusCode, Boolean(upgrade), Boolean(shouldKeepAlive)) || 0;
			},
			wasm_on_body: (p, at, len) => {
				assert$13.strictEqual(currentParser.ptr, p);
				const start = at - currentBufferPtr + currentBufferRef.byteOffset;
				return currentParser.onBody(new FastBuffer(currentBufferRef.buffer, start, len)) || 0;
			},
			wasm_on_message_complete: (p) => {
				assert$13.strictEqual(currentParser.ptr, p);
				return currentParser.onMessageComplete() || 0;
			}
		} });
	}
	var llhttpInstance = null;
	var llhttpPromise = lazyllhttp();
	llhttpPromise.catch();
	var currentParser = null;
	var currentBufferRef = null;
	var currentBufferSize = 0;
	var currentBufferPtr = null;
	var TIMEOUT_HEADERS = 1;
	var TIMEOUT_BODY = 2;
	var TIMEOUT_IDLE = 3;
	var Parser = class {
		constructor(client, socket, { exports: exports$1 }) {
			assert$13(Number.isFinite(client[kMaxHeadersSize]) && client[kMaxHeadersSize] > 0);
			this.llhttp = exports$1;
			this.ptr = this.llhttp.llhttp_alloc(constants.TYPE.RESPONSE);
			this.client = client;
			this.socket = socket;
			this.timeout = null;
			this.timeoutValue = null;
			this.timeoutType = null;
			this.statusCode = null;
			this.statusText = "";
			this.upgrade = false;
			this.headers = [];
			this.headersSize = 0;
			this.headersMaxSize = client[kMaxHeadersSize];
			this.shouldKeepAlive = false;
			this.paused = false;
			this.resume = this.resume.bind(this);
			this.bytesRead = 0;
			this.keepAlive = "";
			this.contentLength = "";
			this.connection = "";
			this.maxResponseSize = client[kMaxResponseSize];
		}
		setTimeout(value, type) {
			this.timeoutType = type;
			if (value !== this.timeoutValue) {
				timers.clearTimeout(this.timeout);
				if (value) {
					this.timeout = timers.setTimeout(onParserTimeout, value, this);
					// istanbul ignore else: only for jest
					if (this.timeout.unref) this.timeout.unref();
				} else this.timeout = null;
				this.timeoutValue = value;
			} else if (this.timeout) {
				// istanbul ignore else: only for jest
				if (this.timeout.refresh) this.timeout.refresh();
			}
		}
		resume() {
			if (this.socket.destroyed || !this.paused) return;
			assert$13(this.ptr != null);
			assert$13(currentParser == null);
			this.llhttp.llhttp_resume(this.ptr);
			assert$13(this.timeoutType === TIMEOUT_BODY);
			if (this.timeout) {
				// istanbul ignore else: only for jest
				if (this.timeout.refresh) this.timeout.refresh();
			}
			this.paused = false;
			this.execute(this.socket.read() || EMPTY_BUF);
			this.readMore();
		}
		readMore() {
			while (!this.paused && this.ptr) {
				const chunk = this.socket.read();
				if (chunk === null) break;
				this.execute(chunk);
			}
		}
		execute(data) {
			assert$13(this.ptr != null);
			assert$13(currentParser == null);
			assert$13(!this.paused);
			const { socket, llhttp } = this;
			if (data.length > currentBufferSize) {
				if (currentBufferPtr) llhttp.free(currentBufferPtr);
				currentBufferSize = Math.ceil(data.length / 4096) * 4096;
				currentBufferPtr = llhttp.malloc(currentBufferSize);
			}
			new Uint8Array(llhttp.memory.buffer, currentBufferPtr, currentBufferSize).set(data);
			try {
				let ret;
				try {
					currentBufferRef = data;
					currentParser = this;
					ret = llhttp.llhttp_execute(this.ptr, currentBufferPtr, data.length);
				} catch (err) {
					/* istanbul ignore next: difficult to make a test case for */
					throw err;
				} finally {
					currentParser = null;
					currentBufferRef = null;
				}
				const offset = llhttp.llhttp_get_error_pos(this.ptr) - currentBufferPtr;
				if (ret === constants.ERROR.PAUSED_UPGRADE) this.onUpgrade(data.slice(offset));
				else if (ret === constants.ERROR.PAUSED) {
					this.paused = true;
					socket.unshift(data.slice(offset));
				} else if (ret !== constants.ERROR.OK) {
					const ptr = llhttp.llhttp_get_error_reason(this.ptr);
					let message = "";
					/* istanbul ignore else: difficult to make a test case for */
					if (ptr) {
						const len = new Uint8Array(llhttp.memory.buffer, ptr).indexOf(0);
						message = "Response does not match the HTTP/1.1 protocol (" + Buffer.from(llhttp.memory.buffer, ptr, len).toString() + ")";
					}
					throw new HTTPParserError(message, constants.ERROR[ret], data.slice(offset));
				}
			} catch (err) {
				util.destroy(socket, err);
			}
		}
		destroy() {
			assert$13(this.ptr != null);
			assert$13(currentParser == null);
			this.llhttp.llhttp_free(this.ptr);
			this.ptr = null;
			timers.clearTimeout(this.timeout);
			this.timeout = null;
			this.timeoutValue = null;
			this.timeoutType = null;
			this.paused = false;
		}
		onStatus(buf) {
			this.statusText = buf.toString();
		}
		onMessageBegin() {
			const { socket, client } = this;
			/* istanbul ignore next: difficult to make a test case for */
			if (socket.destroyed) return -1;
			if (!client[kQueue][client[kRunningIdx]]) return -1;
		}
		onHeaderField(buf) {
			const len = this.headers.length;
			if ((len & 1) === 0) this.headers.push(buf);
			else this.headers[len - 1] = Buffer.concat([this.headers[len - 1], buf]);
			this.trackHeader(buf.length);
		}
		onHeaderValue(buf) {
			let len = this.headers.length;
			if ((len & 1) === 1) {
				this.headers.push(buf);
				len += 1;
			} else this.headers[len - 1] = Buffer.concat([this.headers[len - 1], buf]);
			const key = this.headers[len - 2];
			if (key.length === 10 && key.toString().toLowerCase() === "keep-alive") this.keepAlive += buf.toString();
			else if (key.length === 10 && key.toString().toLowerCase() === "connection") this.connection += buf.toString();
			else if (key.length === 14 && key.toString().toLowerCase() === "content-length") this.contentLength += buf.toString();
			this.trackHeader(buf.length);
		}
		trackHeader(len) {
			this.headersSize += len;
			if (this.headersSize >= this.headersMaxSize) util.destroy(this.socket, new HeadersOverflowError());
		}
		onUpgrade(head) {
			const { upgrade, client, socket, headers, statusCode } = this;
			assert$13(upgrade);
			const request = client[kQueue][client[kRunningIdx]];
			assert$13(request);
			assert$13(!socket.destroyed);
			assert$13(socket === client[kSocket]);
			assert$13(!this.paused);
			assert$13(request.upgrade || request.method === "CONNECT");
			this.statusCode = null;
			this.statusText = "";
			this.shouldKeepAlive = null;
			assert$13(this.headers.length % 2 === 0);
			this.headers = [];
			this.headersSize = 0;
			socket.unshift(head);
			socket[kParser].destroy();
			socket[kParser] = null;
			socket[kClient] = null;
			socket[kError] = null;
			socket.removeListener("error", onSocketError).removeListener("readable", onSocketReadable).removeListener("end", onSocketEnd).removeListener("close", onSocketClose);
			client[kSocket] = null;
			client[kQueue][client[kRunningIdx]++] = null;
			client.emit("disconnect", client[kUrl], [client], new InformationalError("upgrade"));
			try {
				request.onUpgrade(statusCode, headers, socket);
			} catch (err) {
				util.destroy(socket, err);
			}
			resume(client);
		}
		onHeadersComplete(statusCode, upgrade, shouldKeepAlive) {
			const { client, socket, headers, statusText } = this;
			/* istanbul ignore next: difficult to make a test case for */
			if (socket.destroyed) return -1;
			const request = client[kQueue][client[kRunningIdx]];
			/* istanbul ignore next: difficult to make a test case for */
			if (!request) return -1;
			assert$13(!this.upgrade);
			assert$13(this.statusCode < 200);
			if (statusCode === 100) {
				util.destroy(socket, new SocketError("bad response", util.getSocketInfo(socket)));
				return -1;
			}
			if (upgrade && !request.upgrade) {
				util.destroy(socket, new SocketError("bad upgrade", util.getSocketInfo(socket)));
				return -1;
			}
			assert$13.strictEqual(this.timeoutType, TIMEOUT_HEADERS);
			this.statusCode = statusCode;
			this.shouldKeepAlive = shouldKeepAlive || request.method === "HEAD" && !socket[kReset] && this.connection.toLowerCase() === "keep-alive";
			if (this.statusCode >= 200) {
				const bodyTimeout = request.bodyTimeout != null ? request.bodyTimeout : client[kBodyTimeout];
				this.setTimeout(bodyTimeout, TIMEOUT_BODY);
			} else if (this.timeout) {
				// istanbul ignore else: only for jest
				if (this.timeout.refresh) this.timeout.refresh();
			}
			if (request.method === "CONNECT") {
				assert$13(client[kRunning] === 1);
				this.upgrade = true;
				return 2;
			}
			if (upgrade) {
				assert$13(client[kRunning] === 1);
				this.upgrade = true;
				return 2;
			}
			assert$13(this.headers.length % 2 === 0);
			this.headers = [];
			this.headersSize = 0;
			if (this.shouldKeepAlive && client[kPipelining]) {
				const keepAliveTimeout = this.keepAlive ? util.parseKeepAliveTimeout(this.keepAlive) : null;
				if (keepAliveTimeout != null) {
					const timeout = Math.min(keepAliveTimeout - client[kKeepAliveTimeoutThreshold], client[kKeepAliveMaxTimeout]);
					if (timeout <= 0) socket[kReset] = true;
					else client[kKeepAliveTimeoutValue] = timeout;
				} else client[kKeepAliveTimeoutValue] = client[kKeepAliveDefaultTimeout];
			} else socket[kReset] = true;
			const pause = request.onHeaders(statusCode, headers, this.resume, statusText) === false;
			if (request.aborted) return -1;
			if (request.method === "HEAD") return 1;
			if (statusCode < 200) return 1;
			if (socket[kBlocking]) {
				socket[kBlocking] = false;
				resume(client);
			}
			return pause ? constants.ERROR.PAUSED : 0;
		}
		onBody(buf) {
			const { client, socket, statusCode, maxResponseSize } = this;
			if (socket.destroyed) return -1;
			const request = client[kQueue][client[kRunningIdx]];
			assert$13(request);
			assert$13.strictEqual(this.timeoutType, TIMEOUT_BODY);
			if (this.timeout) {
				// istanbul ignore else: only for jest
				if (this.timeout.refresh) this.timeout.refresh();
			}
			assert$13(statusCode >= 200);
			if (maxResponseSize > -1 && this.bytesRead + buf.length > maxResponseSize) {
				util.destroy(socket, new ResponseExceededMaxSizeError());
				return -1;
			}
			this.bytesRead += buf.length;
			if (request.onData(buf) === false) return constants.ERROR.PAUSED;
		}
		onMessageComplete() {
			const { client, socket, statusCode, upgrade, headers, contentLength, bytesRead, shouldKeepAlive } = this;
			if (socket.destroyed && (!statusCode || shouldKeepAlive)) return -1;
			if (upgrade) return;
			const request = client[kQueue][client[kRunningIdx]];
			assert$13(request);
			assert$13(statusCode >= 100);
			this.statusCode = null;
			this.statusText = "";
			this.bytesRead = 0;
			this.contentLength = "";
			this.keepAlive = "";
			this.connection = "";
			assert$13(this.headers.length % 2 === 0);
			this.headers = [];
			this.headersSize = 0;
			if (statusCode < 200) return;
			/* istanbul ignore next: should be handled by llhttp? */
			if (request.method !== "HEAD" && contentLength && bytesRead !== parseInt(contentLength, 10)) {
				util.destroy(socket, new ResponseContentLengthMismatchError());
				return -1;
			}
			request.onComplete(headers);
			client[kQueue][client[kRunningIdx]++] = null;
			if (socket[kWriting]) {
				assert$13.strictEqual(client[kRunning], 0);
				util.destroy(socket, new InformationalError("reset"));
				return constants.ERROR.PAUSED;
			} else if (!shouldKeepAlive) {
				util.destroy(socket, new InformationalError("reset"));
				return constants.ERROR.PAUSED;
			} else if (socket[kReset] && client[kRunning] === 0) {
				util.destroy(socket, new InformationalError("reset"));
				return constants.ERROR.PAUSED;
			} else if (client[kPipelining] === 1) setImmediate(resume, client);
			else resume(client);
		}
	};
	function onParserTimeout(parser) {
		const { socket, timeoutType, client } = parser;
		/* istanbul ignore else */
		if (timeoutType === TIMEOUT_HEADERS) {
			if (!socket[kWriting] || socket.writableNeedDrain || client[kRunning] > 1) {
				assert$13(!parser.paused, "cannot be paused while waiting for headers");
				util.destroy(socket, new HeadersTimeoutError());
			}
		} else if (timeoutType === TIMEOUT_BODY) {
			if (!parser.paused) util.destroy(socket, new BodyTimeoutError());
		} else if (timeoutType === TIMEOUT_IDLE) {
			assert$13(client[kRunning] === 0 && client[kKeepAliveTimeoutValue]);
			util.destroy(socket, new InformationalError("socket idle timeout"));
		}
	}
	function onSocketReadable() {
		const { [kParser]: parser } = this;
		if (parser) parser.readMore();
	}
	function onSocketError(err) {
		const { [kClient]: client, [kParser]: parser } = this;
		assert$13(err.code !== "ERR_TLS_CERT_ALTNAME_INVALID");
		if (client[kHTTPConnVersion] !== "h2") {
			if (err.code === "ECONNRESET" && parser.statusCode && !parser.shouldKeepAlive) {
				parser.onMessageComplete();
				return;
			}
		}
		this[kError] = err;
		onError(this[kClient], err);
	}
	function onError(client, err) {
		if (client[kRunning] === 0 && err.code !== "UND_ERR_INFO" && err.code !== "UND_ERR_SOCKET") {
			assert$13(client[kPendingIdx] === client[kRunningIdx]);
			const requests = client[kQueue].splice(client[kRunningIdx]);
			for (let i = 0; i < requests.length; i++) {
				const request = requests[i];
				errorRequest(client, request, err);
			}
			assert$13(client[kSize] === 0);
		}
	}
	function onSocketEnd() {
		const { [kParser]: parser, [kClient]: client } = this;
		if (client[kHTTPConnVersion] !== "h2") {
			if (parser.statusCode && !parser.shouldKeepAlive) {
				parser.onMessageComplete();
				return;
			}
		}
		util.destroy(this, new SocketError("other side closed", util.getSocketInfo(this)));
	}
	function onSocketClose() {
		const { [kClient]: client, [kParser]: parser } = this;
		if (client[kHTTPConnVersion] === "h1" && parser) {
			if (!this[kError] && parser.statusCode && !parser.shouldKeepAlive) parser.onMessageComplete();
			this[kParser].destroy();
			this[kParser] = null;
		}
		const err = this[kError] || new SocketError("closed", util.getSocketInfo(this));
		client[kSocket] = null;
		if (client.destroyed) {
			assert$13(client[kPending] === 0);
			const requests = client[kQueue].splice(client[kRunningIdx]);
			for (let i = 0; i < requests.length; i++) {
				const request = requests[i];
				errorRequest(client, request, err);
			}
		} else if (client[kRunning] > 0 && err.code !== "UND_ERR_INFO") {
			const request = client[kQueue][client[kRunningIdx]];
			client[kQueue][client[kRunningIdx]++] = null;
			errorRequest(client, request, err);
		}
		client[kPendingIdx] = client[kRunningIdx];
		assert$13(client[kRunning] === 0);
		client.emit("disconnect", client[kUrl], [client], err);
		resume(client);
	}
	async function connect(client) {
		assert$13(!client[kConnecting]);
		assert$13(!client[kSocket]);
		let { host, hostname, protocol, port } = client[kUrl];
		if (hostname[0] === "[") {
			const idx = hostname.indexOf("]");
			assert$13(idx !== -1);
			const ip = hostname.substring(1, idx);
			assert$13(net.isIP(ip));
			hostname = ip;
		}
		client[kConnecting] = true;
		if (channels.beforeConnect.hasSubscribers) channels.beforeConnect.publish({
			connectParams: {
				host,
				hostname,
				protocol,
				port,
				servername: client[kServerName],
				localAddress: client[kLocalAddress]
			},
			connector: client[kConnector]
		});
		try {
			const socket = await new Promise((resolve, reject) => {
				client[kConnector]({
					host,
					hostname,
					protocol,
					port,
					servername: client[kServerName],
					localAddress: client[kLocalAddress]
				}, (err, socket) => {
					if (err) reject(err);
					else resolve(socket);
				});
			});
			if (client.destroyed) {
				util.destroy(socket.on("error", () => {}), new ClientDestroyedError());
				return;
			}
			client[kConnecting] = false;
			assert$13(socket);
			if (socket.alpnProtocol === "h2") {
				if (!h2ExperimentalWarned) {
					h2ExperimentalWarned = true;
					process.emitWarning("H2 support is experimental, expect them to change at any time.", { code: "UNDICI-H2" });
				}
				const session = http2.connect(client[kUrl], {
					createConnection: () => socket,
					peerMaxConcurrentStreams: client[kHTTP2SessionState].maxConcurrentStreams
				});
				client[kHTTPConnVersion] = "h2";
				session[kClient] = client;
				session[kSocket] = socket;
				session.on("error", onHttp2SessionError);
				session.on("frameError", onHttp2FrameError);
				session.on("end", onHttp2SessionEnd);
				session.on("goaway", onHTTP2GoAway);
				session.on("close", onSocketClose);
				session.unref();
				client[kHTTP2Session] = session;
				socket[kHTTP2Session] = session;
			} else {
				if (!llhttpInstance) {
					llhttpInstance = await llhttpPromise;
					llhttpPromise = null;
				}
				socket[kNoRef] = false;
				socket[kWriting] = false;
				socket[kReset] = false;
				socket[kBlocking] = false;
				socket[kParser] = new Parser(client, socket, llhttpInstance);
			}
			socket[kCounter] = 0;
			socket[kMaxRequests] = client[kMaxRequests];
			socket[kClient] = client;
			socket[kError] = null;
			socket.on("error", onSocketError).on("readable", onSocketReadable).on("end", onSocketEnd).on("close", onSocketClose);
			client[kSocket] = socket;
			if (channels.connected.hasSubscribers) channels.connected.publish({
				connectParams: {
					host,
					hostname,
					protocol,
					port,
					servername: client[kServerName],
					localAddress: client[kLocalAddress]
				},
				connector: client[kConnector],
				socket
			});
			client.emit("connect", client[kUrl], [client]);
		} catch (err) {
			if (client.destroyed) return;
			client[kConnecting] = false;
			if (channels.connectError.hasSubscribers) channels.connectError.publish({
				connectParams: {
					host,
					hostname,
					protocol,
					port,
					servername: client[kServerName],
					localAddress: client[kLocalAddress]
				},
				connector: client[kConnector],
				error: err
			});
			if (err.code === "ERR_TLS_CERT_ALTNAME_INVALID") {
				assert$13(client[kRunning] === 0);
				while (client[kPending] > 0 && client[kQueue][client[kPendingIdx]].servername === client[kServerName]) {
					const request = client[kQueue][client[kPendingIdx]++];
					errorRequest(client, request, err);
				}
			} else onError(client, err);
			client.emit("connectionError", client[kUrl], [client], err);
		}
		resume(client);
	}
	function emitDrain(client) {
		client[kNeedDrain] = 0;
		client.emit("drain", client[kUrl], [client]);
	}
	function resume(client, sync) {
		if (client[kResuming] === 2) return;
		client[kResuming] = 2;
		_resume(client, sync);
		client[kResuming] = 0;
		if (client[kRunningIdx] > 256) {
			client[kQueue].splice(0, client[kRunningIdx]);
			client[kPendingIdx] -= client[kRunningIdx];
			client[kRunningIdx] = 0;
		}
	}
	function _resume(client, sync) {
		while (true) {
			if (client.destroyed) {
				assert$13(client[kPending] === 0);
				return;
			}
			if (client[kClosedResolve] && !client[kSize]) {
				client[kClosedResolve]();
				client[kClosedResolve] = null;
				return;
			}
			const socket = client[kSocket];
			if (socket && !socket.destroyed && socket.alpnProtocol !== "h2") {
				if (client[kSize] === 0) {
					if (!socket[kNoRef] && socket.unref) {
						socket.unref();
						socket[kNoRef] = true;
					}
				} else if (socket[kNoRef] && socket.ref) {
					socket.ref();
					socket[kNoRef] = false;
				}
				if (client[kSize] === 0) {
					if (socket[kParser].timeoutType !== TIMEOUT_IDLE) socket[kParser].setTimeout(client[kKeepAliveTimeoutValue], TIMEOUT_IDLE);
				} else if (client[kRunning] > 0 && socket[kParser].statusCode < 200) {
					if (socket[kParser].timeoutType !== TIMEOUT_HEADERS) {
						const request = client[kQueue][client[kRunningIdx]];
						const headersTimeout = request.headersTimeout != null ? request.headersTimeout : client[kHeadersTimeout];
						socket[kParser].setTimeout(headersTimeout, TIMEOUT_HEADERS);
					}
				}
			}
			if (client[kBusy]) client[kNeedDrain] = 2;
			else if (client[kNeedDrain] === 2) {
				if (sync) {
					client[kNeedDrain] = 1;
					process.nextTick(emitDrain, client);
				} else emitDrain(client);
				continue;
			}
			if (client[kPending] === 0) return;
			if (client[kRunning] >= (client[kPipelining] || 1)) return;
			const request = client[kQueue][client[kPendingIdx]];
			if (client[kUrl].protocol === "https:" && client[kServerName] !== request.servername) {
				if (client[kRunning] > 0) return;
				client[kServerName] = request.servername;
				if (socket && socket.servername !== request.servername) {
					util.destroy(socket, new InformationalError("servername changed"));
					return;
				}
			}
			if (client[kConnecting]) return;
			if (!socket && !client[kHTTP2Session]) {
				connect(client);
				return;
			}
			if (socket.destroyed || socket[kWriting] || socket[kReset] || socket[kBlocking]) return;
			if (client[kRunning] > 0 && !request.idempotent) return;
			if (client[kRunning] > 0 && (request.upgrade || request.method === "CONNECT")) return;
			if (client[kRunning] > 0 && util.bodyLength(request.body) !== 0 && (util.isStream(request.body) || util.isAsyncIterable(request.body))) return;
			if (!request.aborted && write(client, request)) client[kPendingIdx]++;
			else client[kQueue].splice(client[kPendingIdx], 1);
		}
	}
	function shouldSendContentLength(method) {
		return method !== "GET" && method !== "HEAD" && method !== "OPTIONS" && method !== "TRACE" && method !== "CONNECT";
	}
	function write(client, request) {
		if (client[kHTTPConnVersion] === "h2") {
			writeH2(client, client[kHTTP2Session], request);
			return;
		}
		const { body, method, path, host, upgrade, headers, blocking, reset } = request;
		const expectsPayload = method === "PUT" || method === "POST" || method === "PATCH";
		if (body && typeof body.read === "function") body.read(0);
		const bodyLength = util.bodyLength(body);
		let contentLength = bodyLength;
		if (contentLength === null) contentLength = request.contentLength;
		if (contentLength === 0 && !expectsPayload) contentLength = null;
		if (shouldSendContentLength(method) && contentLength > 0 && request.contentLength !== null && request.contentLength !== contentLength) {
			if (client[kStrictContentLength]) {
				errorRequest(client, request, new RequestContentLengthMismatchError());
				return false;
			}
			process.emitWarning(new RequestContentLengthMismatchError());
		}
		const socket = client[kSocket];
		try {
			request.onConnect((err) => {
				if (request.aborted || request.completed) return;
				errorRequest(client, request, err || new RequestAbortedError());
				util.destroy(socket, new InformationalError("aborted"));
			});
		} catch (err) {
			errorRequest(client, request, err);
		}
		if (request.aborted) return false;
		if (method === "HEAD") socket[kReset] = true;
		if (upgrade || method === "CONNECT") socket[kReset] = true;
		if (reset != null) socket[kReset] = reset;
		if (client[kMaxRequests] && socket[kCounter]++ >= client[kMaxRequests]) socket[kReset] = true;
		if (blocking) socket[kBlocking] = true;
		let header = `${method} ${path} HTTP/1.1\r\n`;
		if (typeof host === "string") header += `host: ${host}\r\n`;
		else header += client[kHostHeader];
		if (upgrade) header += `connection: upgrade\r\nupgrade: ${upgrade}\r\n`;
		else if (client[kPipelining] && !socket[kReset]) header += "connection: keep-alive\r\n";
		else header += "connection: close\r\n";
		if (headers) header += headers;
		if (channels.sendHeaders.hasSubscribers) channels.sendHeaders.publish({
			request,
			headers: header,
			socket
		});
		/* istanbul ignore else: assertion */
		if (!body || bodyLength === 0) {
			if (contentLength === 0) socket.write(`${header}content-length: 0\r\n\r\n`, "latin1");
			else {
				assert$13(contentLength === null, "no body must not have content length");
				socket.write(`${header}\r\n`, "latin1");
			}
			request.onRequestSent();
		} else if (util.isBuffer(body)) {
			assert$13(contentLength === body.byteLength, "buffer body must have content length");
			socket.cork();
			socket.write(`${header}content-length: ${contentLength}\r\n\r\n`, "latin1");
			socket.write(body);
			socket.uncork();
			request.onBodySent(body);
			request.onRequestSent();
			if (!expectsPayload) socket[kReset] = true;
		} else if (util.isBlobLike(body)) {
			if (typeof body.stream === "function") writeIterable({
				body: body.stream(),
				client,
				request,
				socket,
				contentLength,
				header,
				expectsPayload
			});
			else writeBlob({
				body,
				client,
				request,
				socket,
				contentLength,
				header,
				expectsPayload
			});
		} else if (util.isStream(body)) writeStream({
			body,
			client,
			request,
			socket,
			contentLength,
			header,
			expectsPayload
		});
		else if (util.isIterable(body)) writeIterable({
			body,
			client,
			request,
			socket,
			contentLength,
			header,
			expectsPayload
		});
		else assert$13(false);
		return true;
	}
	function writeH2(client, session, request) {
		const { body, method, path, host, upgrade, expectContinue, signal, headers: reqHeaders } = request;
		let headers;
		if (typeof reqHeaders === "string") headers = Request[kHTTP2CopyHeaders](reqHeaders.trim());
		else headers = reqHeaders;
		if (upgrade) {
			errorRequest(client, request, /* @__PURE__ */ new Error("Upgrade not supported for H2"));
			return false;
		}
		try {
			request.onConnect((err) => {
				if (request.aborted || request.completed) return;
				errorRequest(client, request, err || new RequestAbortedError());
			});
		} catch (err) {
			errorRequest(client, request, err);
		}
		if (request.aborted) return false;
		/** @type {import('node:http2').ClientHttp2Stream} */
		let stream;
		const h2State = client[kHTTP2SessionState];
		headers[HTTP2_HEADER_AUTHORITY] = host || client[kHost];
		headers[HTTP2_HEADER_METHOD] = method;
		if (method === "CONNECT") {
			session.ref();
			stream = session.request(headers, {
				endStream: false,
				signal
			});
			if (stream.id && !stream.pending) {
				request.onUpgrade(null, null, stream);
				++h2State.openStreams;
			} else stream.once("ready", () => {
				request.onUpgrade(null, null, stream);
				++h2State.openStreams;
			});
			stream.once("close", () => {
				h2State.openStreams -= 1;
				if (h2State.openStreams === 0) session.unref();
			});
			return true;
		}
		headers[HTTP2_HEADER_PATH] = path;
		headers[HTTP2_HEADER_SCHEME] = "https";
		const expectsPayload = method === "PUT" || method === "POST" || method === "PATCH";
		if (body && typeof body.read === "function") body.read(0);
		let contentLength = util.bodyLength(body);
		if (contentLength == null) contentLength = request.contentLength;
		if (contentLength === 0 || !expectsPayload) contentLength = null;
		if (shouldSendContentLength(method) && contentLength > 0 && request.contentLength != null && request.contentLength !== contentLength) {
			if (client[kStrictContentLength]) {
				errorRequest(client, request, new RequestContentLengthMismatchError());
				return false;
			}
			process.emitWarning(new RequestContentLengthMismatchError());
		}
		if (contentLength != null) {
			assert$13(body, "no body must not have content length");
			headers[HTTP2_HEADER_CONTENT_LENGTH] = `${contentLength}`;
		}
		session.ref();
		const shouldEndStream = method === "GET" || method === "HEAD";
		if (expectContinue) {
			headers[HTTP2_HEADER_EXPECT] = "100-continue";
			stream = session.request(headers, {
				endStream: shouldEndStream,
				signal
			});
			stream.once("continue", writeBodyH2);
		} else {
			stream = session.request(headers, {
				endStream: shouldEndStream,
				signal
			});
			writeBodyH2();
		}
		++h2State.openStreams;
		stream.once("response", (headers) => {
			const { [HTTP2_HEADER_STATUS]: statusCode, ...realHeaders } = headers;
			if (request.onHeaders(Number(statusCode), realHeaders, stream.resume.bind(stream), "") === false) stream.pause();
		});
		stream.once("end", () => {
			request.onComplete([]);
		});
		stream.on("data", (chunk) => {
			if (request.onData(chunk) === false) stream.pause();
		});
		stream.once("close", () => {
			h2State.openStreams -= 1;
			if (h2State.openStreams === 0) session.unref();
		});
		stream.once("error", function(err) {
			if (client[kHTTP2Session] && !client[kHTTP2Session].destroyed && !this.closed && !this.destroyed) {
				h2State.streams -= 1;
				util.destroy(stream, err);
			}
		});
		stream.once("frameError", (type, code) => {
			const err = new InformationalError(`HTTP/2: "frameError" received - type ${type}, code ${code}`);
			errorRequest(client, request, err);
			if (client[kHTTP2Session] && !client[kHTTP2Session].destroyed && !this.closed && !this.destroyed) {
				h2State.streams -= 1;
				util.destroy(stream, err);
			}
		});
		return true;
		function writeBodyH2() {
			/* istanbul ignore else: assertion */
			if (!body) request.onRequestSent();
			else if (util.isBuffer(body)) {
				assert$13(contentLength === body.byteLength, "buffer body must have content length");
				stream.cork();
				stream.write(body);
				stream.uncork();
				stream.end();
				request.onBodySent(body);
				request.onRequestSent();
			} else if (util.isBlobLike(body)) {
				if (typeof body.stream === "function") writeIterable({
					client,
					request,
					contentLength,
					h2stream: stream,
					expectsPayload,
					body: body.stream(),
					socket: client[kSocket],
					header: ""
				});
				else writeBlob({
					body,
					client,
					request,
					contentLength,
					expectsPayload,
					h2stream: stream,
					header: "",
					socket: client[kSocket]
				});
			} else if (util.isStream(body)) writeStream({
				body,
				client,
				request,
				contentLength,
				expectsPayload,
				socket: client[kSocket],
				h2stream: stream,
				header: ""
			});
			else if (util.isIterable(body)) writeIterable({
				body,
				client,
				request,
				contentLength,
				expectsPayload,
				header: "",
				h2stream: stream,
				socket: client[kSocket]
			});
			else assert$13(false);
		}
	}
	function writeStream({ h2stream, body, client, request, socket, contentLength, header, expectsPayload }) {
		assert$13(contentLength !== 0 || client[kRunning] === 0, "stream body cannot be pipelined");
		if (client[kHTTPConnVersion] === "h2") {
			const pipe = pipeline$1(body, h2stream, (err) => {
				if (err) {
					util.destroy(body, err);
					util.destroy(h2stream, err);
				} else request.onRequestSent();
			});
			pipe.on("data", onPipeData);
			pipe.once("end", () => {
				pipe.removeListener("data", onPipeData);
				util.destroy(pipe);
			});
			function onPipeData(chunk) {
				request.onBodySent(chunk);
			}
			return;
		}
		let finished = false;
		const writer = new AsyncWriter({
			socket,
			request,
			contentLength,
			client,
			expectsPayload,
			header
		});
		const onData = function(chunk) {
			if (finished) return;
			try {
				if (!writer.write(chunk) && this.pause) this.pause();
			} catch (err) {
				util.destroy(this, err);
			}
		};
		const onDrain = function() {
			if (finished) return;
			if (body.resume) body.resume();
		};
		const onAbort = function() {
			if (finished) return;
			const err = new RequestAbortedError();
			queueMicrotask(() => onFinished(err));
		};
		const onFinished = function(err) {
			if (finished) return;
			finished = true;
			assert$13(socket.destroyed || socket[kWriting] && client[kRunning] <= 1);
			socket.off("drain", onDrain).off("error", onFinished);
			body.removeListener("data", onData).removeListener("end", onFinished).removeListener("error", onFinished).removeListener("close", onAbort);
			if (!err) try {
				writer.end();
			} catch (er) {
				err = er;
			}
			writer.destroy(err);
			if (err && (err.code !== "UND_ERR_INFO" || err.message !== "reset")) util.destroy(body, err);
			else util.destroy(body);
		};
		body.on("data", onData).on("end", onFinished).on("error", onFinished).on("close", onAbort);
		if (body.resume) body.resume();
		socket.on("drain", onDrain).on("error", onFinished);
	}
	async function writeBlob({ h2stream, body, client, request, socket, contentLength, header, expectsPayload }) {
		assert$13(contentLength === body.size, "blob body must have content length");
		const isH2 = client[kHTTPConnVersion] === "h2";
		try {
			if (contentLength != null && contentLength !== body.size) throw new RequestContentLengthMismatchError();
			const buffer = Buffer.from(await body.arrayBuffer());
			if (isH2) {
				h2stream.cork();
				h2stream.write(buffer);
				h2stream.uncork();
			} else {
				socket.cork();
				socket.write(`${header}content-length: ${contentLength}\r\n\r\n`, "latin1");
				socket.write(buffer);
				socket.uncork();
			}
			request.onBodySent(buffer);
			request.onRequestSent();
			if (!expectsPayload) socket[kReset] = true;
			resume(client);
		} catch (err) {
			util.destroy(isH2 ? h2stream : socket, err);
		}
	}
	async function writeIterable({ h2stream, body, client, request, socket, contentLength, header, expectsPayload }) {
		assert$13(contentLength !== 0 || client[kRunning] === 0, "iterator body cannot be pipelined");
		let callback = null;
		function onDrain() {
			if (callback) {
				const cb = callback;
				callback = null;
				cb();
			}
		}
		const waitForDrain = () => new Promise((resolve, reject) => {
			assert$13(callback === null);
			if (socket[kError]) reject(socket[kError]);
			else callback = resolve;
		});
		if (client[kHTTPConnVersion] === "h2") {
			h2stream.on("close", onDrain).on("drain", onDrain);
			try {
				for await (const chunk of body) {
					if (socket[kError]) throw socket[kError];
					const res = h2stream.write(chunk);
					request.onBodySent(chunk);
					if (!res) await waitForDrain();
				}
			} catch (err) {
				h2stream.destroy(err);
			} finally {
				request.onRequestSent();
				h2stream.end();
				h2stream.off("close", onDrain).off("drain", onDrain);
			}
			return;
		}
		socket.on("close", onDrain).on("drain", onDrain);
		const writer = new AsyncWriter({
			socket,
			request,
			contentLength,
			client,
			expectsPayload,
			header
		});
		try {
			for await (const chunk of body) {
				if (socket[kError]) throw socket[kError];
				if (!writer.write(chunk)) await waitForDrain();
			}
			writer.end();
		} catch (err) {
			writer.destroy(err);
		} finally {
			socket.off("close", onDrain).off("drain", onDrain);
		}
	}
	var AsyncWriter = class {
		constructor({ socket, request, contentLength, client, expectsPayload, header }) {
			this.socket = socket;
			this.request = request;
			this.contentLength = contentLength;
			this.client = client;
			this.bytesWritten = 0;
			this.expectsPayload = expectsPayload;
			this.header = header;
			socket[kWriting] = true;
		}
		write(chunk) {
			const { socket, request, contentLength, client, bytesWritten, expectsPayload, header } = this;
			if (socket[kError]) throw socket[kError];
			if (socket.destroyed) return false;
			const len = Buffer.byteLength(chunk);
			if (!len) return true;
			if (contentLength !== null && bytesWritten + len > contentLength) {
				if (client[kStrictContentLength]) throw new RequestContentLengthMismatchError();
				process.emitWarning(new RequestContentLengthMismatchError());
			}
			socket.cork();
			if (bytesWritten === 0) {
				if (!expectsPayload) socket[kReset] = true;
				if (contentLength === null) socket.write(`${header}transfer-encoding: chunked\r\n`, "latin1");
				else socket.write(`${header}content-length: ${contentLength}\r\n\r\n`, "latin1");
			}
			if (contentLength === null) socket.write(`\r\n${len.toString(16)}\r\n`, "latin1");
			this.bytesWritten += len;
			const ret = socket.write(chunk);
			socket.uncork();
			request.onBodySent(chunk);
			if (!ret) {
				if (socket[kParser].timeout && socket[kParser].timeoutType === TIMEOUT_HEADERS) {
					// istanbul ignore else: only for jest
					if (socket[kParser].timeout.refresh) socket[kParser].timeout.refresh();
				}
			}
			return ret;
		}
		end() {
			const { socket, contentLength, client, bytesWritten, expectsPayload, header, request } = this;
			request.onRequestSent();
			socket[kWriting] = false;
			if (socket[kError]) throw socket[kError];
			if (socket.destroyed) return;
			if (bytesWritten === 0) {
				if (expectsPayload) socket.write(`${header}content-length: 0\r\n\r\n`, "latin1");
				else socket.write(`${header}\r\n`, "latin1");
			} else if (contentLength === null) socket.write("\r\n0\r\n\r\n", "latin1");
			if (contentLength !== null && bytesWritten !== contentLength) {
				if (client[kStrictContentLength]) throw new RequestContentLengthMismatchError();
				else process.emitWarning(new RequestContentLengthMismatchError());
			}
			if (socket[kParser].timeout && socket[kParser].timeoutType === TIMEOUT_HEADERS) {
				// istanbul ignore else: only for jest
				if (socket[kParser].timeout.refresh) socket[kParser].timeout.refresh();
			}
			resume(client);
		}
		destroy(err) {
			const { socket, client } = this;
			socket[kWriting] = false;
			if (err) {
				assert$13(client[kRunning] <= 1, "pipeline should only contain this request");
				util.destroy(socket, err);
			}
		}
	};
	function errorRequest(client, request, err) {
		try {
			request.onError(err);
			assert$13(request.aborted);
		} catch (err) {
			client.emit("error", err);
		}
	}
	module.exports = Client;
}));
//#endregion
//#region node_modules/undici/lib/node/fixed-queue.js
var require_fixed_queue = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var kSize = 2048;
	var kMask = 2047;
	var FixedCircularBuffer = class {
		constructor() {
			this.bottom = 0;
			this.top = 0;
			this.list = new Array(kSize);
			this.next = null;
		}
		isEmpty() {
			return this.top === this.bottom;
		}
		isFull() {
			return (this.top + 1 & kMask) === this.bottom;
		}
		push(data) {
			this.list[this.top] = data;
			this.top = this.top + 1 & kMask;
		}
		shift() {
			const nextItem = this.list[this.bottom];
			if (nextItem === void 0) return null;
			this.list[this.bottom] = void 0;
			this.bottom = this.bottom + 1 & kMask;
			return nextItem;
		}
	};
	module.exports = class FixedQueue {
		constructor() {
			this.head = this.tail = new FixedCircularBuffer();
		}
		isEmpty() {
			return this.head.isEmpty();
		}
		push(data) {
			if (this.head.isFull()) this.head = this.head.next = new FixedCircularBuffer();
			this.head.push(data);
		}
		shift() {
			const tail = this.tail;
			const next = tail.shift();
			if (tail.isEmpty() && tail.next !== null) this.tail = tail.next;
			return next;
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/pool-stats.js
var require_pool_stats = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kFree, kConnected, kPending, kQueued, kRunning, kSize } = require_symbols$4();
	var kPool = Symbol("pool");
	var PoolStats = class {
		constructor(pool) {
			this[kPool] = pool;
		}
		get connected() {
			return this[kPool][kConnected];
		}
		get free() {
			return this[kPool][kFree];
		}
		get pending() {
			return this[kPool][kPending];
		}
		get queued() {
			return this[kPool][kQueued];
		}
		get running() {
			return this[kPool][kRunning];
		}
		get size() {
			return this[kPool][kSize];
		}
	};
	module.exports = PoolStats;
}));
//#endregion
//#region node_modules/undici/lib/pool-base.js
var require_pool_base = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var DispatcherBase = require_dispatcher_base();
	var FixedQueue = require_fixed_queue();
	var { kConnected, kSize, kRunning, kPending, kQueued, kBusy, kFree, kUrl, kClose, kDestroy, kDispatch } = require_symbols$4();
	var PoolStats = require_pool_stats();
	var kClients = Symbol("clients");
	var kNeedDrain = Symbol("needDrain");
	var kQueue = Symbol("queue");
	var kClosedResolve = Symbol("closed resolve");
	var kOnDrain = Symbol("onDrain");
	var kOnConnect = Symbol("onConnect");
	var kOnDisconnect = Symbol("onDisconnect");
	var kOnConnectionError = Symbol("onConnectionError");
	var kGetDispatcher = Symbol("get dispatcher");
	var kAddClient = Symbol("add client");
	var kRemoveClient = Symbol("remove client");
	var kStats = Symbol("stats");
	var PoolBase = class extends DispatcherBase {
		constructor() {
			super();
			this[kQueue] = new FixedQueue();
			this[kClients] = [];
			this[kQueued] = 0;
			const pool = this;
			this[kOnDrain] = function onDrain(origin, targets) {
				const queue = pool[kQueue];
				let needDrain = false;
				while (!needDrain) {
					const item = queue.shift();
					if (!item) break;
					pool[kQueued]--;
					needDrain = !this.dispatch(item.opts, item.handler);
				}
				this[kNeedDrain] = needDrain;
				if (!this[kNeedDrain] && pool[kNeedDrain]) {
					pool[kNeedDrain] = false;
					pool.emit("drain", origin, [pool, ...targets]);
				}
				if (pool[kClosedResolve] && queue.isEmpty()) Promise.all(pool[kClients].map((c) => c.close())).then(pool[kClosedResolve]);
			};
			this[kOnConnect] = (origin, targets) => {
				pool.emit("connect", origin, [pool, ...targets]);
			};
			this[kOnDisconnect] = (origin, targets, err) => {
				pool.emit("disconnect", origin, [pool, ...targets], err);
			};
			this[kOnConnectionError] = (origin, targets, err) => {
				pool.emit("connectionError", origin, [pool, ...targets], err);
			};
			this[kStats] = new PoolStats(this);
		}
		get [kBusy]() {
			return this[kNeedDrain];
		}
		get [kConnected]() {
			return this[kClients].filter((client) => client[kConnected]).length;
		}
		get [kFree]() {
			return this[kClients].filter((client) => client[kConnected] && !client[kNeedDrain]).length;
		}
		get [kPending]() {
			let ret = this[kQueued];
			for (const { [kPending]: pending } of this[kClients]) ret += pending;
			return ret;
		}
		get [kRunning]() {
			let ret = 0;
			for (const { [kRunning]: running } of this[kClients]) ret += running;
			return ret;
		}
		get [kSize]() {
			let ret = this[kQueued];
			for (const { [kSize]: size } of this[kClients]) ret += size;
			return ret;
		}
		get stats() {
			return this[kStats];
		}
		async [kClose]() {
			if (this[kQueue].isEmpty()) return Promise.all(this[kClients].map((c) => c.close()));
			else return new Promise((resolve) => {
				this[kClosedResolve] = resolve;
			});
		}
		async [kDestroy](err) {
			while (true) {
				const item = this[kQueue].shift();
				if (!item) break;
				item.handler.onError(err);
			}
			return Promise.all(this[kClients].map((c) => c.destroy(err)));
		}
		[kDispatch](opts, handler) {
			const dispatcher = this[kGetDispatcher]();
			if (!dispatcher) {
				this[kNeedDrain] = true;
				this[kQueue].push({
					opts,
					handler
				});
				this[kQueued]++;
			} else if (!dispatcher.dispatch(opts, handler)) {
				dispatcher[kNeedDrain] = true;
				this[kNeedDrain] = !this[kGetDispatcher]();
			}
			return !this[kNeedDrain];
		}
		[kAddClient](client) {
			client.on("drain", this[kOnDrain]).on("connect", this[kOnConnect]).on("disconnect", this[kOnDisconnect]).on("connectionError", this[kOnConnectionError]);
			this[kClients].push(client);
			if (this[kNeedDrain]) process.nextTick(() => {
				if (this[kNeedDrain]) this[kOnDrain](client[kUrl], [this, client]);
			});
			return this;
		}
		[kRemoveClient](client) {
			client.close(() => {
				const idx = this[kClients].indexOf(client);
				if (idx !== -1) this[kClients].splice(idx, 1);
			});
			this[kNeedDrain] = this[kClients].some((dispatcher) => !dispatcher[kNeedDrain] && dispatcher.closed !== true && dispatcher.destroyed !== true);
		}
	};
	module.exports = {
		PoolBase,
		kClients,
		kNeedDrain,
		kAddClient,
		kRemoveClient,
		kGetDispatcher
	};
}));
//#endregion
//#region node_modules/undici/lib/pool.js
var require_pool = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { PoolBase, kClients, kNeedDrain, kAddClient, kGetDispatcher } = require_pool_base();
	var Client = require_client();
	var { InvalidArgumentError } = require_errors();
	var util = require_util$6();
	var { kUrl, kInterceptors } = require_symbols$4();
	var buildConnector = require_connect();
	var kOptions = Symbol("options");
	var kConnections = Symbol("connections");
	var kFactory = Symbol("factory");
	function defaultFactory(origin, opts) {
		return new Client(origin, opts);
	}
	var Pool = class extends PoolBase {
		constructor(origin, { connections, factory = defaultFactory, connect, connectTimeout, tls, maxCachedSessions, socketPath, autoSelectFamily, autoSelectFamilyAttemptTimeout, allowH2, ...options } = {}) {
			super();
			if (connections != null && (!Number.isFinite(connections) || connections < 0)) throw new InvalidArgumentError("invalid connections");
			if (typeof factory !== "function") throw new InvalidArgumentError("factory must be a function.");
			if (connect != null && typeof connect !== "function" && typeof connect !== "object") throw new InvalidArgumentError("connect must be a function or an object");
			if (typeof connect !== "function") connect = buildConnector({
				...tls,
				maxCachedSessions,
				allowH2,
				socketPath,
				timeout: connectTimeout,
				...util.nodeHasAutoSelectFamily && autoSelectFamily ? {
					autoSelectFamily,
					autoSelectFamilyAttemptTimeout
				} : void 0,
				...connect
			});
			this[kInterceptors] = options.interceptors && options.interceptors.Pool && Array.isArray(options.interceptors.Pool) ? options.interceptors.Pool : [];
			this[kConnections] = connections || null;
			this[kUrl] = util.parseOrigin(origin);
			this[kOptions] = {
				...util.deepClone(options),
				connect,
				allowH2
			};
			this[kOptions].interceptors = options.interceptors ? { ...options.interceptors } : void 0;
			this[kFactory] = factory;
		}
		[kGetDispatcher]() {
			let dispatcher = this[kClients].find((dispatcher) => !dispatcher[kNeedDrain]);
			if (dispatcher) return dispatcher;
			if (!this[kConnections] || this[kClients].length < this[kConnections]) {
				dispatcher = this[kFactory](this[kUrl], this[kOptions]);
				this[kAddClient](dispatcher);
			}
			return dispatcher;
		}
	};
	module.exports = Pool;
}));
//#endregion
//#region node_modules/undici/lib/balanced-pool.js
var require_balanced_pool = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { BalancedPoolMissingUpstreamError, InvalidArgumentError } = require_errors();
	var { PoolBase, kClients, kNeedDrain, kAddClient, kRemoveClient, kGetDispatcher } = require_pool_base();
	var Pool = require_pool();
	var { kUrl, kInterceptors } = require_symbols$4();
	var { parseOrigin } = require_util$6();
	var kFactory = Symbol("factory");
	var kOptions = Symbol("options");
	var kGreatestCommonDivisor = Symbol("kGreatestCommonDivisor");
	var kCurrentWeight = Symbol("kCurrentWeight");
	var kIndex = Symbol("kIndex");
	var kWeight = Symbol("kWeight");
	var kMaxWeightPerServer = Symbol("kMaxWeightPerServer");
	var kErrorPenalty = Symbol("kErrorPenalty");
	function getGreatestCommonDivisor(a, b) {
		if (b === 0) return a;
		return getGreatestCommonDivisor(b, a % b);
	}
	function defaultFactory(origin, opts) {
		return new Pool(origin, opts);
	}
	var BalancedPool = class extends PoolBase {
		constructor(upstreams = [], { factory = defaultFactory, ...opts } = {}) {
			super();
			this[kOptions] = opts;
			this[kIndex] = -1;
			this[kCurrentWeight] = 0;
			this[kMaxWeightPerServer] = this[kOptions].maxWeightPerServer || 100;
			this[kErrorPenalty] = this[kOptions].errorPenalty || 15;
			if (!Array.isArray(upstreams)) upstreams = [upstreams];
			if (typeof factory !== "function") throw new InvalidArgumentError("factory must be a function.");
			this[kInterceptors] = opts.interceptors && opts.interceptors.BalancedPool && Array.isArray(opts.interceptors.BalancedPool) ? opts.interceptors.BalancedPool : [];
			this[kFactory] = factory;
			for (const upstream of upstreams) this.addUpstream(upstream);
			this._updateBalancedPoolStats();
		}
		addUpstream(upstream) {
			const upstreamOrigin = parseOrigin(upstream).origin;
			if (this[kClients].find((pool) => pool[kUrl].origin === upstreamOrigin && pool.closed !== true && pool.destroyed !== true)) return this;
			const pool = this[kFactory](upstreamOrigin, Object.assign({}, this[kOptions]));
			this[kAddClient](pool);
			pool.on("connect", () => {
				pool[kWeight] = Math.min(this[kMaxWeightPerServer], pool[kWeight] + this[kErrorPenalty]);
			});
			pool.on("connectionError", () => {
				pool[kWeight] = Math.max(1, pool[kWeight] - this[kErrorPenalty]);
				this._updateBalancedPoolStats();
			});
			pool.on("disconnect", (...args) => {
				const err = args[2];
				if (err && err.code === "UND_ERR_SOCKET") {
					pool[kWeight] = Math.max(1, pool[kWeight] - this[kErrorPenalty]);
					this._updateBalancedPoolStats();
				}
			});
			for (const client of this[kClients]) client[kWeight] = this[kMaxWeightPerServer];
			this._updateBalancedPoolStats();
			return this;
		}
		_updateBalancedPoolStats() {
			this[kGreatestCommonDivisor] = this[kClients].map((p) => p[kWeight]).reduce(getGreatestCommonDivisor, 0);
		}
		removeUpstream(upstream) {
			const upstreamOrigin = parseOrigin(upstream).origin;
			const pool = this[kClients].find((pool) => pool[kUrl].origin === upstreamOrigin && pool.closed !== true && pool.destroyed !== true);
			if (pool) this[kRemoveClient](pool);
			return this;
		}
		get upstreams() {
			return this[kClients].filter((dispatcher) => dispatcher.closed !== true && dispatcher.destroyed !== true).map((p) => p[kUrl].origin);
		}
		[kGetDispatcher]() {
			if (this[kClients].length === 0) throw new BalancedPoolMissingUpstreamError();
			if (!this[kClients].find((dispatcher) => !dispatcher[kNeedDrain] && dispatcher.closed !== true && dispatcher.destroyed !== true)) return;
			if (this[kClients].map((pool) => pool[kNeedDrain]).reduce((a, b) => a && b, true)) return;
			let counter = 0;
			let maxWeightIndex = this[kClients].findIndex((pool) => !pool[kNeedDrain]);
			while (counter++ < this[kClients].length) {
				this[kIndex] = (this[kIndex] + 1) % this[kClients].length;
				const pool = this[kClients][this[kIndex]];
				if (pool[kWeight] > this[kClients][maxWeightIndex][kWeight] && !pool[kNeedDrain]) maxWeightIndex = this[kIndex];
				if (this[kIndex] === 0) {
					this[kCurrentWeight] = this[kCurrentWeight] - this[kGreatestCommonDivisor];
					if (this[kCurrentWeight] <= 0) this[kCurrentWeight] = this[kMaxWeightPerServer];
				}
				if (pool[kWeight] >= this[kCurrentWeight] && !pool[kNeedDrain]) return pool;
			}
			this[kCurrentWeight] = this[kClients][maxWeightIndex][kWeight];
			this[kIndex] = maxWeightIndex;
			return this[kClients][maxWeightIndex];
		}
	};
	module.exports = BalancedPool;
}));
//#endregion
//#region node_modules/undici/lib/compat/dispatcher-weakref.js
var require_dispatcher_weakref = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/* istanbul ignore file: only for Node 12 */
	var { kConnected, kSize } = require_symbols$4();
	var CompatWeakRef = class {
		constructor(value) {
			this.value = value;
		}
		deref() {
			return this.value[kConnected] === 0 && this.value[kSize] === 0 ? void 0 : this.value;
		}
	};
	var CompatFinalizer = class {
		constructor(finalizer) {
			this.finalizer = finalizer;
		}
		register(dispatcher, key) {
			if (dispatcher.on) dispatcher.on("disconnect", () => {
				if (dispatcher[kConnected] === 0 && dispatcher[kSize] === 0) this.finalizer(key);
			});
		}
	};
	module.exports = function() {
		if (process.env.NODE_V8_COVERAGE) return {
			WeakRef: CompatWeakRef,
			FinalizationRegistry: CompatFinalizer
		};
		return {
			WeakRef: global.WeakRef || CompatWeakRef,
			FinalizationRegistry: global.FinalizationRegistry || CompatFinalizer
		};
	};
}));
//#endregion
//#region node_modules/undici/lib/agent.js
var require_agent = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { InvalidArgumentError } = require_errors();
	var { kClients, kRunning, kClose, kDestroy, kDispatch, kInterceptors } = require_symbols$4();
	var DispatcherBase = require_dispatcher_base();
	var Pool = require_pool();
	var Client = require_client();
	var util = require_util$6();
	var createRedirectInterceptor = require_redirectInterceptor();
	var { WeakRef, FinalizationRegistry } = require_dispatcher_weakref()();
	var kOnConnect = Symbol("onConnect");
	var kOnDisconnect = Symbol("onDisconnect");
	var kOnConnectionError = Symbol("onConnectionError");
	var kMaxRedirections = Symbol("maxRedirections");
	var kOnDrain = Symbol("onDrain");
	var kFactory = Symbol("factory");
	var kFinalizer = Symbol("finalizer");
	var kOptions = Symbol("options");
	function defaultFactory(origin, opts) {
		return opts && opts.connections === 1 ? new Client(origin, opts) : new Pool(origin, opts);
	}
	var Agent = class extends DispatcherBase {
		constructor({ factory = defaultFactory, maxRedirections = 0, connect, ...options } = {}) {
			super();
			if (typeof factory !== "function") throw new InvalidArgumentError("factory must be a function.");
			if (connect != null && typeof connect !== "function" && typeof connect !== "object") throw new InvalidArgumentError("connect must be a function or an object");
			if (!Number.isInteger(maxRedirections) || maxRedirections < 0) throw new InvalidArgumentError("maxRedirections must be a positive number");
			if (connect && typeof connect !== "function") connect = { ...connect };
			this[kInterceptors] = options.interceptors && options.interceptors.Agent && Array.isArray(options.interceptors.Agent) ? options.interceptors.Agent : [createRedirectInterceptor({ maxRedirections })];
			this[kOptions] = {
				...util.deepClone(options),
				connect
			};
			this[kOptions].interceptors = options.interceptors ? { ...options.interceptors } : void 0;
			this[kMaxRedirections] = maxRedirections;
			this[kFactory] = factory;
			this[kClients] = /* @__PURE__ */ new Map();
			this[kFinalizer] = new FinalizationRegistry(
				/* istanbul ignore next: gc is undeterministic */
				(key) => {
					const ref = this[kClients].get(key);
					if (ref !== void 0 && ref.deref() === void 0) this[kClients].delete(key);
				}
			);
			const agent = this;
			this[kOnDrain] = (origin, targets) => {
				agent.emit("drain", origin, [agent, ...targets]);
			};
			this[kOnConnect] = (origin, targets) => {
				agent.emit("connect", origin, [agent, ...targets]);
			};
			this[kOnDisconnect] = (origin, targets, err) => {
				agent.emit("disconnect", origin, [agent, ...targets], err);
			};
			this[kOnConnectionError] = (origin, targets, err) => {
				agent.emit("connectionError", origin, [agent, ...targets], err);
			};
		}
		get [kRunning]() {
			let ret = 0;
			for (const ref of this[kClients].values()) {
				const client = ref.deref();
				/* istanbul ignore next: gc is undeterministic */
				if (client) ret += client[kRunning];
			}
			return ret;
		}
		[kDispatch](opts, handler) {
			let key;
			if (opts.origin && (typeof opts.origin === "string" || opts.origin instanceof URL)) key = String(opts.origin);
			else throw new InvalidArgumentError("opts.origin must be a non-empty string or URL.");
			const ref = this[kClients].get(key);
			let dispatcher = ref ? ref.deref() : null;
			if (!dispatcher) {
				dispatcher = this[kFactory](opts.origin, this[kOptions]).on("drain", this[kOnDrain]).on("connect", this[kOnConnect]).on("disconnect", this[kOnDisconnect]).on("connectionError", this[kOnConnectionError]);
				this[kClients].set(key, new WeakRef(dispatcher));
				this[kFinalizer].register(dispatcher, key);
			}
			return dispatcher.dispatch(opts, handler);
		}
		async [kClose]() {
			const closePromises = [];
			for (const ref of this[kClients].values()) {
				const client = ref.deref();
				/* istanbul ignore else: gc is undeterministic */
				if (client) closePromises.push(client.close());
			}
			await Promise.all(closePromises);
		}
		async [kDestroy](err) {
			const destroyPromises = [];
			for (const ref of this[kClients].values()) {
				const client = ref.deref();
				/* istanbul ignore else: gc is undeterministic */
				if (client) destroyPromises.push(client.destroy(err));
			}
			await Promise.all(destroyPromises);
		}
	};
	module.exports = Agent;
}));
//#endregion
//#region node_modules/undici/lib/api/readable.js
var require_readable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$12 = __require("assert");
	var { Readable: Readable$2 } = __require("stream");
	var { RequestAbortedError, NotSupportedError, InvalidArgumentError } = require_errors();
	var util = require_util$6();
	var { ReadableStreamFrom, toUSVString } = require_util$6();
	var Blob;
	var kConsume = Symbol("kConsume");
	var kReading = Symbol("kReading");
	var kBody = Symbol("kBody");
	var kAbort = Symbol("abort");
	var kContentType = Symbol("kContentType");
	var noop = () => {};
	module.exports = class BodyReadable extends Readable$2 {
		constructor({ resume, abort, contentType = "", highWaterMark = 65536 }) {
			super({
				autoDestroy: true,
				read: resume,
				highWaterMark
			});
			this._readableState.dataEmitted = false;
			this[kAbort] = abort;
			this[kConsume] = null;
			this[kBody] = null;
			this[kContentType] = contentType;
			this[kReading] = false;
		}
		destroy(err) {
			if (this.destroyed) return this;
			if (!err && !this._readableState.endEmitted) err = new RequestAbortedError();
			if (err) this[kAbort]();
			return super.destroy(err);
		}
		emit(ev, ...args) {
			if (ev === "data") this._readableState.dataEmitted = true;
			else if (ev === "error") this._readableState.errorEmitted = true;
			return super.emit(ev, ...args);
		}
		on(ev, ...args) {
			if (ev === "data" || ev === "readable") this[kReading] = true;
			return super.on(ev, ...args);
		}
		addListener(ev, ...args) {
			return this.on(ev, ...args);
		}
		off(ev, ...args) {
			const ret = super.off(ev, ...args);
			if (ev === "data" || ev === "readable") this[kReading] = this.listenerCount("data") > 0 || this.listenerCount("readable") > 0;
			return ret;
		}
		removeListener(ev, ...args) {
			return this.off(ev, ...args);
		}
		push(chunk) {
			if (this[kConsume] && chunk !== null && this.readableLength === 0) {
				consumePush(this[kConsume], chunk);
				return this[kReading] ? super.push(chunk) : true;
			}
			return super.push(chunk);
		}
		async text() {
			return consume(this, "text");
		}
		async json() {
			return consume(this, "json");
		}
		async blob() {
			return consume(this, "blob");
		}
		async arrayBuffer() {
			return consume(this, "arrayBuffer");
		}
		async formData() {
			throw new NotSupportedError();
		}
		get bodyUsed() {
			return util.isDisturbed(this);
		}
		get body() {
			if (!this[kBody]) {
				this[kBody] = ReadableStreamFrom(this);
				if (this[kConsume]) {
					this[kBody].getReader();
					assert$12(this[kBody].locked);
				}
			}
			return this[kBody];
		}
		dump(opts) {
			let limit = opts && Number.isFinite(opts.limit) ? opts.limit : 262144;
			const signal = opts && opts.signal;
			if (signal) try {
				if (typeof signal !== "object" || !("aborted" in signal)) throw new InvalidArgumentError("signal must be an AbortSignal");
				util.throwIfAborted(signal);
			} catch (err) {
				return Promise.reject(err);
			}
			if (this.closed) return Promise.resolve(null);
			return new Promise((resolve, reject) => {
				const signalListenerCleanup = signal ? util.addAbortListener(signal, () => {
					this.destroy();
				}) : noop;
				this.on("close", function() {
					signalListenerCleanup();
					if (signal && signal.aborted) reject(signal.reason || Object.assign(/* @__PURE__ */ new Error("The operation was aborted"), { name: "AbortError" }));
					else resolve(null);
				}).on("error", noop).on("data", function(chunk) {
					limit -= chunk.length;
					if (limit <= 0) this.destroy();
				}).resume();
			});
		}
	};
	function isLocked(self) {
		return self[kBody] && self[kBody].locked === true || self[kConsume];
	}
	function isUnusable(self) {
		return util.isDisturbed(self) || isLocked(self);
	}
	async function consume(stream, type) {
		if (isUnusable(stream)) throw new TypeError("unusable");
		assert$12(!stream[kConsume]);
		return new Promise((resolve, reject) => {
			stream[kConsume] = {
				type,
				stream,
				resolve,
				reject,
				length: 0,
				body: []
			};
			stream.on("error", function(err) {
				consumeFinish(this[kConsume], err);
			}).on("close", function() {
				if (this[kConsume].body !== null) consumeFinish(this[kConsume], new RequestAbortedError());
			});
			process.nextTick(consumeStart, stream[kConsume]);
		});
	}
	function consumeStart(consume) {
		if (consume.body === null) return;
		const { _readableState: state } = consume.stream;
		for (const chunk of state.buffer) consumePush(consume, chunk);
		if (state.endEmitted) consumeEnd(this[kConsume]);
		else consume.stream.on("end", function() {
			consumeEnd(this[kConsume]);
		});
		consume.stream.resume();
		while (consume.stream.read() != null);
	}
	function consumeEnd(consume) {
		const { type, body, resolve, stream, length } = consume;
		try {
			if (type === "text") resolve(toUSVString(Buffer.concat(body)));
			else if (type === "json") resolve(JSON.parse(Buffer.concat(body)));
			else if (type === "arrayBuffer") {
				const dst = new Uint8Array(length);
				let pos = 0;
				for (const buf of body) {
					dst.set(buf, pos);
					pos += buf.byteLength;
				}
				resolve(dst.buffer);
			} else if (type === "blob") {
				if (!Blob) Blob = __require("buffer").Blob;
				resolve(new Blob(body, { type: stream[kContentType] }));
			}
			consumeFinish(consume);
		} catch (err) {
			stream.destroy(err);
		}
	}
	function consumePush(consume, chunk) {
		consume.length += chunk.length;
		consume.body.push(chunk);
	}
	function consumeFinish(consume, err) {
		if (consume.body === null) return;
		if (err) consume.reject(err);
		else consume.resolve();
		consume.type = null;
		consume.stream = null;
		consume.resolve = null;
		consume.reject = null;
		consume.length = 0;
		consume.body = null;
	}
}));
//#endregion
//#region node_modules/undici/lib/api/util.js
var require_util$4 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$11 = __require("assert");
	var { ResponseStatusCodeError } = require_errors();
	var { toUSVString } = require_util$6();
	async function getResolveErrorBodyCallback({ callback, body, contentType, statusCode, statusMessage, headers }) {
		assert$11(body);
		let chunks = [];
		let limit = 0;
		for await (const chunk of body) {
			chunks.push(chunk);
			limit += chunk.length;
			if (limit > 131072) {
				chunks = null;
				break;
			}
		}
		if (statusCode === 204 || !contentType || !chunks) {
			process.nextTick(callback, new ResponseStatusCodeError(`Response status code ${statusCode}${statusMessage ? `: ${statusMessage}` : ""}`, statusCode, headers));
			return;
		}
		try {
			if (contentType.startsWith("application/json")) {
				const payload = JSON.parse(toUSVString(Buffer.concat(chunks)));
				process.nextTick(callback, new ResponseStatusCodeError(`Response status code ${statusCode}${statusMessage ? `: ${statusMessage}` : ""}`, statusCode, headers, payload));
				return;
			}
			if (contentType.startsWith("text/")) {
				const payload = toUSVString(Buffer.concat(chunks));
				process.nextTick(callback, new ResponseStatusCodeError(`Response status code ${statusCode}${statusMessage ? `: ${statusMessage}` : ""}`, statusCode, headers, payload));
				return;
			}
		} catch (err) {}
		process.nextTick(callback, new ResponseStatusCodeError(`Response status code ${statusCode}${statusMessage ? `: ${statusMessage}` : ""}`, statusCode, headers));
	}
	module.exports = { getResolveErrorBodyCallback };
}));
//#endregion
//#region node_modules/undici/lib/api/abort-signal.js
var require_abort_signal = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { addAbortListener } = require_util$6();
	var { RequestAbortedError } = require_errors();
	var kListener = Symbol("kListener");
	var kSignal = Symbol("kSignal");
	function abort(self) {
		if (self.abort) self.abort();
		else self.onError(new RequestAbortedError());
	}
	function addSignal(self, signal) {
		self[kSignal] = null;
		self[kListener] = null;
		if (!signal) return;
		if (signal.aborted) {
			abort(self);
			return;
		}
		self[kSignal] = signal;
		self[kListener] = () => {
			abort(self);
		};
		addAbortListener(self[kSignal], self[kListener]);
	}
	function removeSignal(self) {
		if (!self[kSignal]) return;
		if ("removeEventListener" in self[kSignal]) self[kSignal].removeEventListener("abort", self[kListener]);
		else self[kSignal].removeListener("abort", self[kListener]);
		self[kSignal] = null;
		self[kListener] = null;
	}
	module.exports = {
		addSignal,
		removeSignal
	};
}));
//#endregion
//#region node_modules/undici/lib/api/api-request.js
var require_api_request = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Readable = require_readable();
	var { InvalidArgumentError, RequestAbortedError } = require_errors();
	var util = require_util$6();
	var { getResolveErrorBodyCallback } = require_util$4();
	var { AsyncResource: AsyncResource$4 } = __require("async_hooks");
	var { addSignal, removeSignal } = require_abort_signal();
	var RequestHandler = class extends AsyncResource$4 {
		constructor(opts, callback) {
			if (!opts || typeof opts !== "object") throw new InvalidArgumentError("invalid opts");
			const { signal, method, opaque, body, onInfo, responseHeaders, throwOnError, highWaterMark } = opts;
			try {
				if (typeof callback !== "function") throw new InvalidArgumentError("invalid callback");
				if (highWaterMark && (typeof highWaterMark !== "number" || highWaterMark < 0)) throw new InvalidArgumentError("invalid highWaterMark");
				if (signal && typeof signal.on !== "function" && typeof signal.addEventListener !== "function") throw new InvalidArgumentError("signal must be an EventEmitter or EventTarget");
				if (method === "CONNECT") throw new InvalidArgumentError("invalid method");
				if (onInfo && typeof onInfo !== "function") throw new InvalidArgumentError("invalid onInfo callback");
				super("UNDICI_REQUEST");
			} catch (err) {
				if (util.isStream(body)) util.destroy(body.on("error", util.nop), err);
				throw err;
			}
			this.responseHeaders = responseHeaders || null;
			this.opaque = opaque || null;
			this.callback = callback;
			this.res = null;
			this.abort = null;
			this.body = body;
			this.trailers = {};
			this.context = null;
			this.onInfo = onInfo || null;
			this.throwOnError = throwOnError;
			this.highWaterMark = highWaterMark;
			if (util.isStream(body)) body.on("error", (err) => {
				this.onError(err);
			});
			addSignal(this, signal);
		}
		onConnect(abort, context) {
			if (!this.callback) throw new RequestAbortedError();
			this.abort = abort;
			this.context = context;
		}
		onHeaders(statusCode, rawHeaders, resume, statusMessage) {
			const { callback, opaque, abort, context, responseHeaders, highWaterMark } = this;
			const headers = responseHeaders === "raw" ? util.parseRawHeaders(rawHeaders) : util.parseHeaders(rawHeaders);
			if (statusCode < 200) {
				if (this.onInfo) this.onInfo({
					statusCode,
					headers
				});
				return;
			}
			const contentType = (responseHeaders === "raw" ? util.parseHeaders(rawHeaders) : headers)["content-type"];
			const body = new Readable({
				resume,
				abort,
				contentType,
				highWaterMark
			});
			this.callback = null;
			this.res = body;
			if (callback !== null) {
				if (this.throwOnError && statusCode >= 400) this.runInAsyncScope(getResolveErrorBodyCallback, null, {
					callback,
					body,
					contentType,
					statusCode,
					statusMessage,
					headers
				});
				else this.runInAsyncScope(callback, null, null, {
					statusCode,
					headers,
					trailers: this.trailers,
					opaque,
					body,
					context
				});
			}
		}
		onData(chunk) {
			const { res } = this;
			return res.push(chunk);
		}
		onComplete(trailers) {
			const { res } = this;
			removeSignal(this);
			util.parseHeaders(trailers, this.trailers);
			res.push(null);
		}
		onError(err) {
			const { res, callback, body, opaque } = this;
			removeSignal(this);
			if (callback) {
				this.callback = null;
				queueMicrotask(() => {
					this.runInAsyncScope(callback, null, err, { opaque });
				});
			}
			if (res) {
				this.res = null;
				queueMicrotask(() => {
					util.destroy(res, err);
				});
			}
			if (body) {
				this.body = null;
				util.destroy(body, err);
			}
		}
	};
	function request(opts, callback) {
		if (callback === void 0) return new Promise((resolve, reject) => {
			request.call(this, opts, (err, data) => {
				return err ? reject(err) : resolve(data);
			});
		});
		try {
			this.dispatch(opts, new RequestHandler(opts, callback));
		} catch (err) {
			if (typeof callback !== "function") throw err;
			const opaque = opts && opts.opaque;
			queueMicrotask(() => callback(err, { opaque }));
		}
	}
	module.exports = request;
	module.exports.RequestHandler = RequestHandler;
}));
//#endregion
//#region node_modules/undici/lib/api/api-stream.js
var require_api_stream = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { finished, PassThrough: PassThrough$1 } = __require("stream");
	var { InvalidArgumentError, InvalidReturnValueError, RequestAbortedError } = require_errors();
	var util = require_util$6();
	var { getResolveErrorBodyCallback } = require_util$4();
	var { AsyncResource: AsyncResource$3 } = __require("async_hooks");
	var { addSignal, removeSignal } = require_abort_signal();
	var StreamHandler = class extends AsyncResource$3 {
		constructor(opts, factory, callback) {
			if (!opts || typeof opts !== "object") throw new InvalidArgumentError("invalid opts");
			const { signal, method, opaque, body, onInfo, responseHeaders, throwOnError } = opts;
			try {
				if (typeof callback !== "function") throw new InvalidArgumentError("invalid callback");
				if (typeof factory !== "function") throw new InvalidArgumentError("invalid factory");
				if (signal && typeof signal.on !== "function" && typeof signal.addEventListener !== "function") throw new InvalidArgumentError("signal must be an EventEmitter or EventTarget");
				if (method === "CONNECT") throw new InvalidArgumentError("invalid method");
				if (onInfo && typeof onInfo !== "function") throw new InvalidArgumentError("invalid onInfo callback");
				super("UNDICI_STREAM");
			} catch (err) {
				if (util.isStream(body)) util.destroy(body.on("error", util.nop), err);
				throw err;
			}
			this.responseHeaders = responseHeaders || null;
			this.opaque = opaque || null;
			this.factory = factory;
			this.callback = callback;
			this.res = null;
			this.abort = null;
			this.context = null;
			this.trailers = null;
			this.body = body;
			this.onInfo = onInfo || null;
			this.throwOnError = throwOnError || false;
			if (util.isStream(body)) body.on("error", (err) => {
				this.onError(err);
			});
			addSignal(this, signal);
		}
		onConnect(abort, context) {
			if (!this.callback) throw new RequestAbortedError();
			this.abort = abort;
			this.context = context;
		}
		onHeaders(statusCode, rawHeaders, resume, statusMessage) {
			const { factory, opaque, context, callback, responseHeaders } = this;
			const headers = responseHeaders === "raw" ? util.parseRawHeaders(rawHeaders) : util.parseHeaders(rawHeaders);
			if (statusCode < 200) {
				if (this.onInfo) this.onInfo({
					statusCode,
					headers
				});
				return;
			}
			this.factory = null;
			let res;
			if (this.throwOnError && statusCode >= 400) {
				const contentType = (responseHeaders === "raw" ? util.parseHeaders(rawHeaders) : headers)["content-type"];
				res = new PassThrough$1();
				this.callback = null;
				this.runInAsyncScope(getResolveErrorBodyCallback, null, {
					callback,
					body: res,
					contentType,
					statusCode,
					statusMessage,
					headers
				});
			} else {
				if (factory === null) return;
				res = this.runInAsyncScope(factory, null, {
					statusCode,
					headers,
					opaque,
					context
				});
				if (!res || typeof res.write !== "function" || typeof res.end !== "function" || typeof res.on !== "function") throw new InvalidReturnValueError("expected Writable");
				finished(res, { readable: false }, (err) => {
					const { callback, res, opaque, trailers, abort } = this;
					this.res = null;
					if (err || !res.readable) util.destroy(res, err);
					this.callback = null;
					this.runInAsyncScope(callback, null, err || null, {
						opaque,
						trailers
					});
					if (err) abort();
				});
			}
			res.on("drain", resume);
			this.res = res;
			return (res.writableNeedDrain !== void 0 ? res.writableNeedDrain : res._writableState && res._writableState.needDrain) !== true;
		}
		onData(chunk) {
			const { res } = this;
			return res ? res.write(chunk) : true;
		}
		onComplete(trailers) {
			const { res } = this;
			removeSignal(this);
			if (!res) return;
			this.trailers = util.parseHeaders(trailers);
			res.end();
		}
		onError(err) {
			const { res, callback, opaque, body } = this;
			removeSignal(this);
			this.factory = null;
			if (res) {
				this.res = null;
				util.destroy(res, err);
			} else if (callback) {
				this.callback = null;
				queueMicrotask(() => {
					this.runInAsyncScope(callback, null, err, { opaque });
				});
			}
			if (body) {
				this.body = null;
				util.destroy(body, err);
			}
		}
	};
	function stream(opts, factory, callback) {
		if (callback === void 0) return new Promise((resolve, reject) => {
			stream.call(this, opts, factory, (err, data) => {
				return err ? reject(err) : resolve(data);
			});
		});
		try {
			this.dispatch(opts, new StreamHandler(opts, factory, callback));
		} catch (err) {
			if (typeof callback !== "function") throw err;
			const opaque = opts && opts.opaque;
			queueMicrotask(() => callback(err, { opaque }));
		}
	}
	module.exports = stream;
}));
//#endregion
//#region node_modules/undici/lib/api/api-pipeline.js
var require_api_pipeline = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Readable: Readable$1, Duplex, PassThrough } = __require("stream");
	var { InvalidArgumentError, InvalidReturnValueError, RequestAbortedError } = require_errors();
	var util = require_util$6();
	var { AsyncResource: AsyncResource$2 } = __require("async_hooks");
	var { addSignal, removeSignal } = require_abort_signal();
	var assert$10 = __require("assert");
	var kResume = Symbol("resume");
	var PipelineRequest = class extends Readable$1 {
		constructor() {
			super({ autoDestroy: true });
			this[kResume] = null;
		}
		_read() {
			const { [kResume]: resume } = this;
			if (resume) {
				this[kResume] = null;
				resume();
			}
		}
		_destroy(err, callback) {
			this._read();
			callback(err);
		}
	};
	var PipelineResponse = class extends Readable$1 {
		constructor(resume) {
			super({ autoDestroy: true });
			this[kResume] = resume;
		}
		_read() {
			this[kResume]();
		}
		_destroy(err, callback) {
			if (!err && !this._readableState.endEmitted) err = new RequestAbortedError();
			callback(err);
		}
	};
	var PipelineHandler = class extends AsyncResource$2 {
		constructor(opts, handler) {
			if (!opts || typeof opts !== "object") throw new InvalidArgumentError("invalid opts");
			if (typeof handler !== "function") throw new InvalidArgumentError("invalid handler");
			const { signal, method, opaque, onInfo, responseHeaders } = opts;
			if (signal && typeof signal.on !== "function" && typeof signal.addEventListener !== "function") throw new InvalidArgumentError("signal must be an EventEmitter or EventTarget");
			if (method === "CONNECT") throw new InvalidArgumentError("invalid method");
			if (onInfo && typeof onInfo !== "function") throw new InvalidArgumentError("invalid onInfo callback");
			super("UNDICI_PIPELINE");
			this.opaque = opaque || null;
			this.responseHeaders = responseHeaders || null;
			this.handler = handler;
			this.abort = null;
			this.context = null;
			this.onInfo = onInfo || null;
			this.req = new PipelineRequest().on("error", util.nop);
			this.ret = new Duplex({
				readableObjectMode: opts.objectMode,
				autoDestroy: true,
				read: () => {
					const { body } = this;
					if (body && body.resume) body.resume();
				},
				write: (chunk, encoding, callback) => {
					const { req } = this;
					if (req.push(chunk, encoding) || req._readableState.destroyed) callback();
					else req[kResume] = callback;
				},
				destroy: (err, callback) => {
					const { body, req, res, ret, abort } = this;
					if (!err && !ret._readableState.endEmitted) err = new RequestAbortedError();
					if (abort && err) abort();
					util.destroy(body, err);
					util.destroy(req, err);
					util.destroy(res, err);
					removeSignal(this);
					callback(err);
				}
			}).on("prefinish", () => {
				const { req } = this;
				req.push(null);
			});
			this.res = null;
			addSignal(this, signal);
		}
		onConnect(abort, context) {
			const { ret, res } = this;
			assert$10(!res, "pipeline cannot be retried");
			if (ret.destroyed) throw new RequestAbortedError();
			this.abort = abort;
			this.context = context;
		}
		onHeaders(statusCode, rawHeaders, resume) {
			const { opaque, handler, context } = this;
			if (statusCode < 200) {
				if (this.onInfo) {
					const headers = this.responseHeaders === "raw" ? util.parseRawHeaders(rawHeaders) : util.parseHeaders(rawHeaders);
					this.onInfo({
						statusCode,
						headers
					});
				}
				return;
			}
			this.res = new PipelineResponse(resume);
			let body;
			try {
				this.handler = null;
				const headers = this.responseHeaders === "raw" ? util.parseRawHeaders(rawHeaders) : util.parseHeaders(rawHeaders);
				body = this.runInAsyncScope(handler, null, {
					statusCode,
					headers,
					opaque,
					body: this.res,
					context
				});
			} catch (err) {
				this.res.on("error", util.nop);
				throw err;
			}
			if (!body || typeof body.on !== "function") throw new InvalidReturnValueError("expected Readable");
			body.on("data", (chunk) => {
				const { ret, body } = this;
				if (!ret.push(chunk) && body.pause) body.pause();
			}).on("error", (err) => {
				const { ret } = this;
				util.destroy(ret, err);
			}).on("end", () => {
				const { ret } = this;
				ret.push(null);
			}).on("close", () => {
				const { ret } = this;
				if (!ret._readableState.ended) util.destroy(ret, new RequestAbortedError());
			});
			this.body = body;
		}
		onData(chunk) {
			const { res } = this;
			return res.push(chunk);
		}
		onComplete(trailers) {
			const { res } = this;
			res.push(null);
		}
		onError(err) {
			const { ret } = this;
			this.handler = null;
			util.destroy(ret, err);
		}
	};
	function pipeline(opts, handler) {
		try {
			const pipelineHandler = new PipelineHandler(opts, handler);
			this.dispatch({
				...opts,
				body: pipelineHandler.req
			}, pipelineHandler);
			return pipelineHandler.ret;
		} catch (err) {
			return new PassThrough().destroy(err);
		}
	}
	module.exports = pipeline;
}));
//#endregion
//#region node_modules/undici/lib/api/api-upgrade.js
var require_api_upgrade = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { InvalidArgumentError, RequestAbortedError, SocketError } = require_errors();
	var { AsyncResource: AsyncResource$1 } = __require("async_hooks");
	var util = require_util$6();
	var { addSignal, removeSignal } = require_abort_signal();
	var assert$9 = __require("assert");
	var UpgradeHandler = class extends AsyncResource$1 {
		constructor(opts, callback) {
			if (!opts || typeof opts !== "object") throw new InvalidArgumentError("invalid opts");
			if (typeof callback !== "function") throw new InvalidArgumentError("invalid callback");
			const { signal, opaque, responseHeaders } = opts;
			if (signal && typeof signal.on !== "function" && typeof signal.addEventListener !== "function") throw new InvalidArgumentError("signal must be an EventEmitter or EventTarget");
			super("UNDICI_UPGRADE");
			this.responseHeaders = responseHeaders || null;
			this.opaque = opaque || null;
			this.callback = callback;
			this.abort = null;
			this.context = null;
			addSignal(this, signal);
		}
		onConnect(abort, context) {
			if (!this.callback) throw new RequestAbortedError();
			this.abort = abort;
			this.context = null;
		}
		onHeaders() {
			throw new SocketError("bad upgrade", null);
		}
		onUpgrade(statusCode, rawHeaders, socket) {
			const { callback, opaque, context } = this;
			assert$9.strictEqual(statusCode, 101);
			removeSignal(this);
			this.callback = null;
			const headers = this.responseHeaders === "raw" ? util.parseRawHeaders(rawHeaders) : util.parseHeaders(rawHeaders);
			this.runInAsyncScope(callback, null, null, {
				headers,
				socket,
				opaque,
				context
			});
		}
		onError(err) {
			const { callback, opaque } = this;
			removeSignal(this);
			if (callback) {
				this.callback = null;
				queueMicrotask(() => {
					this.runInAsyncScope(callback, null, err, { opaque });
				});
			}
		}
	};
	function upgrade(opts, callback) {
		if (callback === void 0) return new Promise((resolve, reject) => {
			upgrade.call(this, opts, (err, data) => {
				return err ? reject(err) : resolve(data);
			});
		});
		try {
			const upgradeHandler = new UpgradeHandler(opts, callback);
			this.dispatch({
				...opts,
				method: opts.method || "GET",
				upgrade: opts.protocol || "Websocket"
			}, upgradeHandler);
		} catch (err) {
			if (typeof callback !== "function") throw err;
			const opaque = opts && opts.opaque;
			queueMicrotask(() => callback(err, { opaque }));
		}
	}
	module.exports = upgrade;
}));
//#endregion
//#region node_modules/undici/lib/api/api-connect.js
var require_api_connect = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { AsyncResource } = __require("async_hooks");
	var { InvalidArgumentError, RequestAbortedError, SocketError } = require_errors();
	var util = require_util$6();
	var { addSignal, removeSignal } = require_abort_signal();
	var ConnectHandler = class extends AsyncResource {
		constructor(opts, callback) {
			if (!opts || typeof opts !== "object") throw new InvalidArgumentError("invalid opts");
			if (typeof callback !== "function") throw new InvalidArgumentError("invalid callback");
			const { signal, opaque, responseHeaders } = opts;
			if (signal && typeof signal.on !== "function" && typeof signal.addEventListener !== "function") throw new InvalidArgumentError("signal must be an EventEmitter or EventTarget");
			super("UNDICI_CONNECT");
			this.opaque = opaque || null;
			this.responseHeaders = responseHeaders || null;
			this.callback = callback;
			this.abort = null;
			addSignal(this, signal);
		}
		onConnect(abort, context) {
			if (!this.callback) throw new RequestAbortedError();
			this.abort = abort;
			this.context = context;
		}
		onHeaders() {
			throw new SocketError("bad connect", null);
		}
		onUpgrade(statusCode, rawHeaders, socket) {
			const { callback, opaque, context } = this;
			removeSignal(this);
			this.callback = null;
			let headers = rawHeaders;
			if (headers != null) headers = this.responseHeaders === "raw" ? util.parseRawHeaders(rawHeaders) : util.parseHeaders(rawHeaders);
			this.runInAsyncScope(callback, null, null, {
				statusCode,
				headers,
				socket,
				opaque,
				context
			});
		}
		onError(err) {
			const { callback, opaque } = this;
			removeSignal(this);
			if (callback) {
				this.callback = null;
				queueMicrotask(() => {
					this.runInAsyncScope(callback, null, err, { opaque });
				});
			}
		}
	};
	function connect(opts, callback) {
		if (callback === void 0) return new Promise((resolve, reject) => {
			connect.call(this, opts, (err, data) => {
				return err ? reject(err) : resolve(data);
			});
		});
		try {
			const connectHandler = new ConnectHandler(opts, callback);
			this.dispatch({
				...opts,
				method: "CONNECT"
			}, connectHandler);
		} catch (err) {
			if (typeof callback !== "function") throw err;
			const opaque = opts && opts.opaque;
			queueMicrotask(() => callback(err, { opaque }));
		}
	}
	module.exports = connect;
}));
//#endregion
//#region node_modules/undici/lib/api/index.js
var require_api = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports.request = require_api_request();
	module.exports.stream = require_api_stream();
	module.exports.pipeline = require_api_pipeline();
	module.exports.upgrade = require_api_upgrade();
	module.exports.connect = require_api_connect();
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-errors.js
var require_mock_errors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { UndiciError } = require_errors();
	module.exports = { MockNotMatchedError: class MockNotMatchedError extends UndiciError {
		constructor(message) {
			super(message);
			Error.captureStackTrace(this, MockNotMatchedError);
			this.name = "MockNotMatchedError";
			this.message = message || "The request does not match any registered mock dispatches";
			this.code = "UND_MOCK_ERR_MOCK_NOT_MATCHED";
		}
	} };
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-symbols.js
var require_mock_symbols = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		kAgent: Symbol("agent"),
		kOptions: Symbol("options"),
		kFactory: Symbol("factory"),
		kDispatches: Symbol("dispatches"),
		kDispatchKey: Symbol("dispatch key"),
		kDefaultHeaders: Symbol("default headers"),
		kDefaultTrailers: Symbol("default trailers"),
		kContentLength: Symbol("content length"),
		kMockAgent: Symbol("mock agent"),
		kMockAgentSet: Symbol("mock agent set"),
		kMockAgentGet: Symbol("mock agent get"),
		kMockDispatch: Symbol("mock dispatch"),
		kClose: Symbol("close"),
		kOriginalClose: Symbol("original agent close"),
		kOrigin: Symbol("origin"),
		kIsMockActive: Symbol("is mock active"),
		kNetConnect: Symbol("net connect"),
		kGetNetConnect: Symbol("get net connect"),
		kConnected: Symbol("connected")
	};
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-utils.js
var require_mock_utils = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { MockNotMatchedError } = require_mock_errors();
	var { kDispatches, kMockAgent, kOriginalDispatch, kOrigin, kGetNetConnect } = require_mock_symbols();
	var { buildURL, nop } = require_util$6();
	var { STATUS_CODES: STATUS_CODES$1 } = __require("http");
	var { types: { isPromise } } = __require("util");
	function matchValue(match, value) {
		if (typeof match === "string") return match === value;
		if (match instanceof RegExp) return match.test(value);
		if (typeof match === "function") return match(value) === true;
		return false;
	}
	function lowerCaseEntries(headers) {
		return Object.fromEntries(Object.entries(headers).map(([headerName, headerValue]) => {
			return [headerName.toLocaleLowerCase(), headerValue];
		}));
	}
	/**
	* @param {import('../../index').Headers|string[]|Record<string, string>} headers
	* @param {string} key
	*/
	function getHeaderByName(headers, key) {
		if (Array.isArray(headers)) {
			for (let i = 0; i < headers.length; i += 2) if (headers[i].toLocaleLowerCase() === key.toLocaleLowerCase()) return headers[i + 1];
			return;
		} else if (typeof headers.get === "function") return headers.get(key);
		else return lowerCaseEntries(headers)[key.toLocaleLowerCase()];
	}
	/** @param {string[]} headers */
	function buildHeadersFromArray(headers) {
		const clone = headers.slice();
		const entries = [];
		for (let index = 0; index < clone.length; index += 2) entries.push([clone[index], clone[index + 1]]);
		return Object.fromEntries(entries);
	}
	function matchHeaders(mockDispatch, headers) {
		if (typeof mockDispatch.headers === "function") {
			if (Array.isArray(headers)) headers = buildHeadersFromArray(headers);
			return mockDispatch.headers(headers ? lowerCaseEntries(headers) : {});
		}
		if (typeof mockDispatch.headers === "undefined") return true;
		if (typeof headers !== "object" || typeof mockDispatch.headers !== "object") return false;
		for (const [matchHeaderName, matchHeaderValue] of Object.entries(mockDispatch.headers)) if (!matchValue(matchHeaderValue, getHeaderByName(headers, matchHeaderName))) return false;
		return true;
	}
	function safeUrl(path) {
		if (typeof path !== "string") return path;
		const pathSegments = path.split("?");
		if (pathSegments.length !== 2) return path;
		const qp = new URLSearchParams(pathSegments.pop());
		qp.sort();
		return [...pathSegments, qp.toString()].join("?");
	}
	function matchKey(mockDispatch, { path, method, body, headers }) {
		const pathMatch = matchValue(mockDispatch.path, path);
		const methodMatch = matchValue(mockDispatch.method, method);
		const bodyMatch = typeof mockDispatch.body !== "undefined" ? matchValue(mockDispatch.body, body) : true;
		const headersMatch = matchHeaders(mockDispatch, headers);
		return pathMatch && methodMatch && bodyMatch && headersMatch;
	}
	function getResponseData(data) {
		if (Buffer.isBuffer(data)) return data;
		else if (typeof data === "object") return JSON.stringify(data);
		else return data.toString();
	}
	function getMockDispatch(mockDispatches, key) {
		const basePath = key.query ? buildURL(key.path, key.query) : key.path;
		const resolvedPath = typeof basePath === "string" ? safeUrl(basePath) : basePath;
		let matchedMockDispatches = mockDispatches.filter(({ consumed }) => !consumed).filter(({ path }) => matchValue(safeUrl(path), resolvedPath));
		if (matchedMockDispatches.length === 0) throw new MockNotMatchedError(`Mock dispatch not matched for path '${resolvedPath}'`);
		matchedMockDispatches = matchedMockDispatches.filter(({ method }) => matchValue(method, key.method));
		if (matchedMockDispatches.length === 0) throw new MockNotMatchedError(`Mock dispatch not matched for method '${key.method}'`);
		matchedMockDispatches = matchedMockDispatches.filter(({ body }) => typeof body !== "undefined" ? matchValue(body, key.body) : true);
		if (matchedMockDispatches.length === 0) throw new MockNotMatchedError(`Mock dispatch not matched for body '${key.body}'`);
		matchedMockDispatches = matchedMockDispatches.filter((mockDispatch) => matchHeaders(mockDispatch, key.headers));
		if (matchedMockDispatches.length === 0) throw new MockNotMatchedError(`Mock dispatch not matched for headers '${typeof key.headers === "object" ? JSON.stringify(key.headers) : key.headers}'`);
		return matchedMockDispatches[0];
	}
	function addMockDispatch(mockDispatches, key, data) {
		const baseData = {
			timesInvoked: 0,
			times: 1,
			persist: false,
			consumed: false
		};
		const replyData = typeof data === "function" ? { callback: data } : { ...data };
		const newMockDispatch = {
			...baseData,
			...key,
			pending: true,
			data: {
				error: null,
				...replyData
			}
		};
		mockDispatches.push(newMockDispatch);
		return newMockDispatch;
	}
	function deleteMockDispatch(mockDispatches, key) {
		const index = mockDispatches.findIndex((dispatch) => {
			if (!dispatch.consumed) return false;
			return matchKey(dispatch, key);
		});
		if (index !== -1) mockDispatches.splice(index, 1);
	}
	function buildKey(opts) {
		const { path, method, body, headers, query } = opts;
		return {
			path,
			method,
			body,
			headers,
			query
		};
	}
	function generateKeyValues(data) {
		return Object.entries(data).reduce((keyValuePairs, [key, value]) => [
			...keyValuePairs,
			Buffer.from(`${key}`),
			Array.isArray(value) ? value.map((x) => Buffer.from(`${x}`)) : Buffer.from(`${value}`)
		], []);
	}
	/**
	* @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Status
	* @param {number} statusCode
	*/
	function getStatusText(statusCode) {
		return STATUS_CODES$1[statusCode] || "unknown";
	}
	async function getResponse(body) {
		const buffers = [];
		for await (const data of body) buffers.push(data);
		return Buffer.concat(buffers).toString("utf8");
	}
	/**
	* Mock dispatch function used to simulate undici dispatches
	*/
	function mockDispatch(opts, handler) {
		const key = buildKey(opts);
		const mockDispatch = getMockDispatch(this[kDispatches], key);
		mockDispatch.timesInvoked++;
		if (mockDispatch.data.callback) mockDispatch.data = {
			...mockDispatch.data,
			...mockDispatch.data.callback(opts)
		};
		const { data: { statusCode, data, headers, trailers, error }, delay, persist } = mockDispatch;
		const { timesInvoked, times } = mockDispatch;
		mockDispatch.consumed = !persist && timesInvoked >= times;
		mockDispatch.pending = timesInvoked < times;
		if (error !== null) {
			deleteMockDispatch(this[kDispatches], key);
			handler.onError(error);
			return true;
		}
		if (typeof delay === "number" && delay > 0) setTimeout(() => {
			handleReply(this[kDispatches]);
		}, delay);
		else handleReply(this[kDispatches]);
		function handleReply(mockDispatches, _data = data) {
			const optsHeaders = Array.isArray(opts.headers) ? buildHeadersFromArray(opts.headers) : opts.headers;
			const body = typeof _data === "function" ? _data({
				...opts,
				headers: optsHeaders
			}) : _data;
			if (isPromise(body)) {
				body.then((newData) => handleReply(mockDispatches, newData));
				return;
			}
			const responseData = getResponseData(body);
			const responseHeaders = generateKeyValues(headers);
			const responseTrailers = generateKeyValues(trailers);
			handler.abort = nop;
			handler.onHeaders(statusCode, responseHeaders, resume, getStatusText(statusCode));
			handler.onData(Buffer.from(responseData));
			handler.onComplete(responseTrailers);
			deleteMockDispatch(mockDispatches, key);
		}
		function resume() {}
		return true;
	}
	function buildMockDispatch() {
		const agent = this[kMockAgent];
		const origin = this[kOrigin];
		const originalDispatch = this[kOriginalDispatch];
		return function dispatch(opts, handler) {
			if (agent.isMockActive) try {
				mockDispatch.call(this, opts, handler);
			} catch (error) {
				if (error instanceof MockNotMatchedError) {
					const netConnect = agent[kGetNetConnect]();
					if (netConnect === false) throw new MockNotMatchedError(`${error.message}: subsequent request to origin ${origin} was not allowed (net.connect disabled)`);
					if (checkNetConnect(netConnect, origin)) originalDispatch.call(this, opts, handler);
					else throw new MockNotMatchedError(`${error.message}: subsequent request to origin ${origin} was not allowed (net.connect is not enabled for this origin)`);
				} else throw error;
			}
			else originalDispatch.call(this, opts, handler);
		};
	}
	function checkNetConnect(netConnect, origin) {
		const url = new URL(origin);
		if (netConnect === true) return true;
		else if (Array.isArray(netConnect) && netConnect.some((matcher) => matchValue(matcher, url.host))) return true;
		return false;
	}
	function buildMockOptions(opts) {
		if (opts) {
			const { agent, ...mockOptions } = opts;
			return mockOptions;
		}
	}
	module.exports = {
		getResponseData,
		getMockDispatch,
		addMockDispatch,
		deleteMockDispatch,
		buildKey,
		generateKeyValues,
		matchValue,
		getResponse,
		getStatusText,
		mockDispatch,
		buildMockDispatch,
		checkNetConnect,
		buildMockOptions,
		getHeaderByName
	};
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-interceptor.js
var require_mock_interceptor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { getResponseData, buildKey, addMockDispatch } = require_mock_utils();
	var { kDispatches, kDispatchKey, kDefaultHeaders, kDefaultTrailers, kContentLength, kMockDispatch } = require_mock_symbols();
	var { InvalidArgumentError } = require_errors();
	var { buildURL } = require_util$6();
	/**
	* Defines the scope API for an interceptor reply
	*/
	var MockScope = class {
		constructor(mockDispatch) {
			this[kMockDispatch] = mockDispatch;
		}
		/**
		* Delay a reply by a set amount in ms.
		*/
		delay(waitInMs) {
			if (typeof waitInMs !== "number" || !Number.isInteger(waitInMs) || waitInMs <= 0) throw new InvalidArgumentError("waitInMs must be a valid integer > 0");
			this[kMockDispatch].delay = waitInMs;
			return this;
		}
		/**
		* For a defined reply, never mark as consumed.
		*/
		persist() {
			this[kMockDispatch].persist = true;
			return this;
		}
		/**
		* Allow one to define a reply for a set amount of matching requests.
		*/
		times(repeatTimes) {
			if (typeof repeatTimes !== "number" || !Number.isInteger(repeatTimes) || repeatTimes <= 0) throw new InvalidArgumentError("repeatTimes must be a valid integer > 0");
			this[kMockDispatch].times = repeatTimes;
			return this;
		}
	};
	/**
	* Defines an interceptor for a Mock
	*/
	var MockInterceptor = class {
		constructor(opts, mockDispatches) {
			if (typeof opts !== "object") throw new InvalidArgumentError("opts must be an object");
			if (typeof opts.path === "undefined") throw new InvalidArgumentError("opts.path must be defined");
			if (typeof opts.method === "undefined") opts.method = "GET";
			if (typeof opts.path === "string") {
				if (opts.query) opts.path = buildURL(opts.path, opts.query);
				else {
					const parsedURL = new URL(opts.path, "data://");
					opts.path = parsedURL.pathname + parsedURL.search;
				}
			}
			if (typeof opts.method === "string") opts.method = opts.method.toUpperCase();
			this[kDispatchKey] = buildKey(opts);
			this[kDispatches] = mockDispatches;
			this[kDefaultHeaders] = {};
			this[kDefaultTrailers] = {};
			this[kContentLength] = false;
		}
		createMockScopeDispatchData(statusCode, data, responseOptions = {}) {
			const responseData = getResponseData(data);
			const contentLength = this[kContentLength] ? { "content-length": responseData.length } : {};
			return {
				statusCode,
				data,
				headers: {
					...this[kDefaultHeaders],
					...contentLength,
					...responseOptions.headers
				},
				trailers: {
					...this[kDefaultTrailers],
					...responseOptions.trailers
				}
			};
		}
		validateReplyParameters(statusCode, data, responseOptions) {
			if (typeof statusCode === "undefined") throw new InvalidArgumentError("statusCode must be defined");
			if (typeof data === "undefined") throw new InvalidArgumentError("data must be defined");
			if (typeof responseOptions !== "object") throw new InvalidArgumentError("responseOptions must be an object");
		}
		/**
		* Mock an undici request with a defined reply.
		*/
		reply(replyData) {
			if (typeof replyData === "function") {
				const wrappedDefaultsCallback = (opts) => {
					const resolvedData = replyData(opts);
					if (typeof resolvedData !== "object") throw new InvalidArgumentError("reply options callback must return an object");
					const { statusCode, data = "", responseOptions = {} } = resolvedData;
					this.validateReplyParameters(statusCode, data, responseOptions);
					return { ...this.createMockScopeDispatchData(statusCode, data, responseOptions) };
				};
				return new MockScope(addMockDispatch(this[kDispatches], this[kDispatchKey], wrappedDefaultsCallback));
			}
			const [statusCode, data = "", responseOptions = {}] = [...arguments];
			this.validateReplyParameters(statusCode, data, responseOptions);
			const dispatchData = this.createMockScopeDispatchData(statusCode, data, responseOptions);
			return new MockScope(addMockDispatch(this[kDispatches], this[kDispatchKey], dispatchData));
		}
		/**
		* Mock an undici request with a defined error.
		*/
		replyWithError(error) {
			if (typeof error === "undefined") throw new InvalidArgumentError("error must be defined");
			return new MockScope(addMockDispatch(this[kDispatches], this[kDispatchKey], { error }));
		}
		/**
		* Set default reply headers on the interceptor for subsequent replies
		*/
		defaultReplyHeaders(headers) {
			if (typeof headers === "undefined") throw new InvalidArgumentError("headers must be defined");
			this[kDefaultHeaders] = headers;
			return this;
		}
		/**
		* Set default reply trailers on the interceptor for subsequent replies
		*/
		defaultReplyTrailers(trailers) {
			if (typeof trailers === "undefined") throw new InvalidArgumentError("trailers must be defined");
			this[kDefaultTrailers] = trailers;
			return this;
		}
		/**
		* Set reply content length header for replies on the interceptor
		*/
		replyContentLength() {
			this[kContentLength] = true;
			return this;
		}
	};
	module.exports.MockInterceptor = MockInterceptor;
	module.exports.MockScope = MockScope;
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-client.js
var require_mock_client = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { promisify: promisify$1 } = __require("util");
	var Client = require_client();
	var { buildMockDispatch } = require_mock_utils();
	var { kDispatches, kMockAgent, kClose, kOriginalClose, kOrigin, kOriginalDispatch, kConnected } = require_mock_symbols();
	var { MockInterceptor } = require_mock_interceptor();
	var Symbols = require_symbols$4();
	var { InvalidArgumentError } = require_errors();
	/**
	* MockClient provides an API that extends the Client to influence the mockDispatches.
	*/
	var MockClient = class extends Client {
		constructor(origin, opts) {
			super(origin, opts);
			if (!opts || !opts.agent || typeof opts.agent.dispatch !== "function") throw new InvalidArgumentError("Argument opts.agent must implement Agent");
			this[kMockAgent] = opts.agent;
			this[kOrigin] = origin;
			this[kDispatches] = [];
			this[kConnected] = 1;
			this[kOriginalDispatch] = this.dispatch;
			this[kOriginalClose] = this.close.bind(this);
			this.dispatch = buildMockDispatch.call(this);
			this.close = this[kClose];
		}
		get [Symbols.kConnected]() {
			return this[kConnected];
		}
		/**
		* Sets up the base interceptor for mocking replies from undici.
		*/
		intercept(opts) {
			return new MockInterceptor(opts, this[kDispatches]);
		}
		async [kClose]() {
			await promisify$1(this[kOriginalClose])();
			this[kConnected] = 0;
			this[kMockAgent][Symbols.kClients].delete(this[kOrigin]);
		}
	};
	module.exports = MockClient;
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-pool.js
var require_mock_pool = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { promisify } = __require("util");
	var Pool = require_pool();
	var { buildMockDispatch } = require_mock_utils();
	var { kDispatches, kMockAgent, kClose, kOriginalClose, kOrigin, kOriginalDispatch, kConnected } = require_mock_symbols();
	var { MockInterceptor } = require_mock_interceptor();
	var Symbols = require_symbols$4();
	var { InvalidArgumentError } = require_errors();
	/**
	* MockPool provides an API that extends the Pool to influence the mockDispatches.
	*/
	var MockPool = class extends Pool {
		constructor(origin, opts) {
			super(origin, opts);
			if (!opts || !opts.agent || typeof opts.agent.dispatch !== "function") throw new InvalidArgumentError("Argument opts.agent must implement Agent");
			this[kMockAgent] = opts.agent;
			this[kOrigin] = origin;
			this[kDispatches] = [];
			this[kConnected] = 1;
			this[kOriginalDispatch] = this.dispatch;
			this[kOriginalClose] = this.close.bind(this);
			this.dispatch = buildMockDispatch.call(this);
			this.close = this[kClose];
		}
		get [Symbols.kConnected]() {
			return this[kConnected];
		}
		/**
		* Sets up the base interceptor for mocking replies from undici.
		*/
		intercept(opts) {
			return new MockInterceptor(opts, this[kDispatches]);
		}
		async [kClose]() {
			await promisify(this[kOriginalClose])();
			this[kConnected] = 0;
			this[kMockAgent][Symbols.kClients].delete(this[kOrigin]);
		}
	};
	module.exports = MockPool;
}));
//#endregion
//#region node_modules/undici/lib/mock/pluralizer.js
var require_pluralizer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var singulars = {
		pronoun: "it",
		is: "is",
		was: "was",
		this: "this"
	};
	var plurals = {
		pronoun: "they",
		is: "are",
		was: "were",
		this: "these"
	};
	module.exports = class Pluralizer {
		constructor(singular, plural) {
			this.singular = singular;
			this.plural = plural;
		}
		pluralize(count) {
			const one = count === 1;
			const keys = one ? singulars : plurals;
			const noun = one ? this.singular : this.plural;
			return {
				...keys,
				count,
				noun
			};
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/mock/pending-interceptors-formatter.js
var require_pending_interceptors_formatter = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Transform } = __require("stream");
	var { Console } = __require("console");
	/**
	* Gets the output of `console.table(…)` as a string.
	*/
	module.exports = class PendingInterceptorsFormatter {
		constructor({ disableColors } = {}) {
			this.transform = new Transform({ transform(chunk, _enc, cb) {
				cb(null, chunk);
			} });
			this.logger = new Console({
				stdout: this.transform,
				inspectOptions: { colors: !disableColors && !process.env.CI }
			});
		}
		format(pendingInterceptors) {
			const withPrettyHeaders = pendingInterceptors.map(({ method, path, data: { statusCode }, persist, times, timesInvoked, origin }) => ({
				Method: method,
				Origin: origin,
				Path: path,
				"Status code": statusCode,
				Persistent: persist ? "✅" : "❌",
				Invocations: timesInvoked,
				Remaining: persist ? Infinity : times - timesInvoked
			}));
			this.logger.table(withPrettyHeaders);
			return this.transform.read().toString();
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/mock/mock-agent.js
var require_mock_agent = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kClients } = require_symbols$4();
	var Agent = require_agent();
	var { kAgent, kMockAgentSet, kMockAgentGet, kDispatches, kIsMockActive, kNetConnect, kGetNetConnect, kOptions, kFactory } = require_mock_symbols();
	var MockClient = require_mock_client();
	var MockPool = require_mock_pool();
	var { matchValue, buildMockOptions } = require_mock_utils();
	var { InvalidArgumentError, UndiciError } = require_errors();
	var Dispatcher = require_dispatcher();
	var Pluralizer = require_pluralizer();
	var PendingInterceptorsFormatter = require_pending_interceptors_formatter();
	var FakeWeakRef = class {
		constructor(value) {
			this.value = value;
		}
		deref() {
			return this.value;
		}
	};
	var MockAgent = class extends Dispatcher {
		constructor(opts) {
			super(opts);
			this[kNetConnect] = true;
			this[kIsMockActive] = true;
			if (opts && opts.agent && typeof opts.agent.dispatch !== "function") throw new InvalidArgumentError("Argument opts.agent must implement Agent");
			const agent = opts && opts.agent ? opts.agent : new Agent(opts);
			this[kAgent] = agent;
			this[kClients] = agent[kClients];
			this[kOptions] = buildMockOptions(opts);
		}
		get(origin) {
			let dispatcher = this[kMockAgentGet](origin);
			if (!dispatcher) {
				dispatcher = this[kFactory](origin);
				this[kMockAgentSet](origin, dispatcher);
			}
			return dispatcher;
		}
		dispatch(opts, handler) {
			this.get(opts.origin);
			return this[kAgent].dispatch(opts, handler);
		}
		async close() {
			await this[kAgent].close();
			this[kClients].clear();
		}
		deactivate() {
			this[kIsMockActive] = false;
		}
		activate() {
			this[kIsMockActive] = true;
		}
		enableNetConnect(matcher) {
			if (typeof matcher === "string" || typeof matcher === "function" || matcher instanceof RegExp) {
				if (Array.isArray(this[kNetConnect])) this[kNetConnect].push(matcher);
				else this[kNetConnect] = [matcher];
			} else if (typeof matcher === "undefined") this[kNetConnect] = true;
			else throw new InvalidArgumentError("Unsupported matcher. Must be one of String|Function|RegExp.");
		}
		disableNetConnect() {
			this[kNetConnect] = false;
		}
		get isMockActive() {
			return this[kIsMockActive];
		}
		[kMockAgentSet](origin, dispatcher) {
			this[kClients].set(origin, new FakeWeakRef(dispatcher));
		}
		[kFactory](origin) {
			const mockOptions = Object.assign({ agent: this }, this[kOptions]);
			return this[kOptions] && this[kOptions].connections === 1 ? new MockClient(origin, mockOptions) : new MockPool(origin, mockOptions);
		}
		[kMockAgentGet](origin) {
			const ref = this[kClients].get(origin);
			if (ref) return ref.deref();
			if (typeof origin !== "string") {
				const dispatcher = this[kFactory]("http://localhost:9999");
				this[kMockAgentSet](origin, dispatcher);
				return dispatcher;
			}
			for (const [keyMatcher, nonExplicitRef] of Array.from(this[kClients])) {
				const nonExplicitDispatcher = nonExplicitRef.deref();
				if (nonExplicitDispatcher && typeof keyMatcher !== "string" && matchValue(keyMatcher, origin)) {
					const dispatcher = this[kFactory](origin);
					this[kMockAgentSet](origin, dispatcher);
					dispatcher[kDispatches] = nonExplicitDispatcher[kDispatches];
					return dispatcher;
				}
			}
		}
		[kGetNetConnect]() {
			return this[kNetConnect];
		}
		pendingInterceptors() {
			const mockAgentClients = this[kClients];
			return Array.from(mockAgentClients.entries()).flatMap(([origin, scope]) => scope.deref()[kDispatches].map((dispatch) => ({
				...dispatch,
				origin
			}))).filter(({ pending }) => pending);
		}
		assertNoPendingInterceptors({ pendingInterceptorsFormatter = new PendingInterceptorsFormatter() } = {}) {
			const pending = this.pendingInterceptors();
			if (pending.length === 0) return;
			const pluralizer = new Pluralizer("interceptor", "interceptors").pluralize(pending.length);
			throw new UndiciError(`
${pluralizer.count} ${pluralizer.noun} ${pluralizer.is} pending:

${pendingInterceptorsFormatter.format(pending)}
`.trim());
		}
	};
	module.exports = MockAgent;
}));
//#endregion
//#region node_modules/undici/lib/proxy-agent.js
var require_proxy_agent = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kProxy, kClose, kDestroy, kInterceptors } = require_symbols$4();
	var { URL: URL$1 } = __require("url");
	var Agent = require_agent();
	var Pool = require_pool();
	var DispatcherBase = require_dispatcher_base();
	var { InvalidArgumentError, RequestAbortedError } = require_errors();
	var buildConnector = require_connect();
	var kAgent = Symbol("proxy agent");
	var kClient = Symbol("proxy client");
	var kProxyHeaders = Symbol("proxy headers");
	var kRequestTls = Symbol("request tls settings");
	var kProxyTls = Symbol("proxy tls settings");
	var kConnectEndpoint = Symbol("connect endpoint function");
	function defaultProtocolPort(protocol) {
		return protocol === "https:" ? 443 : 80;
	}
	function buildProxyOptions(opts) {
		if (typeof opts === "string") opts = { uri: opts };
		if (!opts || !opts.uri) throw new InvalidArgumentError("Proxy opts.uri is mandatory");
		return {
			uri: opts.uri,
			protocol: opts.protocol || "https"
		};
	}
	function defaultFactory(origin, opts) {
		return new Pool(origin, opts);
	}
	var ProxyAgent = class extends DispatcherBase {
		constructor(opts) {
			super(opts);
			this[kProxy] = buildProxyOptions(opts);
			this[kAgent] = new Agent(opts);
			this[kInterceptors] = opts.interceptors && opts.interceptors.ProxyAgent && Array.isArray(opts.interceptors.ProxyAgent) ? opts.interceptors.ProxyAgent : [];
			if (typeof opts === "string") opts = { uri: opts };
			if (!opts || !opts.uri) throw new InvalidArgumentError("Proxy opts.uri is mandatory");
			const { clientFactory = defaultFactory } = opts;
			if (typeof clientFactory !== "function") throw new InvalidArgumentError("Proxy opts.clientFactory must be a function.");
			this[kRequestTls] = opts.requestTls;
			this[kProxyTls] = opts.proxyTls;
			this[kProxyHeaders] = opts.headers || {};
			const resolvedUrl = new URL$1(opts.uri);
			const { origin, port, host, username, password } = resolvedUrl;
			if (opts.auth && opts.token) throw new InvalidArgumentError("opts.auth cannot be used in combination with opts.token");
			else if (opts.auth) this[kProxyHeaders]["proxy-authorization"] = `Basic ${opts.auth}`;
			else if (opts.token) this[kProxyHeaders]["proxy-authorization"] = opts.token;
			else if (username && password) this[kProxyHeaders]["proxy-authorization"] = `Basic ${Buffer.from(`${decodeURIComponent(username)}:${decodeURIComponent(password)}`).toString("base64")}`;
			const connect = buildConnector({ ...opts.proxyTls });
			this[kConnectEndpoint] = buildConnector({ ...opts.requestTls });
			this[kClient] = clientFactory(resolvedUrl, { connect });
			this[kAgent] = new Agent({
				...opts,
				connect: async (opts, callback) => {
					let requestedHost = opts.host;
					if (!opts.port) requestedHost += `:${defaultProtocolPort(opts.protocol)}`;
					try {
						const { socket, statusCode } = await this[kClient].connect({
							origin,
							port,
							path: requestedHost,
							signal: opts.signal,
							headers: {
								...this[kProxyHeaders],
								host
							}
						});
						if (statusCode !== 200) {
							socket.on("error", () => {}).destroy();
							callback(new RequestAbortedError(`Proxy response (${statusCode}) !== 200 when HTTP Tunneling`));
						}
						if (opts.protocol !== "https:") {
							callback(null, socket);
							return;
						}
						let servername;
						if (this[kRequestTls]) servername = this[kRequestTls].servername;
						else servername = opts.servername;
						this[kConnectEndpoint]({
							...opts,
							servername,
							httpSocket: socket
						}, callback);
					} catch (err) {
						callback(err);
					}
				}
			});
		}
		dispatch(opts, handler) {
			const { host } = new URL$1(opts.origin);
			const headers = buildHeaders(opts.headers);
			throwIfProxyAuthIsSent(headers);
			return this[kAgent].dispatch({
				...opts,
				headers: {
					...headers,
					host
				}
			}, handler);
		}
		async [kClose]() {
			await this[kAgent].close();
			await this[kClient].close();
		}
		async [kDestroy]() {
			await this[kAgent].destroy();
			await this[kClient].destroy();
		}
	};
	/**
	* @param {string[] | Record<string, string>} headers
	* @returns {Record<string, string>}
	*/
	function buildHeaders(headers) {
		if (Array.isArray(headers)) {
			/** @type {Record<string, string>} */
			const headersPair = {};
			for (let i = 0; i < headers.length; i += 2) headersPair[headers[i]] = headers[i + 1];
			return headersPair;
		}
		return headers;
	}
	/**
	* @param {Record<string, string>} headers
	*
	* Previous versions of ProxyAgent suggests the Proxy-Authorization in request headers
	* Nevertheless, it was changed and to avoid a security vulnerability by end users
	* this check was created.
	* It should be removed in the next major version for performance reasons
	*/
	function throwIfProxyAuthIsSent(headers) {
		if (headers && Object.keys(headers).find((key) => key.toLowerCase() === "proxy-authorization")) throw new InvalidArgumentError("Proxy-Authorization should be sent in ProxyAgent constructor");
	}
	module.exports = ProxyAgent;
}));
//#endregion
//#region node_modules/undici/lib/handler/RetryHandler.js
var require_RetryHandler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$8 = __require("assert");
	var { kRetryHandlerDefaultRetry } = require_symbols$4();
	var { RequestRetryError } = require_errors();
	var { isDisturbed, parseHeaders, parseRangeHeader } = require_util$6();
	function calculateRetryAfterHeader(retryAfter) {
		const current = Date.now();
		return new Date(retryAfter).getTime() - current;
	}
	module.exports = class RetryHandler {
		constructor(opts, handlers) {
			const { retryOptions, ...dispatchOpts } = opts;
			const { retry: retryFn, maxRetries, maxTimeout, minTimeout, timeoutFactor, methods, errorCodes, retryAfter, statusCodes } = retryOptions ?? {};
			this.dispatch = handlers.dispatch;
			this.handler = handlers.handler;
			this.opts = dispatchOpts;
			this.abort = null;
			this.aborted = false;
			this.retryOpts = {
				retry: retryFn ?? RetryHandler[kRetryHandlerDefaultRetry],
				retryAfter: retryAfter ?? true,
				maxTimeout: maxTimeout ?? 3e4,
				timeout: minTimeout ?? 500,
				timeoutFactor: timeoutFactor ?? 2,
				maxRetries: maxRetries ?? 5,
				methods: methods ?? [
					"GET",
					"HEAD",
					"OPTIONS",
					"PUT",
					"DELETE",
					"TRACE"
				],
				statusCodes: statusCodes ?? [
					500,
					502,
					503,
					504,
					429
				],
				errorCodes: errorCodes ?? [
					"ECONNRESET",
					"ECONNREFUSED",
					"ENOTFOUND",
					"ENETDOWN",
					"ENETUNREACH",
					"EHOSTDOWN",
					"EHOSTUNREACH",
					"EPIPE"
				]
			};
			this.retryCount = 0;
			this.start = 0;
			this.end = null;
			this.etag = null;
			this.resume = null;
			this.handler.onConnect((reason) => {
				this.aborted = true;
				if (this.abort) this.abort(reason);
				else this.reason = reason;
			});
		}
		onRequestSent() {
			if (this.handler.onRequestSent) this.handler.onRequestSent();
		}
		onUpgrade(statusCode, headers, socket) {
			if (this.handler.onUpgrade) this.handler.onUpgrade(statusCode, headers, socket);
		}
		onConnect(abort) {
			if (this.aborted) abort(this.reason);
			else this.abort = abort;
		}
		onBodySent(chunk) {
			if (this.handler.onBodySent) return this.handler.onBodySent(chunk);
		}
		static [kRetryHandlerDefaultRetry](err, { state, opts }, cb) {
			const { statusCode, code, headers } = err;
			const { method, retryOptions } = opts;
			const { maxRetries, timeout, maxTimeout, timeoutFactor, statusCodes, errorCodes, methods } = retryOptions;
			let { counter, currentTimeout } = state;
			currentTimeout = currentTimeout != null && currentTimeout > 0 ? currentTimeout : timeout;
			if (code && code !== "UND_ERR_REQ_RETRY" && code !== "UND_ERR_SOCKET" && !errorCodes.includes(code)) {
				cb(err);
				return;
			}
			if (Array.isArray(methods) && !methods.includes(method)) {
				cb(err);
				return;
			}
			if (statusCode != null && Array.isArray(statusCodes) && !statusCodes.includes(statusCode)) {
				cb(err);
				return;
			}
			if (counter > maxRetries) {
				cb(err);
				return;
			}
			let retryAfterHeader = headers != null && headers["retry-after"];
			if (retryAfterHeader) {
				retryAfterHeader = Number(retryAfterHeader);
				retryAfterHeader = isNaN(retryAfterHeader) ? calculateRetryAfterHeader(retryAfterHeader) : retryAfterHeader * 1e3;
			}
			const retryTimeout = retryAfterHeader > 0 ? Math.min(retryAfterHeader, maxTimeout) : Math.min(currentTimeout * timeoutFactor ** counter, maxTimeout);
			state.currentTimeout = retryTimeout;
			setTimeout(() => cb(null), retryTimeout);
		}
		onHeaders(statusCode, rawHeaders, resume, statusMessage) {
			const headers = parseHeaders(rawHeaders);
			this.retryCount += 1;
			if (statusCode >= 300) {
				this.abort(new RequestRetryError("Request failed", statusCode, {
					headers,
					count: this.retryCount
				}));
				return false;
			}
			if (this.resume != null) {
				this.resume = null;
				if (statusCode !== 206) return true;
				const contentRange = parseRangeHeader(headers["content-range"]);
				if (!contentRange) {
					this.abort(new RequestRetryError("Content-Range mismatch", statusCode, {
						headers,
						count: this.retryCount
					}));
					return false;
				}
				if (this.etag != null && this.etag !== headers.etag) {
					this.abort(new RequestRetryError("ETag mismatch", statusCode, {
						headers,
						count: this.retryCount
					}));
					return false;
				}
				const { start, size, end = size } = contentRange;
				assert$8(this.start === start, "content-range mismatch");
				assert$8(this.end == null || this.end === end, "content-range mismatch");
				this.resume = resume;
				return true;
			}
			if (this.end == null) {
				if (statusCode === 206) {
					const range = parseRangeHeader(headers["content-range"]);
					if (range == null) return this.handler.onHeaders(statusCode, rawHeaders, resume, statusMessage);
					const { start, size, end = size } = range;
					assert$8(start != null && Number.isFinite(start) && this.start !== start, "content-range mismatch");
					assert$8(Number.isFinite(start));
					assert$8(end != null && Number.isFinite(end) && this.end !== end, "invalid content-length");
					this.start = start;
					this.end = end;
				}
				if (this.end == null) {
					const contentLength = headers["content-length"];
					this.end = contentLength != null ? Number(contentLength) : null;
				}
				assert$8(Number.isFinite(this.start));
				assert$8(this.end == null || Number.isFinite(this.end), "invalid content-length");
				this.resume = resume;
				this.etag = headers.etag != null ? headers.etag : null;
				return this.handler.onHeaders(statusCode, rawHeaders, resume, statusMessage);
			}
			const err = new RequestRetryError("Request failed", statusCode, {
				headers,
				count: this.retryCount
			});
			this.abort(err);
			return false;
		}
		onData(chunk) {
			this.start += chunk.length;
			return this.handler.onData(chunk);
		}
		onComplete(rawTrailers) {
			this.retryCount = 0;
			return this.handler.onComplete(rawTrailers);
		}
		onError(err) {
			if (this.aborted || isDisturbed(this.opts.body)) return this.handler.onError(err);
			this.retryOpts.retry(err, {
				state: {
					counter: this.retryCount++,
					currentTimeout: this.retryAfter
				},
				opts: {
					retryOptions: this.retryOpts,
					...this.opts
				}
			}, onRetry.bind(this));
			function onRetry(err) {
				if (err != null || this.aborted || isDisturbed(this.opts.body)) return this.handler.onError(err);
				if (this.start !== 0) this.opts = {
					...this.opts,
					headers: {
						...this.opts.headers,
						range: `bytes=${this.start}-${this.end ?? ""}`
					}
				};
				try {
					this.dispatch(this.opts, this);
				} catch (err) {
					this.handler.onError(err);
				}
			}
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/global.js
var require_global = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var globalDispatcher = Symbol.for("undici.globalDispatcher.1");
	var { InvalidArgumentError } = require_errors();
	var Agent = require_agent();
	if (getGlobalDispatcher() === void 0) setGlobalDispatcher(new Agent());
	function setGlobalDispatcher(agent) {
		if (!agent || typeof agent.dispatch !== "function") throw new InvalidArgumentError("Argument agent must implement Agent");
		Object.defineProperty(globalThis, globalDispatcher, {
			value: agent,
			writable: true,
			enumerable: false,
			configurable: false
		});
	}
	function getGlobalDispatcher() {
		return globalThis[globalDispatcher];
	}
	module.exports = {
		setGlobalDispatcher,
		getGlobalDispatcher
	};
}));
//#endregion
//#region node_modules/undici/lib/handler/DecoratorHandler.js
var require_DecoratorHandler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = class DecoratorHandler {
		constructor(handler) {
			this.handler = handler;
		}
		onConnect(...args) {
			return this.handler.onConnect(...args);
		}
		onError(...args) {
			return this.handler.onError(...args);
		}
		onUpgrade(...args) {
			return this.handler.onUpgrade(...args);
		}
		onHeaders(...args) {
			return this.handler.onHeaders(...args);
		}
		onData(...args) {
			return this.handler.onData(...args);
		}
		onComplete(...args) {
			return this.handler.onComplete(...args);
		}
		onBodySent(...args) {
			return this.handler.onBodySent(...args);
		}
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/headers.js
var require_headers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kHeadersList, kConstruct } = require_symbols$4();
	var { kGuard } = require_symbols$3();
	var { kEnumerableProperty } = require_util$6();
	var { makeIterator, isValidHeaderName, isValidHeaderValue } = require_util$5();
	var { webidl } = require_webidl();
	var assert$7 = __require("assert");
	var kHeadersMap = Symbol("headers map");
	var kHeadersSortedMap = Symbol("headers map sorted");
	/**
	* @param {number} code
	*/
	function isHTTPWhiteSpaceCharCode(code) {
		return code === 10 || code === 13 || code === 9 || code === 32;
	}
	/**
	* @see https://fetch.spec.whatwg.org/#concept-header-value-normalize
	* @param {string} potentialValue
	*/
	function headerValueNormalize(potentialValue) {
		let i = 0;
		let j = potentialValue.length;
		while (j > i && isHTTPWhiteSpaceCharCode(potentialValue.charCodeAt(j - 1))) --j;
		while (j > i && isHTTPWhiteSpaceCharCode(potentialValue.charCodeAt(i))) ++i;
		return i === 0 && j === potentialValue.length ? potentialValue : potentialValue.substring(i, j);
	}
	function fill(headers, object) {
		if (Array.isArray(object)) for (let i = 0; i < object.length; ++i) {
			const header = object[i];
			if (header.length !== 2) throw webidl.errors.exception({
				header: "Headers constructor",
				message: `expected name/value pair to be length 2, found ${header.length}.`
			});
			appendHeader(headers, header[0], header[1]);
		}
		else if (typeof object === "object" && object !== null) {
			const keys = Object.keys(object);
			for (let i = 0; i < keys.length; ++i) appendHeader(headers, keys[i], object[keys[i]]);
		} else throw webidl.errors.conversionFailed({
			prefix: "Headers constructor",
			argument: "Argument 1",
			types: ["sequence<sequence<ByteString>>", "record<ByteString, ByteString>"]
		});
	}
	/**
	* @see https://fetch.spec.whatwg.org/#concept-headers-append
	*/
	function appendHeader(headers, name, value) {
		value = headerValueNormalize(value);
		if (!isValidHeaderName(name)) throw webidl.errors.invalidArgument({
			prefix: "Headers.append",
			value: name,
			type: "header name"
		});
		else if (!isValidHeaderValue(value)) throw webidl.errors.invalidArgument({
			prefix: "Headers.append",
			value,
			type: "header value"
		});
		if (headers[kGuard] === "immutable") throw new TypeError("immutable");
		else if (headers[kGuard] === "request-no-cors") {}
		return headers[kHeadersList].append(name, value);
	}
	var HeadersList = class HeadersList {
		/** @type {[string, string][]|null} */
		cookies = null;
		constructor(init) {
			if (init instanceof HeadersList) {
				this[kHeadersMap] = new Map(init[kHeadersMap]);
				this[kHeadersSortedMap] = init[kHeadersSortedMap];
				this.cookies = init.cookies === null ? null : [...init.cookies];
			} else {
				this[kHeadersMap] = new Map(init);
				this[kHeadersSortedMap] = null;
			}
		}
		contains(name) {
			name = name.toLowerCase();
			return this[kHeadersMap].has(name);
		}
		clear() {
			this[kHeadersMap].clear();
			this[kHeadersSortedMap] = null;
			this.cookies = null;
		}
		append(name, value) {
			this[kHeadersSortedMap] = null;
			const lowercaseName = name.toLowerCase();
			const exists = this[kHeadersMap].get(lowercaseName);
			if (exists) {
				const delimiter = lowercaseName === "cookie" ? "; " : ", ";
				this[kHeadersMap].set(lowercaseName, {
					name: exists.name,
					value: `${exists.value}${delimiter}${value}`
				});
			} else this[kHeadersMap].set(lowercaseName, {
				name,
				value
			});
			if (lowercaseName === "set-cookie") {
				this.cookies ??= [];
				this.cookies.push(value);
			}
		}
		set(name, value) {
			this[kHeadersSortedMap] = null;
			const lowercaseName = name.toLowerCase();
			if (lowercaseName === "set-cookie") this.cookies = [value];
			this[kHeadersMap].set(lowercaseName, {
				name,
				value
			});
		}
		delete(name) {
			this[kHeadersSortedMap] = null;
			name = name.toLowerCase();
			if (name === "set-cookie") this.cookies = null;
			this[kHeadersMap].delete(name);
		}
		get(name) {
			const value = this[kHeadersMap].get(name.toLowerCase());
			return value === void 0 ? null : value.value;
		}
		*[Symbol.iterator]() {
			for (const [name, { value }] of this[kHeadersMap]) yield [name, value];
		}
		get entries() {
			const headers = {};
			if (this[kHeadersMap].size) for (const { name, value } of this[kHeadersMap].values()) headers[name] = value;
			return headers;
		}
	};
	var Headers = class Headers {
		constructor(init = void 0) {
			if (init === kConstruct) return;
			this[kHeadersList] = new HeadersList();
			this[kGuard] = "none";
			if (init !== void 0) {
				init = webidl.converters.HeadersInit(init);
				fill(this, init);
			}
		}
		append(name, value) {
			webidl.brandCheck(this, Headers);
			webidl.argumentLengthCheck(arguments, 2, { header: "Headers.append" });
			name = webidl.converters.ByteString(name);
			value = webidl.converters.ByteString(value);
			return appendHeader(this, name, value);
		}
		delete(name) {
			webidl.brandCheck(this, Headers);
			webidl.argumentLengthCheck(arguments, 1, { header: "Headers.delete" });
			name = webidl.converters.ByteString(name);
			if (!isValidHeaderName(name)) throw webidl.errors.invalidArgument({
				prefix: "Headers.delete",
				value: name,
				type: "header name"
			});
			if (this[kGuard] === "immutable") throw new TypeError("immutable");
			else if (this[kGuard] === "request-no-cors") {}
			if (!this[kHeadersList].contains(name)) return;
			this[kHeadersList].delete(name);
		}
		get(name) {
			webidl.brandCheck(this, Headers);
			webidl.argumentLengthCheck(arguments, 1, { header: "Headers.get" });
			name = webidl.converters.ByteString(name);
			if (!isValidHeaderName(name)) throw webidl.errors.invalidArgument({
				prefix: "Headers.get",
				value: name,
				type: "header name"
			});
			return this[kHeadersList].get(name);
		}
		has(name) {
			webidl.brandCheck(this, Headers);
			webidl.argumentLengthCheck(arguments, 1, { header: "Headers.has" });
			name = webidl.converters.ByteString(name);
			if (!isValidHeaderName(name)) throw webidl.errors.invalidArgument({
				prefix: "Headers.has",
				value: name,
				type: "header name"
			});
			return this[kHeadersList].contains(name);
		}
		set(name, value) {
			webidl.brandCheck(this, Headers);
			webidl.argumentLengthCheck(arguments, 2, { header: "Headers.set" });
			name = webidl.converters.ByteString(name);
			value = webidl.converters.ByteString(value);
			value = headerValueNormalize(value);
			if (!isValidHeaderName(name)) throw webidl.errors.invalidArgument({
				prefix: "Headers.set",
				value: name,
				type: "header name"
			});
			else if (!isValidHeaderValue(value)) throw webidl.errors.invalidArgument({
				prefix: "Headers.set",
				value,
				type: "header value"
			});
			if (this[kGuard] === "immutable") throw new TypeError("immutable");
			else if (this[kGuard] === "request-no-cors") {}
			this[kHeadersList].set(name, value);
		}
		getSetCookie() {
			webidl.brandCheck(this, Headers);
			const list = this[kHeadersList].cookies;
			if (list) return [...list];
			return [];
		}
		get [kHeadersSortedMap]() {
			if (this[kHeadersList][kHeadersSortedMap]) return this[kHeadersList][kHeadersSortedMap];
			const headers = [];
			const names = [...this[kHeadersList]].sort((a, b) => a[0] < b[0] ? -1 : 1);
			const cookies = this[kHeadersList].cookies;
			for (let i = 0; i < names.length; ++i) {
				const [name, value] = names[i];
				if (name === "set-cookie") for (let j = 0; j < cookies.length; ++j) headers.push([name, cookies[j]]);
				else {
					assert$7(value !== null);
					headers.push([name, value]);
				}
			}
			this[kHeadersList][kHeadersSortedMap] = headers;
			return headers;
		}
		keys() {
			webidl.brandCheck(this, Headers);
			if (this[kGuard] === "immutable") {
				const value = this[kHeadersSortedMap];
				return makeIterator(() => value, "Headers", "key");
			}
			return makeIterator(() => [...this[kHeadersSortedMap].values()], "Headers", "key");
		}
		values() {
			webidl.brandCheck(this, Headers);
			if (this[kGuard] === "immutable") {
				const value = this[kHeadersSortedMap];
				return makeIterator(() => value, "Headers", "value");
			}
			return makeIterator(() => [...this[kHeadersSortedMap].values()], "Headers", "value");
		}
		entries() {
			webidl.brandCheck(this, Headers);
			if (this[kGuard] === "immutable") {
				const value = this[kHeadersSortedMap];
				return makeIterator(() => value, "Headers", "key+value");
			}
			return makeIterator(() => [...this[kHeadersSortedMap].values()], "Headers", "key+value");
		}
		/**
		* @param {(value: string, key: string, self: Headers) => void} callbackFn
		* @param {unknown} thisArg
		*/
		forEach(callbackFn, thisArg = globalThis) {
			webidl.brandCheck(this, Headers);
			webidl.argumentLengthCheck(arguments, 1, { header: "Headers.forEach" });
			if (typeof callbackFn !== "function") throw new TypeError("Failed to execute 'forEach' on 'Headers': parameter 1 is not of type 'Function'.");
			for (const [key, value] of this) callbackFn.apply(thisArg, [
				value,
				key,
				this
			]);
		}
		[Symbol.for("nodejs.util.inspect.custom")]() {
			webidl.brandCheck(this, Headers);
			return this[kHeadersList];
		}
	};
	Headers.prototype[Symbol.iterator] = Headers.prototype.entries;
	Object.defineProperties(Headers.prototype, {
		append: kEnumerableProperty,
		delete: kEnumerableProperty,
		get: kEnumerableProperty,
		has: kEnumerableProperty,
		set: kEnumerableProperty,
		getSetCookie: kEnumerableProperty,
		keys: kEnumerableProperty,
		values: kEnumerableProperty,
		entries: kEnumerableProperty,
		forEach: kEnumerableProperty,
		[Symbol.iterator]: { enumerable: false },
		[Symbol.toStringTag]: {
			value: "Headers",
			configurable: true
		}
	});
	webidl.converters.HeadersInit = function(V) {
		if (webidl.util.Type(V) === "Object") {
			if (V[Symbol.iterator]) return webidl.converters["sequence<sequence<ByteString>>"](V);
			return webidl.converters["record<ByteString, ByteString>"](V);
		}
		throw webidl.errors.conversionFailed({
			prefix: "Headers constructor",
			argument: "Argument 1",
			types: ["sequence<sequence<ByteString>>", "record<ByteString, ByteString>"]
		});
	};
	module.exports = {
		fill,
		Headers,
		HeadersList
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/response.js
var require_response = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Headers, HeadersList, fill } = require_headers();
	var { extractBody, cloneBody, mixinBody } = require_body();
	var util = require_util$6();
	var { kEnumerableProperty } = util;
	var { isValidReasonPhrase, isCancelled, isAborted, isBlobLike, serializeJavascriptValueToJSONString, isErrorLike, isomorphicEncode } = require_util$5();
	var { redirectStatusSet, nullBodyStatus, DOMException } = require_constants$3();
	var { kState, kHeaders, kGuard, kRealm } = require_symbols$3();
	var { webidl } = require_webidl();
	var { FormData } = require_formdata();
	var { getGlobalOrigin } = require_global$1();
	var { URLSerializer } = require_dataURL();
	var { kHeadersList, kConstruct } = require_symbols$4();
	var assert$6 = __require("assert");
	var { types: types$2 } = __require("util");
	var ReadableStream = globalThis.ReadableStream || __require("stream/web").ReadableStream;
	var textEncoder = new TextEncoder("utf-8");
	var Response = class Response {
		static error() {
			const relevantRealm = { settingsObject: {} };
			const responseObject = new Response();
			responseObject[kState] = makeNetworkError();
			responseObject[kRealm] = relevantRealm;
			responseObject[kHeaders][kHeadersList] = responseObject[kState].headersList;
			responseObject[kHeaders][kGuard] = "immutable";
			responseObject[kHeaders][kRealm] = relevantRealm;
			return responseObject;
		}
		static json(data, init = {}) {
			webidl.argumentLengthCheck(arguments, 1, { header: "Response.json" });
			if (init !== null) init = webidl.converters.ResponseInit(init);
			const body = extractBody(textEncoder.encode(serializeJavascriptValueToJSONString(data)));
			const relevantRealm = { settingsObject: {} };
			const responseObject = new Response();
			responseObject[kRealm] = relevantRealm;
			responseObject[kHeaders][kGuard] = "response";
			responseObject[kHeaders][kRealm] = relevantRealm;
			initializeResponse(responseObject, init, {
				body: body[0],
				type: "application/json"
			});
			return responseObject;
		}
		static redirect(url, status = 302) {
			const relevantRealm = { settingsObject: {} };
			webidl.argumentLengthCheck(arguments, 1, { header: "Response.redirect" });
			url = webidl.converters.USVString(url);
			status = webidl.converters["unsigned short"](status);
			let parsedURL;
			try {
				parsedURL = new URL(url, getGlobalOrigin());
			} catch (err) {
				throw Object.assign(/* @__PURE__ */ new TypeError("Failed to parse URL from " + url), { cause: err });
			}
			if (!redirectStatusSet.has(status)) throw new RangeError("Invalid status code " + status);
			const responseObject = new Response();
			responseObject[kRealm] = relevantRealm;
			responseObject[kHeaders][kGuard] = "immutable";
			responseObject[kHeaders][kRealm] = relevantRealm;
			responseObject[kState].status = status;
			const value = isomorphicEncode(URLSerializer(parsedURL));
			responseObject[kState].headersList.append("location", value);
			return responseObject;
		}
		constructor(body = null, init = {}) {
			if (body !== null) body = webidl.converters.BodyInit(body);
			init = webidl.converters.ResponseInit(init);
			this[kRealm] = { settingsObject: {} };
			this[kState] = makeResponse({});
			this[kHeaders] = new Headers(kConstruct);
			this[kHeaders][kGuard] = "response";
			this[kHeaders][kHeadersList] = this[kState].headersList;
			this[kHeaders][kRealm] = this[kRealm];
			let bodyWithType = null;
			if (body != null) {
				const [extractedBody, type] = extractBody(body);
				bodyWithType = {
					body: extractedBody,
					type
				};
			}
			initializeResponse(this, init, bodyWithType);
		}
		get type() {
			webidl.brandCheck(this, Response);
			return this[kState].type;
		}
		get url() {
			webidl.brandCheck(this, Response);
			const urlList = this[kState].urlList;
			const url = urlList[urlList.length - 1] ?? null;
			if (url === null) return "";
			return URLSerializer(url, true);
		}
		get redirected() {
			webidl.brandCheck(this, Response);
			return this[kState].urlList.length > 1;
		}
		get status() {
			webidl.brandCheck(this, Response);
			return this[kState].status;
		}
		get ok() {
			webidl.brandCheck(this, Response);
			return this[kState].status >= 200 && this[kState].status <= 299;
		}
		get statusText() {
			webidl.brandCheck(this, Response);
			return this[kState].statusText;
		}
		get headers() {
			webidl.brandCheck(this, Response);
			return this[kHeaders];
		}
		get body() {
			webidl.brandCheck(this, Response);
			return this[kState].body ? this[kState].body.stream : null;
		}
		get bodyUsed() {
			webidl.brandCheck(this, Response);
			return !!this[kState].body && util.isDisturbed(this[kState].body.stream);
		}
		clone() {
			webidl.brandCheck(this, Response);
			if (this.bodyUsed || this.body && this.body.locked) throw webidl.errors.exception({
				header: "Response.clone",
				message: "Body has already been consumed."
			});
			const clonedResponse = cloneResponse(this[kState]);
			const clonedResponseObject = new Response();
			clonedResponseObject[kState] = clonedResponse;
			clonedResponseObject[kRealm] = this[kRealm];
			clonedResponseObject[kHeaders][kHeadersList] = clonedResponse.headersList;
			clonedResponseObject[kHeaders][kGuard] = this[kHeaders][kGuard];
			clonedResponseObject[kHeaders][kRealm] = this[kHeaders][kRealm];
			return clonedResponseObject;
		}
	};
	mixinBody(Response);
	Object.defineProperties(Response.prototype, {
		type: kEnumerableProperty,
		url: kEnumerableProperty,
		status: kEnumerableProperty,
		ok: kEnumerableProperty,
		redirected: kEnumerableProperty,
		statusText: kEnumerableProperty,
		headers: kEnumerableProperty,
		clone: kEnumerableProperty,
		body: kEnumerableProperty,
		bodyUsed: kEnumerableProperty,
		[Symbol.toStringTag]: {
			value: "Response",
			configurable: true
		}
	});
	Object.defineProperties(Response, {
		json: kEnumerableProperty,
		redirect: kEnumerableProperty,
		error: kEnumerableProperty
	});
	function cloneResponse(response) {
		if (response.internalResponse) return filterResponse(cloneResponse(response.internalResponse), response.type);
		const newResponse = makeResponse({
			...response,
			body: null
		});
		if (response.body != null) newResponse.body = cloneBody(response.body);
		return newResponse;
	}
	function makeResponse(init) {
		return {
			aborted: false,
			rangeRequested: false,
			timingAllowPassed: false,
			requestIncludesCredentials: false,
			type: "default",
			status: 200,
			timingInfo: null,
			cacheState: "",
			statusText: "",
			...init,
			headersList: init.headersList ? new HeadersList(init.headersList) : new HeadersList(),
			urlList: init.urlList ? [...init.urlList] : []
		};
	}
	function makeNetworkError(reason) {
		return makeResponse({
			type: "error",
			status: 0,
			error: isErrorLike(reason) ? reason : new Error(reason ? String(reason) : reason),
			aborted: reason && reason.name === "AbortError"
		});
	}
	function makeFilteredResponse(response, state) {
		state = {
			internalResponse: response,
			...state
		};
		return new Proxy(response, {
			get(target, p) {
				return p in state ? state[p] : target[p];
			},
			set(target, p, value) {
				assert$6(!(p in state));
				target[p] = value;
				return true;
			}
		});
	}
	function filterResponse(response, type) {
		if (type === "basic") return makeFilteredResponse(response, {
			type: "basic",
			headersList: response.headersList
		});
		else if (type === "cors") return makeFilteredResponse(response, {
			type: "cors",
			headersList: response.headersList
		});
		else if (type === "opaque") return makeFilteredResponse(response, {
			type: "opaque",
			urlList: Object.freeze([]),
			status: 0,
			statusText: "",
			body: null
		});
		else if (type === "opaqueredirect") return makeFilteredResponse(response, {
			type: "opaqueredirect",
			status: 0,
			statusText: "",
			headersList: [],
			body: null
		});
		else assert$6(false);
	}
	function makeAppropriateNetworkError(fetchParams, err = null) {
		assert$6(isCancelled(fetchParams));
		return isAborted(fetchParams) ? makeNetworkError(Object.assign(new DOMException("The operation was aborted.", "AbortError"), { cause: err })) : makeNetworkError(Object.assign(new DOMException("Request was cancelled."), { cause: err }));
	}
	function initializeResponse(response, init, body) {
		if (init.status !== null && (init.status < 200 || init.status > 599)) throw new RangeError("init[\"status\"] must be in the range of 200 to 599, inclusive.");
		if ("statusText" in init && init.statusText != null) {
			if (!isValidReasonPhrase(String(init.statusText))) throw new TypeError("Invalid statusText");
		}
		if ("status" in init && init.status != null) response[kState].status = init.status;
		if ("statusText" in init && init.statusText != null) response[kState].statusText = init.statusText;
		if ("headers" in init && init.headers != null) fill(response[kHeaders], init.headers);
		if (body) {
			if (nullBodyStatus.includes(response.status)) throw webidl.errors.exception({
				header: "Response constructor",
				message: "Invalid response status code " + response.status
			});
			response[kState].body = body.body;
			if (body.type != null && !response[kState].headersList.contains("Content-Type")) response[kState].headersList.append("content-type", body.type);
		}
	}
	webidl.converters.ReadableStream = webidl.interfaceConverter(ReadableStream);
	webidl.converters.FormData = webidl.interfaceConverter(FormData);
	webidl.converters.URLSearchParams = webidl.interfaceConverter(URLSearchParams);
	webidl.converters.XMLHttpRequestBodyInit = function(V) {
		if (typeof V === "string") return webidl.converters.USVString(V);
		if (isBlobLike(V)) return webidl.converters.Blob(V, { strict: false });
		if (types$2.isArrayBuffer(V) || types$2.isTypedArray(V) || types$2.isDataView(V)) return webidl.converters.BufferSource(V);
		if (util.isFormDataLike(V)) return webidl.converters.FormData(V, { strict: false });
		if (V instanceof URLSearchParams) return webidl.converters.URLSearchParams(V);
		return webidl.converters.DOMString(V);
	};
	webidl.converters.BodyInit = function(V) {
		if (V instanceof ReadableStream) return webidl.converters.ReadableStream(V);
		if (V?.[Symbol.asyncIterator]) return V;
		return webidl.converters.XMLHttpRequestBodyInit(V);
	};
	webidl.converters.ResponseInit = webidl.dictionaryConverter([
		{
			key: "status",
			converter: webidl.converters["unsigned short"],
			defaultValue: 200
		},
		{
			key: "statusText",
			converter: webidl.converters.ByteString,
			defaultValue: ""
		},
		{
			key: "headers",
			converter: webidl.converters.HeadersInit
		}
	]);
	module.exports = {
		makeNetworkError,
		makeResponse,
		makeAppropriateNetworkError,
		filterResponse,
		Response,
		cloneResponse
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/request.js
var require_request = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { extractBody, mixinBody, cloneBody } = require_body();
	var { Headers, fill: fillHeaders, HeadersList } = require_headers();
	var { FinalizationRegistry } = require_dispatcher_weakref()();
	var util = require_util$6();
	var { isValidHTTPToken, sameOrigin, normalizeMethod, makePolicyContainer, normalizeMethodRecord } = require_util$5();
	var { forbiddenMethodsSet, corsSafeListedMethodsSet, referrerPolicy, requestRedirect, requestMode, requestCredentials, requestCache, requestDuplex } = require_constants$3();
	var { kEnumerableProperty } = util;
	var { kHeaders, kSignal, kState, kGuard, kRealm } = require_symbols$3();
	var { webidl } = require_webidl();
	var { getGlobalOrigin } = require_global$1();
	var { URLSerializer } = require_dataURL();
	var { kHeadersList, kConstruct } = require_symbols$4();
	var assert$5 = __require("assert");
	var { getMaxListeners, setMaxListeners, getEventListeners, defaultMaxListeners } = __require("events");
	var TransformStream = globalThis.TransformStream;
	var kAbortController = Symbol("abortController");
	var requestFinalizer = new FinalizationRegistry(({ signal, abort }) => {
		signal.removeEventListener("abort", abort);
	});
	var Request = class Request {
		constructor(input, init = {}) {
			if (input === kConstruct) return;
			webidl.argumentLengthCheck(arguments, 1, { header: "Request constructor" });
			input = webidl.converters.RequestInfo(input);
			init = webidl.converters.RequestInit(init);
			this[kRealm] = { settingsObject: {
				baseUrl: getGlobalOrigin(),
				get origin() {
					return this.baseUrl?.origin;
				},
				policyContainer: makePolicyContainer()
			} };
			let request = null;
			let fallbackMode = null;
			const baseUrl = this[kRealm].settingsObject.baseUrl;
			let signal = null;
			if (typeof input === "string") {
				let parsedURL;
				try {
					parsedURL = new URL(input, baseUrl);
				} catch (err) {
					throw new TypeError("Failed to parse URL from " + input, { cause: err });
				}
				if (parsedURL.username || parsedURL.password) throw new TypeError("Request cannot be constructed from a URL that includes credentials: " + input);
				request = makeRequest({ urlList: [parsedURL] });
				fallbackMode = "cors";
			} else {
				assert$5(input instanceof Request);
				request = input[kState];
				signal = input[kSignal];
			}
			const origin = this[kRealm].settingsObject.origin;
			let window = "client";
			if (request.window?.constructor?.name === "EnvironmentSettingsObject" && sameOrigin(request.window, origin)) window = request.window;
			if (init.window != null) throw new TypeError(`'window' option '${window}' must be null`);
			if ("window" in init) window = "no-window";
			request = makeRequest({
				method: request.method,
				headersList: request.headersList,
				unsafeRequest: request.unsafeRequest,
				client: this[kRealm].settingsObject,
				window,
				priority: request.priority,
				origin: request.origin,
				referrer: request.referrer,
				referrerPolicy: request.referrerPolicy,
				mode: request.mode,
				credentials: request.credentials,
				cache: request.cache,
				redirect: request.redirect,
				integrity: request.integrity,
				keepalive: request.keepalive,
				reloadNavigation: request.reloadNavigation,
				historyNavigation: request.historyNavigation,
				urlList: [...request.urlList]
			});
			const initHasKey = Object.keys(init).length !== 0;
			if (initHasKey) {
				if (request.mode === "navigate") request.mode = "same-origin";
				request.reloadNavigation = false;
				request.historyNavigation = false;
				request.origin = "client";
				request.referrer = "client";
				request.referrerPolicy = "";
				request.url = request.urlList[request.urlList.length - 1];
				request.urlList = [request.url];
			}
			if (init.referrer !== void 0) {
				const referrer = init.referrer;
				if (referrer === "") request.referrer = "no-referrer";
				else {
					let parsedReferrer;
					try {
						parsedReferrer = new URL(referrer, baseUrl);
					} catch (err) {
						throw new TypeError(`Referrer "${referrer}" is not a valid URL.`, { cause: err });
					}
					if (parsedReferrer.protocol === "about:" && parsedReferrer.hostname === "client" || origin && !sameOrigin(parsedReferrer, this[kRealm].settingsObject.baseUrl)) request.referrer = "client";
					else request.referrer = parsedReferrer;
				}
			}
			if (init.referrerPolicy !== void 0) request.referrerPolicy = init.referrerPolicy;
			let mode;
			if (init.mode !== void 0) mode = init.mode;
			else mode = fallbackMode;
			if (mode === "navigate") throw webidl.errors.exception({
				header: "Request constructor",
				message: "invalid request mode navigate."
			});
			if (mode != null) request.mode = mode;
			if (init.credentials !== void 0) request.credentials = init.credentials;
			if (init.cache !== void 0) request.cache = init.cache;
			if (request.cache === "only-if-cached" && request.mode !== "same-origin") throw new TypeError("'only-if-cached' can be set only with 'same-origin' mode");
			if (init.redirect !== void 0) request.redirect = init.redirect;
			if (init.integrity != null) request.integrity = String(init.integrity);
			if (init.keepalive !== void 0) request.keepalive = Boolean(init.keepalive);
			if (init.method !== void 0) {
				let method = init.method;
				if (!isValidHTTPToken(method)) throw new TypeError(`'${method}' is not a valid HTTP method.`);
				if (forbiddenMethodsSet.has(method.toUpperCase())) throw new TypeError(`'${method}' HTTP method is unsupported.`);
				method = normalizeMethodRecord[method] ?? normalizeMethod(method);
				request.method = method;
			}
			if (init.signal !== void 0) signal = init.signal;
			this[kState] = request;
			const ac = new AbortController();
			this[kSignal] = ac.signal;
			this[kSignal][kRealm] = this[kRealm];
			if (signal != null) {
				if (!signal || typeof signal.aborted !== "boolean" || typeof signal.addEventListener !== "function") throw new TypeError("Failed to construct 'Request': member signal is not of type AbortSignal.");
				if (signal.aborted) ac.abort(signal.reason);
				else {
					this[kAbortController] = ac;
					const acRef = new WeakRef(ac);
					const abort = function() {
						const ac = acRef.deref();
						if (ac !== void 0) ac.abort(this.reason);
					};
					try {
						if (typeof getMaxListeners === "function" && getMaxListeners(signal) === defaultMaxListeners) setMaxListeners(100, signal);
						else if (getEventListeners(signal, "abort").length >= defaultMaxListeners) setMaxListeners(100, signal);
					} catch {}
					util.addAbortListener(signal, abort);
					requestFinalizer.register(ac, {
						signal,
						abort
					});
				}
			}
			this[kHeaders] = new Headers(kConstruct);
			this[kHeaders][kHeadersList] = request.headersList;
			this[kHeaders][kGuard] = "request";
			this[kHeaders][kRealm] = this[kRealm];
			if (mode === "no-cors") {
				if (!corsSafeListedMethodsSet.has(request.method)) throw new TypeError(`'${request.method} is unsupported in no-cors mode.`);
				this[kHeaders][kGuard] = "request-no-cors";
			}
			if (initHasKey) {
				/** @type {HeadersList} */
				const headersList = this[kHeaders][kHeadersList];
				const headers = init.headers !== void 0 ? init.headers : new HeadersList(headersList);
				headersList.clear();
				if (headers instanceof HeadersList) {
					for (const [key, val] of headers) headersList.append(key, val);
					headersList.cookies = headers.cookies;
				} else fillHeaders(this[kHeaders], headers);
			}
			const inputBody = input instanceof Request ? input[kState].body : null;
			if ((init.body != null || inputBody != null) && (request.method === "GET" || request.method === "HEAD")) throw new TypeError("Request with GET/HEAD method cannot have body.");
			let initBody = null;
			if (init.body != null) {
				const [extractedBody, contentType] = extractBody(init.body, request.keepalive);
				initBody = extractedBody;
				if (contentType && !this[kHeaders][kHeadersList].contains("content-type")) this[kHeaders].append("content-type", contentType);
			}
			const inputOrInitBody = initBody ?? inputBody;
			if (inputOrInitBody != null && inputOrInitBody.source == null) {
				if (initBody != null && init.duplex == null) throw new TypeError("RequestInit: duplex option is required when sending a body.");
				if (request.mode !== "same-origin" && request.mode !== "cors") throw new TypeError("If request is made from ReadableStream, mode should be \"same-origin\" or \"cors\"");
				request.useCORSPreflightFlag = true;
			}
			let finalBody = inputOrInitBody;
			if (initBody == null && inputBody != null) {
				if (util.isDisturbed(inputBody.stream) || inputBody.stream.locked) throw new TypeError("Cannot construct a Request with a Request object that has already been used.");
				if (!TransformStream) TransformStream = __require("stream/web").TransformStream;
				const identityTransform = new TransformStream();
				inputBody.stream.pipeThrough(identityTransform);
				finalBody = {
					source: inputBody.source,
					length: inputBody.length,
					stream: identityTransform.readable
				};
			}
			this[kState].body = finalBody;
		}
		get method() {
			webidl.brandCheck(this, Request);
			return this[kState].method;
		}
		get url() {
			webidl.brandCheck(this, Request);
			return URLSerializer(this[kState].url);
		}
		get headers() {
			webidl.brandCheck(this, Request);
			return this[kHeaders];
		}
		get destination() {
			webidl.brandCheck(this, Request);
			return this[kState].destination;
		}
		get referrer() {
			webidl.brandCheck(this, Request);
			if (this[kState].referrer === "no-referrer") return "";
			if (this[kState].referrer === "client") return "about:client";
			return this[kState].referrer.toString();
		}
		get referrerPolicy() {
			webidl.brandCheck(this, Request);
			return this[kState].referrerPolicy;
		}
		get mode() {
			webidl.brandCheck(this, Request);
			return this[kState].mode;
		}
		get credentials() {
			return this[kState].credentials;
		}
		get cache() {
			webidl.brandCheck(this, Request);
			return this[kState].cache;
		}
		get redirect() {
			webidl.brandCheck(this, Request);
			return this[kState].redirect;
		}
		get integrity() {
			webidl.brandCheck(this, Request);
			return this[kState].integrity;
		}
		get keepalive() {
			webidl.brandCheck(this, Request);
			return this[kState].keepalive;
		}
		get isReloadNavigation() {
			webidl.brandCheck(this, Request);
			return this[kState].reloadNavigation;
		}
		get isHistoryNavigation() {
			webidl.brandCheck(this, Request);
			return this[kState].historyNavigation;
		}
		get signal() {
			webidl.brandCheck(this, Request);
			return this[kSignal];
		}
		get body() {
			webidl.brandCheck(this, Request);
			return this[kState].body ? this[kState].body.stream : null;
		}
		get bodyUsed() {
			webidl.brandCheck(this, Request);
			return !!this[kState].body && util.isDisturbed(this[kState].body.stream);
		}
		get duplex() {
			webidl.brandCheck(this, Request);
			return "half";
		}
		clone() {
			webidl.brandCheck(this, Request);
			if (this.bodyUsed || this.body?.locked) throw new TypeError("unusable");
			const clonedRequest = cloneRequest(this[kState]);
			const clonedRequestObject = new Request(kConstruct);
			clonedRequestObject[kState] = clonedRequest;
			clonedRequestObject[kRealm] = this[kRealm];
			clonedRequestObject[kHeaders] = new Headers(kConstruct);
			clonedRequestObject[kHeaders][kHeadersList] = clonedRequest.headersList;
			clonedRequestObject[kHeaders][kGuard] = this[kHeaders][kGuard];
			clonedRequestObject[kHeaders][kRealm] = this[kHeaders][kRealm];
			const ac = new AbortController();
			if (this.signal.aborted) ac.abort(this.signal.reason);
			else util.addAbortListener(this.signal, () => {
				ac.abort(this.signal.reason);
			});
			clonedRequestObject[kSignal] = ac.signal;
			return clonedRequestObject;
		}
	};
	mixinBody(Request);
	function makeRequest(init) {
		const request = {
			method: "GET",
			localURLsOnly: false,
			unsafeRequest: false,
			body: null,
			client: null,
			reservedClient: null,
			replacesClientId: "",
			window: "client",
			keepalive: false,
			serviceWorkers: "all",
			initiator: "",
			destination: "",
			priority: null,
			origin: "client",
			policyContainer: "client",
			referrer: "client",
			referrerPolicy: "",
			mode: "no-cors",
			useCORSPreflightFlag: false,
			credentials: "same-origin",
			useCredentials: false,
			cache: "default",
			redirect: "follow",
			integrity: "",
			cryptoGraphicsNonceMetadata: "",
			parserMetadata: "",
			reloadNavigation: false,
			historyNavigation: false,
			userActivation: false,
			taintedOrigin: false,
			redirectCount: 0,
			responseTainting: "basic",
			preventNoCacheCacheControlHeaderModification: false,
			done: false,
			timingAllowFailed: false,
			...init,
			headersList: init.headersList ? new HeadersList(init.headersList) : new HeadersList()
		};
		request.url = request.urlList[0];
		return request;
	}
	function cloneRequest(request) {
		const newRequest = makeRequest({
			...request,
			body: null
		});
		if (request.body != null) newRequest.body = cloneBody(request.body);
		return newRequest;
	}
	Object.defineProperties(Request.prototype, {
		method: kEnumerableProperty,
		url: kEnumerableProperty,
		headers: kEnumerableProperty,
		redirect: kEnumerableProperty,
		clone: kEnumerableProperty,
		signal: kEnumerableProperty,
		duplex: kEnumerableProperty,
		destination: kEnumerableProperty,
		body: kEnumerableProperty,
		bodyUsed: kEnumerableProperty,
		isHistoryNavigation: kEnumerableProperty,
		isReloadNavigation: kEnumerableProperty,
		keepalive: kEnumerableProperty,
		integrity: kEnumerableProperty,
		cache: kEnumerableProperty,
		credentials: kEnumerableProperty,
		attribute: kEnumerableProperty,
		referrerPolicy: kEnumerableProperty,
		referrer: kEnumerableProperty,
		mode: kEnumerableProperty,
		[Symbol.toStringTag]: {
			value: "Request",
			configurable: true
		}
	});
	webidl.converters.Request = webidl.interfaceConverter(Request);
	webidl.converters.RequestInfo = function(V) {
		if (typeof V === "string") return webidl.converters.USVString(V);
		if (V instanceof Request) return webidl.converters.Request(V);
		return webidl.converters.USVString(V);
	};
	webidl.converters.AbortSignal = webidl.interfaceConverter(AbortSignal);
	webidl.converters.RequestInit = webidl.dictionaryConverter([
		{
			key: "method",
			converter: webidl.converters.ByteString
		},
		{
			key: "headers",
			converter: webidl.converters.HeadersInit
		},
		{
			key: "body",
			converter: webidl.nullableConverter(webidl.converters.BodyInit)
		},
		{
			key: "referrer",
			converter: webidl.converters.USVString
		},
		{
			key: "referrerPolicy",
			converter: webidl.converters.DOMString,
			allowedValues: referrerPolicy
		},
		{
			key: "mode",
			converter: webidl.converters.DOMString,
			allowedValues: requestMode
		},
		{
			key: "credentials",
			converter: webidl.converters.DOMString,
			allowedValues: requestCredentials
		},
		{
			key: "cache",
			converter: webidl.converters.DOMString,
			allowedValues: requestCache
		},
		{
			key: "redirect",
			converter: webidl.converters.DOMString,
			allowedValues: requestRedirect
		},
		{
			key: "integrity",
			converter: webidl.converters.DOMString
		},
		{
			key: "keepalive",
			converter: webidl.converters.boolean
		},
		{
			key: "signal",
			converter: webidl.nullableConverter((signal) => webidl.converters.AbortSignal(signal, { strict: false }))
		},
		{
			key: "window",
			converter: webidl.converters.any
		},
		{
			key: "duplex",
			converter: webidl.converters.DOMString,
			allowedValues: requestDuplex
		}
	]);
	module.exports = {
		Request,
		makeRequest
	};
}));
//#endregion
//#region node_modules/undici/lib/fetch/index.js
var require_fetch = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Response, makeNetworkError, makeAppropriateNetworkError, filterResponse, makeResponse } = require_response();
	var { Headers } = require_headers();
	var { Request, makeRequest } = require_request();
	var zlib = __require("zlib");
	var { bytesMatch, makePolicyContainer, clonePolicyContainer, requestBadPort, TAOCheck, appendRequestOriginHeader, responseLocationURL, requestCurrentURL, setRequestReferrerPolicyOnRedirect, tryUpgradeRequestToAPotentiallyTrustworthyURL, createOpaqueTimingInfo, appendFetchMetadata, corsCheck, crossOriginResourcePolicyCheck, determineRequestsReferrer, coarsenedSharedCurrentTime, createDeferredPromise, isBlobLike, sameOrigin, isCancelled, isAborted, isErrorLike, fullyReadBody, readableStreamClose, isomorphicEncode, urlIsLocal, urlIsHttpHttpsScheme, urlHasHttpsScheme } = require_util$5();
	var { kState, kHeaders, kGuard, kRealm } = require_symbols$3();
	var assert$4 = __require("assert");
	var { safelyExtractBody } = require_body();
	var { redirectStatusSet, nullBodyStatus, safeMethodsSet, requestBodyHeader, subresourceSet, DOMException } = require_constants$3();
	var { kHeadersList } = require_symbols$4();
	var EE = __require("events");
	var { Readable, pipeline } = __require("stream");
	var { addAbortListener, isErrored, isReadable, nodeMajor, nodeMinor } = require_util$6();
	var { dataURLProcessor, serializeAMimeType } = require_dataURL();
	var { TransformStream } = __require("stream/web");
	var { getGlobalDispatcher } = require_global();
	var { webidl } = require_webidl();
	var { STATUS_CODES } = __require("http");
	var GET_OR_HEAD = ["GET", "HEAD"];
	/** @type {import('buffer').resolveObjectURL} */
	var resolveObjectURL;
	var ReadableStream = globalThis.ReadableStream;
	var Fetch = class extends EE {
		constructor(dispatcher) {
			super();
			this.dispatcher = dispatcher;
			this.connection = null;
			this.dump = false;
			this.state = "ongoing";
			this.setMaxListeners(21);
		}
		terminate(reason) {
			if (this.state !== "ongoing") return;
			this.state = "terminated";
			this.connection?.destroy(reason);
			this.emit("terminated", reason);
		}
		abort(error) {
			if (this.state !== "ongoing") return;
			this.state = "aborted";
			if (!error) error = new DOMException("The operation was aborted.", "AbortError");
			this.serializedAbortReason = error;
			this.connection?.destroy(error);
			this.emit("terminated", error);
		}
	};
	function fetch(input, init = {}) {
		webidl.argumentLengthCheck(arguments, 1, { header: "globalThis.fetch" });
		const p = createDeferredPromise();
		let requestObject;
		try {
			requestObject = new Request(input, init);
		} catch (e) {
			p.reject(e);
			return p.promise;
		}
		const request = requestObject[kState];
		if (requestObject.signal.aborted) {
			abortFetch(p, request, null, requestObject.signal.reason);
			return p.promise;
		}
		if (request.client.globalObject?.constructor?.name === "ServiceWorkerGlobalScope") request.serviceWorkers = "none";
		let responseObject = null;
		const relevantRealm = null;
		let locallyAborted = false;
		let controller = null;
		addAbortListener(requestObject.signal, () => {
			locallyAborted = true;
			assert$4(controller != null);
			controller.abort(requestObject.signal.reason);
			abortFetch(p, request, responseObject, requestObject.signal.reason);
		});
		const handleFetchDone = (response) => finalizeAndReportTiming(response, "fetch");
		const processResponse = (response) => {
			if (locallyAborted) return Promise.resolve();
			if (response.aborted) {
				abortFetch(p, request, responseObject, controller.serializedAbortReason);
				return Promise.resolve();
			}
			if (response.type === "error") {
				p.reject(Object.assign(/* @__PURE__ */ new TypeError("fetch failed"), { cause: response.error }));
				return Promise.resolve();
			}
			responseObject = new Response();
			responseObject[kState] = response;
			responseObject[kRealm] = relevantRealm;
			responseObject[kHeaders][kHeadersList] = response.headersList;
			responseObject[kHeaders][kGuard] = "immutable";
			responseObject[kHeaders][kRealm] = relevantRealm;
			p.resolve(responseObject);
		};
		controller = fetching({
			request,
			processResponseEndOfBody: handleFetchDone,
			processResponse,
			dispatcher: init.dispatcher ?? getGlobalDispatcher()
		});
		return p.promise;
	}
	function finalizeAndReportTiming(response, initiatorType = "other") {
		if (response.type === "error" && response.aborted) return;
		if (!response.urlList?.length) return;
		const originalURL = response.urlList[0];
		let timingInfo = response.timingInfo;
		let cacheState = response.cacheState;
		if (!urlIsHttpHttpsScheme(originalURL)) return;
		if (timingInfo === null) return;
		if (!response.timingAllowPassed) {
			timingInfo = createOpaqueTimingInfo({ startTime: timingInfo.startTime });
			cacheState = "";
		}
		timingInfo.endTime = coarsenedSharedCurrentTime();
		response.timingInfo = timingInfo;
		markResourceTiming(timingInfo, originalURL, initiatorType, globalThis, cacheState);
	}
	function markResourceTiming(timingInfo, originalURL, initiatorType, globalThis, cacheState) {
		if (nodeMajor > 18 || nodeMajor === 18 && nodeMinor >= 2) performance.markResourceTiming(timingInfo, originalURL.href, initiatorType, globalThis, cacheState);
	}
	function abortFetch(p, request, responseObject, error) {
		if (!error) error = new DOMException("The operation was aborted.", "AbortError");
		p.reject(error);
		if (request.body != null && isReadable(request.body?.stream)) request.body.stream.cancel(error).catch((err) => {
			if (err.code === "ERR_INVALID_STATE") return;
			throw err;
		});
		if (responseObject == null) return;
		const response = responseObject[kState];
		if (response.body != null && isReadable(response.body?.stream)) response.body.stream.cancel(error).catch((err) => {
			if (err.code === "ERR_INVALID_STATE") return;
			throw err;
		});
	}
	function fetching({ request, processRequestBodyChunkLength, processRequestEndOfBody, processResponse, processResponseEndOfBody, processResponseConsumeBody, useParallelQueue = false, dispatcher }) {
		let taskDestination = null;
		let crossOriginIsolatedCapability = false;
		if (request.client != null) {
			taskDestination = request.client.globalObject;
			crossOriginIsolatedCapability = request.client.crossOriginIsolatedCapability;
		}
		const timingInfo = createOpaqueTimingInfo({ startTime: coarsenedSharedCurrentTime(crossOriginIsolatedCapability) });
		const fetchParams = {
			controller: new Fetch(dispatcher),
			request,
			timingInfo,
			processRequestBodyChunkLength,
			processRequestEndOfBody,
			processResponse,
			processResponseConsumeBody,
			processResponseEndOfBody,
			taskDestination,
			crossOriginIsolatedCapability
		};
		assert$4(!request.body || request.body.stream);
		if (request.window === "client") request.window = request.client?.globalObject?.constructor?.name === "Window" ? request.client : "no-window";
		if (request.origin === "client") request.origin = request.client?.origin;
		if (request.policyContainer === "client") {
			if (request.client != null) request.policyContainer = clonePolicyContainer(request.client.policyContainer);
			else request.policyContainer = makePolicyContainer();
		}
		if (!request.headersList.contains("accept")) request.headersList.append("accept", "*/*");
		if (!request.headersList.contains("accept-language")) request.headersList.append("accept-language", "*");
		if (request.priority === null) {}
		if (subresourceSet.has(request.destination)) {}
		mainFetch(fetchParams).catch((err) => {
			fetchParams.controller.terminate(err);
		});
		return fetchParams.controller;
	}
	async function mainFetch(fetchParams, recursive = false) {
		const request = fetchParams.request;
		let response = null;
		if (request.localURLsOnly && !urlIsLocal(requestCurrentURL(request))) response = makeNetworkError("local URLs only");
		tryUpgradeRequestToAPotentiallyTrustworthyURL(request);
		if (requestBadPort(request) === "blocked") response = makeNetworkError("bad port");
		if (request.referrerPolicy === "") request.referrerPolicy = request.policyContainer.referrerPolicy;
		if (request.referrer !== "no-referrer") request.referrer = determineRequestsReferrer(request);
		if (response === null) response = await (async () => {
			const currentURL = requestCurrentURL(request);
			if (sameOrigin(currentURL, request.url) && request.responseTainting === "basic" || currentURL.protocol === "data:" || request.mode === "navigate" || request.mode === "websocket") {
				request.responseTainting = "basic";
				return await schemeFetch(fetchParams);
			}
			if (request.mode === "same-origin") return makeNetworkError("request mode cannot be \"same-origin\"");
			if (request.mode === "no-cors") {
				if (request.redirect !== "follow") return makeNetworkError("redirect mode cannot be \"follow\" for \"no-cors\" request");
				request.responseTainting = "opaque";
				return await schemeFetch(fetchParams);
			}
			if (!urlIsHttpHttpsScheme(requestCurrentURL(request))) return makeNetworkError("URL scheme must be a HTTP(S) scheme");
			request.responseTainting = "cors";
			return await httpFetch(fetchParams);
		})();
		if (recursive) return response;
		if (response.status !== 0 && !response.internalResponse) {
			if (request.responseTainting === "cors") {}
			if (request.responseTainting === "basic") response = filterResponse(response, "basic");
			else if (request.responseTainting === "cors") response = filterResponse(response, "cors");
			else if (request.responseTainting === "opaque") response = filterResponse(response, "opaque");
			else assert$4(false);
		}
		let internalResponse = response.status === 0 ? response : response.internalResponse;
		if (internalResponse.urlList.length === 0) internalResponse.urlList.push(...request.urlList);
		if (!request.timingAllowFailed) response.timingAllowPassed = true;
		if (response.type === "opaque" && internalResponse.status === 206 && internalResponse.rangeRequested && !request.headers.contains("range")) response = internalResponse = makeNetworkError();
		if (response.status !== 0 && (request.method === "HEAD" || request.method === "CONNECT" || nullBodyStatus.includes(internalResponse.status))) {
			internalResponse.body = null;
			fetchParams.controller.dump = true;
		}
		if (request.integrity) {
			const processBodyError = (reason) => fetchFinale(fetchParams, makeNetworkError(reason));
			if (request.responseTainting === "opaque" || response.body == null) {
				processBodyError(response.error);
				return;
			}
			const processBody = (bytes) => {
				if (!bytesMatch(bytes, request.integrity)) {
					processBodyError("integrity mismatch");
					return;
				}
				response.body = safelyExtractBody(bytes)[0];
				fetchFinale(fetchParams, response);
			};
			await fullyReadBody(response.body, processBody, processBodyError);
		} else fetchFinale(fetchParams, response);
	}
	function schemeFetch(fetchParams) {
		if (isCancelled(fetchParams) && fetchParams.request.redirectCount === 0) return Promise.resolve(makeAppropriateNetworkError(fetchParams));
		const { request } = fetchParams;
		const { protocol: scheme } = requestCurrentURL(request);
		switch (scheme) {
			case "about:": return Promise.resolve(makeNetworkError("about scheme is not supported"));
			case "blob:": {
				if (!resolveObjectURL) resolveObjectURL = __require("buffer").resolveObjectURL;
				const blobURLEntry = requestCurrentURL(request);
				if (blobURLEntry.search.length !== 0) return Promise.resolve(makeNetworkError("NetworkError when attempting to fetch resource."));
				const blobURLEntryObject = resolveObjectURL(blobURLEntry.toString());
				if (request.method !== "GET" || !isBlobLike(blobURLEntryObject)) return Promise.resolve(makeNetworkError("invalid method"));
				const bodyWithType = safelyExtractBody(blobURLEntryObject);
				const body = bodyWithType[0];
				const length = isomorphicEncode(`${body.length}`);
				const type = bodyWithType[1] ?? "";
				const response = makeResponse({
					statusText: "OK",
					headersList: [["content-length", {
						name: "Content-Length",
						value: length
					}], ["content-type", {
						name: "Content-Type",
						value: type
					}]]
				});
				response.body = body;
				return Promise.resolve(response);
			}
			case "data:": {
				const dataURLStruct = dataURLProcessor(requestCurrentURL(request));
				if (dataURLStruct === "failure") return Promise.resolve(makeNetworkError("failed to fetch the data URL"));
				const mimeType = serializeAMimeType(dataURLStruct.mimeType);
				return Promise.resolve(makeResponse({
					statusText: "OK",
					headersList: [["content-type", {
						name: "Content-Type",
						value: mimeType
					}]],
					body: safelyExtractBody(dataURLStruct.body)[0]
				}));
			}
			case "file:": return Promise.resolve(makeNetworkError("not implemented... yet..."));
			case "http:":
			case "https:": return httpFetch(fetchParams).catch((err) => makeNetworkError(err));
			default: return Promise.resolve(makeNetworkError("unknown scheme"));
		}
	}
	function finalizeResponse(fetchParams, response) {
		fetchParams.request.done = true;
		if (fetchParams.processResponseDone != null) queueMicrotask(() => fetchParams.processResponseDone(response));
	}
	function fetchFinale(fetchParams, response) {
		if (response.type === "error") {
			response.urlList = [fetchParams.request.urlList[0]];
			response.timingInfo = createOpaqueTimingInfo({ startTime: fetchParams.timingInfo.startTime });
		}
		const processResponseEndOfBody = () => {
			fetchParams.request.done = true;
			if (fetchParams.processResponseEndOfBody != null) queueMicrotask(() => fetchParams.processResponseEndOfBody(response));
		};
		if (fetchParams.processResponse != null) queueMicrotask(() => fetchParams.processResponse(response));
		if (response.body == null) processResponseEndOfBody();
		else {
			const identityTransformAlgorithm = (chunk, controller) => {
				controller.enqueue(chunk);
			};
			const transformStream = new TransformStream({
				start() {},
				transform: identityTransformAlgorithm,
				flush: processResponseEndOfBody
			}, { size() {
				return 1;
			} }, { size() {
				return 1;
			} });
			response.body = { stream: response.body.stream.pipeThrough(transformStream) };
		}
		if (fetchParams.processResponseConsumeBody != null) {
			const processBody = (nullOrBytes) => fetchParams.processResponseConsumeBody(response, nullOrBytes);
			const processBodyError = (failure) => fetchParams.processResponseConsumeBody(response, failure);
			if (response.body == null) queueMicrotask(() => processBody(null));
			else return fullyReadBody(response.body, processBody, processBodyError);
			return Promise.resolve();
		}
	}
	async function httpFetch(fetchParams) {
		const request = fetchParams.request;
		let response = null;
		let actualResponse = null;
		const timingInfo = fetchParams.timingInfo;
		if (request.serviceWorkers === "all") {}
		if (response === null) {
			if (request.redirect === "follow") request.serviceWorkers = "none";
			actualResponse = response = await httpNetworkOrCacheFetch(fetchParams);
			if (request.responseTainting === "cors" && corsCheck(request, response) === "failure") return makeNetworkError("cors failure");
			if (TAOCheck(request, response) === "failure") request.timingAllowFailed = true;
		}
		if ((request.responseTainting === "opaque" || response.type === "opaque") && crossOriginResourcePolicyCheck(request.origin, request.client, request.destination, actualResponse) === "blocked") return makeNetworkError("blocked");
		if (redirectStatusSet.has(actualResponse.status)) {
			if (request.redirect !== "manual") fetchParams.controller.connection.destroy();
			if (request.redirect === "error") response = makeNetworkError("unexpected redirect");
			else if (request.redirect === "manual") response = actualResponse;
			else if (request.redirect === "follow") response = await httpRedirectFetch(fetchParams, response);
			else assert$4(false);
		}
		response.timingInfo = timingInfo;
		return response;
	}
	function httpRedirectFetch(fetchParams, response) {
		const request = fetchParams.request;
		const actualResponse = response.internalResponse ? response.internalResponse : response;
		let locationURL;
		try {
			locationURL = responseLocationURL(actualResponse, requestCurrentURL(request).hash);
			if (locationURL == null) return response;
		} catch (err) {
			return Promise.resolve(makeNetworkError(err));
		}
		if (!urlIsHttpHttpsScheme(locationURL)) return Promise.resolve(makeNetworkError("URL scheme must be a HTTP(S) scheme"));
		if (request.redirectCount === 20) return Promise.resolve(makeNetworkError("redirect count exceeded"));
		request.redirectCount += 1;
		if (request.mode === "cors" && (locationURL.username || locationURL.password) && !sameOrigin(request, locationURL)) return Promise.resolve(makeNetworkError("cross origin not allowed for request mode \"cors\""));
		if (request.responseTainting === "cors" && (locationURL.username || locationURL.password)) return Promise.resolve(makeNetworkError("URL cannot contain credentials for request mode \"cors\""));
		if (actualResponse.status !== 303 && request.body != null && request.body.source == null) return Promise.resolve(makeNetworkError());
		if ([301, 302].includes(actualResponse.status) && request.method === "POST" || actualResponse.status === 303 && !GET_OR_HEAD.includes(request.method)) {
			request.method = "GET";
			request.body = null;
			for (const headerName of requestBodyHeader) request.headersList.delete(headerName);
		}
		if (!sameOrigin(requestCurrentURL(request), locationURL)) {
			request.headersList.delete("authorization");
			request.headersList.delete("proxy-authorization", true);
			request.headersList.delete("cookie");
			request.headersList.delete("host");
		}
		if (request.body != null) {
			assert$4(request.body.source != null);
			request.body = safelyExtractBody(request.body.source)[0];
		}
		const timingInfo = fetchParams.timingInfo;
		timingInfo.redirectEndTime = timingInfo.postRedirectStartTime = coarsenedSharedCurrentTime(fetchParams.crossOriginIsolatedCapability);
		if (timingInfo.redirectStartTime === 0) timingInfo.redirectStartTime = timingInfo.startTime;
		request.urlList.push(locationURL);
		setRequestReferrerPolicyOnRedirect(request, actualResponse);
		return mainFetch(fetchParams, true);
	}
	async function httpNetworkOrCacheFetch(fetchParams, isAuthenticationFetch = false, isNewConnectionFetch = false) {
		const request = fetchParams.request;
		let httpFetchParams = null;
		let httpRequest = null;
		let response = null;
		if (request.window === "no-window" && request.redirect === "error") {
			httpFetchParams = fetchParams;
			httpRequest = request;
		} else {
			httpRequest = makeRequest(request);
			httpFetchParams = { ...fetchParams };
			httpFetchParams.request = httpRequest;
		}
		const includeCredentials = request.credentials === "include" || request.credentials === "same-origin" && request.responseTainting === "basic";
		const contentLength = httpRequest.body ? httpRequest.body.length : null;
		let contentLengthHeaderValue = null;
		if (httpRequest.body == null && ["POST", "PUT"].includes(httpRequest.method)) contentLengthHeaderValue = "0";
		if (contentLength != null) contentLengthHeaderValue = isomorphicEncode(`${contentLength}`);
		if (contentLengthHeaderValue != null) httpRequest.headersList.append("content-length", contentLengthHeaderValue);
		if (contentLength != null && httpRequest.keepalive) {}
		if (httpRequest.referrer instanceof URL) httpRequest.headersList.append("referer", isomorphicEncode(httpRequest.referrer.href));
		appendRequestOriginHeader(httpRequest);
		appendFetchMetadata(httpRequest);
		if (!httpRequest.headersList.contains("user-agent")) httpRequest.headersList.append("user-agent", typeof esbuildDetection === "undefined" ? "undici" : "node");
		if (httpRequest.cache === "default" && (httpRequest.headersList.contains("if-modified-since") || httpRequest.headersList.contains("if-none-match") || httpRequest.headersList.contains("if-unmodified-since") || httpRequest.headersList.contains("if-match") || httpRequest.headersList.contains("if-range"))) httpRequest.cache = "no-store";
		if (httpRequest.cache === "no-cache" && !httpRequest.preventNoCacheCacheControlHeaderModification && !httpRequest.headersList.contains("cache-control")) httpRequest.headersList.append("cache-control", "max-age=0");
		if (httpRequest.cache === "no-store" || httpRequest.cache === "reload") {
			if (!httpRequest.headersList.contains("pragma")) httpRequest.headersList.append("pragma", "no-cache");
			if (!httpRequest.headersList.contains("cache-control")) httpRequest.headersList.append("cache-control", "no-cache");
		}
		if (httpRequest.headersList.contains("range")) httpRequest.headersList.append("accept-encoding", "identity");
		if (!httpRequest.headersList.contains("accept-encoding")) {
			if (urlHasHttpsScheme(requestCurrentURL(httpRequest))) httpRequest.headersList.append("accept-encoding", "br, gzip, deflate");
			else httpRequest.headersList.append("accept-encoding", "gzip, deflate");
		}
		httpRequest.headersList.delete("host");
		if (includeCredentials) {}
		httpRequest.cache = "no-store";
		if (httpRequest.mode !== "no-store" && httpRequest.mode !== "reload") {}
		if (response == null) {
			if (httpRequest.mode === "only-if-cached") return makeNetworkError("only if cached");
			const forwardResponse = await httpNetworkFetch(httpFetchParams, includeCredentials, isNewConnectionFetch);
			if (!safeMethodsSet.has(httpRequest.method) && forwardResponse.status >= 200 && forwardResponse.status <= 399) {}
			if (response == null) response = forwardResponse;
		}
		response.urlList = [...httpRequest.urlList];
		if (httpRequest.headersList.contains("range")) response.rangeRequested = true;
		response.requestIncludesCredentials = includeCredentials;
		if (response.status === 407) {
			if (request.window === "no-window") return makeNetworkError();
			if (isCancelled(fetchParams)) return makeAppropriateNetworkError(fetchParams);
			return makeNetworkError("proxy authentication required");
		}
		if (response.status === 421 && !isNewConnectionFetch && (request.body == null || request.body.source != null)) {
			if (isCancelled(fetchParams)) return makeAppropriateNetworkError(fetchParams);
			fetchParams.controller.connection.destroy();
			response = await httpNetworkOrCacheFetch(fetchParams, isAuthenticationFetch, true);
		}
		if (isAuthenticationFetch) {}
		return response;
	}
	async function httpNetworkFetch(fetchParams, includeCredentials = false, forceNewConnection = false) {
		assert$4(!fetchParams.controller.connection || fetchParams.controller.connection.destroyed);
		fetchParams.controller.connection = {
			abort: null,
			destroyed: false,
			destroy(err) {
				if (!this.destroyed) {
					this.destroyed = true;
					this.abort?.(err ?? new DOMException("The operation was aborted.", "AbortError"));
				}
			}
		};
		const request = fetchParams.request;
		let response = null;
		const timingInfo = fetchParams.timingInfo;
		request.cache = "no-store";
		if (request.mode === "websocket") {}
		let requestBody = null;
		if (request.body == null && fetchParams.processRequestEndOfBody) queueMicrotask(() => fetchParams.processRequestEndOfBody());
		else if (request.body != null) {
			const processBodyChunk = async function* (bytes) {
				if (isCancelled(fetchParams)) return;
				yield bytes;
				fetchParams.processRequestBodyChunkLength?.(bytes.byteLength);
			};
			const processEndOfBody = () => {
				if (isCancelled(fetchParams)) return;
				if (fetchParams.processRequestEndOfBody) fetchParams.processRequestEndOfBody();
			};
			const processBodyError = (e) => {
				if (isCancelled(fetchParams)) return;
				if (e.name === "AbortError") fetchParams.controller.abort();
				else fetchParams.controller.terminate(e);
			};
			requestBody = (async function* () {
				try {
					for await (const bytes of request.body.stream) yield* processBodyChunk(bytes);
					processEndOfBody();
				} catch (err) {
					processBodyError(err);
				}
			})();
		}
		try {
			const { body, status, statusText, headersList, socket } = await dispatch({ body: requestBody });
			if (socket) response = makeResponse({
				status,
				statusText,
				headersList,
				socket
			});
			else {
				const iterator = body[Symbol.asyncIterator]();
				fetchParams.controller.next = () => iterator.next();
				response = makeResponse({
					status,
					statusText,
					headersList
				});
			}
		} catch (err) {
			if (err.name === "AbortError") {
				fetchParams.controller.connection.destroy();
				return makeAppropriateNetworkError(fetchParams, err);
			}
			return makeNetworkError(err);
		}
		const pullAlgorithm = () => {
			fetchParams.controller.resume();
		};
		const cancelAlgorithm = (reason) => {
			fetchParams.controller.abort(reason);
		};
		if (!ReadableStream) ReadableStream = __require("stream/web").ReadableStream;
		const stream = new ReadableStream({
			async start(controller) {
				fetchParams.controller.controller = controller;
			},
			async pull(controller) {
				await pullAlgorithm(controller);
			},
			async cancel(reason) {
				await cancelAlgorithm(reason);
			}
		}, {
			highWaterMark: 0,
			size() {
				return 1;
			}
		});
		response.body = { stream };
		fetchParams.controller.on("terminated", onAborted);
		fetchParams.controller.resume = async () => {
			while (true) {
				let bytes;
				let isFailure;
				try {
					const { done, value } = await fetchParams.controller.next();
					if (isAborted(fetchParams)) break;
					bytes = done ? void 0 : value;
				} catch (err) {
					if (fetchParams.controller.ended && !timingInfo.encodedBodySize) bytes = void 0;
					else {
						bytes = err;
						isFailure = true;
					}
				}
				if (bytes === void 0) {
					readableStreamClose(fetchParams.controller.controller);
					finalizeResponse(fetchParams, response);
					return;
				}
				timingInfo.decodedBodySize += bytes?.byteLength ?? 0;
				if (isFailure) {
					fetchParams.controller.terminate(bytes);
					return;
				}
				fetchParams.controller.controller.enqueue(new Uint8Array(bytes));
				if (isErrored(stream)) {
					fetchParams.controller.terminate();
					return;
				}
				if (!fetchParams.controller.controller.desiredSize) return;
			}
		};
		function onAborted(reason) {
			if (isAborted(fetchParams)) {
				response.aborted = true;
				if (isReadable(stream)) fetchParams.controller.controller.error(fetchParams.controller.serializedAbortReason);
			} else if (isReadable(stream)) fetchParams.controller.controller.error(new TypeError("terminated", { cause: isErrorLike(reason) ? reason : void 0 }));
			fetchParams.controller.connection.destroy();
		}
		return response;
		async function dispatch({ body }) {
			const url = requestCurrentURL(request);
			/** @type {import('../..').Agent} */
			const agent = fetchParams.controller.dispatcher;
			return new Promise((resolve, reject) => agent.dispatch({
				path: url.pathname + url.search,
				origin: url.origin,
				method: request.method,
				body: fetchParams.controller.dispatcher.isMockActive ? request.body && (request.body.source || request.body.stream) : body,
				headers: request.headersList.entries,
				maxRedirections: 0,
				upgrade: request.mode === "websocket" ? "websocket" : void 0
			}, {
				body: null,
				abort: null,
				onConnect(abort) {
					const { connection } = fetchParams.controller;
					if (connection.destroyed) abort(new DOMException("The operation was aborted.", "AbortError"));
					else {
						fetchParams.controller.on("terminated", abort);
						this.abort = connection.abort = abort;
					}
				},
				onHeaders(status, headersList, resume, statusText) {
					if (status < 200) return;
					let codings = [];
					let location = "";
					const headers = new Headers();
					if (Array.isArray(headersList)) for (let n = 0; n < headersList.length; n += 2) {
						const key = headersList[n + 0].toString("latin1");
						const val = headersList[n + 1].toString("latin1");
						if (key.toLowerCase() === "content-encoding") codings = val.toLowerCase().split(",").map((x) => x.trim());
						else if (key.toLowerCase() === "location") location = val;
						headers[kHeadersList].append(key, val);
					}
					else {
						const keys = Object.keys(headersList);
						for (const key of keys) {
							const val = headersList[key];
							if (key.toLowerCase() === "content-encoding") codings = val.toLowerCase().split(",").map((x) => x.trim()).reverse();
							else if (key.toLowerCase() === "location") location = val;
							headers[kHeadersList].append(key, val);
						}
					}
					this.body = new Readable({ read: resume });
					const decoders = [];
					const willFollow = request.redirect === "follow" && location && redirectStatusSet.has(status);
					if (request.method !== "HEAD" && request.method !== "CONNECT" && !nullBodyStatus.includes(status) && !willFollow) for (const coding of codings) if (coding === "x-gzip" || coding === "gzip") decoders.push(zlib.createGunzip({
						flush: zlib.constants.Z_SYNC_FLUSH,
						finishFlush: zlib.constants.Z_SYNC_FLUSH
					}));
					else if (coding === "deflate") decoders.push(zlib.createInflate());
					else if (coding === "br") decoders.push(zlib.createBrotliDecompress());
					else {
						decoders.length = 0;
						break;
					}
					resolve({
						status,
						statusText,
						headersList: headers[kHeadersList],
						body: decoders.length ? pipeline(this.body, ...decoders, () => {}) : this.body.on("error", () => {})
					});
					return true;
				},
				onData(chunk) {
					if (fetchParams.controller.dump) return;
					const bytes = chunk;
					timingInfo.encodedBodySize += bytes.byteLength;
					return this.body.push(bytes);
				},
				onComplete() {
					if (this.abort) fetchParams.controller.off("terminated", this.abort);
					fetchParams.controller.ended = true;
					this.body.push(null);
				},
				onError(error) {
					if (this.abort) fetchParams.controller.off("terminated", this.abort);
					this.body?.destroy(error);
					fetchParams.controller.terminate(error);
					reject(error);
				},
				onUpgrade(status, headersList, socket) {
					if (status !== 101) return;
					const headers = new Headers();
					for (let n = 0; n < headersList.length; n += 2) {
						const key = headersList[n + 0].toString("latin1");
						const val = headersList[n + 1].toString("latin1");
						headers[kHeadersList].append(key, val);
					}
					resolve({
						status,
						statusText: STATUS_CODES[status],
						headersList: headers[kHeadersList],
						socket
					});
					return true;
				}
			}));
		}
	}
	module.exports = {
		fetch,
		Fetch,
		fetching,
		finalizeAndReportTiming
	};
}));
//#endregion
//#region node_modules/undici/lib/fileapi/symbols.js
var require_symbols$2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		kState: Symbol("FileReader state"),
		kResult: Symbol("FileReader result"),
		kError: Symbol("FileReader error"),
		kLastProgressEventFired: Symbol("FileReader last progress event fired timestamp"),
		kEvents: Symbol("FileReader events"),
		kAborted: Symbol("FileReader aborted")
	};
}));
//#endregion
//#region node_modules/undici/lib/fileapi/progressevent.js
var require_progressevent = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { webidl } = require_webidl();
	var kState = Symbol("ProgressEvent state");
	/**
	* @see https://xhr.spec.whatwg.org/#progressevent
	*/
	var ProgressEvent = class ProgressEvent extends Event {
		constructor(type, eventInitDict = {}) {
			type = webidl.converters.DOMString(type);
			eventInitDict = webidl.converters.ProgressEventInit(eventInitDict ?? {});
			super(type, eventInitDict);
			this[kState] = {
				lengthComputable: eventInitDict.lengthComputable,
				loaded: eventInitDict.loaded,
				total: eventInitDict.total
			};
		}
		get lengthComputable() {
			webidl.brandCheck(this, ProgressEvent);
			return this[kState].lengthComputable;
		}
		get loaded() {
			webidl.brandCheck(this, ProgressEvent);
			return this[kState].loaded;
		}
		get total() {
			webidl.brandCheck(this, ProgressEvent);
			return this[kState].total;
		}
	};
	webidl.converters.ProgressEventInit = webidl.dictionaryConverter([
		{
			key: "lengthComputable",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "loaded",
			converter: webidl.converters["unsigned long long"],
			defaultValue: 0
		},
		{
			key: "total",
			converter: webidl.converters["unsigned long long"],
			defaultValue: 0
		},
		{
			key: "bubbles",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "cancelable",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "composed",
			converter: webidl.converters.boolean,
			defaultValue: false
		}
	]);
	module.exports = { ProgressEvent };
}));
//#endregion
//#region node_modules/undici/lib/fileapi/encoding.js
var require_encoding = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* @see https://encoding.spec.whatwg.org/#concept-encoding-get
	* @param {string|undefined} label
	*/
	function getEncoding(label) {
		if (!label) return "failure";
		switch (label.trim().toLowerCase()) {
			case "unicode-1-1-utf-8":
			case "unicode11utf8":
			case "unicode20utf8":
			case "utf-8":
			case "utf8":
			case "x-unicode20utf8": return "UTF-8";
			case "866":
			case "cp866":
			case "csibm866":
			case "ibm866": return "IBM866";
			case "csisolatin2":
			case "iso-8859-2":
			case "iso-ir-101":
			case "iso8859-2":
			case "iso88592":
			case "iso_8859-2":
			case "iso_8859-2:1987":
			case "l2":
			case "latin2": return "ISO-8859-2";
			case "csisolatin3":
			case "iso-8859-3":
			case "iso-ir-109":
			case "iso8859-3":
			case "iso88593":
			case "iso_8859-3":
			case "iso_8859-3:1988":
			case "l3":
			case "latin3": return "ISO-8859-3";
			case "csisolatin4":
			case "iso-8859-4":
			case "iso-ir-110":
			case "iso8859-4":
			case "iso88594":
			case "iso_8859-4":
			case "iso_8859-4:1988":
			case "l4":
			case "latin4": return "ISO-8859-4";
			case "csisolatincyrillic":
			case "cyrillic":
			case "iso-8859-5":
			case "iso-ir-144":
			case "iso8859-5":
			case "iso88595":
			case "iso_8859-5":
			case "iso_8859-5:1988": return "ISO-8859-5";
			case "arabic":
			case "asmo-708":
			case "csiso88596e":
			case "csiso88596i":
			case "csisolatinarabic":
			case "ecma-114":
			case "iso-8859-6":
			case "iso-8859-6-e":
			case "iso-8859-6-i":
			case "iso-ir-127":
			case "iso8859-6":
			case "iso88596":
			case "iso_8859-6":
			case "iso_8859-6:1987": return "ISO-8859-6";
			case "csisolatingreek":
			case "ecma-118":
			case "elot_928":
			case "greek":
			case "greek8":
			case "iso-8859-7":
			case "iso-ir-126":
			case "iso8859-7":
			case "iso88597":
			case "iso_8859-7":
			case "iso_8859-7:1987":
			case "sun_eu_greek": return "ISO-8859-7";
			case "csiso88598e":
			case "csisolatinhebrew":
			case "hebrew":
			case "iso-8859-8":
			case "iso-8859-8-e":
			case "iso-ir-138":
			case "iso8859-8":
			case "iso88598":
			case "iso_8859-8":
			case "iso_8859-8:1988":
			case "visual": return "ISO-8859-8";
			case "csiso88598i":
			case "iso-8859-8-i":
			case "logical": return "ISO-8859-8-I";
			case "csisolatin6":
			case "iso-8859-10":
			case "iso-ir-157":
			case "iso8859-10":
			case "iso885910":
			case "l6":
			case "latin6": return "ISO-8859-10";
			case "iso-8859-13":
			case "iso8859-13":
			case "iso885913": return "ISO-8859-13";
			case "iso-8859-14":
			case "iso8859-14":
			case "iso885914": return "ISO-8859-14";
			case "csisolatin9":
			case "iso-8859-15":
			case "iso8859-15":
			case "iso885915":
			case "iso_8859-15":
			case "l9": return "ISO-8859-15";
			case "iso-8859-16": return "ISO-8859-16";
			case "cskoi8r":
			case "koi":
			case "koi8":
			case "koi8-r":
			case "koi8_r": return "KOI8-R";
			case "koi8-ru":
			case "koi8-u": return "KOI8-U";
			case "csmacintosh":
			case "mac":
			case "macintosh":
			case "x-mac-roman": return "macintosh";
			case "iso-8859-11":
			case "iso8859-11":
			case "iso885911":
			case "tis-620":
			case "windows-874": return "windows-874";
			case "cp1250":
			case "windows-1250":
			case "x-cp1250": return "windows-1250";
			case "cp1251":
			case "windows-1251":
			case "x-cp1251": return "windows-1251";
			case "ansi_x3.4-1968":
			case "ascii":
			case "cp1252":
			case "cp819":
			case "csisolatin1":
			case "ibm819":
			case "iso-8859-1":
			case "iso-ir-100":
			case "iso8859-1":
			case "iso88591":
			case "iso_8859-1":
			case "iso_8859-1:1987":
			case "l1":
			case "latin1":
			case "us-ascii":
			case "windows-1252":
			case "x-cp1252": return "windows-1252";
			case "cp1253":
			case "windows-1253":
			case "x-cp1253": return "windows-1253";
			case "cp1254":
			case "csisolatin5":
			case "iso-8859-9":
			case "iso-ir-148":
			case "iso8859-9":
			case "iso88599":
			case "iso_8859-9":
			case "iso_8859-9:1989":
			case "l5":
			case "latin5":
			case "windows-1254":
			case "x-cp1254": return "windows-1254";
			case "cp1255":
			case "windows-1255":
			case "x-cp1255": return "windows-1255";
			case "cp1256":
			case "windows-1256":
			case "x-cp1256": return "windows-1256";
			case "cp1257":
			case "windows-1257":
			case "x-cp1257": return "windows-1257";
			case "cp1258":
			case "windows-1258":
			case "x-cp1258": return "windows-1258";
			case "x-mac-cyrillic":
			case "x-mac-ukrainian": return "x-mac-cyrillic";
			case "chinese":
			case "csgb2312":
			case "csiso58gb231280":
			case "gb2312":
			case "gb_2312":
			case "gb_2312-80":
			case "gbk":
			case "iso-ir-58":
			case "x-gbk": return "GBK";
			case "gb18030": return "gb18030";
			case "big5":
			case "big5-hkscs":
			case "cn-big5":
			case "csbig5":
			case "x-x-big5": return "Big5";
			case "cseucpkdfmtjapanese":
			case "euc-jp":
			case "x-euc-jp": return "EUC-JP";
			case "csiso2022jp":
			case "iso-2022-jp": return "ISO-2022-JP";
			case "csshiftjis":
			case "ms932":
			case "ms_kanji":
			case "shift-jis":
			case "shift_jis":
			case "sjis":
			case "windows-31j":
			case "x-sjis": return "Shift_JIS";
			case "cseuckr":
			case "csksc56011987":
			case "euc-kr":
			case "iso-ir-149":
			case "korean":
			case "ks_c_5601-1987":
			case "ks_c_5601-1989":
			case "ksc5601":
			case "ksc_5601":
			case "windows-949": return "EUC-KR";
			case "csiso2022kr":
			case "hz-gb-2312":
			case "iso-2022-cn":
			case "iso-2022-cn-ext":
			case "iso-2022-kr":
			case "replacement": return "replacement";
			case "unicodefffe":
			case "utf-16be": return "UTF-16BE";
			case "csunicode":
			case "iso-10646-ucs-2":
			case "ucs-2":
			case "unicode":
			case "unicodefeff":
			case "utf-16":
			case "utf-16le": return "UTF-16LE";
			case "x-user-defined": return "x-user-defined";
			default: return "failure";
		}
	}
	module.exports = { getEncoding };
}));
//#endregion
//#region node_modules/undici/lib/fileapi/util.js
var require_util$3 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kState, kError, kResult, kAborted, kLastProgressEventFired } = require_symbols$2();
	var { ProgressEvent } = require_progressevent();
	var { getEncoding } = require_encoding();
	var { DOMException } = require_constants$3();
	var { serializeAMimeType, parseMIMEType } = require_dataURL();
	var { types: types$1 } = __require("util");
	var { StringDecoder } = __require("string_decoder");
	var { btoa } = __require("buffer");
	/** @type {PropertyDescriptor} */
	var staticPropertyDescriptors = {
		enumerable: true,
		writable: false,
		configurable: false
	};
	/**
	* @see https://w3c.github.io/FileAPI/#readOperation
	* @param {import('./filereader').FileReader} fr
	* @param {import('buffer').Blob} blob
	* @param {string} type
	* @param {string?} encodingName
	*/
	function readOperation(fr, blob, type, encodingName) {
		if (fr[kState] === "loading") throw new DOMException("Invalid state", "InvalidStateError");
		fr[kState] = "loading";
		fr[kResult] = null;
		fr[kError] = null;
		const reader = blob.stream().getReader();
		/** @type {Uint8Array[]} */
		const bytes = [];
		let chunkPromise = reader.read();
		let isFirstChunk = true;
		(async () => {
			while (!fr[kAborted]) try {
				const { done, value } = await chunkPromise;
				if (isFirstChunk && !fr[kAborted]) queueMicrotask(() => {
					fireAProgressEvent("loadstart", fr);
				});
				isFirstChunk = false;
				if (!done && types$1.isUint8Array(value)) {
					bytes.push(value);
					if ((fr[kLastProgressEventFired] === void 0 || Date.now() - fr[kLastProgressEventFired] >= 50) && !fr[kAborted]) {
						fr[kLastProgressEventFired] = Date.now();
						queueMicrotask(() => {
							fireAProgressEvent("progress", fr);
						});
					}
					chunkPromise = reader.read();
				} else if (done) {
					queueMicrotask(() => {
						fr[kState] = "done";
						try {
							const result = packageData(bytes, type, blob.type, encodingName);
							if (fr[kAborted]) return;
							fr[kResult] = result;
							fireAProgressEvent("load", fr);
						} catch (error) {
							fr[kError] = error;
							fireAProgressEvent("error", fr);
						}
						if (fr[kState] !== "loading") fireAProgressEvent("loadend", fr);
					});
					break;
				}
			} catch (error) {
				if (fr[kAborted]) return;
				queueMicrotask(() => {
					fr[kState] = "done";
					fr[kError] = error;
					fireAProgressEvent("error", fr);
					if (fr[kState] !== "loading") fireAProgressEvent("loadend", fr);
				});
				break;
			}
		})();
	}
	/**
	* @see https://w3c.github.io/FileAPI/#fire-a-progress-event
	* @see https://dom.spec.whatwg.org/#concept-event-fire
	* @param {string} e The name of the event
	* @param {import('./filereader').FileReader} reader
	*/
	function fireAProgressEvent(e, reader) {
		const event = new ProgressEvent(e, {
			bubbles: false,
			cancelable: false
		});
		reader.dispatchEvent(event);
	}
	/**
	* @see https://w3c.github.io/FileAPI/#blob-package-data
	* @param {Uint8Array[]} bytes
	* @param {string} type
	* @param {string?} mimeType
	* @param {string?} encodingName
	*/
	function packageData(bytes, type, mimeType, encodingName) {
		switch (type) {
			case "DataURL": {
				let dataURL = "data:";
				const parsed = parseMIMEType(mimeType || "application/octet-stream");
				if (parsed !== "failure") dataURL += serializeAMimeType(parsed);
				dataURL += ";base64,";
				const decoder = new StringDecoder("latin1");
				for (const chunk of bytes) dataURL += btoa(decoder.write(chunk));
				dataURL += btoa(decoder.end());
				return dataURL;
			}
			case "Text": {
				let encoding = "failure";
				if (encodingName) encoding = getEncoding(encodingName);
				if (encoding === "failure" && mimeType) {
					const type = parseMIMEType(mimeType);
					if (type !== "failure") encoding = getEncoding(type.parameters.get("charset"));
				}
				if (encoding === "failure") encoding = "UTF-8";
				return decode(bytes, encoding);
			}
			case "ArrayBuffer": return combineByteSequences(bytes).buffer;
			case "BinaryString": {
				let binaryString = "";
				const decoder = new StringDecoder("latin1");
				for (const chunk of bytes) binaryString += decoder.write(chunk);
				binaryString += decoder.end();
				return binaryString;
			}
		}
	}
	/**
	* @see https://encoding.spec.whatwg.org/#decode
	* @param {Uint8Array[]} ioQueue
	* @param {string} encoding
	*/
	function decode(ioQueue, encoding) {
		const bytes = combineByteSequences(ioQueue);
		const BOMEncoding = BOMSniffing(bytes);
		let slice = 0;
		if (BOMEncoding !== null) {
			encoding = BOMEncoding;
			slice = BOMEncoding === "UTF-8" ? 3 : 2;
		}
		const sliced = bytes.slice(slice);
		return new TextDecoder(encoding).decode(sliced);
	}
	/**
	* @see https://encoding.spec.whatwg.org/#bom-sniff
	* @param {Uint8Array} ioQueue
	*/
	function BOMSniffing(ioQueue) {
		const [a, b, c] = ioQueue;
		if (a === 239 && b === 187 && c === 191) return "UTF-8";
		else if (a === 254 && b === 255) return "UTF-16BE";
		else if (a === 255 && b === 254) return "UTF-16LE";
		return null;
	}
	/**
	* @param {Uint8Array[]} sequences
	*/
	function combineByteSequences(sequences) {
		const size = sequences.reduce((a, b) => {
			return a + b.byteLength;
		}, 0);
		let offset = 0;
		return sequences.reduce((a, b) => {
			a.set(b, offset);
			offset += b.byteLength;
			return a;
		}, new Uint8Array(size));
	}
	module.exports = {
		staticPropertyDescriptors,
		readOperation,
		fireAProgressEvent
	};
}));
//#endregion
//#region node_modules/undici/lib/fileapi/filereader.js
var require_filereader = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { staticPropertyDescriptors, readOperation, fireAProgressEvent } = require_util$3();
	var { kState, kError, kResult, kEvents, kAborted } = require_symbols$2();
	var { webidl } = require_webidl();
	var { kEnumerableProperty } = require_util$6();
	var FileReader = class FileReader extends EventTarget {
		constructor() {
			super();
			this[kState] = "empty";
			this[kResult] = null;
			this[kError] = null;
			this[kEvents] = {
				loadend: null,
				error: null,
				abort: null,
				load: null,
				progress: null,
				loadstart: null
			};
		}
		/**
		* @see https://w3c.github.io/FileAPI/#dfn-readAsArrayBuffer
		* @param {import('buffer').Blob} blob
		*/
		readAsArrayBuffer(blob) {
			webidl.brandCheck(this, FileReader);
			webidl.argumentLengthCheck(arguments, 1, { header: "FileReader.readAsArrayBuffer" });
			blob = webidl.converters.Blob(blob, { strict: false });
			readOperation(this, blob, "ArrayBuffer");
		}
		/**
		* @see https://w3c.github.io/FileAPI/#readAsBinaryString
		* @param {import('buffer').Blob} blob
		*/
		readAsBinaryString(blob) {
			webidl.brandCheck(this, FileReader);
			webidl.argumentLengthCheck(arguments, 1, { header: "FileReader.readAsBinaryString" });
			blob = webidl.converters.Blob(blob, { strict: false });
			readOperation(this, blob, "BinaryString");
		}
		/**
		* @see https://w3c.github.io/FileAPI/#readAsDataText
		* @param {import('buffer').Blob} blob
		* @param {string?} encoding
		*/
		readAsText(blob, encoding = void 0) {
			webidl.brandCheck(this, FileReader);
			webidl.argumentLengthCheck(arguments, 1, { header: "FileReader.readAsText" });
			blob = webidl.converters.Blob(blob, { strict: false });
			if (encoding !== void 0) encoding = webidl.converters.DOMString(encoding);
			readOperation(this, blob, "Text", encoding);
		}
		/**
		* @see https://w3c.github.io/FileAPI/#dfn-readAsDataURL
		* @param {import('buffer').Blob} blob
		*/
		readAsDataURL(blob) {
			webidl.brandCheck(this, FileReader);
			webidl.argumentLengthCheck(arguments, 1, { header: "FileReader.readAsDataURL" });
			blob = webidl.converters.Blob(blob, { strict: false });
			readOperation(this, blob, "DataURL");
		}
		/**
		* @see https://w3c.github.io/FileAPI/#dfn-abort
		*/
		abort() {
			if (this[kState] === "empty" || this[kState] === "done") {
				this[kResult] = null;
				return;
			}
			if (this[kState] === "loading") {
				this[kState] = "done";
				this[kResult] = null;
			}
			this[kAborted] = true;
			fireAProgressEvent("abort", this);
			if (this[kState] !== "loading") fireAProgressEvent("loadend", this);
		}
		/**
		* @see https://w3c.github.io/FileAPI/#dom-filereader-readystate
		*/
		get readyState() {
			webidl.brandCheck(this, FileReader);
			switch (this[kState]) {
				case "empty": return this.EMPTY;
				case "loading": return this.LOADING;
				case "done": return this.DONE;
			}
		}
		/**
		* @see https://w3c.github.io/FileAPI/#dom-filereader-result
		*/
		get result() {
			webidl.brandCheck(this, FileReader);
			return this[kResult];
		}
		/**
		* @see https://w3c.github.io/FileAPI/#dom-filereader-error
		*/
		get error() {
			webidl.brandCheck(this, FileReader);
			return this[kError];
		}
		get onloadend() {
			webidl.brandCheck(this, FileReader);
			return this[kEvents].loadend;
		}
		set onloadend(fn) {
			webidl.brandCheck(this, FileReader);
			if (this[kEvents].loadend) this.removeEventListener("loadend", this[kEvents].loadend);
			if (typeof fn === "function") {
				this[kEvents].loadend = fn;
				this.addEventListener("loadend", fn);
			} else this[kEvents].loadend = null;
		}
		get onerror() {
			webidl.brandCheck(this, FileReader);
			return this[kEvents].error;
		}
		set onerror(fn) {
			webidl.brandCheck(this, FileReader);
			if (this[kEvents].error) this.removeEventListener("error", this[kEvents].error);
			if (typeof fn === "function") {
				this[kEvents].error = fn;
				this.addEventListener("error", fn);
			} else this[kEvents].error = null;
		}
		get onloadstart() {
			webidl.brandCheck(this, FileReader);
			return this[kEvents].loadstart;
		}
		set onloadstart(fn) {
			webidl.brandCheck(this, FileReader);
			if (this[kEvents].loadstart) this.removeEventListener("loadstart", this[kEvents].loadstart);
			if (typeof fn === "function") {
				this[kEvents].loadstart = fn;
				this.addEventListener("loadstart", fn);
			} else this[kEvents].loadstart = null;
		}
		get onprogress() {
			webidl.brandCheck(this, FileReader);
			return this[kEvents].progress;
		}
		set onprogress(fn) {
			webidl.brandCheck(this, FileReader);
			if (this[kEvents].progress) this.removeEventListener("progress", this[kEvents].progress);
			if (typeof fn === "function") {
				this[kEvents].progress = fn;
				this.addEventListener("progress", fn);
			} else this[kEvents].progress = null;
		}
		get onload() {
			webidl.brandCheck(this, FileReader);
			return this[kEvents].load;
		}
		set onload(fn) {
			webidl.brandCheck(this, FileReader);
			if (this[kEvents].load) this.removeEventListener("load", this[kEvents].load);
			if (typeof fn === "function") {
				this[kEvents].load = fn;
				this.addEventListener("load", fn);
			} else this[kEvents].load = null;
		}
		get onabort() {
			webidl.brandCheck(this, FileReader);
			return this[kEvents].abort;
		}
		set onabort(fn) {
			webidl.brandCheck(this, FileReader);
			if (this[kEvents].abort) this.removeEventListener("abort", this[kEvents].abort);
			if (typeof fn === "function") {
				this[kEvents].abort = fn;
				this.addEventListener("abort", fn);
			} else this[kEvents].abort = null;
		}
	};
	FileReader.EMPTY = FileReader.prototype.EMPTY = 0;
	FileReader.LOADING = FileReader.prototype.LOADING = 1;
	FileReader.DONE = FileReader.prototype.DONE = 2;
	Object.defineProperties(FileReader.prototype, {
		EMPTY: staticPropertyDescriptors,
		LOADING: staticPropertyDescriptors,
		DONE: staticPropertyDescriptors,
		readAsArrayBuffer: kEnumerableProperty,
		readAsBinaryString: kEnumerableProperty,
		readAsText: kEnumerableProperty,
		readAsDataURL: kEnumerableProperty,
		abort: kEnumerableProperty,
		readyState: kEnumerableProperty,
		result: kEnumerableProperty,
		error: kEnumerableProperty,
		onloadstart: kEnumerableProperty,
		onprogress: kEnumerableProperty,
		onload: kEnumerableProperty,
		onabort: kEnumerableProperty,
		onerror: kEnumerableProperty,
		onloadend: kEnumerableProperty,
		[Symbol.toStringTag]: {
			value: "FileReader",
			writable: false,
			enumerable: false,
			configurable: true
		}
	});
	Object.defineProperties(FileReader, {
		EMPTY: staticPropertyDescriptors,
		LOADING: staticPropertyDescriptors,
		DONE: staticPropertyDescriptors
	});
	module.exports = { FileReader };
}));
//#endregion
//#region node_modules/undici/lib/cache/symbols.js
var require_symbols$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = { kConstruct: require_symbols$4().kConstruct };
}));
//#endregion
//#region node_modules/undici/lib/cache/util.js
var require_util$2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$3 = __require("assert");
	var { URLSerializer } = require_dataURL();
	var { isValidHeaderName } = require_util$5();
	/**
	* @see https://url.spec.whatwg.org/#concept-url-equals
	* @param {URL} A
	* @param {URL} B
	* @param {boolean | undefined} excludeFragment
	* @returns {boolean}
	*/
	function urlEquals(A, B, excludeFragment = false) {
		return URLSerializer(A, excludeFragment) === URLSerializer(B, excludeFragment);
	}
	/**
	* @see https://github.com/chromium/chromium/blob/694d20d134cb553d8d89e5500b9148012b1ba299/content/browser/cache_storage/cache_storage_cache.cc#L260-L262
	* @param {string} header
	*/
	function fieldValues(header) {
		assert$3(header !== null);
		const values = [];
		for (let value of header.split(",")) {
			value = value.trim();
			if (!value.length) continue;
			else if (!isValidHeaderName(value)) continue;
			values.push(value);
		}
		return values;
	}
	module.exports = {
		urlEquals,
		fieldValues
	};
}));
//#endregion
//#region node_modules/undici/lib/cache/cache.js
var require_cache = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kConstruct } = require_symbols$1();
	var { urlEquals, fieldValues: getFieldValues } = require_util$2();
	var { kEnumerableProperty, isDisturbed } = require_util$6();
	var { kHeadersList } = require_symbols$4();
	var { webidl } = require_webidl();
	var { Response, cloneResponse } = require_response();
	var { Request } = require_request();
	var { kState, kHeaders, kGuard, kRealm } = require_symbols$3();
	var { fetching } = require_fetch();
	var { urlIsHttpHttpsScheme, createDeferredPromise, readAllBytes } = require_util$5();
	var assert$2 = __require("assert");
	var { getGlobalDispatcher } = require_global();
	/**
	* @see https://w3c.github.io/ServiceWorker/#dfn-cache-batch-operation
	* @typedef {Object} CacheBatchOperation
	* @property {'delete' | 'put'} type
	* @property {any} request
	* @property {any} response
	* @property {import('../../types/cache').CacheQueryOptions} options
	*/
	/**
	* @see https://w3c.github.io/ServiceWorker/#dfn-request-response-list
	* @typedef {[any, any][]} requestResponseList
	*/
	var Cache = class Cache {
		/**
		* @see https://w3c.github.io/ServiceWorker/#dfn-relevant-request-response-list
		* @type {requestResponseList}
		*/
		#relevantRequestResponseList;
		constructor() {
			if (arguments[0] !== kConstruct) webidl.illegalConstructor();
			this.#relevantRequestResponseList = arguments[1];
		}
		async match(request, options = {}) {
			webidl.brandCheck(this, Cache);
			webidl.argumentLengthCheck(arguments, 1, { header: "Cache.match" });
			request = webidl.converters.RequestInfo(request);
			options = webidl.converters.CacheQueryOptions(options);
			const p = await this.matchAll(request, options);
			if (p.length === 0) return;
			return p[0];
		}
		async matchAll(request = void 0, options = {}) {
			webidl.brandCheck(this, Cache);
			if (request !== void 0) request = webidl.converters.RequestInfo(request);
			options = webidl.converters.CacheQueryOptions(options);
			let r = null;
			if (request !== void 0) {
				if (request instanceof Request) {
					r = request[kState];
					if (r.method !== "GET" && !options.ignoreMethod) return [];
				} else if (typeof request === "string") r = new Request(request)[kState];
			}
			const responses = [];
			if (request === void 0) for (const requestResponse of this.#relevantRequestResponseList) responses.push(requestResponse[1]);
			else {
				const requestResponses = this.#queryCache(r, options);
				for (const requestResponse of requestResponses) responses.push(requestResponse[1]);
			}
			const responseList = [];
			for (const response of responses) {
				const responseObject = new Response(response.body?.source ?? null);
				const body = responseObject[kState].body;
				responseObject[kState] = response;
				responseObject[kState].body = body;
				responseObject[kHeaders][kHeadersList] = response.headersList;
				responseObject[kHeaders][kGuard] = "immutable";
				responseList.push(responseObject);
			}
			return Object.freeze(responseList);
		}
		async add(request) {
			webidl.brandCheck(this, Cache);
			webidl.argumentLengthCheck(arguments, 1, { header: "Cache.add" });
			request = webidl.converters.RequestInfo(request);
			const requests = [request];
			return await this.addAll(requests);
		}
		async addAll(requests) {
			webidl.brandCheck(this, Cache);
			webidl.argumentLengthCheck(arguments, 1, { header: "Cache.addAll" });
			requests = webidl.converters["sequence<RequestInfo>"](requests);
			const responsePromises = [];
			const requestList = [];
			for (const request of requests) {
				if (typeof request === "string") continue;
				const r = request[kState];
				if (!urlIsHttpHttpsScheme(r.url) || r.method !== "GET") throw webidl.errors.exception({
					header: "Cache.addAll",
					message: "Expected http/s scheme when method is not GET."
				});
			}
			/** @type {ReturnType<typeof fetching>[]} */
			const fetchControllers = [];
			for (const request of requests) {
				const r = new Request(request)[kState];
				if (!urlIsHttpHttpsScheme(r.url)) throw webidl.errors.exception({
					header: "Cache.addAll",
					message: "Expected http/s scheme."
				});
				r.initiator = "fetch";
				r.destination = "subresource";
				requestList.push(r);
				const responsePromise = createDeferredPromise();
				fetchControllers.push(fetching({
					request: r,
					dispatcher: getGlobalDispatcher(),
					processResponse(response) {
						if (response.type === "error" || response.status === 206 || response.status < 200 || response.status > 299) responsePromise.reject(webidl.errors.exception({
							header: "Cache.addAll",
							message: "Received an invalid status code or the request failed."
						}));
						else if (response.headersList.contains("vary")) {
							const fieldValues = getFieldValues(response.headersList.get("vary"));
							for (const fieldValue of fieldValues) if (fieldValue === "*") {
								responsePromise.reject(webidl.errors.exception({
									header: "Cache.addAll",
									message: "invalid vary field value"
								}));
								for (const controller of fetchControllers) controller.abort();
								return;
							}
						}
					},
					processResponseEndOfBody(response) {
						if (response.aborted) {
							responsePromise.reject(new DOMException("aborted", "AbortError"));
							return;
						}
						responsePromise.resolve(response);
					}
				}));
				responsePromises.push(responsePromise.promise);
			}
			const responses = await Promise.all(responsePromises);
			const operations = [];
			let index = 0;
			for (const response of responses) {
				/** @type {CacheBatchOperation} */
				const operation = {
					type: "put",
					request: requestList[index],
					response
				};
				operations.push(operation);
				index++;
			}
			const cacheJobPromise = createDeferredPromise();
			let errorData = null;
			try {
				this.#batchCacheOperations(operations);
			} catch (e) {
				errorData = e;
			}
			queueMicrotask(() => {
				if (errorData === null) cacheJobPromise.resolve(void 0);
				else cacheJobPromise.reject(errorData);
			});
			return cacheJobPromise.promise;
		}
		async put(request, response) {
			webidl.brandCheck(this, Cache);
			webidl.argumentLengthCheck(arguments, 2, { header: "Cache.put" });
			request = webidl.converters.RequestInfo(request);
			response = webidl.converters.Response(response);
			let innerRequest = null;
			if (request instanceof Request) innerRequest = request[kState];
			else innerRequest = new Request(request)[kState];
			if (!urlIsHttpHttpsScheme(innerRequest.url) || innerRequest.method !== "GET") throw webidl.errors.exception({
				header: "Cache.put",
				message: "Expected an http/s scheme when method is not GET"
			});
			const innerResponse = response[kState];
			if (innerResponse.status === 206) throw webidl.errors.exception({
				header: "Cache.put",
				message: "Got 206 status"
			});
			if (innerResponse.headersList.contains("vary")) {
				const fieldValues = getFieldValues(innerResponse.headersList.get("vary"));
				for (const fieldValue of fieldValues) if (fieldValue === "*") throw webidl.errors.exception({
					header: "Cache.put",
					message: "Got * vary field value"
				});
			}
			if (innerResponse.body && (isDisturbed(innerResponse.body.stream) || innerResponse.body.stream.locked)) throw webidl.errors.exception({
				header: "Cache.put",
				message: "Response body is locked or disturbed"
			});
			const clonedResponse = cloneResponse(innerResponse);
			const bodyReadPromise = createDeferredPromise();
			if (innerResponse.body != null) readAllBytes(innerResponse.body.stream.getReader()).then(bodyReadPromise.resolve, bodyReadPromise.reject);
			else bodyReadPromise.resolve(void 0);
			/** @type {CacheBatchOperation[]} */
			const operations = [];
			/** @type {CacheBatchOperation} */
			const operation = {
				type: "put",
				request: innerRequest,
				response: clonedResponse
			};
			operations.push(operation);
			const bytes = await bodyReadPromise.promise;
			if (clonedResponse.body != null) clonedResponse.body.source = bytes;
			const cacheJobPromise = createDeferredPromise();
			let errorData = null;
			try {
				this.#batchCacheOperations(operations);
			} catch (e) {
				errorData = e;
			}
			queueMicrotask(() => {
				if (errorData === null) cacheJobPromise.resolve();
				else cacheJobPromise.reject(errorData);
			});
			return cacheJobPromise.promise;
		}
		async delete(request, options = {}) {
			webidl.brandCheck(this, Cache);
			webidl.argumentLengthCheck(arguments, 1, { header: "Cache.delete" });
			request = webidl.converters.RequestInfo(request);
			options = webidl.converters.CacheQueryOptions(options);
			/**
			* @type {Request}
			*/
			let r = null;
			if (request instanceof Request) {
				r = request[kState];
				if (r.method !== "GET" && !options.ignoreMethod) return false;
			} else {
				assert$2(typeof request === "string");
				r = new Request(request)[kState];
			}
			/** @type {CacheBatchOperation[]} */
			const operations = [];
			/** @type {CacheBatchOperation} */
			const operation = {
				type: "delete",
				request: r,
				options
			};
			operations.push(operation);
			const cacheJobPromise = createDeferredPromise();
			let errorData = null;
			let requestResponses;
			try {
				requestResponses = this.#batchCacheOperations(operations);
			} catch (e) {
				errorData = e;
			}
			queueMicrotask(() => {
				if (errorData === null) cacheJobPromise.resolve(!!requestResponses?.length);
				else cacheJobPromise.reject(errorData);
			});
			return cacheJobPromise.promise;
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#dom-cache-keys
		* @param {any} request
		* @param {import('../../types/cache').CacheQueryOptions} options
		* @returns {readonly Request[]}
		*/
		async keys(request = void 0, options = {}) {
			webidl.brandCheck(this, Cache);
			if (request !== void 0) request = webidl.converters.RequestInfo(request);
			options = webidl.converters.CacheQueryOptions(options);
			let r = null;
			if (request !== void 0) {
				if (request instanceof Request) {
					r = request[kState];
					if (r.method !== "GET" && !options.ignoreMethod) return [];
				} else if (typeof request === "string") r = new Request(request)[kState];
			}
			const promise = createDeferredPromise();
			const requests = [];
			if (request === void 0) for (const requestResponse of this.#relevantRequestResponseList) requests.push(requestResponse[0]);
			else {
				const requestResponses = this.#queryCache(r, options);
				for (const requestResponse of requestResponses) requests.push(requestResponse[0]);
			}
			queueMicrotask(() => {
				const requestList = [];
				for (const request of requests) {
					const requestObject = new Request("https://a");
					requestObject[kState] = request;
					requestObject[kHeaders][kHeadersList] = request.headersList;
					requestObject[kHeaders][kGuard] = "immutable";
					requestObject[kRealm] = request.client;
					requestList.push(requestObject);
				}
				promise.resolve(Object.freeze(requestList));
			});
			return promise.promise;
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#batch-cache-operations-algorithm
		* @param {CacheBatchOperation[]} operations
		* @returns {requestResponseList}
		*/
		#batchCacheOperations(operations) {
			const cache = this.#relevantRequestResponseList;
			const backupCache = [...cache];
			const addedItems = [];
			const resultList = [];
			try {
				for (const operation of operations) {
					if (operation.type !== "delete" && operation.type !== "put") throw webidl.errors.exception({
						header: "Cache.#batchCacheOperations",
						message: "operation type does not match \"delete\" or \"put\""
					});
					if (operation.type === "delete" && operation.response != null) throw webidl.errors.exception({
						header: "Cache.#batchCacheOperations",
						message: "delete operation should not have an associated response"
					});
					if (this.#queryCache(operation.request, operation.options, addedItems).length) throw new DOMException("???", "InvalidStateError");
					let requestResponses;
					if (operation.type === "delete") {
						requestResponses = this.#queryCache(operation.request, operation.options);
						if (requestResponses.length === 0) return [];
						for (const requestResponse of requestResponses) {
							const idx = cache.indexOf(requestResponse);
							assert$2(idx !== -1);
							cache.splice(idx, 1);
						}
					} else if (operation.type === "put") {
						if (operation.response == null) throw webidl.errors.exception({
							header: "Cache.#batchCacheOperations",
							message: "put operation should have an associated response"
						});
						const r = operation.request;
						if (!urlIsHttpHttpsScheme(r.url)) throw webidl.errors.exception({
							header: "Cache.#batchCacheOperations",
							message: "expected http or https scheme"
						});
						if (r.method !== "GET") throw webidl.errors.exception({
							header: "Cache.#batchCacheOperations",
							message: "not get method"
						});
						if (operation.options != null) throw webidl.errors.exception({
							header: "Cache.#batchCacheOperations",
							message: "options must not be defined"
						});
						requestResponses = this.#queryCache(operation.request);
						for (const requestResponse of requestResponses) {
							const idx = cache.indexOf(requestResponse);
							assert$2(idx !== -1);
							cache.splice(idx, 1);
						}
						cache.push([operation.request, operation.response]);
						addedItems.push([operation.request, operation.response]);
					}
					resultList.push([operation.request, operation.response]);
				}
				return resultList;
			} catch (e) {
				this.#relevantRequestResponseList.length = 0;
				this.#relevantRequestResponseList = backupCache;
				throw e;
			}
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#query-cache
		* @param {any} requestQuery
		* @param {import('../../types/cache').CacheQueryOptions} options
		* @param {requestResponseList} targetStorage
		* @returns {requestResponseList}
		*/
		#queryCache(requestQuery, options, targetStorage) {
			/** @type {requestResponseList} */
			const resultList = [];
			const storage = targetStorage ?? this.#relevantRequestResponseList;
			for (const requestResponse of storage) {
				const [cachedRequest, cachedResponse] = requestResponse;
				if (this.#requestMatchesCachedItem(requestQuery, cachedRequest, cachedResponse, options)) resultList.push(requestResponse);
			}
			return resultList;
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#request-matches-cached-item-algorithm
		* @param {any} requestQuery
		* @param {any} request
		* @param {any | null} response
		* @param {import('../../types/cache').CacheQueryOptions | undefined} options
		* @returns {boolean}
		*/
		#requestMatchesCachedItem(requestQuery, request, response = null, options) {
			const queryURL = new URL(requestQuery.url);
			const cachedURL = new URL(request.url);
			if (options?.ignoreSearch) {
				cachedURL.search = "";
				queryURL.search = "";
			}
			if (!urlEquals(queryURL, cachedURL, true)) return false;
			if (response == null || options?.ignoreVary || !response.headersList.contains("vary")) return true;
			const fieldValues = getFieldValues(response.headersList.get("vary"));
			for (const fieldValue of fieldValues) {
				if (fieldValue === "*") return false;
				if (request.headersList.get(fieldValue) !== requestQuery.headersList.get(fieldValue)) return false;
			}
			return true;
		}
	};
	Object.defineProperties(Cache.prototype, {
		[Symbol.toStringTag]: {
			value: "Cache",
			configurable: true
		},
		match: kEnumerableProperty,
		matchAll: kEnumerableProperty,
		add: kEnumerableProperty,
		addAll: kEnumerableProperty,
		put: kEnumerableProperty,
		delete: kEnumerableProperty,
		keys: kEnumerableProperty
	});
	var cacheQueryOptionConverters = [
		{
			key: "ignoreSearch",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "ignoreMethod",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "ignoreVary",
			converter: webidl.converters.boolean,
			defaultValue: false
		}
	];
	webidl.converters.CacheQueryOptions = webidl.dictionaryConverter(cacheQueryOptionConverters);
	webidl.converters.MultiCacheQueryOptions = webidl.dictionaryConverter([...cacheQueryOptionConverters, {
		key: "cacheName",
		converter: webidl.converters.DOMString
	}]);
	webidl.converters.Response = webidl.interfaceConverter(Response);
	webidl.converters["sequence<RequestInfo>"] = webidl.sequenceConverter(webidl.converters.RequestInfo);
	module.exports = { Cache };
}));
//#endregion
//#region node_modules/undici/lib/cache/cachestorage.js
var require_cachestorage = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kConstruct } = require_symbols$1();
	var { Cache } = require_cache();
	var { webidl } = require_webidl();
	var { kEnumerableProperty } = require_util$6();
	var CacheStorage = class CacheStorage {
		/**
		* @see https://w3c.github.io/ServiceWorker/#dfn-relevant-name-to-cache-map
		* @type {Map<string, import('./cache').requestResponseList}
		*/
		#caches = /* @__PURE__ */ new Map();
		constructor() {
			if (arguments[0] !== kConstruct) webidl.illegalConstructor();
		}
		async match(request, options = {}) {
			webidl.brandCheck(this, CacheStorage);
			webidl.argumentLengthCheck(arguments, 1, { header: "CacheStorage.match" });
			request = webidl.converters.RequestInfo(request);
			options = webidl.converters.MultiCacheQueryOptions(options);
			if (options.cacheName != null) {
				if (this.#caches.has(options.cacheName)) return await new Cache(kConstruct, this.#caches.get(options.cacheName)).match(request, options);
			} else for (const cacheList of this.#caches.values()) {
				const response = await new Cache(kConstruct, cacheList).match(request, options);
				if (response !== void 0) return response;
			}
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#cache-storage-has
		* @param {string} cacheName
		* @returns {Promise<boolean>}
		*/
		async has(cacheName) {
			webidl.brandCheck(this, CacheStorage);
			webidl.argumentLengthCheck(arguments, 1, { header: "CacheStorage.has" });
			cacheName = webidl.converters.DOMString(cacheName);
			return this.#caches.has(cacheName);
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#dom-cachestorage-open
		* @param {string} cacheName
		* @returns {Promise<Cache>}
		*/
		async open(cacheName) {
			webidl.brandCheck(this, CacheStorage);
			webidl.argumentLengthCheck(arguments, 1, { header: "CacheStorage.open" });
			cacheName = webidl.converters.DOMString(cacheName);
			if (this.#caches.has(cacheName)) return new Cache(kConstruct, this.#caches.get(cacheName));
			const cache = [];
			this.#caches.set(cacheName, cache);
			return new Cache(kConstruct, cache);
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#cache-storage-delete
		* @param {string} cacheName
		* @returns {Promise<boolean>}
		*/
		async delete(cacheName) {
			webidl.brandCheck(this, CacheStorage);
			webidl.argumentLengthCheck(arguments, 1, { header: "CacheStorage.delete" });
			cacheName = webidl.converters.DOMString(cacheName);
			return this.#caches.delete(cacheName);
		}
		/**
		* @see https://w3c.github.io/ServiceWorker/#cache-storage-keys
		* @returns {string[]}
		*/
		async keys() {
			webidl.brandCheck(this, CacheStorage);
			return [...this.#caches.keys()];
		}
	};
	Object.defineProperties(CacheStorage.prototype, {
		[Symbol.toStringTag]: {
			value: "CacheStorage",
			configurable: true
		},
		match: kEnumerableProperty,
		has: kEnumerableProperty,
		open: kEnumerableProperty,
		delete: kEnumerableProperty,
		keys: kEnumerableProperty
	});
	module.exports = { CacheStorage };
}));
//#endregion
//#region node_modules/undici/lib/cookies/constants.js
var require_constants$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		maxAttributeValueSize: 1024,
		maxNameValuePairSize: 4096
	};
}));
//#endregion
//#region node_modules/undici/lib/cookies/util.js
var require_util$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var assert$1 = __require("assert");
	var { kHeadersList } = require_symbols$4();
	function isCTLExcludingHtab(value) {
		if (value.length === 0) return false;
		for (const char of value) {
			const code = char.charCodeAt(0);
			if (code >= 0 || code <= 8 || code >= 10 || code <= 31 || code === 127) return false;
		}
	}
	/**
	CHAR           = <any US-ASCII character (octets 0 - 127)>
	token          = 1*<any CHAR except CTLs or separators>
	separators     = "(" | ")" | "<" | ">" | "@"
	| "," | ";" | ":" | "\" | <">
	| "/" | "[" | "]" | "?" | "="
	| "{" | "}" | SP | HT
	* @param {string} name
	*/
	function validateCookieName(name) {
		for (const char of name) {
			const code = char.charCodeAt(0);
			if (code <= 32 || code > 127 || char === "(" || char === ")" || char === ">" || char === "<" || char === "@" || char === "," || char === ";" || char === ":" || char === "\\" || char === "\"" || char === "/" || char === "[" || char === "]" || char === "?" || char === "=" || char === "{" || char === "}") throw new Error("Invalid cookie name");
		}
	}
	/**
	cookie-value      = *cookie-octet / ( DQUOTE *cookie-octet DQUOTE )
	cookie-octet      = %x21 / %x23-2B / %x2D-3A / %x3C-5B / %x5D-7E
	; US-ASCII characters excluding CTLs,
	; whitespace DQUOTE, comma, semicolon,
	; and backslash
	* @param {string} value
	*/
	function validateCookieValue(value) {
		for (const char of value) {
			const code = char.charCodeAt(0);
			if (code < 33 || code === 34 || code === 44 || code === 59 || code === 92 || code > 126) throw new Error("Invalid header value");
		}
	}
	/**
	* path-value        = <any CHAR except CTLs or ";">
	* @param {string} path
	*/
	function validateCookiePath(path) {
		for (const char of path) if (char.charCodeAt(0) < 33 || char === ";") throw new Error("Invalid cookie path");
	}
	/**
	* I have no idea why these values aren't allowed to be honest,
	* but Deno tests these. - Khafra
	* @param {string} domain
	*/
	function validateCookieDomain(domain) {
		if (domain.startsWith("-") || domain.endsWith(".") || domain.endsWith("-")) throw new Error("Invalid cookie domain");
	}
	/**
	* @see https://www.rfc-editor.org/rfc/rfc7231#section-7.1.1.1
	* @param {number|Date} date
	IMF-fixdate  = day-name "," SP date1 SP time-of-day SP GMT
	; fixed length/zone/capitalization subset of the format
	; see Section 3.3 of [RFC5322]
	
	day-name     = %x4D.6F.6E ; "Mon", case-sensitive
	/ %x54.75.65 ; "Tue", case-sensitive
	/ %x57.65.64 ; "Wed", case-sensitive
	/ %x54.68.75 ; "Thu", case-sensitive
	/ %x46.72.69 ; "Fri", case-sensitive
	/ %x53.61.74 ; "Sat", case-sensitive
	/ %x53.75.6E ; "Sun", case-sensitive
	date1        = day SP month SP year
	; e.g., 02 Jun 1982
	
	day          = 2DIGIT
	month        = %x4A.61.6E ; "Jan", case-sensitive
	/ %x46.65.62 ; "Feb", case-sensitive
	/ %x4D.61.72 ; "Mar", case-sensitive
	/ %x41.70.72 ; "Apr", case-sensitive
	/ %x4D.61.79 ; "May", case-sensitive
	/ %x4A.75.6E ; "Jun", case-sensitive
	/ %x4A.75.6C ; "Jul", case-sensitive
	/ %x41.75.67 ; "Aug", case-sensitive
	/ %x53.65.70 ; "Sep", case-sensitive
	/ %x4F.63.74 ; "Oct", case-sensitive
	/ %x4E.6F.76 ; "Nov", case-sensitive
	/ %x44.65.63 ; "Dec", case-sensitive
	year         = 4DIGIT
	
	GMT          = %x47.4D.54 ; "GMT", case-sensitive
	
	time-of-day  = hour ":" minute ":" second
	; 00:00:00 - 23:59:60 (leap second)
	
	hour         = 2DIGIT
	minute       = 2DIGIT
	second       = 2DIGIT
	*/
	function toIMFDate(date) {
		if (typeof date === "number") date = new Date(date);
		return `${[
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		][date.getUTCDay()]}, ${date.getUTCDate().toString().padStart(2, "0")} ${[
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		][date.getUTCMonth()]} ${date.getUTCFullYear()} ${date.getUTCHours().toString().padStart(2, "0")}:${date.getUTCMinutes().toString().padStart(2, "0")}:${date.getUTCSeconds().toString().padStart(2, "0")} GMT`;
	}
	/**
	max-age-av        = "Max-Age=" non-zero-digit *DIGIT
	; In practice, both expires-av and max-age-av
	; are limited to dates representable by the
	; user agent.
	* @param {number} maxAge
	*/
	function validateCookieMaxAge(maxAge) {
		if (maxAge < 0) throw new Error("Invalid cookie max-age");
	}
	/**
	* @see https://www.rfc-editor.org/rfc/rfc6265#section-4.1.1
	* @param {import('./index').Cookie} cookie
	*/
	function stringify(cookie) {
		if (cookie.name.length === 0) return null;
		validateCookieName(cookie.name);
		validateCookieValue(cookie.value);
		const out = [`${cookie.name}=${cookie.value}`];
		if (cookie.name.startsWith("__Secure-")) cookie.secure = true;
		if (cookie.name.startsWith("__Host-")) {
			cookie.secure = true;
			cookie.domain = null;
			cookie.path = "/";
		}
		if (cookie.secure) out.push("Secure");
		if (cookie.httpOnly) out.push("HttpOnly");
		if (typeof cookie.maxAge === "number") {
			validateCookieMaxAge(cookie.maxAge);
			out.push(`Max-Age=${cookie.maxAge}`);
		}
		if (cookie.domain) {
			validateCookieDomain(cookie.domain);
			out.push(`Domain=${cookie.domain}`);
		}
		if (cookie.path) {
			validateCookiePath(cookie.path);
			out.push(`Path=${cookie.path}`);
		}
		if (cookie.expires && cookie.expires.toString() !== "Invalid Date") out.push(`Expires=${toIMFDate(cookie.expires)}`);
		if (cookie.sameSite) out.push(`SameSite=${cookie.sameSite}`);
		for (const part of cookie.unparsed) {
			if (!part.includes("=")) throw new Error("Invalid unparsed");
			const [key, ...value] = part.split("=");
			out.push(`${key.trim()}=${value.join("=")}`);
		}
		return out.join("; ");
	}
	var kHeadersListNode;
	function getHeadersList(headers) {
		if (headers[kHeadersList]) return headers[kHeadersList];
		if (!kHeadersListNode) {
			kHeadersListNode = Object.getOwnPropertySymbols(headers).find((symbol) => symbol.description === "headers list");
			assert$1(kHeadersListNode, "Headers cannot be parsed");
		}
		const headersList = headers[kHeadersListNode];
		assert$1(headersList);
		return headersList;
	}
	module.exports = {
		isCTLExcludingHtab,
		stringify,
		getHeadersList
	};
}));
//#endregion
//#region node_modules/undici/lib/cookies/parse.js
var require_parse = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { maxNameValuePairSize, maxAttributeValueSize } = require_constants$1();
	var { isCTLExcludingHtab } = require_util$1();
	var { collectASequenceOfCodePointsFast } = require_dataURL();
	var assert = __require("assert");
	/**
	* @description Parses the field-value attributes of a set-cookie header string.
	* @see https://datatracker.ietf.org/doc/html/draft-ietf-httpbis-rfc6265bis#section-5.4
	* @param {string} header
	* @returns if the header is invalid, null will be returned
	*/
	function parseSetCookie(header) {
		if (isCTLExcludingHtab(header)) return null;
		let nameValuePair = "";
		let unparsedAttributes = "";
		let name = "";
		let value = "";
		if (header.includes(";")) {
			const position = { position: 0 };
			nameValuePair = collectASequenceOfCodePointsFast(";", header, position);
			unparsedAttributes = header.slice(position.position);
		} else nameValuePair = header;
		if (!nameValuePair.includes("=")) value = nameValuePair;
		else {
			const position = { position: 0 };
			name = collectASequenceOfCodePointsFast("=", nameValuePair, position);
			value = nameValuePair.slice(position.position + 1);
		}
		name = name.trim();
		value = value.trim();
		if (name.length + value.length > maxNameValuePairSize) return null;
		return {
			name,
			value,
			...parseUnparsedAttributes(unparsedAttributes)
		};
	}
	/**
	* Parses the remaining attributes of a set-cookie header
	* @see https://datatracker.ietf.org/doc/html/draft-ietf-httpbis-rfc6265bis#section-5.4
	* @param {string} unparsedAttributes
	* @param {[Object.<string, unknown>]={}} cookieAttributeList
	*/
	function parseUnparsedAttributes(unparsedAttributes, cookieAttributeList = {}) {
		if (unparsedAttributes.length === 0) return cookieAttributeList;
		assert(unparsedAttributes[0] === ";");
		unparsedAttributes = unparsedAttributes.slice(1);
		let cookieAv = "";
		if (unparsedAttributes.includes(";")) {
			cookieAv = collectASequenceOfCodePointsFast(";", unparsedAttributes, { position: 0 });
			unparsedAttributes = unparsedAttributes.slice(cookieAv.length);
		} else {
			cookieAv = unparsedAttributes;
			unparsedAttributes = "";
		}
		let attributeName = "";
		let attributeValue = "";
		if (cookieAv.includes("=")) {
			const position = { position: 0 };
			attributeName = collectASequenceOfCodePointsFast("=", cookieAv, position);
			attributeValue = cookieAv.slice(position.position + 1);
		} else attributeName = cookieAv;
		attributeName = attributeName.trim();
		attributeValue = attributeValue.trim();
		if (attributeValue.length > maxAttributeValueSize) return parseUnparsedAttributes(unparsedAttributes, cookieAttributeList);
		const attributeNameLowercase = attributeName.toLowerCase();
		if (attributeNameLowercase === "expires") cookieAttributeList.expires = new Date(attributeValue);
		else if (attributeNameLowercase === "max-age") {
			const charCode = attributeValue.charCodeAt(0);
			if ((charCode < 48 || charCode > 57) && attributeValue[0] !== "-") return parseUnparsedAttributes(unparsedAttributes, cookieAttributeList);
			if (!/^\d+$/.test(attributeValue)) return parseUnparsedAttributes(unparsedAttributes, cookieAttributeList);
			cookieAttributeList.maxAge = Number(attributeValue);
		} else if (attributeNameLowercase === "domain") {
			let cookieDomain = attributeValue;
			if (cookieDomain[0] === ".") cookieDomain = cookieDomain.slice(1);
			cookieDomain = cookieDomain.toLowerCase();
			cookieAttributeList.domain = cookieDomain;
		} else if (attributeNameLowercase === "path") {
			let cookiePath = "";
			if (attributeValue.length === 0 || attributeValue[0] !== "/") cookiePath = "/";
			else cookiePath = attributeValue;
			cookieAttributeList.path = cookiePath;
		} else if (attributeNameLowercase === "secure") cookieAttributeList.secure = true;
		else if (attributeNameLowercase === "httponly") cookieAttributeList.httpOnly = true;
		else if (attributeNameLowercase === "samesite") {
			let enforcement = "Default";
			const attributeValueLowercase = attributeValue.toLowerCase();
			if (attributeValueLowercase.includes("none")) enforcement = "None";
			if (attributeValueLowercase.includes("strict")) enforcement = "Strict";
			if (attributeValueLowercase.includes("lax")) enforcement = "Lax";
			cookieAttributeList.sameSite = enforcement;
		} else {
			cookieAttributeList.unparsed ??= [];
			cookieAttributeList.unparsed.push(`${attributeName}=${attributeValue}`);
		}
		return parseUnparsedAttributes(unparsedAttributes, cookieAttributeList);
	}
	module.exports = {
		parseSetCookie,
		parseUnparsedAttributes
	};
}));
//#endregion
//#region node_modules/undici/lib/cookies/index.js
var require_cookies = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { parseSetCookie } = require_parse();
	var { stringify, getHeadersList } = require_util$1();
	var { webidl } = require_webidl();
	var { Headers } = require_headers();
	/**
	* @typedef {Object} Cookie
	* @property {string} name
	* @property {string} value
	* @property {Date|number|undefined} expires
	* @property {number|undefined} maxAge
	* @property {string|undefined} domain
	* @property {string|undefined} path
	* @property {boolean|undefined} secure
	* @property {boolean|undefined} httpOnly
	* @property {'Strict'|'Lax'|'None'} sameSite
	* @property {string[]} unparsed
	*/
	/**
	* @param {Headers} headers
	* @returns {Record<string, string>}
	*/
	function getCookies(headers) {
		webidl.argumentLengthCheck(arguments, 1, { header: "getCookies" });
		webidl.brandCheck(headers, Headers, { strict: false });
		const cookie = headers.get("cookie");
		const out = {};
		if (!cookie) return out;
		for (const piece of cookie.split(";")) {
			const [name, ...value] = piece.split("=");
			out[name.trim()] = value.join("=");
		}
		return out;
	}
	/**
	* @param {Headers} headers
	* @param {string} name
	* @param {{ path?: string, domain?: string }|undefined} attributes
	* @returns {void}
	*/
	function deleteCookie(headers, name, attributes) {
		webidl.argumentLengthCheck(arguments, 2, { header: "deleteCookie" });
		webidl.brandCheck(headers, Headers, { strict: false });
		name = webidl.converters.DOMString(name);
		attributes = webidl.converters.DeleteCookieAttributes(attributes);
		setCookie(headers, {
			name,
			value: "",
			expires: /* @__PURE__ */ new Date(0),
			...attributes
		});
	}
	/**
	* @param {Headers} headers
	* @returns {Cookie[]}
	*/
	function getSetCookies(headers) {
		webidl.argumentLengthCheck(arguments, 1, { header: "getSetCookies" });
		webidl.brandCheck(headers, Headers, { strict: false });
		const cookies = getHeadersList(headers).cookies;
		if (!cookies) return [];
		return cookies.map((pair) => parseSetCookie(Array.isArray(pair) ? pair[1] : pair));
	}
	/**
	* @param {Headers} headers
	* @param {Cookie} cookie
	* @returns {void}
	*/
	function setCookie(headers, cookie) {
		webidl.argumentLengthCheck(arguments, 2, { header: "setCookie" });
		webidl.brandCheck(headers, Headers, { strict: false });
		cookie = webidl.converters.Cookie(cookie);
		if (stringify(cookie)) headers.append("Set-Cookie", stringify(cookie));
	}
	webidl.converters.DeleteCookieAttributes = webidl.dictionaryConverter([{
		converter: webidl.nullableConverter(webidl.converters.DOMString),
		key: "path",
		defaultValue: null
	}, {
		converter: webidl.nullableConverter(webidl.converters.DOMString),
		key: "domain",
		defaultValue: null
	}]);
	webidl.converters.Cookie = webidl.dictionaryConverter([
		{
			converter: webidl.converters.DOMString,
			key: "name"
		},
		{
			converter: webidl.converters.DOMString,
			key: "value"
		},
		{
			converter: webidl.nullableConverter((value) => {
				if (typeof value === "number") return webidl.converters["unsigned long long"](value);
				return new Date(value);
			}),
			key: "expires",
			defaultValue: null
		},
		{
			converter: webidl.nullableConverter(webidl.converters["long long"]),
			key: "maxAge",
			defaultValue: null
		},
		{
			converter: webidl.nullableConverter(webidl.converters.DOMString),
			key: "domain",
			defaultValue: null
		},
		{
			converter: webidl.nullableConverter(webidl.converters.DOMString),
			key: "path",
			defaultValue: null
		},
		{
			converter: webidl.nullableConverter(webidl.converters.boolean),
			key: "secure",
			defaultValue: null
		},
		{
			converter: webidl.nullableConverter(webidl.converters.boolean),
			key: "httpOnly",
			defaultValue: null
		},
		{
			converter: webidl.converters.USVString,
			key: "sameSite",
			allowedValues: [
				"Strict",
				"Lax",
				"None"
			]
		},
		{
			converter: webidl.sequenceConverter(webidl.converters.DOMString),
			key: "unparsed",
			defaultValue: []
		}
	]);
	module.exports = {
		getCookies,
		deleteCookie,
		getSetCookies,
		setCookie
	};
}));
//#endregion
//#region node_modules/undici/lib/websocket/constants.js
var require_constants = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		uid: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
		staticPropertyDescriptors: {
			enumerable: true,
			writable: false,
			configurable: false
		},
		states: {
			CONNECTING: 0,
			OPEN: 1,
			CLOSING: 2,
			CLOSED: 3
		},
		opcodes: {
			CONTINUATION: 0,
			TEXT: 1,
			BINARY: 2,
			CLOSE: 8,
			PING: 9,
			PONG: 10
		},
		maxUnsigned16Bit: 2 ** 16 - 1,
		parserStates: {
			INFO: 0,
			PAYLOADLENGTH_16: 2,
			PAYLOADLENGTH_64: 3,
			READ_DATA: 4
		},
		emptyBuffer: Buffer.allocUnsafe(0)
	};
}));
//#endregion
//#region node_modules/undici/lib/websocket/symbols.js
var require_symbols = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		kWebSocketURL: Symbol("url"),
		kReadyState: Symbol("ready state"),
		kController: Symbol("controller"),
		kResponse: Symbol("response"),
		kBinaryType: Symbol("binary type"),
		kSentClose: Symbol("sent close"),
		kReceivedClose: Symbol("received close"),
		kByteParser: Symbol("byte parser")
	};
}));
//#endregion
//#region node_modules/undici/lib/websocket/events.js
var require_events = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { webidl } = require_webidl();
	var { kEnumerableProperty } = require_util$6();
	var { MessagePort } = __require("worker_threads");
	/**
	* @see https://html.spec.whatwg.org/multipage/comms.html#messageevent
	*/
	var MessageEvent = class MessageEvent extends Event {
		#eventInit;
		constructor(type, eventInitDict = {}) {
			webidl.argumentLengthCheck(arguments, 1, { header: "MessageEvent constructor" });
			type = webidl.converters.DOMString(type);
			eventInitDict = webidl.converters.MessageEventInit(eventInitDict);
			super(type, eventInitDict);
			this.#eventInit = eventInitDict;
		}
		get data() {
			webidl.brandCheck(this, MessageEvent);
			return this.#eventInit.data;
		}
		get origin() {
			webidl.brandCheck(this, MessageEvent);
			return this.#eventInit.origin;
		}
		get lastEventId() {
			webidl.brandCheck(this, MessageEvent);
			return this.#eventInit.lastEventId;
		}
		get source() {
			webidl.brandCheck(this, MessageEvent);
			return this.#eventInit.source;
		}
		get ports() {
			webidl.brandCheck(this, MessageEvent);
			if (!Object.isFrozen(this.#eventInit.ports)) Object.freeze(this.#eventInit.ports);
			return this.#eventInit.ports;
		}
		initMessageEvent(type, bubbles = false, cancelable = false, data = null, origin = "", lastEventId = "", source = null, ports = []) {
			webidl.brandCheck(this, MessageEvent);
			webidl.argumentLengthCheck(arguments, 1, { header: "MessageEvent.initMessageEvent" });
			return new MessageEvent(type, {
				bubbles,
				cancelable,
				data,
				origin,
				lastEventId,
				source,
				ports
			});
		}
	};
	/**
	* @see https://websockets.spec.whatwg.org/#the-closeevent-interface
	*/
	var CloseEvent = class CloseEvent extends Event {
		#eventInit;
		constructor(type, eventInitDict = {}) {
			webidl.argumentLengthCheck(arguments, 1, { header: "CloseEvent constructor" });
			type = webidl.converters.DOMString(type);
			eventInitDict = webidl.converters.CloseEventInit(eventInitDict);
			super(type, eventInitDict);
			this.#eventInit = eventInitDict;
		}
		get wasClean() {
			webidl.brandCheck(this, CloseEvent);
			return this.#eventInit.wasClean;
		}
		get code() {
			webidl.brandCheck(this, CloseEvent);
			return this.#eventInit.code;
		}
		get reason() {
			webidl.brandCheck(this, CloseEvent);
			return this.#eventInit.reason;
		}
	};
	var ErrorEvent = class ErrorEvent extends Event {
		#eventInit;
		constructor(type, eventInitDict) {
			webidl.argumentLengthCheck(arguments, 1, { header: "ErrorEvent constructor" });
			super(type, eventInitDict);
			type = webidl.converters.DOMString(type);
			eventInitDict = webidl.converters.ErrorEventInit(eventInitDict ?? {});
			this.#eventInit = eventInitDict;
		}
		get message() {
			webidl.brandCheck(this, ErrorEvent);
			return this.#eventInit.message;
		}
		get filename() {
			webidl.brandCheck(this, ErrorEvent);
			return this.#eventInit.filename;
		}
		get lineno() {
			webidl.brandCheck(this, ErrorEvent);
			return this.#eventInit.lineno;
		}
		get colno() {
			webidl.brandCheck(this, ErrorEvent);
			return this.#eventInit.colno;
		}
		get error() {
			webidl.brandCheck(this, ErrorEvent);
			return this.#eventInit.error;
		}
	};
	Object.defineProperties(MessageEvent.prototype, {
		[Symbol.toStringTag]: {
			value: "MessageEvent",
			configurable: true
		},
		data: kEnumerableProperty,
		origin: kEnumerableProperty,
		lastEventId: kEnumerableProperty,
		source: kEnumerableProperty,
		ports: kEnumerableProperty,
		initMessageEvent: kEnumerableProperty
	});
	Object.defineProperties(CloseEvent.prototype, {
		[Symbol.toStringTag]: {
			value: "CloseEvent",
			configurable: true
		},
		reason: kEnumerableProperty,
		code: kEnumerableProperty,
		wasClean: kEnumerableProperty
	});
	Object.defineProperties(ErrorEvent.prototype, {
		[Symbol.toStringTag]: {
			value: "ErrorEvent",
			configurable: true
		},
		message: kEnumerableProperty,
		filename: kEnumerableProperty,
		lineno: kEnumerableProperty,
		colno: kEnumerableProperty,
		error: kEnumerableProperty
	});
	webidl.converters.MessagePort = webidl.interfaceConverter(MessagePort);
	webidl.converters["sequence<MessagePort>"] = webidl.sequenceConverter(webidl.converters.MessagePort);
	var eventInit = [
		{
			key: "bubbles",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "cancelable",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "composed",
			converter: webidl.converters.boolean,
			defaultValue: false
		}
	];
	webidl.converters.MessageEventInit = webidl.dictionaryConverter([
		...eventInit,
		{
			key: "data",
			converter: webidl.converters.any,
			defaultValue: null
		},
		{
			key: "origin",
			converter: webidl.converters.USVString,
			defaultValue: ""
		},
		{
			key: "lastEventId",
			converter: webidl.converters.DOMString,
			defaultValue: ""
		},
		{
			key: "source",
			converter: webidl.nullableConverter(webidl.converters.MessagePort),
			defaultValue: null
		},
		{
			key: "ports",
			converter: webidl.converters["sequence<MessagePort>"],
			get defaultValue() {
				return [];
			}
		}
	]);
	webidl.converters.CloseEventInit = webidl.dictionaryConverter([
		...eventInit,
		{
			key: "wasClean",
			converter: webidl.converters.boolean,
			defaultValue: false
		},
		{
			key: "code",
			converter: webidl.converters["unsigned short"],
			defaultValue: 0
		},
		{
			key: "reason",
			converter: webidl.converters.USVString,
			defaultValue: ""
		}
	]);
	webidl.converters.ErrorEventInit = webidl.dictionaryConverter([
		...eventInit,
		{
			key: "message",
			converter: webidl.converters.DOMString,
			defaultValue: ""
		},
		{
			key: "filename",
			converter: webidl.converters.USVString,
			defaultValue: ""
		},
		{
			key: "lineno",
			converter: webidl.converters["unsigned long"],
			defaultValue: 0
		},
		{
			key: "colno",
			converter: webidl.converters["unsigned long"],
			defaultValue: 0
		},
		{
			key: "error",
			converter: webidl.converters.any
		}
	]);
	module.exports = {
		MessageEvent,
		CloseEvent,
		ErrorEvent
	};
}));
//#endregion
//#region node_modules/undici/lib/websocket/util.js
var require_util = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kReadyState, kController, kResponse, kBinaryType, kWebSocketURL } = require_symbols();
	var { states, opcodes } = require_constants();
	var { MessageEvent, ErrorEvent } = require_events();
	/**
	* @param {import('./websocket').WebSocket} ws
	*/
	function isEstablished(ws) {
		return ws[kReadyState] === states.OPEN;
	}
	/**
	* @param {import('./websocket').WebSocket} ws
	*/
	function isClosing(ws) {
		return ws[kReadyState] === states.CLOSING;
	}
	/**
	* @param {import('./websocket').WebSocket} ws
	*/
	function isClosed(ws) {
		return ws[kReadyState] === states.CLOSED;
	}
	/**
	* @see https://dom.spec.whatwg.org/#concept-event-fire
	* @param {string} e
	* @param {EventTarget} target
	* @param {EventInit | undefined} eventInitDict
	*/
	function fireEvent(e, target, eventConstructor = Event, eventInitDict) {
		const event = new eventConstructor(e, eventInitDict);
		target.dispatchEvent(event);
	}
	/**
	* @see https://websockets.spec.whatwg.org/#feedback-from-the-protocol
	* @param {import('./websocket').WebSocket} ws
	* @param {number} type Opcode
	* @param {Buffer} data application data
	*/
	function websocketMessageReceived(ws, type, data) {
		if (ws[kReadyState] !== states.OPEN) return;
		let dataForEvent;
		if (type === opcodes.TEXT) try {
			dataForEvent = new TextDecoder("utf-8", { fatal: true }).decode(data);
		} catch {
			failWebsocketConnection(ws, "Received invalid UTF-8 in text frame.");
			return;
		}
		else if (type === opcodes.BINARY) {
			if (ws[kBinaryType] === "blob") dataForEvent = new Blob([data]);
			else dataForEvent = new Uint8Array(data).buffer;
		}
		fireEvent("message", ws, MessageEvent, {
			origin: ws[kWebSocketURL].origin,
			data: dataForEvent
		});
	}
	/**
	* @see https://datatracker.ietf.org/doc/html/rfc6455
	* @see https://datatracker.ietf.org/doc/html/rfc2616
	* @see https://bugs.chromium.org/p/chromium/issues/detail?id=398407
	* @param {string} protocol
	*/
	function isValidSubprotocol(protocol) {
		if (protocol.length === 0) return false;
		for (const char of protocol) {
			const code = char.charCodeAt(0);
			if (code < 33 || code > 126 || char === "(" || char === ")" || char === "<" || char === ">" || char === "@" || char === "," || char === ";" || char === ":" || char === "\\" || char === "\"" || char === "/" || char === "[" || char === "]" || char === "?" || char === "=" || char === "{" || char === "}" || code === 32 || code === 9) return false;
		}
		return true;
	}
	/**
	* @see https://datatracker.ietf.org/doc/html/rfc6455#section-7-4
	* @param {number} code
	*/
	function isValidStatusCode(code) {
		if (code >= 1e3 && code < 1015) return code !== 1004 && code !== 1005 && code !== 1006;
		return code >= 3e3 && code <= 4999;
	}
	/**
	* @param {import('./websocket').WebSocket} ws
	* @param {string|undefined} reason
	*/
	function failWebsocketConnection(ws, reason) {
		const { [kController]: controller, [kResponse]: response } = ws;
		controller.abort();
		if (response?.socket && !response.socket.destroyed) response.socket.destroy();
		if (reason) fireEvent("error", ws, ErrorEvent, { error: new Error(reason) });
	}
	module.exports = {
		isEstablished,
		isClosing,
		isClosed,
		fireEvent,
		isValidSubprotocol,
		isValidStatusCode,
		failWebsocketConnection,
		websocketMessageReceived
	};
}));
//#endregion
//#region node_modules/undici/lib/websocket/connection.js
var require_connection = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var diagnosticsChannel$1 = __require("diagnostics_channel");
	var { uid, states } = require_constants();
	var { kReadyState, kSentClose, kByteParser, kReceivedClose } = require_symbols();
	var { fireEvent, failWebsocketConnection } = require_util();
	var { CloseEvent } = require_events();
	var { makeRequest } = require_request();
	var { fetching } = require_fetch();
	var { Headers } = require_headers();
	var { getGlobalDispatcher } = require_global();
	var { kHeadersList } = require_symbols$4();
	var channels = {};
	channels.open = diagnosticsChannel$1.channel("undici:websocket:open");
	channels.close = diagnosticsChannel$1.channel("undici:websocket:close");
	channels.socketError = diagnosticsChannel$1.channel("undici:websocket:socket_error");
	/** @type {import('crypto')} */
	var crypto;
	try {
		crypto = __require("crypto");
	} catch {}
	/**
	* @see https://websockets.spec.whatwg.org/#concept-websocket-establish
	* @param {URL} url
	* @param {string|string[]} protocols
	* @param {import('./websocket').WebSocket} ws
	* @param {(response: any) => void} onEstablish
	* @param {Partial<import('../../types/websocket').WebSocketInit>} options
	*/
	function establishWebSocketConnection(url, protocols, ws, onEstablish, options) {
		const requestURL = url;
		requestURL.protocol = url.protocol === "ws:" ? "http:" : "https:";
		const request = makeRequest({
			urlList: [requestURL],
			serviceWorkers: "none",
			referrer: "no-referrer",
			mode: "websocket",
			credentials: "include",
			cache: "no-store",
			redirect: "error"
		});
		if (options.headers) request.headersList = new Headers(options.headers)[kHeadersList];
		const keyValue = crypto.randomBytes(16).toString("base64");
		request.headersList.append("sec-websocket-key", keyValue);
		request.headersList.append("sec-websocket-version", "13");
		for (const protocol of protocols) request.headersList.append("sec-websocket-protocol", protocol);
		const permessageDeflate = "";
		return fetching({
			request,
			useParallelQueue: true,
			dispatcher: options.dispatcher ?? getGlobalDispatcher(),
			processResponse(response) {
				if (response.type === "error" || response.status !== 101) {
					failWebsocketConnection(ws, "Received network error or non-101 status code.");
					return;
				}
				if (protocols.length !== 0 && !response.headersList.get("Sec-WebSocket-Protocol")) {
					failWebsocketConnection(ws, "Server did not respond with sent protocols.");
					return;
				}
				if (response.headersList.get("Upgrade")?.toLowerCase() !== "websocket") {
					failWebsocketConnection(ws, "Server did not set Upgrade header to \"websocket\".");
					return;
				}
				if (response.headersList.get("Connection")?.toLowerCase() !== "upgrade") {
					failWebsocketConnection(ws, "Server did not set Connection header to \"upgrade\".");
					return;
				}
				if (response.headersList.get("Sec-WebSocket-Accept") !== crypto.createHash("sha1").update(keyValue + uid).digest("base64")) {
					failWebsocketConnection(ws, "Incorrect hash received in Sec-WebSocket-Accept header.");
					return;
				}
				const secExtension = response.headersList.get("Sec-WebSocket-Extensions");
				if (secExtension !== null && secExtension !== permessageDeflate) {
					failWebsocketConnection(ws, "Received different permessage-deflate than the one set.");
					return;
				}
				const secProtocol = response.headersList.get("Sec-WebSocket-Protocol");
				if (secProtocol !== null && secProtocol !== request.headersList.get("Sec-WebSocket-Protocol")) {
					failWebsocketConnection(ws, "Protocol was not set in the opening handshake.");
					return;
				}
				response.socket.on("data", onSocketData);
				response.socket.on("close", onSocketClose);
				response.socket.on("error", onSocketError);
				if (channels.open.hasSubscribers) channels.open.publish({
					address: response.socket.address(),
					protocol: secProtocol,
					extensions: secExtension
				});
				onEstablish(response);
			}
		});
	}
	/**
	* @param {Buffer} chunk
	*/
	function onSocketData(chunk) {
		if (!this.ws[kByteParser].write(chunk)) this.pause();
	}
	/**
	* @see https://websockets.spec.whatwg.org/#feedback-from-the-protocol
	* @see https://datatracker.ietf.org/doc/html/rfc6455#section-7.1.4
	*/
	function onSocketClose() {
		const { ws } = this;
		const wasClean = ws[kSentClose] && ws[kReceivedClose];
		let code = 1005;
		let reason = "";
		const result = ws[kByteParser].closingInfo;
		if (result) {
			code = result.code ?? 1005;
			reason = result.reason;
		} else if (!ws[kSentClose]) code = 1006;
		ws[kReadyState] = states.CLOSED;
		fireEvent("close", ws, CloseEvent, {
			wasClean,
			code,
			reason
		});
		if (channels.close.hasSubscribers) channels.close.publish({
			websocket: ws,
			code,
			reason
		});
	}
	function onSocketError(error) {
		const { ws } = this;
		ws[kReadyState] = states.CLOSING;
		if (channels.socketError.hasSubscribers) channels.socketError.publish(error);
		this.destroy();
	}
	module.exports = { establishWebSocketConnection };
}));
//#endregion
//#region node_modules/undici/lib/websocket/frame.js
var require_frame = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { maxUnsigned16Bit } = require_constants();
	/** @type {import('crypto')} */
	var crypto;
	try {
		crypto = __require("crypto");
	} catch {}
	var WebsocketFrameSend = class {
		/**
		* @param {Buffer|undefined} data
		*/
		constructor(data) {
			this.frameData = data;
			this.maskKey = crypto.randomBytes(4);
		}
		createFrame(opcode) {
			const bodyLength = this.frameData?.byteLength ?? 0;
			/** @type {number} */
			let payloadLength = bodyLength;
			let offset = 6;
			if (bodyLength > maxUnsigned16Bit) {
				offset += 8;
				payloadLength = 127;
			} else if (bodyLength > 125) {
				offset += 2;
				payloadLength = 126;
			}
			const buffer = Buffer.allocUnsafe(bodyLength + offset);
			buffer[0] = buffer[1] = 0;
			buffer[0] |= 128;
			buffer[0] = (buffer[0] & 240) + opcode;
			/*! ws. MIT License. Einar Otto Stangvik <einaros@gmail.com> */
			buffer[offset - 4] = this.maskKey[0];
			buffer[offset - 3] = this.maskKey[1];
			buffer[offset - 2] = this.maskKey[2];
			buffer[offset - 1] = this.maskKey[3];
			buffer[1] = payloadLength;
			if (payloadLength === 126) buffer.writeUInt16BE(bodyLength, 2);
			else if (payloadLength === 127) {
				buffer[2] = buffer[3] = 0;
				buffer.writeUIntBE(bodyLength, 4, 6);
			}
			buffer[1] |= 128;
			for (let i = 0; i < bodyLength; i++) buffer[offset + i] = this.frameData[i] ^ this.maskKey[i % 4];
			return buffer;
		}
	};
	module.exports = { WebsocketFrameSend };
}));
//#endregion
//#region node_modules/undici/lib/websocket/receiver.js
var require_receiver = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Writable } = __require("stream");
	var diagnosticsChannel = __require("diagnostics_channel");
	var { parserStates, opcodes, states, emptyBuffer } = require_constants();
	var { kReadyState, kSentClose, kResponse, kReceivedClose } = require_symbols();
	var { isValidStatusCode, failWebsocketConnection, websocketMessageReceived } = require_util();
	var { WebsocketFrameSend } = require_frame();
	var channels = {};
	channels.ping = diagnosticsChannel.channel("undici:websocket:ping");
	channels.pong = diagnosticsChannel.channel("undici:websocket:pong");
	var ByteParser = class extends Writable {
		#buffers = [];
		#byteOffset = 0;
		#state = parserStates.INFO;
		#info = {};
		#fragments = [];
		constructor(ws) {
			super();
			this.ws = ws;
		}
		/**
		* @param {Buffer} chunk
		* @param {() => void} callback
		*/
		_write(chunk, _, callback) {
			this.#buffers.push(chunk);
			this.#byteOffset += chunk.length;
			this.run(callback);
		}
		/**
		* Runs whenever a new chunk is received.
		* Callback is called whenever there are no more chunks buffering,
		* or not enough bytes are buffered to parse.
		*/
		run(callback) {
			while (true) {
				if (this.#state === parserStates.INFO) {
					if (this.#byteOffset < 2) return callback();
					const buffer = this.consume(2);
					this.#info.fin = (buffer[0] & 128) !== 0;
					this.#info.opcode = buffer[0] & 15;
					this.#info.originalOpcode ??= this.#info.opcode;
					this.#info.fragmented = !this.#info.fin && this.#info.opcode !== opcodes.CONTINUATION;
					if (this.#info.fragmented && this.#info.opcode !== opcodes.BINARY && this.#info.opcode !== opcodes.TEXT) {
						failWebsocketConnection(this.ws, "Invalid frame type was fragmented.");
						return;
					}
					const payloadLength = buffer[1] & 127;
					if (payloadLength <= 125) {
						this.#info.payloadLength = payloadLength;
						this.#state = parserStates.READ_DATA;
					} else if (payloadLength === 126) this.#state = parserStates.PAYLOADLENGTH_16;
					else if (payloadLength === 127) this.#state = parserStates.PAYLOADLENGTH_64;
					if (this.#info.fragmented && payloadLength > 125) {
						failWebsocketConnection(this.ws, "Fragmented frame exceeded 125 bytes.");
						return;
					} else if ((this.#info.opcode === opcodes.PING || this.#info.opcode === opcodes.PONG || this.#info.opcode === opcodes.CLOSE) && payloadLength > 125) {
						failWebsocketConnection(this.ws, "Payload length for control frame exceeded 125 bytes.");
						return;
					} else if (this.#info.opcode === opcodes.CLOSE) {
						if (payloadLength === 1) {
							failWebsocketConnection(this.ws, "Received close frame with a 1-byte body.");
							return;
						}
						const body = this.consume(payloadLength);
						this.#info.closeInfo = this.parseCloseBody(false, body);
						if (!this.ws[kSentClose]) {
							const body = Buffer.allocUnsafe(2);
							body.writeUInt16BE(this.#info.closeInfo.code, 0);
							const closeFrame = new WebsocketFrameSend(body);
							this.ws[kResponse].socket.write(closeFrame.createFrame(opcodes.CLOSE), (err) => {
								if (!err) this.ws[kSentClose] = true;
							});
						}
						this.ws[kReadyState] = states.CLOSING;
						this.ws[kReceivedClose] = true;
						this.end();
						return;
					} else if (this.#info.opcode === opcodes.PING) {
						const body = this.consume(payloadLength);
						if (!this.ws[kReceivedClose]) {
							const frame = new WebsocketFrameSend(body);
							this.ws[kResponse].socket.write(frame.createFrame(opcodes.PONG));
							if (channels.ping.hasSubscribers) channels.ping.publish({ payload: body });
						}
						this.#state = parserStates.INFO;
						if (this.#byteOffset > 0) continue;
						else {
							callback();
							return;
						}
					} else if (this.#info.opcode === opcodes.PONG) {
						const body = this.consume(payloadLength);
						if (channels.pong.hasSubscribers) channels.pong.publish({ payload: body });
						if (this.#byteOffset > 0) continue;
						else {
							callback();
							return;
						}
					}
				} else if (this.#state === parserStates.PAYLOADLENGTH_16) {
					if (this.#byteOffset < 2) return callback();
					const buffer = this.consume(2);
					this.#info.payloadLength = buffer.readUInt16BE(0);
					this.#state = parserStates.READ_DATA;
				} else if (this.#state === parserStates.PAYLOADLENGTH_64) {
					if (this.#byteOffset < 8) return callback();
					const buffer = this.consume(8);
					const upper = buffer.readUInt32BE(0);
					if (upper > 2 ** 31 - 1) {
						failWebsocketConnection(this.ws, "Received payload length > 2^31 bytes.");
						return;
					}
					const lower = buffer.readUInt32BE(4);
					this.#info.payloadLength = (upper << 8) + lower;
					this.#state = parserStates.READ_DATA;
				} else if (this.#state === parserStates.READ_DATA) {
					if (this.#byteOffset < this.#info.payloadLength) return callback();
					else if (this.#byteOffset >= this.#info.payloadLength) {
						const body = this.consume(this.#info.payloadLength);
						this.#fragments.push(body);
						if (!this.#info.fragmented || this.#info.fin && this.#info.opcode === opcodes.CONTINUATION) {
							const fullMessage = Buffer.concat(this.#fragments);
							websocketMessageReceived(this.ws, this.#info.originalOpcode, fullMessage);
							this.#info = {};
							this.#fragments.length = 0;
						}
						this.#state = parserStates.INFO;
					}
				}
				if (this.#byteOffset > 0) continue;
				else {
					callback();
					break;
				}
			}
		}
		/**
		* Take n bytes from the buffered Buffers
		* @param {number} n
		* @returns {Buffer|null}
		*/
		consume(n) {
			if (n > this.#byteOffset) return null;
			else if (n === 0) return emptyBuffer;
			if (this.#buffers[0].length === n) {
				this.#byteOffset -= this.#buffers[0].length;
				return this.#buffers.shift();
			}
			const buffer = Buffer.allocUnsafe(n);
			let offset = 0;
			while (offset !== n) {
				const next = this.#buffers[0];
				const { length } = next;
				if (length + offset === n) {
					buffer.set(this.#buffers.shift(), offset);
					break;
				} else if (length + offset > n) {
					buffer.set(next.subarray(0, n - offset), offset);
					this.#buffers[0] = next.subarray(n - offset);
					break;
				} else {
					buffer.set(this.#buffers.shift(), offset);
					offset += next.length;
				}
			}
			this.#byteOffset -= n;
			return buffer;
		}
		parseCloseBody(onlyCode, data) {
			/** @type {number|undefined} */
			let code;
			if (data.length >= 2) code = data.readUInt16BE(0);
			if (onlyCode) {
				if (!isValidStatusCode(code)) return null;
				return { code };
			}
			/** @type {Buffer} */
			let reason = data.subarray(2);
			if (reason[0] === 239 && reason[1] === 187 && reason[2] === 191) reason = reason.subarray(3);
			if (code !== void 0 && !isValidStatusCode(code)) return null;
			try {
				reason = new TextDecoder("utf-8", { fatal: true }).decode(reason);
			} catch {
				return null;
			}
			return {
				code,
				reason
			};
		}
		get closingInfo() {
			return this.#info.closeInfo;
		}
	};
	module.exports = { ByteParser };
}));
//#endregion
//#region node_modules/undici/lib/websocket/websocket.js
var require_websocket = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { webidl } = require_webidl();
	var { DOMException } = require_constants$3();
	var { URLSerializer } = require_dataURL();
	var { getGlobalOrigin } = require_global$1();
	var { staticPropertyDescriptors, states, opcodes, emptyBuffer } = require_constants();
	var { kWebSocketURL, kReadyState, kController, kBinaryType, kResponse, kSentClose, kByteParser } = require_symbols();
	var { isEstablished, isClosing, isValidSubprotocol, failWebsocketConnection, fireEvent } = require_util();
	var { establishWebSocketConnection } = require_connection();
	var { WebsocketFrameSend } = require_frame();
	var { ByteParser } = require_receiver();
	var { kEnumerableProperty, isBlobLike } = require_util$6();
	var { getGlobalDispatcher } = require_global();
	var { types } = __require("util");
	var experimentalWarned = false;
	var WebSocket = class WebSocket extends EventTarget {
		#events = {
			open: null,
			error: null,
			close: null,
			message: null
		};
		#bufferedAmount = 0;
		#protocol = "";
		#extensions = "";
		/**
		* @param {string} url
		* @param {string|string[]} protocols
		*/
		constructor(url, protocols = []) {
			super();
			webidl.argumentLengthCheck(arguments, 1, { header: "WebSocket constructor" });
			if (!experimentalWarned) {
				experimentalWarned = true;
				process.emitWarning("WebSockets are experimental, expect them to change at any time.", { code: "UNDICI-WS" });
			}
			const options = webidl.converters["DOMString or sequence<DOMString> or WebSocketInit"](protocols);
			url = webidl.converters.USVString(url);
			protocols = options.protocols;
			const baseURL = getGlobalOrigin();
			let urlRecord;
			try {
				urlRecord = new URL(url, baseURL);
			} catch (e) {
				throw new DOMException(e, "SyntaxError");
			}
			if (urlRecord.protocol === "http:") urlRecord.protocol = "ws:";
			else if (urlRecord.protocol === "https:") urlRecord.protocol = "wss:";
			if (urlRecord.protocol !== "ws:" && urlRecord.protocol !== "wss:") throw new DOMException(`Expected a ws: or wss: protocol, got ${urlRecord.protocol}`, "SyntaxError");
			if (urlRecord.hash || urlRecord.href.endsWith("#")) throw new DOMException("Got fragment", "SyntaxError");
			if (typeof protocols === "string") protocols = [protocols];
			if (protocols.length !== new Set(protocols.map((p) => p.toLowerCase())).size) throw new DOMException("Invalid Sec-WebSocket-Protocol value", "SyntaxError");
			if (protocols.length > 0 && !protocols.every((p) => isValidSubprotocol(p))) throw new DOMException("Invalid Sec-WebSocket-Protocol value", "SyntaxError");
			this[kWebSocketURL] = new URL(urlRecord.href);
			this[kController] = establishWebSocketConnection(urlRecord, protocols, this, (response) => this.#onConnectionEstablished(response), options);
			this[kReadyState] = WebSocket.CONNECTING;
			this[kBinaryType] = "blob";
		}
		/**
		* @see https://websockets.spec.whatwg.org/#dom-websocket-close
		* @param {number|undefined} code
		* @param {string|undefined} reason
		*/
		close(code = void 0, reason = void 0) {
			webidl.brandCheck(this, WebSocket);
			if (code !== void 0) code = webidl.converters["unsigned short"](code, { clamp: true });
			if (reason !== void 0) reason = webidl.converters.USVString(reason);
			if (code !== void 0) {
				if (code !== 1e3 && (code < 3e3 || code > 4999)) throw new DOMException("invalid code", "InvalidAccessError");
			}
			let reasonByteLength = 0;
			if (reason !== void 0) {
				reasonByteLength = Buffer.byteLength(reason);
				if (reasonByteLength > 123) throw new DOMException(`Reason must be less than 123 bytes; received ${reasonByteLength}`, "SyntaxError");
			}
			if (this[kReadyState] === WebSocket.CLOSING || this[kReadyState] === WebSocket.CLOSED) {} else if (!isEstablished(this)) {
				failWebsocketConnection(this, "Connection was closed before it was established.");
				this[kReadyState] = WebSocket.CLOSING;
			} else if (!isClosing(this)) {
				const frame = new WebsocketFrameSend();
				if (code !== void 0 && reason === void 0) {
					frame.frameData = Buffer.allocUnsafe(2);
					frame.frameData.writeUInt16BE(code, 0);
				} else if (code !== void 0 && reason !== void 0) {
					frame.frameData = Buffer.allocUnsafe(2 + reasonByteLength);
					frame.frameData.writeUInt16BE(code, 0);
					frame.frameData.write(reason, 2, "utf-8");
				} else frame.frameData = emptyBuffer;
				this[kResponse].socket.write(frame.createFrame(opcodes.CLOSE), (err) => {
					if (!err) this[kSentClose] = true;
				});
				this[kReadyState] = states.CLOSING;
			} else this[kReadyState] = WebSocket.CLOSING;
		}
		/**
		* @see https://websockets.spec.whatwg.org/#dom-websocket-send
		* @param {NodeJS.TypedArray|ArrayBuffer|Blob|string} data
		*/
		send(data) {
			webidl.brandCheck(this, WebSocket);
			webidl.argumentLengthCheck(arguments, 1, { header: "WebSocket.send" });
			data = webidl.converters.WebSocketSendData(data);
			if (this[kReadyState] === WebSocket.CONNECTING) throw new DOMException("Sent before connected.", "InvalidStateError");
			if (!isEstablished(this) || isClosing(this)) return;
			/** @type {import('stream').Duplex} */
			const socket = this[kResponse].socket;
			if (typeof data === "string") {
				const value = Buffer.from(data);
				const buffer = new WebsocketFrameSend(value).createFrame(opcodes.TEXT);
				this.#bufferedAmount += value.byteLength;
				socket.write(buffer, () => {
					this.#bufferedAmount -= value.byteLength;
				});
			} else if (types.isArrayBuffer(data)) {
				const value = Buffer.from(data);
				const buffer = new WebsocketFrameSend(value).createFrame(opcodes.BINARY);
				this.#bufferedAmount += value.byteLength;
				socket.write(buffer, () => {
					this.#bufferedAmount -= value.byteLength;
				});
			} else if (ArrayBuffer.isView(data)) {
				const ab = Buffer.from(data, data.byteOffset, data.byteLength);
				const buffer = new WebsocketFrameSend(ab).createFrame(opcodes.BINARY);
				this.#bufferedAmount += ab.byteLength;
				socket.write(buffer, () => {
					this.#bufferedAmount -= ab.byteLength;
				});
			} else if (isBlobLike(data)) {
				const frame = new WebsocketFrameSend();
				data.arrayBuffer().then((ab) => {
					const value = Buffer.from(ab);
					frame.frameData = value;
					const buffer = frame.createFrame(opcodes.BINARY);
					this.#bufferedAmount += value.byteLength;
					socket.write(buffer, () => {
						this.#bufferedAmount -= value.byteLength;
					});
				});
			}
		}
		get readyState() {
			webidl.brandCheck(this, WebSocket);
			return this[kReadyState];
		}
		get bufferedAmount() {
			webidl.brandCheck(this, WebSocket);
			return this.#bufferedAmount;
		}
		get url() {
			webidl.brandCheck(this, WebSocket);
			return URLSerializer(this[kWebSocketURL]);
		}
		get extensions() {
			webidl.brandCheck(this, WebSocket);
			return this.#extensions;
		}
		get protocol() {
			webidl.brandCheck(this, WebSocket);
			return this.#protocol;
		}
		get onopen() {
			webidl.brandCheck(this, WebSocket);
			return this.#events.open;
		}
		set onopen(fn) {
			webidl.brandCheck(this, WebSocket);
			if (this.#events.open) this.removeEventListener("open", this.#events.open);
			if (typeof fn === "function") {
				this.#events.open = fn;
				this.addEventListener("open", fn);
			} else this.#events.open = null;
		}
		get onerror() {
			webidl.brandCheck(this, WebSocket);
			return this.#events.error;
		}
		set onerror(fn) {
			webidl.brandCheck(this, WebSocket);
			if (this.#events.error) this.removeEventListener("error", this.#events.error);
			if (typeof fn === "function") {
				this.#events.error = fn;
				this.addEventListener("error", fn);
			} else this.#events.error = null;
		}
		get onclose() {
			webidl.brandCheck(this, WebSocket);
			return this.#events.close;
		}
		set onclose(fn) {
			webidl.brandCheck(this, WebSocket);
			if (this.#events.close) this.removeEventListener("close", this.#events.close);
			if (typeof fn === "function") {
				this.#events.close = fn;
				this.addEventListener("close", fn);
			} else this.#events.close = null;
		}
		get onmessage() {
			webidl.brandCheck(this, WebSocket);
			return this.#events.message;
		}
		set onmessage(fn) {
			webidl.brandCheck(this, WebSocket);
			if (this.#events.message) this.removeEventListener("message", this.#events.message);
			if (typeof fn === "function") {
				this.#events.message = fn;
				this.addEventListener("message", fn);
			} else this.#events.message = null;
		}
		get binaryType() {
			webidl.brandCheck(this, WebSocket);
			return this[kBinaryType];
		}
		set binaryType(type) {
			webidl.brandCheck(this, WebSocket);
			if (type !== "blob" && type !== "arraybuffer") this[kBinaryType] = "blob";
			else this[kBinaryType] = type;
		}
		/**
		* @see https://websockets.spec.whatwg.org/#feedback-from-the-protocol
		*/
		#onConnectionEstablished(response) {
			this[kResponse] = response;
			const parser = new ByteParser(this);
			parser.on("drain", function onParserDrain() {
				this.ws[kResponse].socket.resume();
			});
			response.socket.ws = this;
			this[kByteParser] = parser;
			this[kReadyState] = states.OPEN;
			const extensions = response.headersList.get("sec-websocket-extensions");
			if (extensions !== null) this.#extensions = extensions;
			const protocol = response.headersList.get("sec-websocket-protocol");
			if (protocol !== null) this.#protocol = protocol;
			fireEvent("open", this);
		}
	};
	WebSocket.CONNECTING = WebSocket.prototype.CONNECTING = states.CONNECTING;
	WebSocket.OPEN = WebSocket.prototype.OPEN = states.OPEN;
	WebSocket.CLOSING = WebSocket.prototype.CLOSING = states.CLOSING;
	WebSocket.CLOSED = WebSocket.prototype.CLOSED = states.CLOSED;
	Object.defineProperties(WebSocket.prototype, {
		CONNECTING: staticPropertyDescriptors,
		OPEN: staticPropertyDescriptors,
		CLOSING: staticPropertyDescriptors,
		CLOSED: staticPropertyDescriptors,
		url: kEnumerableProperty,
		readyState: kEnumerableProperty,
		bufferedAmount: kEnumerableProperty,
		onopen: kEnumerableProperty,
		onerror: kEnumerableProperty,
		onclose: kEnumerableProperty,
		close: kEnumerableProperty,
		onmessage: kEnumerableProperty,
		binaryType: kEnumerableProperty,
		send: kEnumerableProperty,
		extensions: kEnumerableProperty,
		protocol: kEnumerableProperty,
		[Symbol.toStringTag]: {
			value: "WebSocket",
			writable: false,
			enumerable: false,
			configurable: true
		}
	});
	Object.defineProperties(WebSocket, {
		CONNECTING: staticPropertyDescriptors,
		OPEN: staticPropertyDescriptors,
		CLOSING: staticPropertyDescriptors,
		CLOSED: staticPropertyDescriptors
	});
	webidl.converters["sequence<DOMString>"] = webidl.sequenceConverter(webidl.converters.DOMString);
	webidl.converters["DOMString or sequence<DOMString>"] = function(V) {
		if (webidl.util.Type(V) === "Object" && Symbol.iterator in V) return webidl.converters["sequence<DOMString>"](V);
		return webidl.converters.DOMString(V);
	};
	webidl.converters.WebSocketInit = webidl.dictionaryConverter([
		{
			key: "protocols",
			converter: webidl.converters["DOMString or sequence<DOMString>"],
			get defaultValue() {
				return [];
			}
		},
		{
			key: "dispatcher",
			converter: (V) => V,
			get defaultValue() {
				return getGlobalDispatcher();
			}
		},
		{
			key: "headers",
			converter: webidl.nullableConverter(webidl.converters.HeadersInit)
		}
	]);
	webidl.converters["DOMString or sequence<DOMString> or WebSocketInit"] = function(V) {
		if (webidl.util.Type(V) === "Object" && !(Symbol.iterator in V)) return webidl.converters.WebSocketInit(V);
		return { protocols: webidl.converters["DOMString or sequence<DOMString>"](V) };
	};
	webidl.converters.WebSocketSendData = function(V) {
		if (webidl.util.Type(V) === "Object") {
			if (isBlobLike(V)) return webidl.converters.Blob(V, { strict: false });
			if (ArrayBuffer.isView(V) || types.isAnyArrayBuffer(V)) return webidl.converters.BufferSource(V);
		}
		return webidl.converters.USVString(V);
	};
	module.exports = { WebSocket };
}));
//#endregion
//#region node_modules/@firebase/storage/dist/node-esm/index.node.esm.js
var import_undici = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Client = require_client();
	var Dispatcher = require_dispatcher();
	var errors = require_errors();
	var Pool = require_pool();
	var BalancedPool = require_balanced_pool();
	var Agent = require_agent();
	var util = require_util$6();
	var { InvalidArgumentError } = errors;
	var api = require_api();
	var buildConnector = require_connect();
	var MockClient = require_mock_client();
	var MockAgent = require_mock_agent();
	var MockPool = require_mock_pool();
	var mockErrors = require_mock_errors();
	var ProxyAgent = require_proxy_agent();
	var RetryHandler = require_RetryHandler();
	var { getGlobalDispatcher, setGlobalDispatcher } = require_global();
	var DecoratorHandler = require_DecoratorHandler();
	var RedirectHandler = require_RedirectHandler();
	var createRedirectInterceptor = require_redirectInterceptor();
	var hasCrypto;
	try {
		__require("crypto");
		hasCrypto = true;
	} catch {
		hasCrypto = false;
	}
	Object.assign(Dispatcher.prototype, api);
	module.exports.Dispatcher = Dispatcher;
	module.exports.Client = Client;
	module.exports.Pool = Pool;
	module.exports.BalancedPool = BalancedPool;
	module.exports.Agent = Agent;
	module.exports.ProxyAgent = ProxyAgent;
	module.exports.RetryHandler = RetryHandler;
	module.exports.DecoratorHandler = DecoratorHandler;
	module.exports.RedirectHandler = RedirectHandler;
	module.exports.createRedirectInterceptor = createRedirectInterceptor;
	module.exports.buildConnector = buildConnector;
	module.exports.errors = errors;
	function makeDispatcher(fn) {
		return (url, opts, handler) => {
			if (typeof opts === "function") {
				handler = opts;
				opts = null;
			}
			if (!url || typeof url !== "string" && typeof url !== "object" && !(url instanceof URL)) throw new InvalidArgumentError("invalid url");
			if (opts != null && typeof opts !== "object") throw new InvalidArgumentError("invalid opts");
			if (opts && opts.path != null) {
				if (typeof opts.path !== "string") throw new InvalidArgumentError("invalid opts.path");
				let path = opts.path;
				if (!opts.path.startsWith("/")) path = `/${path}`;
				url = new URL(util.parseOrigin(url).origin + path);
			} else {
				if (!opts) opts = typeof url === "object" ? url : {};
				url = util.parseURL(url);
			}
			const { agent, dispatcher = getGlobalDispatcher() } = opts;
			if (agent) throw new InvalidArgumentError("unsupported opts.agent. Did you mean opts.client?");
			return fn.call(dispatcher, {
				...opts,
				origin: url.origin,
				path: url.search ? `${url.pathname}${url.search}` : url.pathname,
				method: opts.method || (opts.body ? "PUT" : "GET")
			}, handler);
		};
	}
	module.exports.setGlobalDispatcher = setGlobalDispatcher;
	module.exports.getGlobalDispatcher = getGlobalDispatcher;
	if (util.nodeMajor > 16 || util.nodeMajor === 16 && util.nodeMinor >= 8) {
		let fetchImpl = null;
		module.exports.fetch = async function fetch(resource) {
			if (!fetchImpl) fetchImpl = require_fetch().fetch;
			try {
				return await fetchImpl(...arguments);
			} catch (err) {
				if (typeof err === "object") Error.captureStackTrace(err, this);
				throw err;
			}
		};
		module.exports.Headers = require_headers().Headers;
		module.exports.Response = require_response().Response;
		module.exports.Request = require_request().Request;
		module.exports.FormData = require_formdata().FormData;
		module.exports.File = require_file().File;
		module.exports.FileReader = require_filereader().FileReader;
		const { setGlobalOrigin, getGlobalOrigin } = require_global$1();
		module.exports.setGlobalOrigin = setGlobalOrigin;
		module.exports.getGlobalOrigin = getGlobalOrigin;
		const { CacheStorage } = require_cachestorage();
		const { kConstruct } = require_symbols$1();
		module.exports.caches = new CacheStorage(kConstruct);
	}
	if (util.nodeMajor >= 16) {
		const { deleteCookie, getCookies, getSetCookies, setCookie } = require_cookies();
		module.exports.deleteCookie = deleteCookie;
		module.exports.getCookies = getCookies;
		module.exports.getSetCookies = getSetCookies;
		module.exports.setCookie = setCookie;
		const { parseMIMEType, serializeAMimeType } = require_dataURL();
		module.exports.parseMIMEType = parseMIMEType;
		module.exports.serializeAMimeType = serializeAMimeType;
	}
	if (util.nodeMajor >= 18 && hasCrypto) {
		const { WebSocket } = require_websocket();
		module.exports.WebSocket = WebSocket;
	}
	module.exports.request = makeDispatcher(api.request);
	module.exports.stream = makeDispatcher(api.stream);
	module.exports.pipeline = makeDispatcher(api.pipeline);
	module.exports.connect = makeDispatcher(api.connect);
	module.exports.upgrade = makeDispatcher(api.upgrade);
	module.exports.MockClient = MockClient;
	module.exports.MockPool = MockPool;
	module.exports.MockAgent = MockAgent;
	module.exports.mockErrors = mockErrors;
})))();
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @fileoverview Constants used in the Firebase Storage library.
*/
/**
* Domain name for firebase storage.
*/
var DEFAULT_HOST = "firebasestorage.googleapis.com";
/**
* The key in Firebase config json for the storage bucket.
*/
var CONFIG_STORAGE_BUCKET_KEY = "storageBucket";
/**
* 2 minutes
*
* The timeout for all operations except upload.
*/
var DEFAULT_MAX_OPERATION_RETRY_TIME = 12e4;
/**
* 10 minutes
*
* The timeout for upload.
*/
var DEFAULT_MAX_UPLOAD_RETRY_TIME = 6e5;
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An error returned by the Firebase Storage SDK.
* @public
*/
var StorageError = class StorageError extends FirebaseError {
	/**
	* @param code - A `StorageErrorCode` string to be prefixed with 'storage/' and
	*  added to the end of the message.
	* @param message  - Error message.
	* @param status_ - Corresponding HTTP Status Code
	*/
	constructor(code, message, status_ = 0) {
		super(prependCode(code), `Firebase Storage: ${message} (${prependCode(code)})`);
		this.status_ = status_;
		/**
		* Stores custom error data unique to the `StorageError`.
		*/
		this.customData = { serverResponse: null };
		this._baseMessage = this.message;
		Object.setPrototypeOf(this, StorageError.prototype);
	}
	get status() {
		return this.status_;
	}
	set status(status) {
		this.status_ = status;
	}
	/**
	* Compares a `StorageErrorCode` against this error's code, filtering out the prefix.
	*/
	_codeEquals(code) {
		return prependCode(code) === this.code;
	}
	/**
	* Optional response message that was added by the server.
	*/
	get serverResponse() {
		return this.customData.serverResponse;
	}
	set serverResponse(serverResponse) {
		this.customData.serverResponse = serverResponse;
		if (this.customData.serverResponse) this.message = `${this._baseMessage}\n${this.customData.serverResponse}`;
		else this.message = this._baseMessage;
	}
};
/**
* @public
* Error codes that can be attached to `StorageError` objects.
*/
var StorageErrorCode;
(function(StorageErrorCode) {
	StorageErrorCode["UNKNOWN"] = "unknown";
	StorageErrorCode["OBJECT_NOT_FOUND"] = "object-not-found";
	StorageErrorCode["BUCKET_NOT_FOUND"] = "bucket-not-found";
	StorageErrorCode["PROJECT_NOT_FOUND"] = "project-not-found";
	StorageErrorCode["QUOTA_EXCEEDED"] = "quota-exceeded";
	StorageErrorCode["UNAUTHENTICATED"] = "unauthenticated";
	StorageErrorCode["UNAUTHORIZED"] = "unauthorized";
	StorageErrorCode["UNAUTHORIZED_APP"] = "unauthorized-app";
	StorageErrorCode["RETRY_LIMIT_EXCEEDED"] = "retry-limit-exceeded";
	StorageErrorCode["INVALID_CHECKSUM"] = "invalid-checksum";
	StorageErrorCode["CANCELED"] = "canceled";
	StorageErrorCode["INVALID_EVENT_NAME"] = "invalid-event-name";
	StorageErrorCode["INVALID_URL"] = "invalid-url";
	StorageErrorCode["INVALID_DEFAULT_BUCKET"] = "invalid-default-bucket";
	StorageErrorCode["NO_DEFAULT_BUCKET"] = "no-default-bucket";
	StorageErrorCode["CANNOT_SLICE_BLOB"] = "cannot-slice-blob";
	StorageErrorCode["SERVER_FILE_WRONG_SIZE"] = "server-file-wrong-size";
	StorageErrorCode["NO_DOWNLOAD_URL"] = "no-download-url";
	StorageErrorCode["INVALID_ARGUMENT"] = "invalid-argument";
	StorageErrorCode["INVALID_ARGUMENT_COUNT"] = "invalid-argument-count";
	StorageErrorCode["APP_DELETED"] = "app-deleted";
	StorageErrorCode["INVALID_ROOT_OPERATION"] = "invalid-root-operation";
	StorageErrorCode["INVALID_FORMAT"] = "invalid-format";
	StorageErrorCode["INTERNAL_ERROR"] = "internal-error";
	StorageErrorCode["UNSUPPORTED_ENVIRONMENT"] = "unsupported-environment";
})(StorageErrorCode || (StorageErrorCode = {}));
function prependCode(code) {
	return "storage/" + code;
}
function unknown() {
	return new StorageError(StorageErrorCode.UNKNOWN, "An unknown error occurred, please check the error payload for server response.");
}
function objectNotFound(path) {
	return new StorageError(StorageErrorCode.OBJECT_NOT_FOUND, "Object '" + path + "' does not exist.");
}
function quotaExceeded(bucket) {
	return new StorageError(StorageErrorCode.QUOTA_EXCEEDED, "Quota for bucket '" + bucket + "' exceeded, please view quota on https://firebase.google.com/pricing/.");
}
function unauthenticated() {
	return new StorageError(StorageErrorCode.UNAUTHENTICATED, "User is not authenticated, please authenticate using Firebase Authentication and try again.");
}
function unauthorizedApp() {
	return new StorageError(StorageErrorCode.UNAUTHORIZED_APP, "This app does not have permission to access Firebase Storage on this project.");
}
function unauthorized(path) {
	return new StorageError(StorageErrorCode.UNAUTHORIZED, "User does not have permission to access '" + path + "'.");
}
function retryLimitExceeded() {
	return new StorageError(StorageErrorCode.RETRY_LIMIT_EXCEEDED, "Max retry time for operation exceeded, please try again.");
}
function canceled() {
	return new StorageError(StorageErrorCode.CANCELED, "User canceled the upload/download.");
}
function invalidUrl(url) {
	return new StorageError(StorageErrorCode.INVALID_URL, "Invalid URL '" + url + "'.");
}
function invalidDefaultBucket(bucket) {
	return new StorageError(StorageErrorCode.INVALID_DEFAULT_BUCKET, "Invalid default bucket '" + bucket + "'.");
}
function noDefaultBucket() {
	return new StorageError(StorageErrorCode.NO_DEFAULT_BUCKET, "No default bucket found. Did you set the 'storageBucket' property when initializing the app?");
}
function cannotSliceBlob() {
	return new StorageError(StorageErrorCode.CANNOT_SLICE_BLOB, "Cannot slice blob for upload. Please retry the upload.");
}
function noDownloadURL() {
	return new StorageError(StorageErrorCode.NO_DOWNLOAD_URL, "The given file does not have any download URLs.");
}
/**
* @internal
*/
function invalidArgument(message) {
	return new StorageError(StorageErrorCode.INVALID_ARGUMENT, message);
}
function appDeleted() {
	return new StorageError(StorageErrorCode.APP_DELETED, "The Firebase app was deleted.");
}
/**
* @param name - The name of the operation that was invalid.
*
* @internal
*/
function invalidRootOperation(name) {
	return new StorageError(StorageErrorCode.INVALID_ROOT_OPERATION, "The operation '" + name + "' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').");
}
/**
* @param format - The format that was not valid.
* @param message - A message describing the format violation.
*/
function invalidFormat(format, message) {
	return new StorageError(StorageErrorCode.INVALID_FORMAT, "String does not match format '" + format + "': " + message);
}
/**
* @param message - A message describing the internal error.
*/
function internalError(message) {
	throw new StorageError(StorageErrorCode.INTERNAL_ERROR, "Internal error: " + message);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Firebase Storage location data.
*
* @internal
*/
var Location = class Location {
	constructor(bucket, path) {
		this.bucket = bucket;
		this.path_ = path;
	}
	get path() {
		return this.path_;
	}
	get isRoot() {
		return this.path.length === 0;
	}
	fullServerUrl() {
		const encode = encodeURIComponent;
		return "/b/" + encode(this.bucket) + "/o/" + encode(this.path);
	}
	bucketOnlyServerUrl() {
		return "/b/" + encodeURIComponent(this.bucket) + "/o";
	}
	static makeFromBucketSpec(bucketString, host) {
		let bucketLocation;
		try {
			bucketLocation = Location.makeFromUrl(bucketString, host);
		} catch (e) {
			return new Location(bucketString, "");
		}
		if (bucketLocation.path === "") return bucketLocation;
		else throw invalidDefaultBucket(bucketString);
	}
	static makeFromUrl(url, host) {
		let location = null;
		const bucketDomain = "([A-Za-z0-9.\\-_]+)";
		function gsModify(loc) {
			if (loc.path.charAt(loc.path.length - 1) === "/") loc.path_ = loc.path_.slice(0, -1);
		}
		const gsRegex = new RegExp("^gs://" + bucketDomain + "(/(.*))?$", "i");
		const gsIndices = {
			bucket: 1,
			path: 3
		};
		function httpModify(loc) {
			loc.path_ = decodeURIComponent(loc.path);
		}
		const version = "v[A-Za-z0-9_]+";
		const firebaseStorageHost = host.replace(/[.]/g, "\\.");
		const firebaseStorageRegExp = new RegExp(`^https?://${firebaseStorageHost}/${version}/b/${bucketDomain}/o(/([^?#]*).*)?\$`, "i");
		const firebaseStorageIndices = {
			bucket: 1,
			path: 3
		};
		const cloudStorageRegExp = new RegExp(`^https?://${host === DEFAULT_HOST ? "(?:storage.googleapis.com|storage.cloud.google.com)" : host}/${bucketDomain}/([^?#]*)`, "i");
		const groups = [
			{
				regex: gsRegex,
				indices: gsIndices,
				postModify: gsModify
			},
			{
				regex: firebaseStorageRegExp,
				indices: firebaseStorageIndices,
				postModify: httpModify
			},
			{
				regex: cloudStorageRegExp,
				indices: {
					bucket: 1,
					path: 2
				},
				postModify: httpModify
			}
		];
		for (let i = 0; i < groups.length; i++) {
			const group = groups[i];
			const captures = group.regex.exec(url);
			if (captures) {
				const bucketValue = captures[group.indices.bucket];
				let pathValue = captures[group.indices.path];
				if (!pathValue) pathValue = "";
				location = new Location(bucketValue, pathValue);
				group.postModify(location);
				break;
			}
		}
		if (location == null) throw invalidUrl(url);
		return location;
	}
};
/**
* A request whose promise always fails.
*/
var FailRequest = class {
	constructor(error) {
		this.promise_ = Promise.reject(error);
	}
	/** @inheritDoc */
	getPromise() {
		return this.promise_;
	}
	/** @inheritDoc */
	cancel(_appDelete = false) {}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Accepts a callback for an action to perform (`doRequest`),
* and then a callback for when the backoff has completed (`backoffCompleteCb`).
* The callback sent to start requires an argument to call (`onRequestComplete`).
* When `start` calls `doRequest`, it passes a callback for when the request has
* completed, `onRequestComplete`. Based on this, the backoff continues, with
* another call to `doRequest` and the above loop continues until the timeout
* is hit, or a successful response occurs.
* @description
* @param doRequest Callback to perform request
* @param backoffCompleteCb Callback to call when backoff has been completed
*/
function start(doRequest, backoffCompleteCb, timeout) {
	let waitSeconds = 1;
	let retryTimeoutId = null;
	let globalTimeoutId = null;
	let hitTimeout = false;
	let cancelState = 0;
	function canceled() {
		return cancelState === 2;
	}
	let triggeredCallback = false;
	function triggerCallback(...args) {
		if (!triggeredCallback) {
			triggeredCallback = true;
			backoffCompleteCb.apply(null, args);
		}
	}
	function callWithDelay(millis) {
		retryTimeoutId = setTimeout(() => {
			retryTimeoutId = null;
			doRequest(responseHandler, canceled());
		}, millis);
	}
	function clearGlobalTimeout() {
		if (globalTimeoutId) clearTimeout(globalTimeoutId);
	}
	function responseHandler(success, ...args) {
		if (triggeredCallback) {
			clearGlobalTimeout();
			return;
		}
		if (success) {
			clearGlobalTimeout();
			triggerCallback.call(null, success, ...args);
			return;
		}
		if (canceled() || hitTimeout) {
			clearGlobalTimeout();
			triggerCallback.call(null, success, ...args);
			return;
		}
		if (waitSeconds < 64) waitSeconds *= 2;
		let waitMillis;
		if (cancelState === 1) {
			cancelState = 2;
			waitMillis = 0;
		} else waitMillis = (waitSeconds + Math.random()) * 1e3;
		callWithDelay(waitMillis);
	}
	let stopped = false;
	function stop(wasTimeout) {
		if (stopped) return;
		stopped = true;
		clearGlobalTimeout();
		if (triggeredCallback) return;
		if (retryTimeoutId !== null) {
			if (!wasTimeout) cancelState = 2;
			clearTimeout(retryTimeoutId);
			callWithDelay(0);
		} else if (!wasTimeout) cancelState = 1;
	}
	callWithDelay(0);
	globalTimeoutId = setTimeout(() => {
		hitTimeout = true;
		stop(true);
	}, timeout);
	return stop;
}
/**
* Stops the retry loop from repeating.
* If the function is currently "in between" retries, it is invoked immediately
* with the second parameter as "true". Otherwise, it will be invoked once more
* after the current invocation finishes iff the current invocation would have
* triggered another retry.
*/
function stop(id) {
	id(false);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function isJustDef(p) {
	return p !== void 0;
}
function isNonArrayObject(p) {
	return typeof p === "object" && !Array.isArray(p);
}
function isString(p) {
	return typeof p === "string" || p instanceof String;
}
function isNativeBlob(p) {
	return isNativeBlobDefined() && p instanceof Blob;
}
function isNativeBlobDefined() {
	return typeof Blob !== "undefined";
}
function validateNumber(argument, minValue, maxValue, value) {
	if (value < minValue) throw invalidArgument(`Invalid value for '${argument}'. Expected ${minValue} or greater.`);
	if (value > maxValue) throw invalidArgument(`Invalid value for '${argument}'. Expected ${maxValue} or less.`);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function makeUrl(urlPart, host, protocol) {
	let origin = host;
	if (protocol == null) origin = `https://${host}`;
	return `${protocol}://${origin}/v0${urlPart}`;
}
function makeQueryString(params) {
	const encode = encodeURIComponent;
	let queryPart = "?";
	for (const key in params) if (params.hasOwnProperty(key)) {
		const nextPart = encode(key) + "=" + encode(params[key]);
		queryPart = queryPart + nextPart + "&";
	}
	queryPart = queryPart.slice(0, -1);
	return queryPart;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Error codes for requests made by the the XhrIo wrapper.
*/
var ErrorCode;
(function(ErrorCode) {
	ErrorCode[ErrorCode["NO_ERROR"] = 0] = "NO_ERROR";
	ErrorCode[ErrorCode["NETWORK_ERROR"] = 1] = "NETWORK_ERROR";
	ErrorCode[ErrorCode["ABORT"] = 2] = "ABORT";
})(ErrorCode || (ErrorCode = {}));
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Checks the status code to see if the action should be retried.
*
* @param status Current HTTP status code returned by server.
* @param additionalRetryCodes additional retry codes to check against
*/
function isRetryStatusCode(status, additionalRetryCodes) {
	const isFiveHundredCode = status >= 500 && status < 600;
	const isExtraRetryCode = [408, 429].indexOf(status) !== -1;
	const isAdditionalRetryCode = additionalRetryCodes.indexOf(status) !== -1;
	return isFiveHundredCode || isExtraRetryCode || isAdditionalRetryCode;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Handles network logic for all Storage Requests, including error reporting and
* retries with backoff.
*
* @param I - the type of the backend's network response.
* @param - O the output type used by the rest of the SDK. The conversion
* happens in the specified `callback_`.
*/
var NetworkRequest = class {
	constructor(url_, method_, headers_, body_, successCodes_, additionalRetryCodes_, callback_, errorCallback_, timeout_, progressCallback_, connectionFactory_, retry = true) {
		this.url_ = url_;
		this.method_ = method_;
		this.headers_ = headers_;
		this.body_ = body_;
		this.successCodes_ = successCodes_;
		this.additionalRetryCodes_ = additionalRetryCodes_;
		this.callback_ = callback_;
		this.errorCallback_ = errorCallback_;
		this.timeout_ = timeout_;
		this.progressCallback_ = progressCallback_;
		this.connectionFactory_ = connectionFactory_;
		this.retry = retry;
		this.pendingConnection_ = null;
		this.backoffId_ = null;
		this.canceled_ = false;
		this.appDelete_ = false;
		this.promise_ = new Promise((resolve, reject) => {
			this.resolve_ = resolve;
			this.reject_ = reject;
			this.start_();
		});
	}
	/**
	* Actually starts the retry loop.
	*/
	start_() {
		const doTheRequest = (backoffCallback, canceled) => {
			if (canceled) {
				backoffCallback(false, new RequestEndStatus(false, null, true));
				return;
			}
			const connection = this.connectionFactory_();
			this.pendingConnection_ = connection;
			const progressListener = (progressEvent) => {
				const loaded = progressEvent.loaded;
				const total = progressEvent.lengthComputable ? progressEvent.total : -1;
				if (this.progressCallback_ !== null) this.progressCallback_(loaded, total);
			};
			if (this.progressCallback_ !== null) connection.addUploadProgressListener(progressListener);
			connection.send(this.url_, this.method_, this.body_, this.headers_).then(() => {
				if (this.progressCallback_ !== null) connection.removeUploadProgressListener(progressListener);
				this.pendingConnection_ = null;
				const hitServer = connection.getErrorCode() === ErrorCode.NO_ERROR;
				const status = connection.getStatus();
				if (!hitServer || isRetryStatusCode(status, this.additionalRetryCodes_) && this.retry) {
					backoffCallback(false, new RequestEndStatus(false, null, connection.getErrorCode() === ErrorCode.ABORT));
					return;
				}
				backoffCallback(true, new RequestEndStatus(this.successCodes_.indexOf(status) !== -1, connection));
			});
		};
		/**
		* @param requestWentThrough - True if the request eventually went
		*     through, false if it hit the retry limit or was canceled.
		*/
		const backoffDone = (requestWentThrough, status) => {
			const resolve = this.resolve_;
			const reject = this.reject_;
			const connection = status.connection;
			if (status.wasSuccessCode) try {
				const result = this.callback_(connection, connection.getResponse());
				if (isJustDef(result)) resolve(result);
				else resolve();
			} catch (e) {
				reject(e);
			}
			else if (connection !== null) {
				const err = unknown();
				err.serverResponse = connection.getErrorText();
				if (this.errorCallback_) reject(this.errorCallback_(connection, err));
				else reject(err);
			} else if (status.canceled) reject(this.appDelete_ ? appDeleted() : canceled());
			else reject(retryLimitExceeded());
		};
		if (this.canceled_) backoffDone(false, new RequestEndStatus(false, null, true));
		else this.backoffId_ = start(doTheRequest, backoffDone, this.timeout_);
	}
	/** @inheritDoc */
	getPromise() {
		return this.promise_;
	}
	/** @inheritDoc */
	cancel(appDelete) {
		this.canceled_ = true;
		this.appDelete_ = appDelete || false;
		if (this.backoffId_ !== null) stop(this.backoffId_);
		if (this.pendingConnection_ !== null) this.pendingConnection_.abort();
	}
};
/**
* A collection of information about the result of a network request.
* @param opt_canceled - Defaults to false.
*/
var RequestEndStatus = class {
	constructor(wasSuccessCode, connection, canceled) {
		this.wasSuccessCode = wasSuccessCode;
		this.connection = connection;
		this.canceled = !!canceled;
	}
};
function addAuthHeader_(headers, authToken) {
	if (authToken !== null && authToken.length > 0) headers["Authorization"] = "Firebase " + authToken;
}
function addVersionHeader_(headers, firebaseVersion) {
	headers["X-Firebase-Storage-Version"] = "webjs/" + (firebaseVersion !== null && firebaseVersion !== void 0 ? firebaseVersion : "AppManager");
}
function addGmpidHeader_(headers, appId) {
	if (appId) headers["X-Firebase-GMPID"] = appId;
}
function addAppCheckHeader_(headers, appCheckToken) {
	if (appCheckToken !== null) headers["X-Firebase-AppCheck"] = appCheckToken;
}
function makeRequest(requestInfo, appId, authToken, appCheckToken, requestFactory, firebaseVersion, retry = true) {
	const queryPart = makeQueryString(requestInfo.urlParams);
	const url = requestInfo.url + queryPart;
	const headers = Object.assign({}, requestInfo.headers);
	addGmpidHeader_(headers, appId);
	addAuthHeader_(headers, authToken);
	addVersionHeader_(headers, firebaseVersion);
	addAppCheckHeader_(headers, appCheckToken);
	return new NetworkRequest(url, requestInfo.method, headers, requestInfo.body, requestInfo.successCodes, requestInfo.additionalRetryCodes, requestInfo.handler, requestInfo.errorHandler, requestInfo.timeout, requestInfo.progressCallback, requestFactory, retry);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function getBlobBuilder() {
	if (typeof BlobBuilder !== "undefined") return BlobBuilder;
	else if (typeof WebKitBlobBuilder !== "undefined") return WebKitBlobBuilder;
	else return;
}
/**
* Concatenates one or more values together and converts them to a Blob.
*
* @param args The values that will make up the resulting blob.
* @return The blob.
*/
function getBlob$1(...args) {
	const BlobBuilder = getBlobBuilder();
	if (BlobBuilder !== void 0) {
		const bb = new BlobBuilder();
		for (let i = 0; i < args.length; i++) bb.append(args[i]);
		return bb.getBlob();
	} else if (isNativeBlobDefined()) return new Blob(args);
	else throw new StorageError(StorageErrorCode.UNSUPPORTED_ENVIRONMENT, "This browser doesn't seem to support creating Blobs");
}
/**
* Slices the blob. The returned blob contains data from the start byte
* (inclusive) till the end byte (exclusive). Negative indices cannot be used.
*
* @param blob The blob to be sliced.
* @param start Index of the starting byte.
* @param end Index of the ending byte.
* @return The blob slice or null if not supported.
*/
function sliceBlob(blob, start, end) {
	if (blob.webkitSlice) return blob.webkitSlice(start, end);
	else if (blob.mozSlice) return blob.mozSlice(start, end);
	else if (blob.slice) return blob.slice(start, end);
	return null;
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Converts a Base64 encoded string to a binary string. */
function decodeBase64(encoded) {
	if (/[^-A-Za-z0-9+/=]/.test(encoded)) throw invalidFormat("base64", "Invalid character found");
	return Buffer.from(encoded, "base64").toString("binary");
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An enumeration of the possible string formats for upload.
* @public
*/
var StringFormat = {
	/**
	* Indicates the string should be interpreted "raw", that is, as normal text.
	* The string will be interpreted as UTF-16, then uploaded as a UTF-8 byte
	* sequence.
	* Example: The string 'Hello! \\ud83d\\ude0a' becomes the byte sequence
	* 48 65 6c 6c 6f 21 20 f0 9f 98 8a
	*/
	RAW: "raw",
	/**
	* Indicates the string should be interpreted as base64-encoded data.
	* Padding characters (trailing '='s) are optional.
	* Example: The string 'rWmO++E6t7/rlw==' becomes the byte sequence
	* ad 69 8e fb e1 3a b7 bf eb 97
	*/
	BASE64: "base64",
	/**
	* Indicates the string should be interpreted as base64url-encoded data.
	* Padding characters (trailing '='s) are optional.
	* Example: The string 'rWmO--E6t7_rlw==' becomes the byte sequence
	* ad 69 8e fb e1 3a b7 bf eb 97
	*/
	BASE64URL: "base64url",
	/**
	* Indicates the string is a data URL, such as one obtained from
	* canvas.toDataURL().
	* Example: the string 'data:application/octet-stream;base64,aaaa'
	* becomes the byte sequence
	* 69 a6 9a
	* (the content-type "application/octet-stream" is also applied, but can
	* be overridden in the metadata object).
	*/
	DATA_URL: "data_url"
};
var StringData = class {
	constructor(data, contentType) {
		this.data = data;
		this.contentType = contentType || null;
	}
};
/**
* @internal
*/
function dataFromString(format, stringData) {
	switch (format) {
		case StringFormat.RAW: return new StringData(utf8Bytes_(stringData));
		case StringFormat.BASE64:
		case StringFormat.BASE64URL: return new StringData(base64Bytes_(format, stringData));
		case StringFormat.DATA_URL: return new StringData(dataURLBytes_(stringData), dataURLContentType_(stringData));
	}
	throw unknown();
}
function utf8Bytes_(value) {
	const b = [];
	for (let i = 0; i < value.length; i++) {
		let c = value.charCodeAt(i);
		if (c <= 127) b.push(c);
		else if (c <= 2047) b.push(192 | c >> 6, 128 | c & 63);
		else if ((c & 64512) === 55296) {
			if (!(i < value.length - 1 && (value.charCodeAt(i + 1) & 64512) === 56320)) b.push(239, 191, 189);
			else {
				const hi = c;
				const lo = value.charCodeAt(++i);
				c = 65536 | (hi & 1023) << 10 | lo & 1023;
				b.push(240 | c >> 18, 128 | c >> 12 & 63, 128 | c >> 6 & 63, 128 | c & 63);
			}
		} else if ((c & 64512) === 56320) b.push(239, 191, 189);
		else b.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
	}
	return new Uint8Array(b);
}
function percentEncodedBytes_(value) {
	let decoded;
	try {
		decoded = decodeURIComponent(value);
	} catch (e) {
		throw invalidFormat(StringFormat.DATA_URL, "Malformed data URL.");
	}
	return utf8Bytes_(decoded);
}
function base64Bytes_(format, value) {
	switch (format) {
		case StringFormat.BASE64: {
			const hasMinus = value.indexOf("-") !== -1;
			const hasUnder = value.indexOf("_") !== -1;
			if (hasMinus || hasUnder) throw invalidFormat(format, "Invalid character '" + (hasMinus ? "-" : "_") + "' found: is it base64url encoded?");
			break;
		}
		case StringFormat.BASE64URL: {
			const hasPlus = value.indexOf("+") !== -1;
			const hasSlash = value.indexOf("/") !== -1;
			if (hasPlus || hasSlash) throw invalidFormat(format, "Invalid character '" + (hasPlus ? "+" : "/") + "' found: is it base64 encoded?");
			value = value.replace(/-/g, "+").replace(/_/g, "/");
			break;
		}
	}
	let bytes;
	try {
		bytes = decodeBase64(value);
	} catch (e) {
		if (e.message.includes("polyfill")) throw e;
		throw invalidFormat(format, "Invalid character found");
	}
	const array = new Uint8Array(bytes.length);
	for (let i = 0; i < bytes.length; i++) array[i] = bytes.charCodeAt(i);
	return array;
}
var DataURLParts = class {
	constructor(dataURL) {
		this.base64 = false;
		this.contentType = null;
		const matches = dataURL.match(/^data:([^,]+)?,/);
		if (matches === null) throw invalidFormat(StringFormat.DATA_URL, "Must be formatted 'data:[<mediatype>][;base64],<data>");
		const middle = matches[1] || null;
		if (middle != null) {
			this.base64 = endsWith(middle, ";base64");
			this.contentType = this.base64 ? middle.substring(0, middle.length - 7) : middle;
		}
		this.rest = dataURL.substring(dataURL.indexOf(",") + 1);
	}
};
function dataURLBytes_(dataUrl) {
	const parts = new DataURLParts(dataUrl);
	if (parts.base64) return base64Bytes_(StringFormat.BASE64, parts.rest);
	else return percentEncodedBytes_(parts.rest);
}
function dataURLContentType_(dataUrl) {
	return new DataURLParts(dataUrl).contentType;
}
function endsWith(s, end) {
	if (!(s.length >= end.length)) return false;
	return s.substring(s.length - end.length) === end;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @param opt_elideCopy - If true, doesn't copy mutable input data
*     (e.g. Uint8Arrays). Pass true only if you know the objects will not be
*     modified after this blob's construction.
*
* @internal
*/
var FbsBlob = class FbsBlob {
	constructor(data, elideCopy) {
		let size = 0;
		let blobType = "";
		if (isNativeBlob(data)) {
			this.data_ = data;
			size = data.size;
			blobType = data.type;
		} else if (data instanceof ArrayBuffer) {
			if (elideCopy) this.data_ = new Uint8Array(data);
			else {
				this.data_ = new Uint8Array(data.byteLength);
				this.data_.set(new Uint8Array(data));
			}
			size = this.data_.length;
		} else if (data instanceof Uint8Array) {
			if (elideCopy) this.data_ = data;
			else {
				this.data_ = new Uint8Array(data.length);
				this.data_.set(data);
			}
			size = data.length;
		}
		this.size_ = size;
		this.type_ = blobType;
	}
	size() {
		return this.size_;
	}
	type() {
		return this.type_;
	}
	slice(startByte, endByte) {
		if (isNativeBlob(this.data_)) {
			const realBlob = this.data_;
			const sliced = sliceBlob(realBlob, startByte, endByte);
			if (sliced === null) return null;
			return new FbsBlob(sliced);
		} else {
			const slice = new Uint8Array(this.data_.buffer, startByte, endByte - startByte);
			return new FbsBlob(slice, true);
		}
	}
	static getBlob(...args) {
		if (isNativeBlobDefined()) {
			const blobby = args.map((val) => {
				if (val instanceof FbsBlob) return val.data_;
				else return val;
			});
			return new FbsBlob(getBlob$1.apply(null, blobby));
		} else {
			const uint8Arrays = args.map((val) => {
				if (isString(val)) return dataFromString(StringFormat.RAW, val).data;
				else return val.data_;
			});
			let finalLength = 0;
			uint8Arrays.forEach((array) => {
				finalLength += array.byteLength;
			});
			const merged = new Uint8Array(finalLength);
			let index = 0;
			uint8Arrays.forEach((array) => {
				for (let i = 0; i < array.length; i++) merged[index++] = array[i];
			});
			return new FbsBlob(merged, true);
		}
	}
	uploadData() {
		return this.data_;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns the Object resulting from parsing the given JSON, or null if the
* given string does not represent a JSON object.
*/
function jsonObjectOrNull(s) {
	let obj;
	try {
		obj = JSON.parse(s);
	} catch (e) {
		return null;
	}
	if (isNonArrayObject(obj)) return obj;
	else return null;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @fileoverview Contains helper methods for manipulating paths.
*/
/**
* @return Null if the path is already at the root.
*/
function parent(path) {
	if (path.length === 0) return null;
	const index = path.lastIndexOf("/");
	if (index === -1) return "";
	return path.slice(0, index);
}
function child(path, childPath) {
	const canonicalChildPath = childPath.split("/").filter((component) => component.length > 0).join("/");
	if (path.length === 0) return canonicalChildPath;
	else return path + "/" + canonicalChildPath;
}
/**
* Returns the last component of a path.
* '/foo/bar' -> 'bar'
* '/foo/bar/baz/' -> 'baz/'
* '/a' -> 'a'
*/
function lastComponent(path) {
	const index = path.lastIndexOf("/", path.length - 2);
	if (index === -1) return path;
	else return path.slice(index + 1);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function noXform_(metadata, value) {
	return value;
}
var Mapping = class {
	constructor(server, local, writable, xform) {
		this.server = server;
		this.local = local || server;
		this.writable = !!writable;
		this.xform = xform || noXform_;
	}
};
var mappings_ = null;
function xformPath(fullPath) {
	if (!isString(fullPath) || fullPath.length < 2) return fullPath;
	else return lastComponent(fullPath);
}
function getMappings() {
	if (mappings_) return mappings_;
	const mappings = [];
	mappings.push(new Mapping("bucket"));
	mappings.push(new Mapping("generation"));
	mappings.push(new Mapping("metageneration"));
	mappings.push(new Mapping("name", "fullPath", true));
	function mappingsXformPath(_metadata, fullPath) {
		return xformPath(fullPath);
	}
	const nameMapping = new Mapping("name");
	nameMapping.xform = mappingsXformPath;
	mappings.push(nameMapping);
	/**
	* Coerces the second param to a number, if it is defined.
	*/
	function xformSize(_metadata, size) {
		if (size !== void 0) return Number(size);
		else return size;
	}
	const sizeMapping = new Mapping("size");
	sizeMapping.xform = xformSize;
	mappings.push(sizeMapping);
	mappings.push(new Mapping("timeCreated"));
	mappings.push(new Mapping("updated"));
	mappings.push(new Mapping("md5Hash", null, true));
	mappings.push(new Mapping("cacheControl", null, true));
	mappings.push(new Mapping("contentDisposition", null, true));
	mappings.push(new Mapping("contentEncoding", null, true));
	mappings.push(new Mapping("contentLanguage", null, true));
	mappings.push(new Mapping("contentType", null, true));
	mappings.push(new Mapping("metadata", "customMetadata", true));
	mappings_ = mappings;
	return mappings_;
}
function addRef(metadata, service) {
	function generateRef() {
		const bucket = metadata["bucket"];
		const path = metadata["fullPath"];
		const loc = new Location(bucket, path);
		return service._makeStorageReference(loc);
	}
	Object.defineProperty(metadata, "ref", { get: generateRef });
}
function fromResource(service, resource, mappings) {
	const metadata = {};
	metadata["type"] = "file";
	const len = mappings.length;
	for (let i = 0; i < len; i++) {
		const mapping = mappings[i];
		metadata[mapping.local] = mapping.xform(metadata, resource[mapping.server]);
	}
	addRef(metadata, service);
	return metadata;
}
function fromResourceString(service, resourceString, mappings) {
	const obj = jsonObjectOrNull(resourceString);
	if (obj === null) return null;
	return fromResource(service, obj, mappings);
}
function downloadUrlFromResourceString(metadata, resourceString, host, protocol) {
	const obj = jsonObjectOrNull(resourceString);
	if (obj === null) return null;
	if (!isString(obj["downloadTokens"])) return null;
	const tokens = obj["downloadTokens"];
	if (tokens.length === 0) return null;
	const encode = encodeURIComponent;
	return tokens.split(",").map((token) => {
		const bucket = metadata["bucket"];
		const path = metadata["fullPath"];
		return makeUrl("/b/" + encode(bucket) + "/o/" + encode(path), host, protocol) + makeQueryString({
			alt: "media",
			token
		});
	})[0];
}
function toResourceString(metadata, mappings) {
	const resource = {};
	const len = mappings.length;
	for (let i = 0; i < len; i++) {
		const mapping = mappings[i];
		if (mapping.writable) resource[mapping.server] = metadata[mapping.local];
	}
	return JSON.stringify(resource);
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Contains a fully specified request.
*
* @param I - the type of the backend's network response.
* @param O - the output response type used by the rest of the SDK.
*/
var RequestInfo = class {
	constructor(url, method, handler, timeout) {
		this.url = url;
		this.method = method;
		this.handler = handler;
		this.timeout = timeout;
		this.urlParams = {};
		this.headers = {};
		this.body = null;
		this.errorHandler = null;
		/**
		* Called with the current number of bytes uploaded and total size (-1 if not
		* computable) of the request body (i.e. used to report upload progress).
		*/
		this.progressCallback = null;
		this.successCodes = [200];
		this.additionalRetryCodes = [];
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Throws the UNKNOWN StorageError if cndn is false.
*/
function handlerCheck(cndn) {
	if (!cndn) throw unknown();
}
function metadataHandler(service, mappings) {
	function handler(xhr, text) {
		const metadata = fromResourceString(service, text, mappings);
		handlerCheck(metadata !== null);
		return metadata;
	}
	return handler;
}
function downloadUrlHandler(service, mappings) {
	function handler(xhr, text) {
		const metadata = fromResourceString(service, text, mappings);
		handlerCheck(metadata !== null);
		return downloadUrlFromResourceString(metadata, text, service.host, service._protocol);
	}
	return handler;
}
function sharedErrorHandler(location) {
	function errorHandler(xhr, err) {
		let newErr;
		if (xhr.getStatus() === 401) {
			if (xhr.getErrorText().includes("Firebase App Check token is invalid")) newErr = unauthorizedApp();
			else newErr = unauthenticated();
		} else if (xhr.getStatus() === 402) newErr = quotaExceeded(location.bucket);
		else if (xhr.getStatus() === 403) newErr = unauthorized(location.path);
		else newErr = err;
		newErr.status = xhr.getStatus();
		newErr.serverResponse = err.serverResponse;
		return newErr;
	}
	return errorHandler;
}
function objectErrorHandler(location) {
	const shared = sharedErrorHandler(location);
	function errorHandler(xhr, err) {
		let newErr = shared(xhr, err);
		if (xhr.getStatus() === 404) newErr = objectNotFound(location.path);
		newErr.serverResponse = err.serverResponse;
		return newErr;
	}
	return errorHandler;
}
function getDownloadUrl(service, location, mappings) {
	const url = makeUrl(location.fullServerUrl(), service.host, service._protocol);
	const method = "GET";
	const timeout = service.maxOperationRetryTime;
	const requestInfo = new RequestInfo(url, method, downloadUrlHandler(service, mappings), timeout);
	requestInfo.errorHandler = objectErrorHandler(location);
	return requestInfo;
}
function determineContentType_(metadata, blob) {
	return metadata && metadata["contentType"] || blob && blob.type() || "application/octet-stream";
}
function metadataForUpload_(location, blob, metadata) {
	const metadataClone = Object.assign({}, metadata);
	metadataClone["fullPath"] = location.path;
	metadataClone["size"] = blob.size();
	if (!metadataClone["contentType"]) metadataClone["contentType"] = determineContentType_(null, blob);
	return metadataClone;
}
/**
* Prepare RequestInfo for uploads as Content-Type: multipart.
*/
function multipartUpload(service, location, mappings, blob, metadata) {
	const urlPart = location.bucketOnlyServerUrl();
	const headers = { "X-Goog-Upload-Protocol": "multipart" };
	function genBoundary() {
		let str = "";
		for (let i = 0; i < 2; i++) str = str + Math.random().toString().slice(2);
		return str;
	}
	const boundary = genBoundary();
	headers["Content-Type"] = "multipart/related; boundary=" + boundary;
	const metadata_ = metadataForUpload_(location, blob, metadata);
	const metadataString = toResourceString(metadata_, mappings);
	const preBlobPart = "--" + boundary + "\r\nContent-Type: application/json; charset=utf-8\r\n\r\n" + metadataString + "\r\n--" + boundary + "\r\nContent-Type: " + metadata_["contentType"] + "\r\n\r\n";
	const postBlobPart = "\r\n--" + boundary + "--";
	const body = FbsBlob.getBlob(preBlobPart, blob, postBlobPart);
	if (body === null) throw cannotSliceBlob();
	const urlParams = { name: metadata_["fullPath"] };
	const url = makeUrl(urlPart, service.host, service._protocol);
	const method = "POST";
	const timeout = service.maxUploadRetryTime;
	const requestInfo = new RequestInfo(url, method, metadataHandler(service, mappings), timeout);
	requestInfo.urlParams = urlParams;
	requestInfo.headers = headers;
	requestInfo.body = body.uploadData();
	requestInfo.errorHandler = sharedErrorHandler(location);
	return requestInfo;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Network layer that works in Node.
*
* This network implementation should not be used in browsers as it does not
* support progress updates.
*/
var FetchConnection = class {
	constructor() {
		this.errorText_ = "";
		this.sent_ = false;
		this.fetch_ = import_undici.fetch;
		this.errorCode_ = ErrorCode.NO_ERROR;
	}
	async send(url, method, body, headers) {
		if (this.sent_) throw internalError("cannot .send() more than once");
		this.sent_ = true;
		try {
			const response = await this.fetch_(url, {
				method,
				headers: headers || {},
				body
			});
			this.headers_ = response.headers;
			this.statusCode_ = response.status;
			this.errorCode_ = ErrorCode.NO_ERROR;
			this.body_ = await response.arrayBuffer();
		} catch (e) {
			this.errorText_ = e === null || e === void 0 ? void 0 : e.message;
			this.statusCode_ = 0;
			this.errorCode_ = ErrorCode.NETWORK_ERROR;
		}
	}
	getErrorCode() {
		if (this.errorCode_ === void 0) throw internalError("cannot .getErrorCode() before receiving response");
		return this.errorCode_;
	}
	getStatus() {
		if (this.statusCode_ === void 0) throw internalError("cannot .getStatus() before receiving response");
		return this.statusCode_;
	}
	getErrorText() {
		return this.errorText_;
	}
	abort() {}
	getResponseHeader(header) {
		if (!this.headers_) throw internalError("cannot .getResponseHeader() before receiving response");
		return this.headers_.get(header);
	}
	addUploadProgressListener(listener) {}
	removeUploadProgressListener(listener) {}
};
var FetchTextConnection = class extends FetchConnection {
	getResponse() {
		if (!this.body_) throw internalError("cannot .getResponse() before receiving response");
		return Buffer.from(this.body_).toString("utf-8");
	}
};
function newTextConnection() {
	return new FetchTextConnection();
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provides methods to interact with a bucket in the Firebase Storage service.
* @internal
* @param _location - An fbs.location, or the URL at
*     which to base this object, in one of the following forms:
*         gs://<bucket>/<object-path>
*         http[s]://firebasestorage.googleapis.com/
*                     <api-version>/b/<bucket>/o/<object-path>
*     Any query or fragment strings will be ignored in the http[s]
*     format. If no value is passed, the storage object will use a URL based on
*     the project ID of the base firebase.App instance.
*/
var Reference = class Reference {
	constructor(_service, location) {
		this._service = _service;
		if (location instanceof Location) this._location = location;
		else this._location = Location.makeFromUrl(location, _service.host);
	}
	/**
	* Returns the URL for the bucket and path this object references,
	*     in the form gs://<bucket>/<object-path>
	* @override
	*/
	toString() {
		return "gs://" + this._location.bucket + "/" + this._location.path;
	}
	_newRef(service, location) {
		return new Reference(service, location);
	}
	/**
	* A reference to the root of this object's bucket.
	*/
	get root() {
		const location = new Location(this._location.bucket, "");
		return this._newRef(this._service, location);
	}
	/**
	* The name of the bucket containing this reference's object.
	*/
	get bucket() {
		return this._location.bucket;
	}
	/**
	* The full path of this object.
	*/
	get fullPath() {
		return this._location.path;
	}
	/**
	* The short name of this object, which is the last component of the full path.
	* For example, if fullPath is 'full/path/image.png', name is 'image.png'.
	*/
	get name() {
		return lastComponent(this._location.path);
	}
	/**
	* The `StorageService` instance this `StorageReference` is associated with.
	*/
	get storage() {
		return this._service;
	}
	/**
	* A `StorageReference` pointing to the parent location of this `StorageReference`, or null if
	* this reference is the root.
	*/
	get parent() {
		const newPath = parent(this._location.path);
		if (newPath === null) return null;
		const location = new Location(this._location.bucket, newPath);
		return new Reference(this._service, location);
	}
	/**
	* Utility function to throw an error in methods that do not accept a root reference.
	*/
	_throwIfRoot(name) {
		if (this._location.path === "") throw invalidRootOperation(name);
	}
};
/**
* Uploads data to this object's location.
* The upload is not resumable.
*
* @param ref - StorageReference where data should be uploaded.
* @param data - The data to upload.
* @param metadata - Metadata for the newly uploaded data.
* @returns A Promise containing an UploadResult
*/
function uploadBytes$1(ref, data, metadata) {
	ref._throwIfRoot("uploadBytes");
	const requestInfo = multipartUpload(ref.storage, ref._location, getMappings(), new FbsBlob(data, true), metadata);
	return ref.storage.makeRequestWithTokens(requestInfo, newTextConnection).then((finalMetadata) => {
		return {
			metadata: finalMetadata,
			ref
		};
	});
}
/**
* Uploads a string to this object's location.
* The upload is not resumable.
* @public
* @param ref - StorageReference where string should be uploaded.
* @param value - The string to upload.
* @param format - The format of the string to upload.
* @param metadata - Metadata for the newly uploaded string.
* @returns A Promise containing an UploadResult
*/
function uploadString$1(ref, value, format = StringFormat.RAW, metadata) {
	ref._throwIfRoot("uploadString");
	const data = dataFromString(format, value);
	const metadataClone = Object.assign({}, metadata);
	if (metadataClone["contentType"] == null && data.contentType != null) metadataClone["contentType"] = data.contentType;
	return uploadBytes$1(ref, data.data, metadataClone);
}
/**
* Returns the download URL for the given Reference.
* @public
* @returns A `Promise` that resolves with the download
*     URL for this object.
*/
function getDownloadURL$1(ref) {
	ref._throwIfRoot("getDownloadURL");
	const requestInfo = getDownloadUrl(ref.storage, ref._location, getMappings());
	return ref.storage.makeRequestWithTokens(requestInfo, newTextConnection).then((url) => {
		if (url === null) throw noDownloadURL();
		return url;
	});
}
/**
* Returns reference for object obtained by appending `childPath` to `ref`.
*
* @param ref - StorageReference to get child of.
* @param childPath - Child path from provided ref.
* @returns A reference to the object obtained by
* appending childPath, removing any duplicate, beginning, or trailing
* slashes.
*
*/
function _getChild$1(ref, childPath) {
	const newPath = child(ref._location.path, childPath);
	const location = new Location(ref._location.bucket, newPath);
	return new Reference(ref.storage, location);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function isUrl(path) {
	return /^[A-Za-z]+:\/\//.test(path);
}
/**
* Returns a firebaseStorage.Reference for the given url.
*/
function refFromURL(service, url) {
	return new Reference(service, url);
}
/**
* Returns a firebaseStorage.Reference for the given path in the default
* bucket.
*/
function refFromPath(ref, path) {
	if (ref instanceof FirebaseStorageImpl) {
		const service = ref;
		if (service._bucket == null) throw noDefaultBucket();
		const reference = new Reference(service, service._bucket);
		if (path != null) return refFromPath(reference, path);
		else return reference;
	} else if (path !== void 0) return _getChild$1(ref, path);
	else return ref;
}
function ref$1(serviceOrRef, pathOrUrl) {
	if (pathOrUrl && isUrl(pathOrUrl)) {
		if (serviceOrRef instanceof FirebaseStorageImpl) return refFromURL(serviceOrRef, pathOrUrl);
		else throw invalidArgument("To use ref(service, url), the first argument must be a Storage instance.");
	} else return refFromPath(serviceOrRef, pathOrUrl);
}
function extractBucket(host, config) {
	const bucketString = config === null || config === void 0 ? void 0 : config[CONFIG_STORAGE_BUCKET_KEY];
	if (bucketString == null) return null;
	return Location.makeFromBucketSpec(bucketString, host);
}
function connectStorageEmulator$1(storage, host, port, options = {}) {
	storage.host = `${host}:${port}`;
	storage._protocol = "http";
	const { mockUserToken } = options;
	if (mockUserToken) storage._overrideAuthToken = typeof mockUserToken === "string" ? mockUserToken : createMockUserToken(mockUserToken, storage.app.options.projectId);
}
/**
* A service that provides Firebase Storage Reference instances.
* @param opt_url - gs:// url to a custom Storage Bucket
*
* @internal
*/
var FirebaseStorageImpl = class {
	constructor(app, _authProvider, _appCheckProvider, _url, _firebaseVersion) {
		this.app = app;
		this._authProvider = _authProvider;
		this._appCheckProvider = _appCheckProvider;
		this._url = _url;
		this._firebaseVersion = _firebaseVersion;
		this._bucket = null;
		/**
		* This string can be in the formats:
		* - host
		* - host:port
		*/
		this._host = DEFAULT_HOST;
		this._protocol = "https";
		this._appId = null;
		this._deleted = false;
		this._maxOperationRetryTime = DEFAULT_MAX_OPERATION_RETRY_TIME;
		this._maxUploadRetryTime = DEFAULT_MAX_UPLOAD_RETRY_TIME;
		this._requests = /* @__PURE__ */ new Set();
		if (_url != null) this._bucket = Location.makeFromBucketSpec(_url, this._host);
		else this._bucket = extractBucket(this._host, this.app.options);
	}
	/**
	* The host string for this service, in the form of `host` or
	* `host:port`.
	*/
	get host() {
		return this._host;
	}
	set host(host) {
		this._host = host;
		if (this._url != null) this._bucket = Location.makeFromBucketSpec(this._url, host);
		else this._bucket = extractBucket(host, this.app.options);
	}
	/**
	* The maximum time to retry uploads in milliseconds.
	*/
	get maxUploadRetryTime() {
		return this._maxUploadRetryTime;
	}
	set maxUploadRetryTime(time) {
		validateNumber("time", 0, Number.POSITIVE_INFINITY, time);
		this._maxUploadRetryTime = time;
	}
	/**
	* The maximum time to retry operations other than uploads or downloads in
	* milliseconds.
	*/
	get maxOperationRetryTime() {
		return this._maxOperationRetryTime;
	}
	set maxOperationRetryTime(time) {
		validateNumber("time", 0, Number.POSITIVE_INFINITY, time);
		this._maxOperationRetryTime = time;
	}
	async _getAuthToken() {
		if (this._overrideAuthToken) return this._overrideAuthToken;
		const auth = this._authProvider.getImmediate({ optional: true });
		if (auth) {
			const tokenData = await auth.getToken();
			if (tokenData !== null) return tokenData.accessToken;
		}
		return null;
	}
	async _getAppCheckToken() {
		const appCheck = this._appCheckProvider.getImmediate({ optional: true });
		if (appCheck) return (await appCheck.getToken()).token;
		return null;
	}
	/**
	* Stop running requests and prevent more from being created.
	*/
	_delete() {
		if (!this._deleted) {
			this._deleted = true;
			this._requests.forEach((request) => request.cancel());
			this._requests.clear();
		}
		return Promise.resolve();
	}
	/**
	* Returns a new firebaseStorage.Reference object referencing this StorageService
	* at the given Location.
	*/
	_makeStorageReference(loc) {
		return new Reference(this, loc);
	}
	/**
	* @param requestInfo - HTTP RequestInfo object
	* @param authToken - Firebase auth token
	*/
	_makeRequest(requestInfo, requestFactory, authToken, appCheckToken, retry = true) {
		if (!this._deleted) {
			const request = makeRequest(requestInfo, this._appId, authToken, appCheckToken, requestFactory, this._firebaseVersion, retry);
			this._requests.add(request);
			request.getPromise().then(() => this._requests.delete(request), () => this._requests.delete(request));
			return request;
		} else return new FailRequest(appDeleted());
	}
	async makeRequestWithTokens(requestInfo, requestFactory) {
		const [authToken, appCheckToken] = await Promise.all([this._getAuthToken(), this._getAppCheckToken()]);
		return this._makeRequest(requestInfo, requestFactory, authToken, appCheckToken).getPromise();
	}
};
var name = "@firebase/storage";
var version = "0.12.5";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Type constant for Firebase Storage.
*/
var STORAGE_TYPE = "storage";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Uploads a string to this object's location.
* The upload is not resumable.
* @public
* @param ref - {@link StorageReference} where string should be uploaded.
* @param value - The string to upload.
* @param format - The format of the string to upload.
* @param metadata - Metadata for the string to upload.
* @returns A Promise containing an UploadResult
*/
function uploadString(ref, value, format, metadata) {
	ref = getModularInstance(ref);
	return uploadString$1(ref, value, format, metadata);
}
/**
* Returns the download URL for the given {@link StorageReference}.
* @public
* @param ref - {@link StorageReference} to get the download URL for.
* @returns A `Promise` that resolves with the download
*     URL for this object.
*/
function getDownloadURL(ref) {
	ref = getModularInstance(ref);
	return getDownloadURL$1(ref);
}
function ref(serviceOrRef, pathOrUrl) {
	serviceOrRef = getModularInstance(serviceOrRef);
	return ref$1(serviceOrRef, pathOrUrl);
}
/**
* Gets a {@link FirebaseStorage} instance for the given Firebase app.
* @public
* @param app - Firebase app to get {@link FirebaseStorage} instance for.
* @param bucketUrl - The gs:// url to your Firebase Storage Bucket.
* If not passed, uses the app's default Storage Bucket.
* @returns A {@link FirebaseStorage} instance.
*/
function getStorage(app = getApp(), bucketUrl) {
	app = getModularInstance(app);
	const storageInstance = _getProvider(app, STORAGE_TYPE).getImmediate({ identifier: bucketUrl });
	const emulator = getDefaultEmulatorHostnameAndPort("storage");
	if (emulator) connectStorageEmulator(storageInstance, ...emulator);
	return storageInstance;
}
/**
* Modify this {@link FirebaseStorage} instance to communicate with the Cloud Storage emulator.
*
* @param storage - The {@link FirebaseStorage} instance
* @param host - The emulator host (ex: localhost)
* @param port - The emulator port (ex: 5001)
* @param options - Emulator options. `options.mockUserToken` is the mock auth
* token to use for unit testing Security Rules.
* @public
*/
function connectStorageEmulator(storage, host, port, options = {}) {
	connectStorageEmulator$1(storage, host, port, options);
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Cloud Storage for Firebase
*
* @packageDocumentation
*/
function factory(container, { instanceIdentifier: url }) {
	return new FirebaseStorageImpl(container.getProvider("app").getImmediate(), container.getProvider("auth-internal"), container.getProvider("app-check-internal"), url, SDK_VERSION);
}
function registerStorage() {
	_registerComponent(new Component(STORAGE_TYPE, factory, "PUBLIC").setMultipleInstances(true));
	registerVersion(name, version);
}
registerStorage();
//#endregion
export { uploadString as i, getStorage as n, ref as r, getDownloadURL as t };
