import { getApp, getApps, initializeApp } from "firebase/app";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  onSnapshot,
  writeBatch,
  type Firestore,
  type QuerySnapshot,
  type Unsubscribe,
} from "firebase/firestore";
import { getStorage, ref, uploadString, getDownloadURL, type FirebaseStorage } from "firebase/storage";
import { checkAuth, loginWithPassword, logoutSession } from "./auth";
import { defaultOffice, firebaseConfig } from "./defaults";
import { t } from "./i18n";
import { idbDelete, idbGetAll, idbSet } from "./idb";
import {
  cancelIdle,
  cloudPayload,
  idle,
  newId,
  normalizeMaterial,
  parseQty,
  sanitizeDocId,
} from "./helpers";
import { useWarehouse } from "./state";
import type { HistoryEntry, Lang, Material, OpType, SyncStatus, TabId } from "./types";
import { loadSheetJS } from "./xlsx";

let inventory: Record<string, Material> = {};
let history: HistoryEntry[] = [];
let borrowHistory: HistoryEntry[] = [];
let syncedMaterialSnapshots: Record<string, string> = {};
let syncedHistoryIds = new Set<string>();
let syncedBorrowIds = new Set<string>();
let isSyncing = false;
let cloudEnabled = false;
let db: Firestore | null = null;
let storage: FirebaseStorage | null = null;
let unsubs: Unsubscribe[] = [];
let pending: {
  materials: QuerySnapshot | null;
  history: QuerySnapshot | null;
  borrow: QuerySnapshot | null;
} = { materials: null, history: null, borrow: null };
let idleHandle: number | null = null;
let seeded = false;

function lang(): Lang {
  return useWarehouse.getState().lang;
}

function admin(): boolean {
  return useWarehouse.getState().isAdmin;
}

export function showToast(
  message: string,
  type: "success" | "error" | "warning" | "info" = "info",
  duration = 4000,
) {
  const id = newId();
  const toasts = [...useWarehouse.getState().toasts, { id, message, type }];
  useWarehouse.setState({ toasts });
  window.setTimeout(() => {
    useWarehouse.setState({
      toasts: useWarehouse.getState().toasts.filter((x) => x.id !== id),
    });
  }, duration);
}

export function dismissToast(id: string) {
  useWarehouse.setState({
    toasts: useWarehouse.getState().toasts.filter((x) => x.id !== id),
  });
}

function updateSyncStatus(status: SyncStatus) {
  useWarehouse.setState({ syncStatus: status });
}

function pushData() {
  useWarehouse.setState({
    inventory: { ...inventory },
    history: history.slice(),
    borrowHistory: borrowHistory.slice(),
  });
}

function saveToStorage() {
  const slim: Record<string, Omit<Material, "img">> = {};
  for (const [key, item] of Object.entries(inventory)) {
    const { img: _ignored, ...rest } = item;
    void _ignored;
    slim[key] = rest;
  }
  try {
    localStorage.setItem("inventory", JSON.stringify(slim));
    localStorage.setItem("history", JSON.stringify(history));
    localStorage.setItem("borrowHistory", JSON.stringify(borrowHistory));
  } catch {
    showToast(t(lang(), "quotaError"), "warning");
  }
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function loadFromStorage() {
  const saved = readJson<Record<string, Partial<Material>> | null>("inventory", null);
  if (saved && typeof saved === "object") {
    const next: Record<string, Material> = {};
    for (const [key, value] of Object.entries(saved)) {
      next[key] = normalizeMaterial(value, key);
    }
    inventory = next;
  } else {
    inventory = structuredClone(defaultOffice);
  }
  history = normalizeEntries(readJson<HistoryEntry[]>("history", []));
  borrowHistory = normalizeEntries(readJson<HistoryEntry[]>("borrowHistory", []));
}

function normalizeEntries(list: unknown): HistoryEntry[] {
  if (!Array.isArray(list)) return [];
  return list.map((raw) => {
    const e = raw as Partial<HistoryEntry> & { id?: string | number };
    const id = String(e.id ?? newId());
    const ts = typeof e.ts === "number" ? e.ts : Number(e.id) || Date.now();
    const type = (e.type as OpType) || "out";
    return {
      id,
      ts,
      material: String(e.material || ""),
      qty: Number(e.qty) || 0,
      employee: String(e.employee || ""),
      date: String(e.date || ""),
      type,
      section: "office",
      note: e.note ? String(e.note) : undefined,
    };
  });
}

async function hydrateImages() {
  try {
    const images = await idbGetAll();
    for (const key of Object.keys(inventory)) {
      if (images[key]) inventory[key].img = images[key];
      else if (inventory[key].imgUrl) inventory[key].img = inventory[key].imgUrl;
    }
  } catch (err) {
    console.warn("idb hydrate", err);
  }
}

async function persistImage(key: string, dataUrl: string) {
  inventory[key].img = dataUrl;
  try {
    await idbSet(key, dataUrl);
  } catch (err) {
    console.warn("idb set", err);
  }
  const url = await uploadImage(key, dataUrl);
  if (url) inventory[key].imgUrl = url;
}

async function uploadImage(key: string, dataUrl: string): Promise<string> {
  if (!storage) return "";
  try {
    const r = ref(storage, `wh_images/${sanitizeDocId(key)}.jpg`);
    await uploadString(r, dataUrl, "data_url");
    return await getDownloadURL(r);
  } catch (err) {
    console.warn("storage upload skipped", err);
    return "";
  }
}

async function syncToCloud() {
  if (!cloudEnabled || !db) return;
  updateSyncStatus("syncing");
  const ops: Array<
    | { type: "set"; ref: ReturnType<typeof doc>; data: Record<string, unknown> }
    | { type: "delete"; ref: ReturnType<typeof doc> }
  > = [];

  const currentKeys = new Set(Object.keys(inventory));
  for (const key of Object.keys(syncedMaterialSnapshots)) {
    if (!currentKeys.has(key)) {
      ops.push({ type: "delete", ref: doc(db, "wh_materials", sanitizeDocId(key)) });
    }
  }
  for (const key of currentKeys) {
    const json = JSON.stringify(cloudPayload(key, inventory[key]));
    if (syncedMaterialSnapshots[key] !== json) {
      ops.push({
        type: "set",
        ref: doc(db, "wh_materials", sanitizeDocId(key)),
        data: cloudPayload(key, inventory[key]),
      });
    }
  }

  const currentHistoryIds = new Set(history.map((h) => String(h.id)));
  for (const id of syncedHistoryIds) {
    if (!currentHistoryIds.has(id)) ops.push({ type: "delete", ref: doc(db, "wh_history", id) });
  }
  for (const entry of history) {
    const idStr = String(entry.id);
    if (!syncedHistoryIds.has(idStr)) {
      ops.push({ type: "set", ref: doc(db, "wh_history", idStr), data: { ...entry } });
    }
  }

  const currentBorrowIds = new Set(borrowHistory.map((h) => String(h.id)));
  for (const id of syncedBorrowIds) {
    if (!currentBorrowIds.has(id)) ops.push({ type: "delete", ref: doc(db, "wh_borrowHistory", id) });
  }
  for (const entry of borrowHistory) {
    const idStr = String(entry.id);
    if (!syncedBorrowIds.has(idStr)) {
      ops.push({ type: "set", ref: doc(db, "wh_borrowHistory", idStr), data: { ...entry } });
    }
  }

  try {
    for (let i = 0; i < ops.length; i += 450) {
      const chunk = ops.slice(i, i + 450);
      const batch = writeBatch(db);
      for (const op of chunk) {
        if (op.type === "set") batch.set(op.ref, op.data);
        else batch.delete(op.ref);
      }
      await batch.commit();
    }
    syncedMaterialSnapshots = {};
    for (const key of currentKeys) {
      syncedMaterialSnapshots[key] = JSON.stringify(cloudPayload(key, inventory[key]));
    }
    syncedHistoryIds = currentHistoryIds;
    syncedBorrowIds = currentBorrowIds;
    updateSyncStatus("online");
  } catch (err) {
    console.error("Sync error:", err);
    updateSyncStatus("error");
    throw err;
  }
}

function mergeMaterialsSnapshot(snap: QuerySnapshot) {
  const next: Record<string, Material> = {};
  snap.forEach((d) => {
    const data = d.data() as Record<string, unknown>;
    const key = String(data.key || d.id);
    const mat = normalizeMaterial(data, key);
    const prev = inventory[key];
    if (typeof data.img === "string" && data.img.startsWith("data:")) {
      mat.img = data.img;
      void idbSet(key, data.img);
    } else if (prev?.img) {
      mat.img = prev.img;
    } else if (mat.imgUrl) {
      mat.img = mat.imgUrl;
    }
    next[key] = mat;
  });
  inventory = next;
  syncedMaterialSnapshots = {};
  for (const key of Object.keys(inventory)) {
    syncedMaterialSnapshots[key] = JSON.stringify(cloudPayload(key, inventory[key]));
  }
}

function mergeHistorySnapshot(snap: QuerySnapshot) {
  const list: HistoryEntry[] = [];
  snap.forEach((d) => list.push(normalizeEntries([d.data()])[0]!));
  list.sort((a, b) => a.ts - b.ts);
  history = list;
  syncedHistoryIds = new Set(list.map((h) => String(h.id)));
}

function mergeBorrowSnapshot(snap: QuerySnapshot) {
  const list: HistoryEntry[] = [];
  snap.forEach((d) => list.push(normalizeEntries([d.data()])[0]!));
  list.sort((a, b) => a.ts - b.ts);
  borrowHistory = list;
  syncedBorrowIds = new Set(list.map((h) => String(h.id)));
}

function scheduleCloudApply() {
  if (idleHandle != null) return;
  idleHandle = idle(() => {
    idleHandle = null;
    if (isSyncing) {
      scheduleCloudApply();
      return;
    }
    let changed = false;
    if (pending.materials) {
      mergeMaterialsSnapshot(pending.materials);
      pending.materials = null;
      changed = true;
    }
    if (pending.history) {
      mergeHistorySnapshot(pending.history);
      pending.history = null;
      changed = true;
    }
    if (pending.borrow) {
      mergeBorrowSnapshot(pending.borrow);
      pending.borrow = null;
      changed = true;
    }
    if (!changed) return;
    saveToStorage();
    pushData();
    updateSyncStatus("online");
  });
}

async function migrateOldDataIfNeeded() {
  if (!db) return false;
  try {
    const matSnap = await getDocs(collection(db, "wh_materials"));
    if (!matSnap.empty) return false;
    const oldSnap = await getDoc(doc(db, "warehouse", "data"));
    if (!oldSnap.exists()) return false;
    const oldData = oldSnap.data() as {
      inventory?: Record<string, Partial<Material>>;
      history?: HistoryEntry[];
      borrowHistory?: HistoryEntry[];
    };
    const oldInventory = oldData.inventory || {};
    const oldHistory = normalizeEntries(oldData.history || []);
    const oldBorrow = normalizeEntries(oldData.borrowHistory || []);
    if (Object.keys(oldInventory).length === 0 && oldHistory.length === 0 && oldBorrow.length === 0) {
      return false;
    }
    const ops: Array<{ ref: ReturnType<typeof doc>; data: Record<string, unknown> }> = [];
    for (const key of Object.keys(oldInventory)) {
      const mat = normalizeMaterial(oldInventory[key]!, key);
      const rawImg = oldInventory[key]?.img;
      if (typeof rawImg === "string" && rawImg.startsWith("data:")) {
        await persistImage(key, rawImg);
      }
      ops.push({ ref: doc(db, "wh_materials", sanitizeDocId(key)), data: cloudPayload(key, mat) });
    }
    for (const entry of oldHistory) {
      ops.push({ ref: doc(db, "wh_history", String(entry.id)), data: { ...entry } });
    }
    for (const entry of oldBorrow) {
      ops.push({ ref: doc(db, "wh_borrowHistory", String(entry.id)), data: { ...entry } });
    }
    for (let i = 0; i < ops.length; i += 450) {
      const chunk = ops.slice(i, i + 450);
      const batch = writeBatch(db);
      for (const op of chunk) batch.set(op.ref, op.data);
      await batch.commit();
    }
    return true;
  } catch (err) {
    console.error("Migration error:", err);
    return false;
  }
}

function attachListeners() {
  if (!db) return;
  unsubs.forEach((u) => u());
  unsubs = [];
  unsubs.push(
    onSnapshot(
      collection(db, "wh_materials"),
      (snap) => {
        if (isSyncing) return;
        if (snap.metadata.hasPendingWrites) return;
        if (!seeded && snap.empty) {
          void seedIfEmpty();
          return;
        }
        pending.materials = snap;
        scheduleCloudApply();
      },
      (err) => {
        console.error("Materials snapshot error:", err);
        updateSyncStatus("offline");
      },
    ),
  );
  unsubs.push(
    onSnapshot(
      collection(db, "wh_history"),
      (snap) => {
        if (isSyncing) return;
        if (snap.metadata.hasPendingWrites) return;
        pending.history = snap;
        scheduleCloudApply();
      },
      (err) => console.error("History snapshot error:", err),
    ),
  );
  unsubs.push(
    onSnapshot(
      collection(db, "wh_borrowHistory"),
      (snap) => {
        if (isSyncing) return;
        if (snap.metadata.hasPendingWrites) return;
        pending.borrow = snap;
        scheduleCloudApply();
      },
      (err) => console.error("BorrowHistory snapshot error:", err),
    ),
  );
}

async function seedIfEmpty() {
  if (seeded) return;
  seeded = true;
  if (Object.keys(inventory).length === 0) inventory = structuredClone(defaultOffice);
  saveToStorage();
  pushData();
  try {
    await syncToCloud();
  } catch {
    /* local only */
  }
}

export async function initWarehouse() {
  if (typeof window === "undefined") return;
  const isAdmin = checkAuth();
  useWarehouse.setState({ isAdmin, ready: false, syncStatus: "syncing" });
  loadFromStorage();
  await hydrateImages();
  pushData();

  try {
    if (firebaseConfig.apiKey && firebaseConfig.apiKey.length > 10) {
      const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
      db = getFirestore(app);
      try {
        storage = getStorage(app);
      } catch {
        storage = null;
      }
      cloudEnabled = true;
    }
  } catch (err) {
    console.warn("Firebase init failed:", err);
    cloudEnabled = false;
  }

  if (cloudEnabled && db) {
    try {
      await migrateOldDataIfNeeded();
      attachListeners();
    } catch (err) {
      console.error("Load from Firebase error:", err);
      updateSyncStatus("offline");
    }
  } else {
    updateSyncStatus("offline");
  }

  useWarehouse.setState({ ready: true });
  if (!isAdmin) showToast(t(lang(), "guestHint"), "info", 5000);
}

export async function login(password: string) {
  const ok = await loginWithPassword(password);
  if (ok) {
    useWarehouse.setState({ isAdmin: true });
    showToast(t(lang(), "loginOk"), "success");
    return true;
  }
  showToast(t(lang(), "loginError"), "error");
  return false;
}

export function logout() {
  logoutSession();
  useWarehouse.setState({ isAdmin: false, tab: "dashboard", editingKey: null });
  showToast(t(lang(), "logoutOk"), "info");
}

export function setLang(next: Lang) {
  useWarehouse.setState({ lang: next });
  document.documentElement.lang = next === "ar" ? "ar" : next;
  document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
}

export function setTab(tab: TabId) {
  useWarehouse.setState({ tab });
}

export function setSearch(search: string) {
  useWarehouse.setState({ search });
}

export function setType(type: "in" | "out") {
  if (!admin()) return;
  useWarehouse.setState({ currentType: type });
}

export function setBorrowType(type: "borrow" | "return") {
  if (!admin()) return;
  useWarehouse.setState({ currentBorrowType: type });
}

export function loadMoreHistory() {
  useWarehouse.setState({ historyLimit: useWarehouse.getState().historyLimit + 50 });
}

export function loadMoreBorrow() {
  useWarehouse.setState({ borrowLimit: useWarehouse.getState().borrowLimit + 50 });
}

export function openEdit(key: string) {
  if (!admin()) return;
  useWarehouse.setState({ editingKey: key });
}

export function closeEdit() {
  useWarehouse.setState({ editingKey: null });
}

async function withSync<T>(fn: () => Promise<T> | T): Promise<T | undefined> {
  if (isSyncing || useWarehouse.getState().submitting) {
    showToast(t(lang(), "busy"), "warning");
    return undefined;
  }
  isSyncing = true;
  useWarehouse.setState({ submitting: true });
  updateSyncStatus("syncing");
  try {
    const result = await fn();
    saveToStorage();
    pushData();
    try {
      await syncToCloud();
    } catch {
      /* local kept */
    }
    return result;
  } finally {
    isSyncing = false;
    useWarehouse.setState({ submitting: false });
    if (cloudEnabled) updateSyncStatus("online");
  }
}

export async function submitRegister(input: {
  material: string;
  quantity: string;
  employee: string;
  date: string;
}) {
  if (!admin()) {
    showToast(t(lang(), "adminOnly"), "error");
    return false;
  }
  const quantity = parseQty(input.quantity);
  const employee = input.employee.trim();
  if (!quantity || !employee || !input.material) {
    showToast(!quantity ? t(lang(), "qtyInvalid") : t(lang(), "fillFields"), "error");
    return false;
  }
  const item = inventory[input.material];
  if (!item) {
    showToast(t(lang(), "materialMissing"), "error");
    return false;
  }
  const type = useWarehouse.getState().currentType;
  if (type === "out" && item.qty < quantity) {
    showToast(`${t(lang(), "notEnough")} ${item.qty}`, "error");
    return false;
  }
  await withSync(() => {
    if (type === "out") item.qty -= quantity;
    else item.qty += quantity;
    history.push({
      id: newId(),
      ts: Date.now(),
      material: input.material,
      qty: type === "out" ? -quantity : quantity,
      employee,
      date: input.date || "",
      type,
      section: "office",
    });
  });
  showToast(`${t(lang(), type === "out" ? "typeOut" : "typeIn")} — OK`, "success");
  return true;
}

export async function submitBorrow(input: {
  material: string;
  quantity: string;
  employee: string;
  date: string;
  note: string;
}) {
  if (!admin()) {
    showToast(t(lang(), "adminOnly"), "error");
    return false;
  }
  const quantity = parseQty(input.quantity);
  const employee = input.employee.trim();
  if (!quantity || !employee || !input.material) {
    showToast(!quantity ? t(lang(), "qtyInvalid") : t(lang(), "fillFields"), "error");
    return false;
  }
  const item = inventory[input.material];
  if (!item) {
    showToast(t(lang(), "materialMissing"), "error");
    return false;
  }
  const type = useWarehouse.getState().currentBorrowType;
  if (type === "borrow" && item.qty < quantity) {
    showToast(`${t(lang(), "notEnough")} ${item.qty}`, "error");
    return false;
  }
  if (type === "return" && (item.borrowed || 0) < quantity) {
    showToast(`${t(lang(), "notEnoughBorrowed")} ${item.borrowed || 0}`, "error");
    return false;
  }
  await withSync(() => {
    if (type === "borrow") {
      item.qty -= quantity;
      item.borrowed = (item.borrowed || 0) + quantity;
    } else {
      item.qty += quantity;
      item.borrowed = Math.max(0, (item.borrowed || 0) - quantity);
    }
    const entry: HistoryEntry = {
      id: newId(),
      ts: Date.now(),
      material: input.material,
      qty: quantity,
      employee,
      date: input.date || "",
      type,
      section: "office",
      note: input.note.trim() || (type === "borrow" ? t(lang(), "typeBorrow") : t(lang(), "typeReturn")),
    };
    borrowHistory.push(entry);
    history.push(entry);
  });
  showToast(t(lang(), type === "borrow" ? "borrowSuccess" : "returnSuccess"), "success");
  return true;
}

function isDuplicateName(name: string, excludeKey: string | null = null) {
  const lower = name.toLowerCase();
  return Object.keys(inventory).some((k) => k !== excludeKey && k.toLowerCase() === lower);
}

export async function addMaterial(input: {
  ar: string;
  fr: string;
  en: string;
  unit: string;
  minQty: string;
  img: string;
}) {
  if (!admin()) {
    showToast(t(lang(), "adminOnly"), "error");
    return false;
  }
  const ar = input.ar.trim();
  const fr = input.fr.trim();
  const en = input.en.trim();
  if (!ar && !fr && !en) {
    showToast(t(lang(), "enterName"), "error");
    return false;
  }
  const key = ar || fr || en;
  if (isDuplicateName(key)) {
    showToast(`${t(lang(), "duplicateName")}: ${key}`, "error");
    return false;
  }
  const minQty = Number.parseInt(input.minQty, 10);
  await withSync(async () => {
    inventory[key] = {
      qty: 0,
      unit: input.unit.trim() || "قطعة",
      borrowed: 0,
      section: "office",
      ar: ar || key,
      fr: fr || key,
      en: en || key,
      img: "",
      imgUrl: "",
      minQty: minQty > 0 ? minQty : 10,
    };
    if (input.img) await persistImage(key, input.img);
  });
  showToast(`${t(lang(), "addedOk")}: ${key}`, "success");
  return true;
}

export async function saveEdit(input: {
  key: string;
  ar: string;
  fr: string;
  en: string;
  unit: string;
  minQty: string;
  img?: string;
}) {
  if (!admin()) return false;
  const item = inventory[input.key];
  if (!item) {
    showToast(t(lang(), "materialMissing"), "error");
    return false;
  }
  const minQty = Number.parseInt(input.minQty, 10);
  await withSync(async () => {
    item.ar = input.ar.trim() || input.key;
    item.fr = input.fr.trim() || input.key;
    item.en = input.en.trim() || input.key;
    item.unit = input.unit.trim() || item.unit;
    if (minQty > 0) item.minQty = minQty;
    if (input.img) await persistImage(input.key, input.img);
  });
  useWarehouse.setState({ editingKey: null });
  showToast(t(lang(), "savedOk"), "success");
  return true;
}

export async function deleteMaterial(key: string) {
  if (!admin()) {
    showToast(t(lang(), "adminOnly"), "error");
    return false;
  }
  if (!inventory[key]) {
    showToast(t(lang(), "materialMissing"), "error");
    return false;
  }
  if (!window.confirm(`${t(lang(), "confirmDelete")}\n${key}`)) return false;
  await withSync(async () => {
    delete inventory[key];
    history = history.filter((h) => h.material !== key);
    borrowHistory = borrowHistory.filter((h) => h.material !== key);
    try {
      await idbDelete(key);
    } catch {
      /* ignore */
    }
  });
  showToast(`${t(lang(), "deletedOk")}: ${key}`, "success");
  return true;
}

export function exportJson() {
  const data = {
    inventory: Object.fromEntries(
      Object.entries(inventory).map(([k, v]) => {
        const { img: _ignored, ...rest } = v;
        void _ignored;
        return [k, rest];
      }),
    ),
    history,
    borrowHistory,
    exportedAt: new Date().toISOString(),
    version: "2.0",
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `warehouse-backup-${new Date().toISOString().split("T")[0]}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  showToast(t(lang(), "exportOk"), "success");
}

export async function importJsonFile(file: File) {
  if (!admin()) {
    showToast(t(lang(), "adminOnly"), "error");
    return;
  }
  if (!window.confirm(t(lang(), "confirmImport"))) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text) as {
      inventory?: Record<string, Partial<Material>>;
      history?: HistoryEntry[];
      borrowHistory?: HistoryEntry[];
    };
    await withSync(() => {
      if (data.inventory) {
        const next: Record<string, Material> = {};
        for (const [key, value] of Object.entries(data.inventory)) {
          const mat = normalizeMaterial(value, key);
          const prev = inventory[key];
          if (prev?.img) mat.img = prev.img;
          next[key] = mat;
        }
        inventory = next;
      }
      if (data.history) history = normalizeEntries(data.history);
      if (data.borrowHistory) borrowHistory = normalizeEntries(data.borrowHistory);
    });
    showToast(t(lang(), "importOk"), "success");
  } catch (err) {
    showToast(`${t(lang(), "jsonError")}: ${(err as Error).message}`, "error");
  }
}

export async function exportExcel() {
  try {
    showToast(t(lang(), "syncSyncing"), "info", 1600);
    const XLSX = await loadSheetJS();
    const rows = Object.keys(inventory).map((key) => {
      const it = inventory[key];
      return {
        "المفتاح/Key": key,
        بالعربية: it.ar || "",
        بالفرنسية: it.fr || "",
        بالإنجليزية: it.en || "",
        الوحدة: it.unit || "",
        الكمية: it.qty || 0,
        المستعار: it.borrowed || 0,
        "الحد الأدنى": it.minQty || 10,
      };
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "المواد");
    XLSX.writeFile(wb, `warehouse-materials-${new Date().toISOString().split("T")[0]}.xlsx`);
    showToast(t(lang(), "excelExportOk"), "success");
  } catch (err) {
    showToast(`${t(lang(), "excelError")}: ${(err as Error).message}`, "error");
  }
}

export async function importExcelFile(file: File) {
  if (!admin()) {
    showToast(t(lang(), "adminOnly"), "error");
    return;
  }
  if (!window.confirm(t(lang(), "confirmExcel"))) return;
  try {
    const XLSX = await loadSheetJS();
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const sheet = wb.Sheets[wb.SheetNames[0] ?? ""];
    if (!sheet) {
      showToast(t(lang(), "emptyFile"), "error");
      return;
    }
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
    if (!rows.length) {
      showToast(t(lang(), "emptyFile"), "error");
      return;
    }
    let added = 0;
    let updated = 0;
    await withSync(() => {
      for (const row of rows) {
        const ar = String(row["بالعربية"] ?? row.ar ?? "").trim();
        const fr = String(row["بالفرنسية"] ?? row.fr ?? "").trim();
        const en = String(row["بالإنجليزية"] ?? row.en ?? "").trim();
        const unit = String(row["الوحدة"] ?? row.unit ?? "قطعة").trim() || "قطعة";
        const qtyRaw = Number(row["الكمية"] ?? row.qty ?? 0);
        const qty = Number.isFinite(qtyRaw) ? qtyRaw : 0;
        const borrowedRaw = Number(row["المستعار"] ?? row.borrowed ?? 0);
        const borrowed = Number.isFinite(borrowedRaw) ? borrowedRaw : 0;
        const minRaw = Number(row["الحد الأدنى"] ?? row.minQty ?? 10);
        const minQty = minRaw > 0 ? minRaw : 10;
        const explicitKey = String(row["المفتاح/Key"] ?? row.key ?? "").trim();
        const key = explicitKey || ar || fr || en;
        if (!key) continue;
        if (inventory[key]) {
          inventory[key].qty = qty;
          inventory[key].borrowed = borrowed;
          inventory[key].unit = unit;
          inventory[key].minQty = minQty;
          if (ar) inventory[key].ar = ar;
          if (fr) inventory[key].fr = fr;
          if (en) inventory[key].en = en;
          updated += 1;
        } else {
          inventory[key] = {
            qty,
            unit,
            borrowed,
            section: "office",
            ar: ar || key,
            fr: fr || key,
            en: en || key,
            img: "",
            imgUrl: "",
            minQty,
          };
          added += 1;
        }
      }
    });
    showToast(`${t(lang(), "importOk")}: +${added} / ~${updated}`, "success");
  } catch (err) {
    showToast(`${t(lang(), "excelError")}: ${(err as Error).message}`, "error");
  }
}

export function destroyWarehouse() {
  unsubs.forEach((u) => u());
  unsubs = [];
  if (idleHandle != null) cancelIdle(idleHandle);
  idleHandle = null;
}
