import type { HistoryEntry, Lang, Material, OpType } from "./types";
import { t } from "./i18n";

export function newId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function parseQty(raw: string): number | null {
  const trimmed = String(raw).trim();
  if (!trimmed || !/^[0-9]+$/.test(trimmed)) return null;
  const n = Number(trimmed);
  if (!Number.isInteger(n) || n < 1 || n > 1_000_000) return null;
  return n;
}

export function sanitizeDocId(str: string) {
  const s = String(str).trim().replace(/[/.#$[\]]/g, "_").slice(0, 300);
  return s || `m_${Date.now()}`;
}

export function matchesSearch(key: string, item: Material, query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  const blob = `${item.ar || ""} ${item.fr || ""} ${item.en || ""} ${key}`.toLowerCase();
  return blob.includes(q);
}

export function getName(item: Material, key: string, lang: Lang) {
  if (lang === "ar" && item.ar) return item.ar;
  if (lang === "en" && item.en) return item.en;
  if (lang === "fr" && item.fr) return item.fr;
  return item.ar || item.fr || item.en || key;
}

export function stockLevel(qty: number, minQty: number): "missing" | "low" | "med" | "ok" {
  const min = minQty > 0 ? minQty : 10;
  if (qty <= 0) return "missing";
  if (qty < min) return "low";
  if (qty < min * 5) return "med";
  return "ok";
}

export function stockColor(qty: number, minQty: number) {
  const level = stockLevel(qty, minQty);
  if (level === "missing") return "var(--color-bad)";
  if (level === "low") return "var(--color-warn)";
  if (level === "med") return "var(--color-mid)";
  return "var(--color-ok)";
}

export function stockLabel(qty: number, minQty: number, lang: Lang) {
  const level = stockLevel(qty, minQty);
  if (level === "missing") return t(lang, "statusMissing");
  if (level === "low") return t(lang, "statusLow");
  if (level === "med") return t(lang, "statusMed");
  return t(lang, "statusOK");
}

export function typeLabel(type: OpType, lang: Lang) {
  if (type === "in") return t(lang, "typeIn");
  if (type === "borrow") return t(lang, "typeBorrow");
  if (type === "return") return t(lang, "typeReturn");
  return t(lang, "typeOut");
}

export function entryTs(entry: HistoryEntry) {
  if (typeof entry.ts === "number" && Number.isFinite(entry.ts)) return entry.ts;
  const n = Number(entry.id);
  return Number.isFinite(n) ? n : 0;
}

export function todayISO() {
  return new Date().toISOString().split("T")[0] ?? "";
}

export function normalizeMaterial(data: Partial<Material> | Record<string, unknown>, key: string): Material {
  const d = data as Record<string, unknown>;
  const minRaw = Number(d.minQty);
  return {
    qty: Number(d.qty) || 0,
    unit: String(d.unit || "قطعة"),
    borrowed: Number(d.borrowed) || 0,
    section: "office",
    ar: String(d.ar || key),
    fr: String(d.fr || key),
    en: String(d.en || key),
    img: "",
    imgUrl: typeof d.imgUrl === "string" ? d.imgUrl : "",
    minQty: minRaw > 0 ? minRaw : 10,
  };
}

export function cloudPayload(key: string, item: Material) {
  return {
    key,
    qty: item.qty,
    unit: item.unit,
    borrowed: item.borrowed || 0,
    section: "office" as const,
    ar: item.ar,
    fr: item.fr,
    en: item.en,
    minQty: item.minQty > 0 ? item.minQty : 10,
    imgUrl: item.imgUrl || "",
  };
}

export function idle(cb: () => void, timeout = 400) {
  const ric = window.requestIdleCallback;
  if (typeof ric === "function") return ric(cb, { timeout }) as unknown as number;
  return window.setTimeout(cb, 200);
}

export function cancelIdle(handle: number) {
  const cic = window.cancelIdleCallback;
  if (typeof cic === "function") cic(handle);
  else window.clearTimeout(handle);
}
