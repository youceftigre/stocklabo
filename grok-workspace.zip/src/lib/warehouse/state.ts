import { create } from "zustand";
import type { HistoryEntry, Lang, Material, OpType, SyncStatus, TabId, Toast } from "./types";

export type WarehouseState = {
  ready: boolean;
  lang: Lang;
  isAdmin: boolean;
  inventory: Record<string, Material>;
  history: HistoryEntry[];
  borrowHistory: HistoryEntry[];
  syncStatus: SyncStatus;
  search: string;
  tab: TabId;
  historyLimit: number;
  borrowLimit: number;
  toasts: Toast[];
  submitting: boolean;
  currentType: Extract<OpType, "in" | "out">;
  currentBorrowType: Extract<OpType, "borrow" | "return">;
  editingKey: string | null;
};

export const useWarehouse = create<WarehouseState>(() => ({
  ready: false,
  lang: "ar",
  isAdmin: false,
  inventory: {},
  history: [],
  borrowHistory: [],
  syncStatus: "syncing",
  search: "",
  tab: "dashboard",
  historyLimit: 50,
  borrowLimit: 50,
  toasts: [],
  submitting: false,
  currentType: "out",
  currentBorrowType: "borrow",
  editingKey: null,
}));
