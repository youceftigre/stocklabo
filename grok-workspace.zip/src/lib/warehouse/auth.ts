/** Client-side gate — kept byte-for-byte compatible with the original app. */

export const ADMIN_PASSWORD_HASH =
  "d93e1653433b2a3a23c4ebcdded3a4fb566c6625cacdc4be468988df54b4f35a";

export async function sha256Hex(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function checkAuth() {
  return sessionStorage.getItem("warehouse_admin") === "true";
}

export async function loginWithPassword(value: string) {
  const hash = await sha256Hex(value);
  if (hash === ADMIN_PASSWORD_HASH) {
    sessionStorage.setItem("warehouse_admin", "true");
    return true;
  }
  return false;
}

export function logoutSession() {
  sessionStorage.removeItem("warehouse_admin");
}
