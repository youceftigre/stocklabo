export type Lang = "ar" | "fr" | "en";
export type TabId = "dashboard" | "register" | "inventory" | "borrow" | "history" | "manage";
export type OpType = "in" | "out" | "borrow" | "return";
export type SyncStatus = "syncing" | "online" | "offline" | "error";
export type ToastType = "success" | "error" | "warning" | "info";

export type Material = {
  qty: number;
  unit: string;
  borrowed: number;
  section: "office";
  ar: string;
  fr: string;
  en: string;
  img: string;
  imgUrl: string;
  minQty: number;
};

export type HistoryEntry = {
  id: string;
  ts: number;
  material: string;
  qty: number;
  employee: string;
  date: string;
  type: OpType;
  section: "office";
  note?: string;
};

export type Toast = {
  id: string;
  message: string;
  type: ToastType;
};
