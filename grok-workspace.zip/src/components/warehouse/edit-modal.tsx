"use client";

import { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Camera, ImagePlus, X } from "lucide-react";
import { closeEdit, saveEdit, showToast } from "@/lib/warehouse/engine";
import { compressImage } from "@/lib/warehouse/images";
import { t } from "@/lib/warehouse/i18n";
import { useWarehouse } from "@/lib/warehouse/state";

export function EditModal() {
  const lang = useWarehouse((s) => s.lang);
  const editingKey = useWarehouse((s) => s.editingKey);
  const inventory = useWarehouse((s) => s.inventory);
  const submitting = useWarehouse((s) => s.submitting);
  const item = editingKey ? inventory[editingKey] : null;

  const [ar, setAr] = useState("");
  const [fr, setFr] = useState("");
  const [en, setEn] = useState("");
  const [unit, setUnit] = useState("");
  const [minQty, setMinQty] = useState("10");
  const [img, setImg] = useState("");

  useEffect(() => {
    if (!item || !editingKey) return;
    setAr(item.ar || editingKey);
    setFr(item.fr || editingKey);
    setEn(item.en || editingKey);
    setUnit(item.unit || "");
    setMinQty(String(item.minQty || 10));
    setImg(item.img || "");
  }, [editingKey, item]);

  async function onPick(file: File | undefined) {
    if (!file) return;
    try {
      setImg(await compressImage(file));
    } catch (err) {
      showToast(String((err as Error).message), "error");
    }
  }

  return (
    <Dialog.Root open={Boolean(editingKey && item)} onOpenChange={(open) => !open && closeEdit()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-black/50" />
        <Dialog.Content className="fixed top-1/2 left-1/2 z-50 max-h-[80vh] w-[min(500px,92vw)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-lg bg-card p-5 shadow-2xl">
          <div className="mb-3 flex items-center justify-between">
            <Dialog.Title className="text-lg font-bold text-navy">{t(lang, "editTitle")}</Dialog.Title>
            <Dialog.Description className="sr-only">{t(lang, "editTitle")}</Dialog.Description>
            <Dialog.Close className="text-muted hover:text-ink">
              <X className="size-5" />
            </Dialog.Close>
          </div>
          {editingKey && item ? (
            <div className="grid gap-3">
              <div className="field">
                <label>{t(lang, "nameAr")}</label>
                <input value={ar} onChange={(e) => setAr(e.target.value)} />
              </div>
              <div className="field">
                <label>{t(lang, "nameFr")}</label>
                <input value={fr} onChange={(e) => setFr(e.target.value)} />
              </div>
              <div className="field">
                <label>{t(lang, "nameEn")}</label>
                <input value={en} onChange={(e) => setEn(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="field">
                  <label>{t(lang, "unit")}</label>
                  <input value={unit} onChange={(e) => setUnit(e.target.value)} />
                </div>
                <div className="field">
                  <label>{t(lang, "minQty")}</label>
                  <input type="number" min={1} value={minQty} onChange={(e) => setMinQty(e.target.value)} />
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                {img ? <img src={img} alt="" className="size-16 rounded-md border border-line object-cover" /> : null}
                <label className="chip !bg-navy !text-paper">
                  <ImagePlus className="size-3.5" /> {t(lang, "changeImg")}
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => void onPick(e.target.files?.[0])} />
                </label>
                <label className="chip !bg-navy-deep !text-paper">
                  <Camera className="size-3.5" /> {t(lang, "captureImg")}
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    onChange={(e) => void onPick(e.target.files?.[0])}
                  />
                </label>
              </div>
              <button
                type="button"
                className="primary-btn"
                disabled={submitting}
                onClick={() =>
                  void saveEdit({
                    key: editingKey,
                    ar,
                    fr,
                    en,
                    unit,
                    minQty,
                    img: img && img !== item.img ? img : undefined,
                  })
                }
              >
                {t(lang, "btnSave")}
              </button>
            </div>
          ) : null}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
