"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Camera, FileSpreadsheet, ImagePlus, Pencil, Plus, Trash2 } from "lucide-react";
import {
  addMaterial,
  deleteMaterial,
  exportExcel,
  importExcelFile,
  loadMoreBorrow,
  loadMoreHistory,
  openEdit,
  setBorrowType,
  setType,
  showToast,
  submitBorrow,
  submitRegister,
} from "@/lib/warehouse/engine";
import { compressImage } from "@/lib/warehouse/images";
import { t } from "@/lib/warehouse/i18n";
import { entryTs, getName, matchesSearch, todayISO, typeLabel } from "@/lib/warehouse/helpers";
import { useWarehouse } from "@/lib/warehouse/state";
import type { HistoryEntry } from "@/lib/warehouse/types";
import { Thumb } from "./dashboard";

export function RegisterPanel() {
  const lang = useWarehouse((s) => s.lang);
  const inventory = useWarehouse((s) => s.inventory);
  const currentType = useWarehouse((s) => s.currentType);
  const submitting = useWarehouse((s) => s.submitting);
  const keys = Object.keys(inventory);
  const [material, setMaterial] = useState(keys[0] || "");
  const [quantity, setQuantity] = useState("");
  const [employee, setEmployee] = useState("");
  const [date, setDate] = useState(todayISO());

  useEffect(() => {
    if (!material && keys[0]) setMaterial(keys[0]);
    if (material && !inventory[material] && keys[0]) setMaterial(keys[0]);
  }, [inventory, keys, material]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const ok = await submitRegister({ material, quantity, employee, date });
    if (ok) {
      setQuantity("");
      setEmployee("");
    }
  }

  return (
    <div className="card mx-auto max-w-lg">
      <h2 className="mb-4 text-center text-lg font-bold text-navy">{t(lang, "quickReg")}</h2>
      <form className="grid gap-3" onSubmit={onSubmit}>
        <MaterialSelect value={material} onChange={setMaterial} />
        <div className="field">
          <label>{t(lang, "quantity")}</label>
          <input
            type="number"
            min={1}
            step={1}
            inputMode="numeric"
            required
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
          />
        </div>
        <div className="field">
          <label>{t(lang, "type")}</label>
          <div className="grid grid-cols-2 gap-2">
            <TypeBtn active={currentType === "out"} tone="out" onClick={() => setType("out")}>
              {t(lang, "btnOut")}
            </TypeBtn>
            <TypeBtn active={currentType === "in"} tone="in" onClick={() => setType("in")}>
              {t(lang, "btnIn")}
            </TypeBtn>
          </div>
        </div>
        <div className="field">
          <label>{t(lang, "employee")}</label>
          <input required value={employee} onChange={(e) => setEmployee(e.target.value)} />
        </div>
        <div className="field">
          <label>{t(lang, "date")}</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <button type="submit" className="primary-btn" disabled={submitting}>
          {t(lang, "btnSubmit")}
        </button>
      </form>
    </div>
  );
}

export function BorrowPanel() {
  const lang = useWarehouse((s) => s.lang);
  const inventory = useWarehouse((s) => s.inventory);
  const currentBorrowType = useWarehouse((s) => s.currentBorrowType);
  const submitting = useWarehouse((s) => s.submitting);
  const borrowHistory = useWarehouse((s) => s.borrowHistory);
  const borrowLimit = useWarehouse((s) => s.borrowLimit);
  const keys = Object.keys(inventory);
  const [material, setMaterial] = useState(keys[0] || "");
  const [quantity, setQuantity] = useState("");
  const [employee, setEmployee] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(todayISO());

  useEffect(() => {
    if (!material && keys[0]) setMaterial(keys[0]);
    if (material && !inventory[material] && keys[0]) setMaterial(keys[0]);
  }, [inventory, keys, material]);

  const shown = useMemo(
    () => [...borrowHistory].sort((a, b) => entryTs(b) - entryTs(a)).slice(0, borrowLimit),
    [borrowHistory, borrowLimit],
  );

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const ok = await submitBorrow({ material, quantity, employee, date, note });
    if (ok) {
      setQuantity("");
      setEmployee("");
      setNote("");
    }
  }

  return (
    <>
      <div className="card mx-auto max-w-lg">
        <h2 className="mb-4 text-center text-lg font-bold text-navy">{t(lang, "borrowTitle")}</h2>
        <form className="grid gap-3" onSubmit={onSubmit}>
          <MaterialSelect value={material} onChange={setMaterial} />
          <div className="field">
            <label>{t(lang, "borrowType")}</label>
            <div className="grid grid-cols-2 gap-2">
              <TypeBtn active={currentBorrowType === "borrow"} tone="borrow" onClick={() => setBorrowType("borrow")}>
                {t(lang, "btnBorrow")}
              </TypeBtn>
              <TypeBtn active={currentBorrowType === "return"} tone="return" onClick={() => setBorrowType("return")}>
                {t(lang, "btnReturn")}
              </TypeBtn>
            </div>
          </div>
          <div className="field">
            <label>{t(lang, "quantity")}</label>
            <input
              type="number"
              min={1}
              step={1}
              inputMode="numeric"
              required
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
            />
          </div>
          <div className="field">
            <label>{t(lang, "employee")}</label>
            <input required value={employee} onChange={(e) => setEmployee(e.target.value)} />
          </div>
          <div className="field">
            <label>{t(lang, "borrowNote")}</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
          <div className="field">
            <label>{t(lang, "date")}</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <button type="submit" className="primary-btn" disabled={submitting}>
            {t(lang, currentBorrowType === "borrow" ? "btnBorrowSubmit" : "btnReturnSubmit")}
          </button>
        </form>
      </div>
      <div className="card">
        <h2 className="mb-3 text-lg font-bold text-navy">{t(lang, "borrowHistory")}</h2>
        {shown.length === 0 ? (
          <p className="py-6 text-center text-muted">{t(lang, "noBorrowHistory")}</p>
        ) : (
          <HistoryList items={shown} />
        )}
        {borrowHistory.length > shown.length ? (
          <button type="button" className="primary-btn" onClick={loadMoreBorrow}>
            {t(lang, "loadMore")} ({shown.length} {t(lang, "of")} {borrowHistory.length})
          </button>
        ) : null}
      </div>
    </>
  );
}

export function HistoryPanel() {
  const lang = useWarehouse((s) => s.lang);
  const history = useWarehouse((s) => s.history);
  const historyLimit = useWarehouse((s) => s.historyLimit);

  const stats = useMemo(() => {
    const map: Record<string, { out: number; in: number }> = {};
    for (const entry of history) {
      const name = entry.employee || "-";
      if (!map[name]) map[name] = { out: 0, in: 0 };
      if (entry.type === "out") map[name].out += 1;
      else if (entry.type === "in") map[name].in += 1;
    }
    return Object.entries(map).sort((a, b) => b[1].out + b[1].in - (a[1].out + a[1].in));
  }, [history]);

  const shown = useMemo(
    () => [...history].sort((a, b) => entryTs(b) - entryTs(a)).slice(0, historyLimit),
    [history, historyLimit],
  );

  return (
    <>
      <div className="card">
        <h2 className="mb-3 text-lg font-bold text-navy">{t(lang, "empStatsTitle")}</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-line text-center">
                <th className="p-2 text-start">{t(lang, "thEmployee")}</th>
                <th className="p-2">{t(lang, "thOutCount")}</th>
                <th className="p-2">{t(lang, "thInCount")}</th>
                <th className="p-2">{t(lang, "thTotalOps")}</th>
              </tr>
            </thead>
            <tbody>
              {stats.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-4 text-center text-muted">
                    {t(lang, "noEmpStats")}
                  </td>
                </tr>
              ) : (
                stats.map(([name, s]) => (
                  <tr key={name} className="border-b border-line">
                    <td className="p-2 text-start font-semibold">{name}</td>
                    <td className="p-2 text-center tabular-nums text-bad">{s.out}</td>
                    <td className="p-2 text-center tabular-nums text-ok">{s.in}</td>
                    <td className="p-2 text-center font-bold tabular-nums">{s.out + s.in}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      <div className="card">
        <h2 className="mb-3 text-lg font-bold text-navy">{t(lang, "historyTitle")}</h2>
        {shown.length === 0 ? (
          <p className="py-6 text-center text-muted">{t(lang, "noHistory")}</p>
        ) : (
          <HistoryList items={shown} />
        )}
        {history.length > shown.length ? (
          <button type="button" className="primary-btn" onClick={loadMoreHistory}>
            {t(lang, "loadMore")} ({shown.length} {t(lang, "of")} {history.length})
          </button>
        ) : null}
      </div>
    </>
  );
}

export function ManagePanel() {
  const lang = useWarehouse((s) => s.lang);
  const inventory = useWarehouse((s) => s.inventory);
  const search = useWarehouse((s) => s.search);
  const submitting = useWarehouse((s) => s.submitting);
  const fileRef = useRef<HTMLInputElement>(null);
  const [ar, setAr] = useState("");
  const [fr, setFr] = useState("");
  const [en, setEn] = useState("");
  const [unit, setUnit] = useState("");
  const [minQty, setMinQty] = useState("10");
  const [img, setImg] = useState("");

  const entries = Object.entries(inventory).filter(([key, item]) => matchesSearch(key, item, search));

  async function onPick(file: File | undefined) {
    if (!file) return;
    try {
      setImg(await compressImage(file));
    } catch (err) {
      showToast(String((err as Error).message), "error");
    }
  }

  async function onAdd() {
    const ok = await addMaterial({ ar, fr, en, unit, minQty, img });
    if (ok) {
      setAr("");
      setFr("");
      setEn("");
      setUnit("");
      setMinQty("10");
      setImg("");
    }
  }

  return (
    <div className="card">
      <h2 className="mb-3 text-lg font-bold text-navy">{t(lang, "manageTitle")}</h2>
      <div className="mb-4 rounded-lg border-2 border-dashed border-navy/30 bg-paper/50 p-4">
        <h3 className="mb-3 flex items-center gap-2 font-bold text-navy">
          <Plus className="size-4" /> {t(lang, "addOffice")}
        </h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="field">
            <label>{t(lang, "nameAr")}</label>
            <input value={ar} onChange={(e) => setAr(e.target.value)} />
          </div>
          <div className="field">
            <label>{t(lang, "nameFr")}</label>
            <input value={fr} onChange={(e) => setFr(e.target.value)} />
          </div>
          <div className="field">
            <label>{t(lang, "nameEn")}</label>
            <input value={en} onChange={(e) => setEn(e.target.value)} />
          </div>
          <div className="field">
            <label>{t(lang, "unit")}</label>
            <input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="قطعة" />
          </div>
          <div className="field">
            <label>{t(lang, "minQty")}</label>
            <input type="number" min={1} value={minQty} onChange={(e) => setMinQty(e.target.value)} />
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <label className="chip !bg-navy !text-paper">
            <ImagePlus className="size-3.5" /> {t(lang, "chooseImg")}
            <input type="file" accept="image/*" className="hidden" onChange={(e) => void onPick(e.target.files?.[0])} />
          </label>
          <label className="chip !bg-navy-deep !text-paper">
            <Camera className="size-3.5" /> {t(lang, "captureImg")}
            <input
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(e) => void onPick(e.target.files?.[0])}
            />
          </label>
          {img ? <img src={img} alt="" className="size-16 rounded-md border border-line object-cover" /> : null}
        </div>
        <p className="mt-2 text-xs text-muted">{t(lang, "imagesHint")}</p>
        <button type="button" className="primary-btn max-w-xs" disabled={submitting} onClick={() => void onAdd()}>
          {t(lang, "btnAdd")}
        </button>
      </div>

      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-bold text-navy">{t(lang, "listOffice")}</h3>
        <div className="flex gap-2">
          <button
            type="button"
            className="inline-flex items-center gap-1 rounded-md bg-navy px-3 py-1.5 text-xs text-paper"
            onClick={() => void exportExcel()}
          >
            <FileSpreadsheet className="size-3.5" /> {t(lang, "exportExcel")}
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-1 rounded-md bg-navy px-3 py-1.5 text-xs text-paper"
            onClick={() => fileRef.current?.click()}
          >
            <FileSpreadsheet className="size-3.5" /> {t(lang, "importExcel")}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void importExcelFile(file);
              e.target.value = "";
            }}
          />
        </div>
      </div>

      <div className="grid gap-2">
        {entries.map(([key, item]) => (
          <div
            key={key}
            className="grid grid-cols-[40px_1fr_auto] items-center gap-2 rounded-md border border-line bg-paper/40 p-2 sm:grid-cols-[48px_1fr_1fr_80px_auto]"
          >
            <Thumb src={item.img} />
            <div className="min-w-0">
              <div className="truncate text-sm font-bold">{item.ar || key}</div>
              <div className="truncate text-xs text-muted">
                {item.fr} · {item.en}
              </div>
            </div>
            <div className="hidden text-xs text-muted sm:block">{item.unit}</div>
            <div className="hidden text-xs tabular-nums sm:block">
              {item.qty} / {t(lang, "minQty")} {item.minQty}
            </div>
            <div className="flex gap-1">
              <button
                type="button"
                className="rounded-md bg-navy px-2 py-1 text-xs text-paper"
                onClick={() => openEdit(key)}
                aria-label={t(lang, "btnEdit")}
              >
                <Pencil className="size-3.5" />
              </button>
              <button
                type="button"
                className="rounded-md bg-bad px-2 py-1 text-xs text-white"
                onClick={() => void deleteMaterial(key)}
                aria-label={t(lang, "btnDelete")}
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MaterialSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const lang = useWarehouse((s) => s.lang);
  const inventory = useWarehouse((s) => s.inventory);
  return (
    <div className="field">
      <label>{t(lang, "material")}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)} required>
        {Object.entries(inventory).map(([key, item]) => (
          <option key={key} value={key}>
            {getName(item, key, lang)}
          </option>
        ))}
      </select>
    </div>
  );
}

function TypeBtn({
  active,
  tone,
  onClick,
  children,
}: {
  active: boolean;
  tone: "in" | "out" | "borrow" | "return";
  onClick: () => void;
  children: ReactNode;
}) {
  const activeClass =
    tone === "out"
      ? "border-bad bg-paper text-bad"
      : tone === "in"
        ? "border-ok bg-paper text-ok"
        : tone === "borrow"
          ? "border-warn bg-paper text-warn"
          : "border-cyan bg-paper text-cyan-dark";
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-md border-2 px-3 py-2 text-sm ${active ? `${activeClass} font-bold` : "border-line bg-white text-ink"}`}
    >
      {children}
    </button>
  );
}

function HistoryList({ items }: { items: HistoryEntry[] }) {
  const lang = useWarehouse((s) => s.lang);
  const inventory = useWarehouse((s) => s.inventory);
  return (
    <div className="grid max-h-[420px] gap-2 overflow-y-auto">
      {items.map((entry) => {
        const tone =
          entry.type === "in"
            ? "border-s-ok bg-paper"
            : entry.type === "borrow"
              ? "border-s-warn bg-paper"
              : entry.type === "return"
                ? "border-s-cyan bg-paper"
                : "border-s-bad bg-paper";
        const item = inventory[entry.material];
        const name = item ? getName(item, entry.material, lang) : entry.material;
        const color =
          entry.type === "in"
            ? "var(--color-ok)"
            : entry.type === "borrow"
              ? "var(--color-warn)"
              : entry.type === "return"
                ? "var(--color-cyan)"
                : "var(--color-bad)";
        return (
          <div key={entry.id} className={`grid grid-cols-2 gap-2 rounded-md border-s-4 p-3 text-sm ${tone}`}>
            <div>
              <div className="text-[10px] font-bold text-cyan-dark">Office</div>
              <div className="font-bold">{name}</div>
              <div className="text-xs text-muted">
                {entry.employee}
                {entry.note ? ` · ${entry.note}` : ""}
              </div>
            </div>
            <div className="text-end">
              <div className="font-bold" style={{ color }}>
                {entry.qty > 0 && (entry.type === "in" || entry.type === "out") ? "+" : ""}
                {entry.qty} {typeLabel(entry.type, lang)}
              </div>
              <div className="text-xs text-muted">{entry.date}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
